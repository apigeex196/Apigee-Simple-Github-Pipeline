#!/usr/bin/env bash
set -e

if [ -z "$1" ]; then
  echo "Usage: $0 <SYSGEN_CODE>"
  echo "Example: $0 123456789"
  exit 1
fi

SYSGEN_CODE="$1"
MAL_DIR="mal/mal-${SYSGEN_CODE}"

if [ -d "$MAL_DIR" ]; then
  echo "MAL folder ${MAL_DIR} already exists."
  exit 1
fi

echo "Creating MAL folder at ${MAL_DIR}..."

mkdir -p "${MAL_DIR}/proxies"
mkdir -p "${MAL_DIR}/products"
mkdir -p "${MAL_DIR}/kvms"

cat > "${MAL_DIR}/README.md" <<EOF
# MAL ${SYSGEN_CODE}

This folder contains application-owned configuration for MAL ${SYSGEN_CODE}.

Structure:
- proxies/  – proxy configuration
- products/ – API products
- kvms/     – KVM definitions (optional)

Update this file with details specific to your application.
EOF

cat > "${MAL_DIR}/CODEOWNERS" <<EOF
# Owners for MAL ${SYSGEN_CODE}
/mal/mal-${SYSGEN_CODE}/ @REPLACE_WITH_TEAM
EOF

echo "MAL folder created. Please update CODEOWNERS with the correct GitHub team."
