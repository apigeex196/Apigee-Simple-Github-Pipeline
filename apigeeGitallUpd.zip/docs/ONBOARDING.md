# Onboarding a New MAL Folder

Each MAL folder represents one application team and maps to a single
Apigee organization. This guide describes how to add a new MAL folder
and structure proxies, products, and (optionally) KVM configuration.

---

## Prerequisites

Before creating a MAL folder, ensure the following:

1. You have a valid MAL code, for example: `SYSGEN123456789`.
2. Your GitHub team has been identified as the owner for this MAL.
3. A service account and corresponding secret in **GCP Secret Manager**
   will be (or has been) provisioned for your MAL by the
   API Enablement / DevSecOps teams.

Service account secrets are not stored in this repository. They follow a
standard naming convention in Secret Manager:

- `sa-apigees-<mal-code>-<org>-<env>`

Example:

- `sa-apigees-123456789-gcp-prj-apigee-dev-np-01-apicc-dev`

The GitHub workflows use a shared `get-service-account` composite action
to retrieve the key at runtime.

---

## Step 1 – Create the MAL Folder

Create a new folder at the repository root following this pattern:

```text
mal-SYSGEN123456789/
```

Inside it, create a `CODEOWNERS` file and set your team as the owner:

```text
/mal-SYSGEN123456789/ @your-github-team
```

Optionally, add a `README.md` in the MAL folder with team-specific
details, contacts, and notes.

---

## Step 2 – Add Proxy Configuration

Under your MAL folder, create a `proxies/` directory and a folder for
each proxy you own. Use the SYSGEN-style naming convention for proxies,
for example:

```text
mal-SYSGEN123456789/
  proxies/
    SYSGEN123456789-my-api/
```

Inside each proxy folder, create folders for each environment:

```text
mal-SYSGEN123456789/
  proxies/
    SYSGEN123456789-my-api/
      dev/
        base.yaml
      test/
        base.yaml
      prod/
        base.yaml
```

Notes:

- This repository does **not** use the older `base + overlays` pattern.
- Each environment (`dev`, `test`, `prod`) has its own configuration
  directory and file(s).
- The reusable deploy workflows use environment inputs (for example
  `APIGEE_ENV`) to determine which environment configuration to apply.

---

## Step 3 – Add Product Configuration

Create a `products/` folder under your MAL directory and add one or
more product YAML files:

```text
mal-SYSGEN123456789/
  products/
    SYSGEN123456789-my-product.yaml
```

Products are still organization-level resources in Apigee, but are
grouped per MAL in this repository so that teams can manage their own
product definitions alongside their proxies.

---

## Step 4 – (Optional) Add KVM Configuration

If your MAL requires KeyValueMaps, use the `kvms/` folder as the
designated location for KVM definitions:

```text
mal-SYSGEN123456789/
  kvms/
    my-kvm.yaml
```

The exact schema and structure should follow the KVM pattern used in
the enterprise Apigee GitOps repository. This template only introduces
the folder as a placeholder so teams have a consistent home for KVMs.

---

## Step 5 – Open a Pull Request

Once your MAL folder, proxies, products, and any KVMs are in place:

1. Commit your changes.
2. Open a Pull Request targeting the main branch.
3. The validation workflow will run automatically on the PR:
   - It checks MAL folder structure.
   - It validates proxy and product configuration where applicable.
4. Address any validation errors reported by the workflow.

After the PR is reviewed and merged:

- The deploy workflows will detect which MAL folders changed.
- Only the modified MALs (and their proxies/products/KVMs) will be
  targeted for deployment.

---

## What This Onboarding Guide Does Not Cover

This guide intentionally does **not** define:

- The detailed process for requesting service accounts.
- The exact KVM schema and advanced usage patterns.
- Detailed proxy or product schema fields.

Those topics are covered in the broader Apigee GitOps documentation and
by the API Enablement team. This document focuses on the repository
layout and basic steps to get a MAL folder ready for use with the
shared workflows.
