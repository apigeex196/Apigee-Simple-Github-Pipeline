# CODEOWNERS Guide

This repository uses CODEOWNERS to control which teams own which folders.

## Root CODEOWNERS

The root `.github/CODEOWNERS` file is used to declare:

- Ownership of repository plumbing such as `.github/`, `docs/`, `scripts/`, `orgs/`.
- Optional aggregated ownership entries for MAL folders.

## MAL-level CODEOWNERS

Each MAL folder under `mal-SYSGEN/` has its own `CODEOWNERS` file, for example:

- `mal-SYSGEN123456789/CODEOWNERS`

This file should list the GitHub team(s) that own that MAL:

```
mal-SYSGEN123456789/ @REPLACE_WITH_TEAM
```

In a complete implementation, automation can read all MAL-level CODEOWNERS files and regenerate the root `.github/CODEOWNERS`.
