# Application MAL Repository Template

This repository contains the Apigee API proxy, product, and KVM configuration
skeleton for a single MAL (Managed API Layer). Each MAL folder is owned by
an application team and maps to a single Apigee organization.

This repository is **not** the platform GitOps repository. Platform-owned
shared infrastructure (SharedFlows, utility proxies, reusable bundles, etc.)
continues to live in the enterprise Apigee GitOps repo. This application
repository is focused on producer-owned configuration only.

---

## MAL Folder Layout

Each MAL lives under its own `mal-<SYSGEN_CODE>/` folder. A minimal example:

```text
mal-SYSGEN123456789/
│
├── CODEOWNERS
├── README.md
│
├── proxies/
│   └── SYSGEN123456789-my-api/
│       ├── dev/
│       │   └── base.yaml
│       ├── test/
│       │   └── base.yaml
│       └── prod/
│           └── base.yaml
│
├── products/
│   └── SYSGEN123456789-my-product.yaml
│
└── kvms/
    └── (reserved for KVM configuration)
```

### Proxies

- All MAL proxies are defined under `mal-<SYSGEN_CODE>/proxies/`.
- Each proxy has its own folder named using the SYSGEN-style convention,
  for example: `SYSGEN123456789-my-api`.
- Environment-specific configuration for that proxy lives in the
  `dev/`, `test`, and `prod/` subfolders.

This model avoids the older `base + overlays` pattern. Instead of
`base.yaml` plus overlays, each environment has its own configuration
file inside the appropriate folder (for example `dev/base.yaml`).

### Products

- API products for the MAL live under `mal-<SYSGEN_CODE>/products/`.
- Product files use the same SYSGEN-style ID in the name, for example:
  `SYSGEN123456789-my-product.yaml`.

Products are still organization-level in Apigee, but are grouped per MAL
in this repository so that each team can manage their own product
definitions alongside their proxies.

### KVMs

The `kvms/` folder is reserved for KeyValueMap configuration associated
with the MAL. The exact file format and schema will follow the KVM pattern
used in the enterprise Apigee GitOps repository and can be finalized with
the API Enablement team.

For now, this directory exists as a clear, consistent placeholder so that
KVM configuration has a well-defined home once teams are ready to add it.

---

## Service Accounts & Secrets

Deployments for each MAL use a dedicated GCP service account per
organization and environment. Service account keys are **not** stored in
this repository.

- Keys are stored in **GCP Secret Manager** using a standard naming
  convention: `sa-apigees-<mal-code>-<org>-<env>`
- Example: `sa-apigees-123456789-gcp-prj-apigee-dev-np-01-apicc-dev`
- GitHub workflows retrieve the key at runtime via a shared
  `get-service-account` composite action.

The process for requesting and provisioning service accounts is managed
centrally by the API Enablement / DevSecOps teams and documented outside
of this template.

---

## Workflows & Deployments

This repository is designed to work with reusable GitHub Actions
workflows that:

- Validate configuration on pull requests.
- Detect which MAL folders have changed.
- Deploy only the proxies/products/KVMs that changed.
- Target the correct organization and environment based on workflow
  inputs (for example: `APIGEE_ORG`, `APIGEE_ENV`).

The reusable workflows live under `.github/workflows/` and are managed by
the platform team. Application teams generally:
- Add or modify configuration under their `mal-<SYSGEN-CODE>/` folder(s).
- Rely on the shared workflows for validation and deployment.

---

## What This Repository Does *Not* Contain

The following are intentionally **out of scope** for this application
repository and continue to live in the platform GitOps repository:

- SharedFlows
- Low-level XML proxy bundles
- Organization-level `orgs/` folder structure
- Top-level `envs/` or `global` folders
- `apigeeproxies` and `apigeesharedflows` folders
- `base.yaml` + `overlays/` environment pattern

Keeping these concerns separate lets the platform team manage shared
infrastructure while application teams own their MAL-specific
configuration here.

---

## Getting Started

For details on onboarding a new MAL folder, see [`docs/ONBOARDING.md`](docs/ONBOARDING.md).
