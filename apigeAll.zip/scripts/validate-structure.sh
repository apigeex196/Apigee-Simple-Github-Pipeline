#!/usr/bin/env bash
set -e

echo "Running basic structure validation..."

if [ ! -d "mal-SYSGEN[0-9]*" ]; then
  echo "Warning: mal-SYSGEN/ directory not found."
fi

if [ ! -d ".github" ]; then
  echo "Error: .github directory not found."
  exit 1
fi

echo "Structure validation completed (template)."
