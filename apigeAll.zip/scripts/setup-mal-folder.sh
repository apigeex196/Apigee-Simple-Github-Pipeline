#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 <SYSGEN_CODE>"
  echo "Examples:"
  echo "  $0 123456789"
  echo "  $0 SYSGEN123456789"
  echo "  $0 mal-SYSGEN123456789"
  exit 1
fi

RAW="$1"
DIGITS="$(echo "$RAW" | sed -E 's/[^0-9]//g')"
if [ -z "$DIGITS" ]; then
  echo "Error: Could not parse digits from input: $RAW"
  exit 1
fi

SYSGEN_CODE="SYSGEN${DIGITS}"
MAL_DIR="mal-${SYSGEN_CODE}"  # => mal-SYSGEN123...

if [ -d "$MAL_DIR" ]; then
  echo "MAL folder ${MAL_DIR} already exists."
  exit 1
fi

echo "Creating MAL folder at ${MAL_DIR}..."
mkdir -p "${MAL_DIR}/proxies" "${MAL_DIR}/products" "${MAL_DIR}/kvms"

cat > "${MAL_DIR}/README.md" <<EOF
# MAL ${SYSGEN_CODE}

This folder contains application-owned configuration for MAL ${SYSGEN_CODE}.

Structure:
- proxies/  – proxy configuration
- products/ – API products
- kvms/     – KVM definitions (optional)

After creating/updating MAL CODEOWNERS, run:
  ./scripts/generate-codeowners.sh
and commit the updated .github/CODEOWNERS
EOF

cat > "${MAL_DIR}/CODEOWNERS" <<EOF
# CODEOWNERS for MAL ${SYSGEN_CODE}
/${MAL_DIR}/ @REPLACE_WITH_TEAM
EOF

# Minimal sample product file
cat > "${MAL_DIR}/products/${SYSGEN_CODE}-my-product.yaml" <<EOF
name: ${SYSGEN_CODE}-my-product
displayName: "${SYSGEN_CODE} My Product"
description: "Template product for ${SYSGEN_CODE}"
EOF

echo "✅ MAL folder created: ${MAL_DIR}"
echo "Next:"
echo "  1) Replace @REPLACE_WITH_TEAM in ${MAL_DIR}/CODEOWNERS"
echo "  2) Run: ./scripts/generate-codeowners.sh"
echo "  3) Commit updated .github/CODEOWNERS"
