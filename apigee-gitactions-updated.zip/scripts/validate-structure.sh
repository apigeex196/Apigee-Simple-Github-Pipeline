#!/usr/bin/env bash
set -e

echo "Running basic structure validation..."

# Check for at least one MAL folder
MAL_COUNT=$(ls -d mal-* 2>/dev/null | wc -l | tr -d ' ')
if [ "$MAL_COUNT" = "0" ]; then
  echo "Warning: no mal-<MAL_CODE> folders found at the repository root."
fi

if [ ! -d ".github" ]; then
  echo "Error: .github directory not found."
  exit 1
fi

echo "Structure validation completed (template)."
