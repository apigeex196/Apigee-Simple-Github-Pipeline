# Deployment Guide

This document explains how deployments are handled for application APIs in this repository.

## High-level flow

1. Developers make changes under their MAL folder.
2. They open a pull request to `main`.
3. Validation workflows run on the PR.
4. After approval and merge, environment-specific workflows run on `main` and deploy to the configured Apigee org and environment.

## Workflows

The following workflows live under `.github/workflows`:

- `validate-mal-structure.yml`
  - Runs on pull requests and performs basic structural checks.
- `deploy-to-dev.yml`, `deploy-to-test.yml`, `deploy-to-prod.yml`
  - Triggered on pushes to `main`. Each workflow is parameterized with an Apigee org and environment.

## Composite actions

The template includes composite actions under `.github/actions`:

- `get-service-account`
- `validate-proxy`
- `deploy-proxy`
- `validate-product`
- `deploy-product`
- `manage-kvms`

In this template, these actions only contain placeholder logic (they echo what they would do). In a production setup, these actions can be wired to Apigee tooling and GCP Secret Manager.
