# Onboarding an application (MAL)

This document describes how an API producer team onboards their application into this repository.

## Prerequisites

- A valid MAL code for the application (for example `1234567`).
- A GitHub team that will own the MAL folder.
- At least one API proxy and product identified.

## Steps

1. Create the MAL folder

   - Copy the sample MAL folder `mal-1234567`, or
   - Run the `scripts/setup-mal-folder.sh` script once it is available.

   This will create a structure similar to:

   - `mal-1234567/README.md`
   - `mal-1234567/CODEOWNERS`
   - `mal-1234567/proxies/`
   - `mal-1234567/products/`

2. Configure CODEOWNERS for the MAL

   - Edit `mal-1234567/CODEOWNERS` and add your GitHub team(s).

3. Add proxy configuration

   - Under `mal-<MAL_CODE>/proxies/`, create a folder per proxy using its SYSENG ID.
   - Inside each proxy folder, create `dev/base.yaml`, `test/base.yaml` and `prod/base.yaml`.
   - Each `base.yaml` file contains the configuration for that environment.

4. Add product configuration

   - Under `mal-<MAL_CODE>/products/`, define one or more products in YAML format.
   - Reference the proxies defined in the previous step.

5. Open a pull request

   - Push your changes and open a PR against `main`.
   - Validation workflows will run automatically and report status.

6. Deploy

   - After approval and merge, the environment-specific deploy workflows will take care of rolling out changes.
   - In this template, the workflows are placeholders; the API Enablement team can extend them with real deployment logic.

If you have questions or need help onboarding, contact the API Enablement team through the standard channels.
