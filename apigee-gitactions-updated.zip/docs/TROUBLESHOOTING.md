# Troubleshooting

This file provides high-level troubleshooting notes for the template.

## Validation workflow fails

- Check the GitHub Actions logs for the validation job.
- Ensure that your changes are under a `mal-<MAL_CODE>/` folder and that the basic folder structure exists.

## Deploy workflows do nothing

- In this template, the deploy workflows only echo what they would do.
- The API Enablement team can extend these workflows with real deployment logic.
