# CODEOWNERS Guide

This repository uses CODEOWNERS to control which teams own which folders.

## Root CODEOWNERS

The root `.github/CODEOWNERS` file is used to declare:

- Ownership of repository plumbing such as `.github/`, `docs/`, `scripts/`.
- Optional aggregated ownership entries for MAL folders.

## MAL-level CODEOWNERS

Each MAL folder at the root has its own `CODEOWNERS` file, for example:

- `mal-1234567/CODEOWNERS`

This file should list the GitHub team(s) that own that MAL:

```
/mal-1234567/ @REPLACE_WITH_TEAM
```
