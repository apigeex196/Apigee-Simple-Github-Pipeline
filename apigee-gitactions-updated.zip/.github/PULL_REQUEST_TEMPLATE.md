## Summary

Describe the changes in this pull request.

## MALs Affected

List the MAL codes and proxies affected by this change.

## Checks

- [ ] Updated proxy YAML
- [ ] Updated product YAML (if applicable)
- [ ] CI workflows are passing
