# MAL 1234567 – Sample Application

This is a sample MAL folder used as a template for application teams.

## Structure

- `proxies/` – proxy configuration for this application
- `products/` – API product definitions
- `kvms/` – KVM declarations if needed
- `CODEOWNERS` – GitHub ownership for this MAL

Replace this text with information specific to your application when you copy this folder.
