# enterprise-apigees-applications

This repository is the application GitOps template for Apigee X.

Platform-level shared assets (SharedFlows, utility proxies, common bundles, platform workflows) remain in the `enterprise-apigees-gitops` repository.
This repo is for application (MAL) owned APIs: proxy configs, products, KVMs and related CI.

## Repository layout

- `mal/` – folders for each MAL (application), for example `mal-1234567/`
- `orgs/` – organization and environment configuration (per GCP project / Apigee org)
- `.github/` – GitHub Actions workflows and composite actions
- `docs/` – onboarding and usage documentation
- `scripts/` – helper scripts for maintaining the repo

## Adding a new MAL

1. Obtain a MAL code (for example `1234567`).
2. Run `scripts/setup-mal-folder.sh <MAL_CODE>` or copy the sample MAL folder.
3. Update `mal/mal-<MAL_CODE>/README.md` with your application details.
4. Add your proxy configuration under `mal/mal-<MAL_CODE>/proxies/`.
5. Add or update products under `mal/mal-<MAL_CODE>/products/`.
6. Open a pull request; the validation workflows will run automatically.

## Deployments

Deployments are handled by GitHub Actions.

- Validation workflows run on pull requests.
- Environment deploy workflows (Dev / Test / Prod) run on changes merged to `main`.
- Only MALs that have changed are targeted by deployments (future optimization; current template just echoes).

See `docs/DEPLOYMENT-GUIDE.md` for more details.

## Ownership

- The API Enablement team owns repository plumbing (`.github`, `docs`, `scripts`, `orgs`).
- Each MAL folder (`mal/mal-XXXXXXX`) is owned by the corresponding application team via CODEOWNERS.

See `docs/CODEOWNERS-GUIDE.md` for details.
