# Vendored Apigee Tools

This directory contains cached copies of Apigee tooling binaries to ensure workflow reliability and reduce dependency on external downloads.

## Contents

- **apigee-go-gen_v1.1.1_Linux_x86_64.tar.gz** (6.0 MB)
  - Version: v1.1.1
  - Released: November 14, 2025
  - Source: https://github.com/apigee/apigee-go-gen/releases/tag/v1.1.1
  - SHA256: Run `sha256sum apigee-go-gen_v1.1.1_Linux_x86_64.tar.gz` to verify

- **apigeecli_v2.7.0_Linux_x86_64.zip** (5.4 MB)
  - Version: v2.7.0
  - Released: November 6, 2024
  - Source: https://github.com/apigee/apigeecli/releases/tag/v2.7.0
  - SHA256: Run `sha256sum apigeecli_v2.7.0_Linux_x86_64.zip` to verify

## Usage

The `setup-apigee-tooling` action checks this directory first before attempting external downloads:

1. **Local First**: If vendored binary exists, use it
2. **Download Fallback**: If not found, download from GitHub releases with retry logic

## Updating Tools

When new versions are released:

```bash
cd .github/tools

# Download new apigee-go-gen version
curl -L -o apigee-go-gen_vX.Y.Z_Linux_x86_64.tar.gz \
  "https://github.com/apigee/apigee-go-gen/releases/download/vX.Y.Z/apigee-go-gen_Linux_x86_64.tar.gz"

# Download new apigeecli version
curl -L -o apigeecli_vX.Y.Z_Linux_x86_64.zip \
  "https://github.com/apigee/apigeecli/releases/download/vX.Y.Z/apigeecli_vX.Y.Z_Linux_x86_64.zip"

# Update the setup-apigee-tooling action.yml default versions
# Commit and push
```

## Why Vendor?

**Reliability**: External downloads can fail due to:
- Network connectivity issues
- GitHub release CDN problems (experienced Dec 11, 2025)
- Azure Blob Storage timeouts
- Truncated downloads

**Benefits**:
- ✅ No external dependency during CI/CD
- ✅ Consistent tool versions across runs
- ✅ Faster workflow execution (no download time)
- ✅ Works even if GitHub releases are unavailable
- ✅ Eliminates intermittent network failures

## Fallback Strategy

Even with vendored tools, the action maintains download capability as fallback:
- Uses wget with retry logic (3 attempts)
- Validates file size before extraction
- Clear error messages if both methods fail
