# Validate Product Action

Validates API Product YAML files against the JSON schema and enforces business rules.

## Usage

```yaml
- name: Validate API Product
  id: validate-product
  uses: ./.github/actions/validate-product
  with:
    product_file: mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
    mal_folder: mal-SYSGEN123456789  # Optional: enables proxy reference validation
```

## Inputs

| Input | Required | Default | Description |
|-------|----------|---------|-------------|
| `product_file` | Yes | - | Path to the product YAML file to validate |
| `mal_folder` | No | `''` | Path to MAL folder for proxy reference validation |

## Outputs

| Output | Description |
|--------|-------------|
| `is_valid` | `true` if validation passed, `false` otherwise |
| `product_name` | Extracted product name from metadata.name |
| `errors` | Validation error messages (empty if valid) |

## Validation Rules

### Schema Validation
- ✅ Validates against `apiproduct.schema.json`
- ✅ Checks YAML syntax
- ✅ Validates required fields exist

### Required Fields
- `apiVersion`: Must be present
- `kind`: Must be "ApiProduct"
- `metadata.name`: Product name (follows SYSGEN pattern)
- `metadata.description`: Human-readable description
- `metadata.owner`: Contact email for product owner
- `metadata.sysgen`: SYSGEN/MAL ID
- `metadata.approvedBySRB`: Boolean (true/false)
- `spec.approval`: "auto" or "manual"
- `spec.access`: "public" or "internal"
- `spec.proxies`: Array of proxy references (at least one)

### Naming Convention
- Product names should follow pattern: `SYSGEN<9-digits>-<name>`
- Example: `SYSGEN123456789-my-product`
- Warning (not error) if pattern not followed

### Proxy References
- Each proxy must have a `name` field
- If `mal_folder` provided, validates proxy directories exist
- Validates `operations` array if present:
  - Each operation must have a `path` starting with `/`
  - Optional `methods` array (GET, POST, PUT, DELETE, etc.)

### Quota Configuration (Optional)
If quota is defined, validates:
- `limit`: Positive integer
- `interval`: Positive integer
- `timeUnit`: One of: minute, hour, day, month

### OAuth Scopes (Optional)
- Validates scopes array if present
- Each scope is a string

## Examples

### Valid Product

```yaml
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProduct
metadata:
  name: SYSGEN123456789-my-product
  description: "My API Product"
  owner: team@lumen.com
  sysgen: "SYSGEN123456789"
  approvedBySRB: true
spec:
  approval: auto
  access: internal
  environments:
    - apicc-dev1
    - apicc-test1
  proxies:
    - name: SYSGEN123456789-my-api
      operations:
        - path: /api/v1/users
          methods:
            - GET
            - POST
        - path: /api/v1/users/{id}
          methods:
            - GET
            - PUT
            - DELETE
  quota:
    limit: 10000
    interval: 1
    timeUnit: hour
  scopes:
    - read
    - write
```

### Invalid Product (Missing Required Fields)

```yaml
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProduct
metadata:
  name: my-product  # Missing SYSGEN prefix (warning)
  # Missing: description, owner, sysgen, approvedBySRB (errors)
spec:
  approval: auto
  # Missing: access, proxies (errors)
```

## Common Errors

### Missing Required Fields
```
Product owner is required in metadata.owner
Product description is required in metadata.description
SYSGEN ID is required in metadata.sysgen
approvedBySRB is required in metadata.approvedBySRB
```

### Invalid Values
```
Approval type must be 'auto' or 'manual'
Access level must be 'public' or 'internal'
At least one proxy is required in spec.proxies
```

### Quota Validation
```
Quota interval is required when quota is defined
Quota timeUnit must be one of: minute, hour, day, month
```

### Proxy References
```
Proxy 'my-api' referenced in product but not found in mal-SYSGEN123456789/proxies/my-api
Operation path must start with /: api/v1/test
```

## Complete Workflow Example

```yaml
name: Validate Product Changes

on:
  pull_request:
    paths:
      - 'mal-*/products/*.yaml'

permissions:
  contents: read

jobs:
  validate-products:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Setup Apigee tooling
        uses: ./.github/actions/setup-apigee-tooling

      - name: Get changed product files
        id: changed-files
        uses: ./.github/actions/changed-files

      - name: Validate each product
        run: |
          CHANGED_FILES="${{ steps.changed-files.outputs.changed_files }}"

          for file in $CHANGED_FILES; do
            if [[ "$file" =~ ^(mal-SYSGEN[0-9]{9})/products/.*\.yaml$ ]]; then
              MAL_FOLDER="${BASH_REMATCH[1]}"

              echo "Validating product: $file"

              # Run validation
              if ! ./.github/actions/validate-product \
                --product_file "$file" \
                --mal_folder "$MAL_FOLDER"; then
                echo "❌ Validation failed for $file"
                exit 1
              fi

              echo "✅ Validated: $file"
            fi
          done
```

## Integration with MAL Structure

When provided with `mal_folder`, the action:
1. Extracts MAL code from product name
2. Verifies MAL code matches the folder
3. Checks that referenced proxies exist in `{mal_folder}/proxies/`

Example:
```yaml
- uses: ./.github/actions/validate-product
  with:
    product_file: mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
    mal_folder: mal-SYSGEN123456789
```

Will validate that:
- Product name starts with `SYSGEN123456789-`
- Referenced proxy `SYSGEN123456789-my-api` exists in `mal-SYSGEN123456789/proxies/SYSGEN123456789-my-api/`

## Testing

Run the test workflow:
```bash
gh workflow run test-validate-product.yml
```

Or test locally:
```bash
# Valid product
yq eval -o=json mal-SYSGEN123456789/products/SYSGEN123456789-test-product.yaml | \
  ajv validate -s apiproduct.schema.json -d -

# Check specific field
yq eval '.metadata.name' mal-SYSGEN123456789/products/SYSGEN123456789-test-product.yaml
```

## Related Actions

- **setup-apigee-tooling**: Installs required tools (yq, ajv-cli)
- **validate-mal-structure**: Validates overall MAL folder structure
- **changed-files**: Detects changed product files in PRs
