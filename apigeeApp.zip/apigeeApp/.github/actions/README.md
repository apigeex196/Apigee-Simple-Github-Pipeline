# Composite Actions

This directory contains reusable composite actions for the API producer CI/CD workflows.

## Available Actions

### 1. changed-files

**Purpose**: Detect which MAL folders changed in a PR or push.

**Usage**:
```yaml
- name: Detect changed files
  id: changed-files
  uses: ./.github/actions/changed-files
  with:
    changed_files: ${{ inputs.changed_files }}  # Optional manual override
```

**Outputs**:
- `changed_files`: Space-separated list of changed files in `mal-SYSGEN*` folders
- `deleted_files`: Space-separated list of deleted files in `mal-SYSGEN*` folders
- `has_changes`: `true` if any MAL folders have changes, `false` otherwise

**Features**:
- ✅ Automatically detects PR context (compares against `base_ref`)
- ✅ Automatically detects push context (compares against `before` commit)
- ✅ Filters to only `mal-SYSGEN[0-9]{9}/` pattern
- ✅ Supports manual override for testing
- ✅ Sets both outputs AND environment variables

**Example**:
```yaml
- uses: ./.github/actions/changed-files
- name: Process if changes detected
  if: steps.changed-files.outputs.has_changes == 'true'
  run: |
    echo "Changed: ${{ steps.changed-files.outputs.changed_files }}"
    echo "Deleted: ${{ steps.changed-files.outputs.deleted_files }}"
```

---

### 2. extract-mal-metadata

**Purpose**: Extract MAL codes and determine target org/env from changed file paths.

**Usage**:
```yaml
- name: Extract MAL metadata
  id: mal-metadata
  uses: ./.github/actions/extract-mal-metadata
  with:
    changed_files: ${{ steps.changed-files.outputs.changed_files }}
    target_org: gcp-prj-apigee-dev-np-01
    target_env: apicc-dev
```

**Inputs**:
- `changed_files` (required): Space-separated list of changed files
- `target_org` (required): Target Apigee organization
- `target_env` (required): Target Apigee environment

**Outputs**:
- `mal_codes`: Space-separated list of unique MAL codes (e.g., `"123456789 987654321"`)
- `mal_folders`: Space-separated list of unique MAL folders (e.g., `"mal-SYSGEN123456789 mal-SYSGEN987654321"`)
- `apigee_org`: Target org normalized to lowercase
- `apigee_org_upper`: Target org in uppercase with underscores (for secret lookups)
- `apigee_env`: Target environment normalized to lowercase

**Features**:
- ✅ Extracts numeric MAL codes from folder names
- ✅ Handles multiple MALs changed in same PR
- ✅ Normalizes org/env names for consistency
- ✅ Creates secret name format: `SA_APIGEES_{MAL_CODE}_{ORG_UPPER}_{ENV_UPPER}`

**Example**:
```yaml
- uses: ./.github/actions/extract-mal-metadata
  with:
    changed_files: "mal-SYSGEN123456789/proxies/api/dev/base.yaml"
    target_org: gcp-prj-apigee-dev-np-01
    target_env: apicc-dev

# Outputs:
# mal_codes: "123456789"
# mal_folders: "mal-SYSGEN123456789"
# apigee_org: "gcp-prj-apigee-dev-np-01"
# apigee_org_upper: "GCP_PRJ_APIGEE_DEV_NP_01"
# apigee_env: "apicc-dev"
```

---

### 3. download-template

**Purpose**: Download the latest template bundle from GitHub releases.

**Usage**:
```yaml
- name: Download template
  id: download-template
  uses: ./.github/actions/download-template
  with:
    template_name: jwt-oauth-proxy-ahpt-backend
    output_dir: .template-cache  # Optional, defaults to .template-cache
    github_token: ${{ secrets.GITHUB_TOKEN }}  # Optional, defaults to github.token
```

**Inputs**:
- `template_name` (required): Template name from proxy YAML config (e.g., `jwt-oauth-proxy-ahpt-backend`)
- `output_dir` (optional): Directory to extract templates (default: `.template-cache`)
- `github_token` (optional): GitHub token for API access (default: `${{ github.token }}`)

**Outputs**:
- `template_path`: Path to the extracted template directory
- `template_release`: Release tag/version that was downloaded
- `cache_hit`: `true` if template was loaded from cache, `false` if newly downloaded

**Features**:
- ✅ Loads template mappings from `template-mappings.json`
- ✅ Fetches latest release matching template name pattern
- ✅ Downloads release zip using `gh` CLI
- ✅ Extracts to cache directory structure
- ✅ Caches downloads for speed (by template name and release tag)
- ✅ Handles template not found errors gracefully
- ✅ Validates template-mappings.json exists

**Example**:
```yaml
- uses: ./.github/actions/download-template
  id: template
  with:
    template_name: jwt-oauth-proxy-ahpt-backend

- name: Use template
  run: |
    echo "Template path: ${{ steps.template.outputs.template_path }}"
    echo "Release: ${{ steps.template.outputs.template_release }}"
    echo "From cache: ${{ steps.template.outputs.cache_hit }}"
```

**Dependencies**:
- Requires `template-mappings.json` in repository root
- Requires `gh` CLI (available in GitHub-hosted runners)
- Requires `jq` for JSON parsing (available in GitHub-hosted runners)
- Requires `unzip` for extraction (available in GitHub-hosted runners)

---

## Testing

### Test Workflow

Run the test workflow to validate both actions:

```bash
# Via GitHub UI
# Go to Actions → Test Changed Files Detection → Run workflow

# Or via gh CLI
gh workflow run test-changed-files.yml
```

The test workflow:
1. Detects changed files in `mal-SYSGEN*` folders
2. Extracts MAL metadata
3. Validates output format
4. Creates summary with results

### Manual Testing

You can manually test with specific files:

```bash
gh workflow run test-changed-files.yml -f changed_files="mal-SYSGEN123456789/proxies/api/dev/base.yaml,mal-SYSGEN987654321/products/product.yaml"
```

---

## Development Guide

### Adding a New Action

1. Create directory: `.github/actions/{action-name}/`
2. Create `action.yml` with metadata and steps
3. Document inputs/outputs
4. Add test coverage in `test-changed-files.yml`
5. Update this README

### Action Structure

```yaml
---
name: 'action-name'
description: 'What it does'
inputs:
  input_name:
    description: 'Input description'
    required: true
outputs:
  output_name:
    description: 'Output description'
    value: ${{ steps.step-id.outputs.output_name }}
runs:
  using: 'composite'
  steps:
    - name: Step name
      id: step-id
      shell: bash
      run: |
        echo "output_name=value" >> $GITHUB_OUTPUT
```

### Best Practices

1. **Error Handling**: Use `set -e` at start of bash scripts
2. **Output Format**: Set both `$GITHUB_OUTPUT` and `$GITHUB_ENV`
3. **Validation**: Validate inputs and outputs
4. **Documentation**: Add clear descriptions and examples
5. **Testing**: Add test cases in workflow
6. **Logging**: Use `::notice::`, `::warning::`, `::error::` for visibility
7. **Grouping**: Use `::group::` / `::endgroup::` for better logs

---

## Dependencies

### Changed Files Action
- Requires: Git history (use `fetch-depth: 0` or appropriate depth)
- Works with: PRs and pushes
- Platform: Any runner with bash

### Extract MAL Metadata Action
- Requires: Output from changed-files action
- Dependencies: None (pure bash)
- Platform: Any runner with bash

---

## Patterns for Your Peer

These actions establish patterns your peer can follow:

### Pattern 1: Composite Action Structure
```yaml
---
name: 'descriptive-name'
description: 'Clear description'
inputs: {...}
outputs: {...}
runs:
  using: 'composite'
  steps: [...]
```

### Pattern 2: Dual Output Format
```bash
# Set for step outputs
echo "key=value" >> $GITHUB_OUTPUT

# Also set for environment (backward compatibility)
echo "KEY=value" >> $GITHUB_ENV
```

### Pattern 3: Validation
```bash
if [ -z "$REQUIRED_INPUT" ]; then
  echo "::error::Required input is missing"
  exit 1
fi
```

### Pattern 4: Summary Output
```bash
echo "## Results" >> $GITHUB_STEP_SUMMARY
echo "- Item 1" >> $GITHUB_STEP_SUMMARY
```

---

### 4. validate-mal-structure

**Purpose**: Validate MAL folder structure and naming conventions.

**Usage**:
```yaml
- name: Validate MAL structure
  id: validate-mal
  uses: ./.github/actions/validate-mal-structure
  with:
    mal_folder: mal-SYSGEN123456789
```

**Outputs**:
- `is_valid`: `true` if validation passed, `false` otherwise
- `mal_code`: Extracted MAL code from folder name (e.g., `123456789`)
- `errors`: Validation error messages (empty if valid)

**Features**:
- ✅ Validates MAL folder naming: `mal-SYSGEN<9-digit-code>`
- ✅ Validates required subfolders: `proxies/`, `products/`, `kvms/`
- ✅ Validates proxy naming: `SYSGEN<code>-<name>`
- ✅ Validates environment folders: `dev/`, `test/`, `prod/`
- ✅ Validates `base.yaml` exists in each environment
- ✅ Validates product naming: `SYSGEN<code>-<name>.yaml`
- ✅ Provides detailed error messages with file locations

**Example**:
```yaml
- uses: ./.github/actions/validate-mal-structure
  with:
    mal_folder: mal-SYSGEN123456789
- name: Check validation result
  if: steps.validate-mal.outputs.is_valid != 'true'
  run: |
    echo "Validation failed!"
    echo "${{ steps.validate-mal.outputs.errors }}"
    exit 1
```

---

### 5. validate-product

**Purpose**: Validate API Product YAML files against schema and business rules.

**Usage**:
```yaml
- name: Validate API Product
  id: validate-product
  uses: ./.github/actions/validate-product
  with:
    product_file: mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
    mal_folder: mal-SYSGEN123456789
```

**Outputs**:
- `is_valid`: `true` if validation passed, `false` otherwise
- `product_name`: Extracted product name from metadata.name
- `errors`: Validation error messages (empty if valid)

**Features**:
- ✅ Validates against `apiproduct.schema.json`
- ✅ Validates YAML syntax
- ✅ Validates required fields (name, description, owner, sysgen, approvedBySRB)
- ✅ Validates spec fields (approval, access, proxies)
- ✅ Validates product naming: `SYSGEN<9-digits>-<name>`
- ✅ Validates proxy references exist (if mal_folder provided)
- ✅ Validates quota configuration (if present)
- ✅ Validates OAuth scopes (if present)
- ✅ Validates operation paths start with `/`
- ✅ Provides detailed error messages with file locations

**Example**:
```yaml
- uses: ./.github/actions/validate-product
  with:
    product_file: mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
    mal_folder: mal-SYSGEN123456789
- name: Check validation result
  if: steps.validate-product.outputs.is_valid != 'true'
  run: |
    echo "Validation failed!"
    echo "${{ steps.validate-product.outputs.errors }}"
    exit 1
```

---

## Next Actions to Implement

Your peer can use these as templates for:

- `download-template` - Download template from GitHub releases
- `validate-proxy-yaml` - Validate YAML against schema
- `process-template-variables` - Replace variables in template
- `build-deployment-bundle` - Create deployment zip
- `get-service-account` - Retrieve SA from Secret Manager
- `deploy-proxy` - Deploy to Apigee X
- `manage-kvms` - Create/update KVMs

Each should follow the same structure and patterns established here.

---

## Example MAL Folder

See `mal-SYSGEN123456789/` for a complete example structure:
- `CODEOWNERS` - Team ownership
- `README.md` - Documentation
- `proxies/{proxy-name}/{env}/base.yaml` - Proxy configs
- `products/{product-name}.yaml` - Product configs (optional)

This can be used for testing workflows without affecting real APIs.
