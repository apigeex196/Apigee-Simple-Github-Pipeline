# Create MAL Service Account Action

This composite action creates a service account for a MAL team in a specific GCP project with the necessary Apigee permissions.

## Purpose

Automates the creation of service accounts for API Producer teams (MALs) to enable CI/CD deployments to Apigee X environments. This action is called by the `create-mal-service-accounts.yml` workflow.

## Features

- ✅ **Idempotent**: Safe to re-run, won't fail if SA already exists
- ✅ **Validation**: Checks MAL code format and environment
- ✅ **IAM Setup**: Grants `apigee.apiAdminV2` and `secretmanager.secretAccessor` roles
- ✅ **Secret Storage**: Stores SA key in Secret Manager with monitoring labels
- ✅ **Monitoring Integration**: Adds labels for automatic expiration alerts
- ✅ **Dry Run Mode**: Test without creating resources

## Inputs

| Input | Description | Required | Default |
|-------|-------------|----------|---------|
| `mal-code` | MAL code (e.g., SYSGEN788836350) | Yes | - |
| `gcp-project` | GCP project ID (e.g., gcp-prj-apigee-dev-np-01) | Yes | - |
| `apigee-org` | Apigee organization name | Yes | - |
| `environment` | Environment name (dev, qa, prod) | Yes | - |
| `dry-run` | If true, only show what would be created | No | false |

## Outputs

| Output | Description |
|--------|-------------|
| `service-account-email` | Email address of the created service account |
| `secret-name` | Name of the Secret Manager secret containing the SA key |
| `status` | Status of the operation (created, exists, failed, dry-run) |

## Usage

```yaml
- name: Create service account
  uses: ./.github/actions/create-mal-sa
  with:
    mal-code: SYSGEN788836350
    gcp-project: gcp-prj-apigee-dev-np-01
    apigee-org: gcp-prj-apigee-dev-np-01
    environment: dev
    dry-run: false
```

## What It Does

1. **Validates inputs**: Checks MAL code format and environment
2. **Checks existence**: Verifies if SA already exists
3. **Creates SA**: If needed, creates service account with descriptive name
4. **Grants IAM roles**:
   - `roles/apigee.apiAdminV2` - Deploy proxies and products
   - `roles/secretmanager.secretAccessor` - Read KVM secrets
5. **Creates key**: Generates SA key JSON
6. **Stores in Secret Manager**: Saves key with monitoring labels
7. **Verifies**: Confirms SA can be described

## Service Account Naming

- **Name**: `sa-apigeex-{MAL-CODE}`
- **Email**: `sa-apigeex-{MAL-CODE}@{project}.iam.gserviceaccount.com`
- **Example**: `sa-apigeex-SYSGEN788836350@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com`

## Secret Manager Schema

**Secret Name**: `sa-apigeex-{MAL-CODE}`

**Labels** (for monitoring integration):
```yaml
owner: "mal-sysgen788836350"          # Lowercase
alert_channel: "MAL_SYSGEN788836350"  # Uppercase
environment: "dev" | "qa" | "prod"
created_by: "github-actions"
created_date: "2026-02-04"
```

## Prerequisites

The calling workflow must:
1. Authenticate with GCP using `GCP_SA_MAL_PROVISIONING` secret
2. Have `gcloud` CLI installed and configured
3. The automation SA must have these permissions in the target project:
   - `roles/iam.serviceAccountAdmin`
   - `roles/iam.serviceAccountKeyAdmin`
   - `roles/resourcemanager.projectIamAdmin`
   - `roles/secretmanager.admin`

## Error Handling

- **Invalid MAL code**: Fails with validation error
- **Invalid environment**: Fails with validation error
- **SA already exists**: Success, verifies IAM roles
- **Permission denied**: Fails with specific permission error
- **Secret Manager error**: Retries internally, fails after 3 attempts

## Dry Run Mode

Set `dry-run: true` to see what would be created without actually creating resources:

```yaml
- uses: ./.github/actions/create-mal-sa
  with:
    mal-code: SYSGEN788836350
    gcp-project: gcp-prj-apigee-dev-np-01
    apigee-org: gcp-prj-apigee-dev-np-01
    environment: dev
    dry-run: true
```

Outputs will show what would happen, but no resources are created.

## Integration with Monitoring

Service accounts created by this action automatically integrate with the SA key expiration monitoring system (DPEAPI-19480):

1. Labels added to Secret Manager secret
2. Daily monitoring workflow reads secrets with labels
3. Alerts routed to team-specific Teams webhooks 30 days before expiration

See: `cloud-functions/sa-key-monitor/` for monitoring system details.

## Related

- **Workflow**: `.github/workflows/create-mal-service-accounts.yml`
- **Design Doc**: `docs/workflows/SA-CREATION-AUTOMATION.md`
- **Jira Story**: DPEAPI-19473
- **Monitoring**: DPEAPI-19480
