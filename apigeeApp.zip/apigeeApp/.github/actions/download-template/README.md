# Download Template Action

Downloads the latest template bundle from GitHub releases based on template mappings.

## Usage

```yaml
- name: Download template
  id: download-template
  uses: ./.github/actions/download-template
  with:
    template_name: jwt-oauth-proxy-ahpt-backend
    output_dir: .template-cache
    github_token: ${{ secrets.GITHUB_TOKEN }}
```

## Inputs

| Input | Required | Default | Description |
|-------|----------|---------|-------------|
| `template_name` | Yes | - | Template name from proxy YAML (e.g., `jwt-oauth-proxy-ahpt-backend`) |
| `output_dir` | No | `.template-cache` | Directory to extract templates |
| `github_token` | No | `${{ github.token }}` | GitHub token for API access |

## Outputs

| Output | Description |
|--------|-------------|
| `template_path` | Path to the extracted template directory |
| `template_release` | Release tag/version that was downloaded |
| `cache_hit` | `true` if loaded from cache, `false` if newly downloaded |

## Features

- ✅ Loads template mappings from `template-mappings.json`
- ✅ Fetches latest release matching template name pattern
- ✅ Downloads release zip using `gh` CLI
- ✅ Caches downloads for speed (by template + release tag)
- ✅ Handles errors gracefully with clear messages
- ✅ Validates `template-mappings.json` exists

## Template Mappings

The action reads from `template-mappings.json` at repository root:

```json
{
  "template_mappings": {
    "jwt-oauth-proxy-ahpt-backend": "SYSGEN788836350-JWT_and_OAuth_Proxy_AHPT_Backend_Template",
    "jwt-proxy-ahpt-backend": "SYSGEN788836350-JWT_Proxy_AHPT_Backend_Template",
    "oauth-proxy-jwt-backend": "SYSGEN788836350-OAuth_Proxy_JWT_Backend_Template",
    "oauth-proxy-oauth-backend": "SYSGEN788836350-OAuth_Proxy_OAuth_Backend_Template"
  },
  "release_repository": "CenturyLink/enterprise-apigeex-templates"
}
```

The action:
1. Maps `template_name` to release tag pattern (e.g., `jwt-oauth-proxy-ahpt-backend` → `SYSGEN788836350-JWT_and_OAuth_Proxy_AHPT_Backend_Template`)
2. Searches for latest release with matching tag pattern in `release_repository`
3. Downloads the release zip file
4. Extracts to cache directory

## Cache Structure

Templates are cached at:
```
.template-cache/
  {template_name}/
    {release_tag}/
      [extracted template files]
```

Example:
```
.template-cache/
  jwt-oauth-proxy-ahpt-backend/
    SYSGEN788836350-JWT_and_OAuth_Proxy_AHPT_Backend_Template-v1.2.3/
      apiproxy/
      ...
```

Subsequent runs with the same template + release will use cached version (no re-download).

## Error Handling

The action handles:
- Missing `template-mappings.json` → Clear error with file path
- Template not in mappings → Lists available templates
- No matching release → Shows recent releases for debugging
- Download failures → Standard `gh` CLI error messages
- Extraction failures → Validates zip file exists

## Dependencies

- `gh` CLI (for release downloads)
- `jq` (for JSON parsing)
- `unzip` (for extraction)

All available in GitHub-hosted runners.

## Testing

Run the test workflow:

```bash
# Test with default template
gh workflow run test-download-template.yml

# Test with specific template
gh workflow run test-download-template.yml -f template_name=oauth-proxy-jwt-backend
```

The test workflow verifies:
1. Template downloads successfully
2. Template directory exists and is not empty
3. Cache works on second download
4. All templates from mappings are listed

## Example

```yaml
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Download template
        id: template
        uses: ./.github/actions/download-template
        with:
          template_name: jwt-oauth-proxy-ahpt-backend
      
      - name: Use template
        run: |
          echo "Template: ${{ steps.template.outputs.template_path }}"
          echo "Release: ${{ steps.template.outputs.template_release }}"
          
          # Transform template with apigee-go-gen
          apigee-go-gen transform \
            --template "${{ steps.template.outputs.template_path }}" \
            --config proxy-config.yaml \
            --output bundle.zip
```

## Related

- See [changed-files](../changed-files/) for detecting changed proxies
- See [extract-mal-metadata](../extract-mal-metadata/) for MAL info extraction
- See parent [README.md](../README.md) for all available actions
