# Deploy API Product Action

Composite GitHub Action that deploys API Products to Apigee X using apigeecli. This action creates or updates API Products, associates them with proxies, and configures quotas and OAuth scopes.

## Features

- ✅ **Create/Update Products**: Automatically detects if product exists and performs the appropriate action
- ✅ **Proxy Association**: Links products with one or more API proxies
- ✅ **Quota Configuration**: Configures rate limits (requests per time unit)
- ✅ **OAuth Scopes**: Associates OAuth scopes with products
- ✅ **Environment Support**: Deploys to specific Apigee environments
- ✅ **Custom Attributes**: Supports additional custom attributes
- ✅ **Validation**: Validates product configuration before deployment
- ✅ **Detailed Logging**: Provides clear deployment status and error messages

## Usage

```yaml
- name: Deploy API Product
  uses: ./.github/actions/deploy-product
  with:
    product-file: mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
    apigee-org: gcp-prj-apigee-dev-np-01
    apigee-env: apicc-dev
    service-account-email: ${{ steps.sa.outputs.service-account }}
    access-token: ${{ steps.auth.outputs.access_token }}
```

## Inputs

| Input | Required | Default | Description |
|-------|----------|---------|-------------|
| `product-file` | Yes | - | Path to product YAML file (e.g., `mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml`) |
| `apigee-org` | Yes | - | Apigee organization name (e.g., `gcp-prj-apigee-dev-np-01`) |
| `apigee-env` | Yes | - | Apigee environment name (e.g., `apicc-dev`) - Note: Products are org-level resources; this is used for environment filtering in product spec |
| `service-account-email` | Yes | - | Service account email for authentication |
| `access-token` | Yes | - | GCP access token for authentication |

## Outputs

| Output | Description |
|--------|-------------|
| `product-name` | Name of the deployed product |
| `deployment-status` | Deployment status (`success` or `failed`) |
| `action-type` | Action performed (`create` or `update`) |

## Product YAML Format

The action expects a product YAML file following this structure:

```yaml
apiVersion: apigee.lumen.com/v1
kind: ApiProduct
metadata:
  name: SYSGEN123456789-my-product
  description: My API Product
  sysgen: "123456789"
  owner: john.doe@company.com
  approvedBySRB: true
spec:
  approval: auto
  access: internal
  environments:
    - apicc-dev
    - apicc-test1
  proxies:
    - name: SYSGEN123456789-my-api
      operations:
        - path: /api/v1/*
          methods: [GET, POST]
  scopes:
    - read
    - write
  quota:
    limit: 1000
    interval: 1
    timeUnit: minute
  attributes:
    developer-category: gold
    billing-enabled: "true"
```

### Supported Proxy Formats

The action supports multiple proxy specification formats:

**Array of Objects (Recommended)**:
```yaml
spec:
  proxies:
    - name: SYSGEN123456789-api-one
      operations:
        - path: /v1/*
          methods: [GET, POST]
    - name: SYSGEN123456789-api-two
```

**Simple String Array**:
```yaml
spec:
  proxies:
    - SYSGEN123456789-api-one
    - SYSGEN123456789-api-two
```

## Configuration Options

### Quota Settings

Configure rate limiting for the API product:

```yaml
spec:
  quota:
    limit: 1000        # Number of requests
    interval: 1        # Time interval
    timeUnit: minute   # minute, hour, day, or month
```

### OAuth Scopes

Define OAuth scopes for access control:

```yaml
spec:
  scopes:
    - read
    - write
    - admin
```

### Custom Attributes

Add custom metadata to the product:

```yaml
spec:
  attributes:
    billing-tier: premium
    support-level: enterprise
    developer-category: gold
```

### Approval Type

Control app subscription approval process:

```yaml
spec:
  approval: auto    # auto or manual
```

### Access Level

Define product visibility:

```yaml
spec:
  access: internal  # internal or public
```

## Complete Workflow Example

```yaml
name: Deploy Products

on:
  push:
    branches: [main]
    paths:
      - 'mal-SYSGEN*/products/*.yaml'

permissions:
  contents: read
  id-token: write

jobs:
  deploy-products:
    runs-on: ubuntu-latest
    environment: dev
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Apigee Tooling
        uses: ./.github/actions/setup-apigee-tooling

      - name: Get Service Account
        id: sa
        uses: ./.github/actions/get-service-account
        with:
          mal-code: SYSGEN123456789
          apigee-org: gcp-prj-apigee-dev-np-01
          apigee-env: apicc-dev

      - name: Authenticate to Google Cloud
        id: auth
        uses: google-github-actions/auth@v2
        with:
          create_credentials_file: true
          workload_identity_provider: ${{ secrets.WIF_PROVIDER }}
          service_account: ${{ steps.sa.outputs.service-account }}

      - name: Deploy Product
        id: deploy-product
        uses: ./.github/actions/deploy-product
        with:
          product-file: mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
          apigee-org: gcp-prj-apigee-dev-np-01
          apigee-env: apicc-dev
          service-account-email: ${{ steps.sa.outputs.service-account }}
          access-token: ${{ steps.auth.outputs.access_token }}

      - name: Check Deployment Status
        run: |
          echo "Product: ${{ steps.deploy-product.outputs.product-name }}"
          echo "Status: ${{ steps.deploy-product.outputs.deployment-status }}"
          echo "Action: ${{ steps.deploy-product.outputs.action-type }}"
```

## How It Works

1. **Validation**: Verifies product YAML file exists and has valid syntax
2. **Extraction**: Parses product configuration (name, proxies, quotas, scopes, etc.)
3. **Detection**: Checks if product already exists in Apigee
4. **Deployment**: Creates new product or updates existing one using apigeecli
5. **Verification**: Confirms product was deployed successfully

## apigeecli Commands

The action uses the following apigeecli commands:

**Create Product**:
```bash
apigeecli products create \
  --name "PRODUCT_NAME" \
  --displayname "Display Name" \
  --desc "Description" \
  --proxies "proxy1,proxy2" \
  --scopes "read,write" \
  --quota 1000 \
  --interval 1 \
  --unit minute \
  --approval auto \
  --access internal \
  --org "gcp-prj-apigee-dev-np-01" \
  --token "$ACCESS_TOKEN"
```

**Update Product**:
```bash
apigeecli products update \
  --name "PRODUCT_NAME" \
  --displayname "Display Name" \
  --desc "Description" \
  --proxies "proxy1,proxy2" \
  --scopes "read,write" \
  --quota 1000 \
  --interval 1 \
  --unit minute \
  --approval auto \
  --access internal \
  --org "gcp-prj-apigee-dev-np-01" \
  --token "$ACCESS_TOKEN"
```

## Error Handling

The action provides clear error messages for common issues:

- **Missing Product File**: `❌ Product file not found: <path>`
- **Invalid YAML**: `❌ Invalid YAML syntax in product file`
- **Missing Product Name**: `❌ Product name is required`
- **No Proxies**: `❌ At least one proxy is required`
- **Deployment Failure**: `❌ Failed to create/update product: <error details>`

## Output Examples

**Successful Deployment**:
```
🔍 Validating product file
✅ Product file exists: mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
✅ YAML syntax is valid
📋 Extracting product configuration
✅ Extracted configuration:
  Product Name: SYSGEN123456789-my-product
  Display Name: My API Product
  Proxies: SYSGEN123456789-my-api
  Scopes: read,write
  Quota: 1000 requests per 1 minute
  Environments: apicc-dev
  Approval: auto
  Access: internal
🔎 Checking if product exists
✨ Product does not exist, will create
🚀 Deploying API Product
📝 Executing: apigeecli products create (details hidden for security)
✅ Product created successfully: SYSGEN123456789-my-product
✅ Verifying product deployment
✅ Product verified in Apigee
```

## Dependencies

- **apigeecli**: Must be installed (use `setup-apigee-tooling` action)
- **yq**: Must be installed (included in GitHub runners)
- **Service Account**: Valid GCP service account with Apigee permissions
- **Access Token**: Valid GCP access token

## Related Actions

- [validate-product](../validate-product/README.md) - Validates product YAML before deployment
- [get-service-account](../get-service-account/README.md) - Retrieves service account for authentication
- [setup-apigee-tooling](../setup-apigee-tooling/README.md) - Installs apigeecli

## Troubleshooting

### Product Already Exists Error

If you receive an error that the product already exists, the action should automatically detect and update it. If this fails:
- Verify access token has sufficient permissions
- Check if product name matches exactly (case-sensitive)

### Proxy Not Found Error

If deployment fails because a proxy doesn't exist:
- Ensure proxies are deployed before products
- Verify proxy names match exactly in the product YAML
- Check the proxy is deployed to the same organization

### Quota Not Applied

If quotas aren't being enforced:
- Verify all quota fields are present (limit, interval, timeUnit)
- Check that quota values are valid integers
- Ensure timeUnit is one of: minute, hour, day, month

## Schema Reference

For complete product YAML schema, see [apiproduct.schema.json](../../../apiproduct.schema.json).

## Story Information

- **Jira**: [DPEAPI-18712](https://lumen.atlassian.net/browse/DPEAPI-18712)
- **Story Points**: 5
- **Dependencies**: DPEAPI-18702 (Get Service Account), DPEAPI-18711 (Validate Product)
- **Enables**: DPEAPI-18713 (Product Deployment Workflows)
