# Validate MAL Structure Action

Validates MAL (Multi-Application Line) folder structure and naming conventions for Apigee X deployments.

## Usage

```yaml
- name: Validate MAL structure
  id: validate-mal
  uses: ./.github/actions/validate-mal-structure
  with:
    mal_folder: mal-SYSGEN123456789
```

## Inputs

| Input | Required | Default | Description |
|-------|----------|---------|-------------|
| `mal_folder` | Yes | - | Path to the MAL folder to validate (e.g., `mal-SYSGEN123456789`) |

## Outputs

| Output | Description |
|--------|-------------|
| `is_valid` | `true` if validation passed, `false` otherwise |
| `mal_code` | Extracted MAL code from folder name (e.g., `123456789`) |
| `errors` | Validation error messages (empty if valid) |

## Validation Rules

### MAL Folder Naming
- ✅ **Pattern**: `mal-SYSGEN<9-digit-code>`
- ✅ **Example**: `mal-SYSGEN123456789`
- ❌ **Invalid**: `mal-123456789`, `SYSGEN123456789`, `mal-SYSGEN12345`

### Required Subfolders
The following subfolders must exist:
- ✅ `proxies/` - Contains API proxy configurations
- ✅ `products/` - Contains API product configurations
- ✅ `kvms/` - Contains Key-Value Map configurations

### Proxy Structure
Each proxy in `proxies/` must follow:
- ✅ **Naming**: `SYSGEN<mal-code>-<proxy-name>`
  - Example: `SYSGEN123456789-my-api`
- ✅ **Environments**: At least one of `dev/`, `test/`, or `prod/`
- ✅ **Config**: Each environment must have `{proxy-name}.yaml`

**Valid Proxy Structure**:
```
mal-SYSGEN123456789/
  proxies/
    SYSGEN123456789-my-api/
      dev/
        base.yaml
      test/
        base.yaml
      prod/
        base.yaml
```

### Product Structure
Each product in `products/` must follow:
- ✅ **Naming**: `SYSGEN<mal-code>-<product-name>.yaml`
  - Example: `SYSGEN123456789-my-product.yaml`
- ✅ **Extension**: Must be `.yaml`

**Valid Product Structure**:
```
mal-SYSGEN123456789/
  products/
    SYSGEN123456789-my-product.yaml
    SYSGEN123456789-another-product.yaml
```

## Examples

### Valid MAL Structure
```
mal-SYSGEN123456789/
├── CODEOWNERS
├── README.md
├── proxies/
│   ├── SYSGEN123456789-api-one/
│   │   ├── dev/
│   │   │   └── SYSGEN123456789-my-api.yaml
│   │   ├── test/
│   │   │   └── SYSGEN123456789-my-api.yaml
│   │   └── prod/
│   │       └── SYSGEN123456789-my-api.yaml
│   └── SYSGEN123456789-another-api/
│       ├── dev/
│           └── SYSGEN123456789-another-api.yaml
├── products/
│   ├── SYSGEN123456789-product-one.yaml
│   └── SYSGEN123456789-product-two.yaml
└── kvms/
    └── placeholder.txt
```

### Complete Workflow Example

```yaml
name: Validate MAL Changes

on:
  pull_request:
    paths:
      - 'mal-SYSGEN*/**'

permissions:
  contents: read

jobs:
  validate:
    name: Validate MAL Structure
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Get changed MAL folders
        id: changed-files
        uses: ./.github/actions/changed-files

      - name: Extract MAL metadata
        id: mal-metadata
        uses: ./.github/actions/extract-mal-metadata
        with:
          changed_files: ${{ steps.changed-files.outputs.changed_files }}

      - name: Validate MAL structure
        id: validate
        uses: ./.github/actions/validate-mal-structure
        with:
          mal_folder: ${{ steps.mal-metadata.outputs.mal_folders }}

      - name: Print results
        run: |
          echo "MAL Code: ${{ steps.validate.outputs.mal_code }}"
          echo "Valid: ${{ steps.validate.outputs.is_valid }}"
```

## Error Handling

The action will:
- ❌ Exit with code 1 if validation fails
- ❌ Create GitHub error annotations at specific file locations
- ⚠️ Create warnings for non-critical issues (e.g., empty folders)
- ✅ Provide detailed error messages in outputs

### Common Errors

**Invalid folder name**:
```
::error file=mal-invalid::Invalid folder name pattern.
Expected: mal-SYSGEN<9-digit-code>, Got: mal-invalid
```

**Missing subfolder**:
```
::error file=mal-SYSGEN123456789/proxies::Required subfolder missing: proxies
```

**Invalid proxy naming**:
```
::error file=mal-SYSGEN123456789/proxies/wrong-name::Invalid proxy naming.
Expected: SYSGEN123456789-<name>, Got: wrong-name
```

**Missing {proxy-name}.yaml**:
```
::warning file=mal-SYSGEN123456789/proxies/SYSGEN123456789-api/dev/SYSGEN123456789-api.yaml::
Missing {proxy-name}.yaml in environment folder
```

## Testing

Run the test workflow:
```bash
# Test with default MAL folder
gh workflow run test-validate-mal-structure.yml

# Test with specific MAL folder
gh workflow run test-validate-mal-structure.yml -f mal_folder=mal-SYSGEN987654321
```

## Integration

This action is used by:
- PR validation workflows
- MAL structure compliance checks
- Deployment pre-checks
- CODEOWNERS enforcement workflows

## See Also

- [changed-files](../changed-files/) - Detect changed MAL folders
- [extract-mal-metadata](../extract-mal-metadata/) - Extract MAL codes and metadata
- [validate-proxy](../validate-proxy/) - Validate proxy YAML schemas
