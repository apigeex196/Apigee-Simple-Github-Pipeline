# Validate Proxy Reusable Action

A reusable composite action that validates a single Apigee proxy YAML file against schema, naming conventions, and template references.

## Features

- **YAML Syntax Validation**: Ensures the proxy file is valid YAML
- **JSON Schema Validation**: Validates against `apiproxy.schema.json` using AJV
- **Naming Convention Validation**: Verifies proxy name follows `SYSGEN[0-9]{9}-` pattern
- **Template Reference Validation**: Checks template exists in `template-mappings.json`
- **Detailed Error Reporting**: Provides specific error messages and counts
- **Multiple Outputs**: Returns validation status, errors, proxy name, template name

## Usage

### Basic Validation

```yaml
- name: Validate proxy
  id: validate
  uses: ./.github/actions/validate-proxy
  with:
    proxy_file: mal-SYSGEN123456789/proxies/SYSGEN123456789-my-api/dev/base.yaml
```

### With Template Override

```yaml
- name: Validate proxy
  id: validate
  uses: ./.github/actions/validate-proxy
  with:
    proxy_file: mal-SYSGEN123456789/proxies/SYSGEN123456789-my-api/dev/base.yaml
    template_name: basic-api-v1
```

### Using Outputs

```yaml
- name: Validate proxy
  id: validate
  uses: ./.github/actions/validate-proxy
  with:
    proxy_file: mal-SYSGEN123456789/proxies/SYSGEN123456789-my-api/dev/base.yaml

- name: Check validation result
  if: steps.validate.outputs.validation_result == 'failed'
  run: |
    echo "Validation failed with ${{ steps.validate.outputs.error_count }} errors"
    echo "Errors: ${{ steps.validate.outputs.error_messages }}"
    exit 1

- name: Use extracted values
  run: |
    echo "Proxy name: ${{ steps.validate.outputs.proxy_name }}"
    echo "Template name: ${{ steps.validate.outputs.template_name }}"
```

## Inputs

| Input | Description | Required | Default |
|-------|-------------|----------|---------|
| `proxy_file` | Path to proxy YAML file to validate | Yes | - |
| `template_name` | Template name (optional - will be extracted from proxy file if not provided) | No | - |
| `verify_template_download` | Whether to verify template can be downloaded (true/false) | No | `false` |

## Outputs

| Output | Description | Example |
|--------|-------------|---------|
| `validation_result` | Validation result: "passed" or "failed" | `passed` |
| `error_messages` | Concatenated error messages (empty if validation passed) | `Schema validation failed; Invalid proxy name` |
| `proxy_name` | Extracted proxy name from metadata.name | `SYSGEN123456789-my-api` |
| `template_name` | Extracted or provided template name | `basic-api-v1` |
| `error_count` | Number of validation errors found | `0` |

## Validation Checks

### 1. YAML Syntax Validation

Validates that the file is well-formed YAML using `yq`.

**Pass Example:**
```yaml
metadata:
  name: SYSGEN123456789-my-api
```

**Fail Example:**
```yaml
metadata
  name: SYSGEN123456789-my-api
```

### 2. JSON Schema Validation

Validates the proxy file against `apiproxy.schema.json` using AJV with JSON Schema Draft 7.

**Required Schema Elements:**
- `metadata.name` (string)
- `spec.template` (string) - Template name reference
- Other schema constraints as defined in `apiproxy.schema.json`

### 3. Naming Convention Validation

Verifies that `metadata.name` follows the pattern `SYSGEN[0-9]{9}-*`.

**Valid Names:**
- `SYSGEN123456789-my-api`
- `SYSGEN987654321-customer-service`

**Invalid Names:**
- `my-api` (missing SYSGEN prefix)
- `SYSGEN12345-api` (too few digits)
- `SYSGEN123456789a-api` (non-numeric characters)

### 4. Template Reference Validation

Verifies that `spec.template` exists in `template-mappings.json`.

**Example template-mappings.json:**
```json
{
  "template_mappings": {
    "basic-api-v1": "basic-api-v1.0.0",
    "oauth-api-v1": "oauth-api-v1.0.0"
  }
}
```

## Environment Variables

The action also sets the following environment variables for backward compatibility:

- `VALIDATION_RESULT` - Same as `validation_result` output
- `ERROR_MESSAGES` - Same as `error_messages` output
- `PROXY_NAME` - Same as `proxy_name` output
- `TEMPLATE_NAME` - Same as `template_name` output
- `ERROR_COUNT` - Same as `error_count` output

## Dependencies

This action requires the following tools (pre-installed in GitHub Actions runners):

- `yq` - YAML processor
- `jq` - JSON processor
- `ajv-cli` - JSON schema validator (install via: `npm install -g ajv-cli ajv-formats`)

**Required Files:**
- `apiproxy.schema.json` - JSON schema for proxy validation
- `template-mappings.json` - Template name to release mapping

## Error Handling

The action uses `set +e` to continue validation even when errors are found, allowing it to collect all validation errors in a single run.

**Exit Codes:**
- `0` - All validations passed
- `1` - One or more validations failed

**Error Messages Format:**
Error messages are concatenated with "; " separator for multiple errors:
```
Invalid YAML syntax; Schema validation failed; Template 'unknown-api' not found in mappings
```

## Integration Examples

### With Changed Files Detection

```yaml
- name: Get changed proxy files
  id: changed
  uses: ./.github/actions/changed-files
  with:
    filters: |
      proxies:
        - mal-*/proxies/**/base.yaml

- name: Validate each changed proxy
  if: steps.changed.outputs.proxies_count > 0
  run: |
    for file in ${{ steps.changed.outputs.proxies_files }}; do
      echo "Validating $file..."
      
      # Use the validate-proxy action
      # (In actual workflow, use jobs/matrix or loop with action calls)
    done
```

### In a Validation Workflow

```yaml
name: Validate Proxies

on:
  pull_request:
    paths:
      - 'mal-*/proxies/**/base.yaml'

jobs:
  validate:
    runs-on: ubuntu-latest
    permissions:
      contents: read
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node.js for AJV
        uses: actions/setup-node@v4
        with:
          node-version: '20'
      
      - name: Install AJV CLI
        run: npm install -g ajv-cli ajv-formats
      
      - name: Validate proxy
        uses: ./.github/actions/validate-proxy
        with:
          proxy_file: mal-SYSGEN123456789/proxies/SYSGEN123456789-my-api/dev/base.yaml
```

## Related Actions

- **changed-files** - Detects changed files in pull requests
- **download-template** - Downloads template bundles from GitHub releases
- **deploy-proxy** - Deploys validated proxies to Apigee environments

## Story Reference

**JIRA Story:** DPEAPI-18705  
**PR Reference:** #7 (Similar patterns from validate-apigee-artifacts-action)

## Troubleshooting

### Schema Validation Errors

If you see schema validation errors, ensure:

1. `apiproxy.schema.json` is present in repository root
2. AJV CLI is installed: `npm install -g ajv-cli ajv-formats`
3. Proxy file has all required fields

### Template Not Found

If template validation fails:

1. Verify `template-mappings.json` exists
2. Check template name matches exactly (case-sensitive)
3. Ensure template is listed in mappings file

### YAML Syntax Errors

If YAML syntax validation fails:

1. Check for proper indentation (use spaces, not tabs)
2. Verify colons have space after them
3. Ensure strings with special characters are quoted
4. Use a YAML linter locally: `yq eval '.' your-file.yaml`

## Contributing

When modifying this action:

1. Test with various proxy file formats
2. Ensure error messages are clear and actionable
3. Update this README with new features
4. Add examples for common use cases
5. Test integration with existing workflows
