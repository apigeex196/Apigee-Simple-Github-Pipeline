# Get MAL Service Account

Composite action to retrieve MAL-specific service accounts from GCP Secret Manager and authenticate with GCP.

## Overview

This action implements the secure service account retrieval pattern for MAL-based deployments. Each MAL (Managed API Layer) has dedicated service accounts per environment stored in GCP Secret Manager.

## Secret Naming Convention

Secrets must follow this exact naming pattern:

```
sa-apigeex-{SYSGEN+mal-code}
```

**Note**: The same secret name exists in each GCP org's Secret Manager (dev, qa, prod), but contains the org-specific service account key.

### Examples

```bash
# Secret name in all environments
sa-apigeex-SYSGEN788836350
```

Each GCP org (dev, qa, prod) has its own Secret Manager with this secret name, but the secret value contains that org's specific service account key.

## Secret Format

The secret value must be a **complete GCP service account JSON key** file:

```json
{
  "type": "service_account",
  "project_id": "gcp-prj-apigee-dev-np-01",
  "private_key_id": "...",
  "private_key": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n",
  "client_email": "sa-apigees-mal123@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com",
  "client_id": "...",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "..."
}
```

## Creating Secrets in GCP Secret Manager

### Using gcloud CLI

```bash
# Create secret in DEV org from service account key file
gcloud secrets create sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-dev-np-01 \
  --data-file=/path/to/dev-service-account-key.json \
  --replication-policy=automatic

# Create secret in QA org from service account key file
gcloud secrets create sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-qa-np-01 \
  --data-file=/path/to/qa-service-account-key.json \
  --replication-policy=automatic

# Create secret in PROD org from service account key file
gcloud secrets create sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-prod-01 \
  --data-file=/path/to/prod-service-account-key.json \
  --replication-policy=automatic

# Grant access to GitHub Actions service account (repeat for each org)
gcloud secrets add-iam-policy-binding sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-dev-np-01 \
  --member="serviceAccount:github-actions@project.iam.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"
```

### Using GCP Console

1. Navigate to **Secret Manager** in the appropriate GCP project
2. Click **Create Secret**
3. Name: Use the naming convention above
4. Secret value: Paste the complete service account JSON
5. Click **Create Secret**
6. Grant access to the GitHub Actions service account

## Usage

```yaml
steps:
  - name: Get Service Account
    id: get-sa
    uses: ./.github/actions/get-service-account
    with:
      mal-code: 'SYSGEN788836350'
      apigee-org: gcp-prj-apigee-dev-np-01
      apigee-env: apicc-dev1
      # Optional: override project where secrets are stored
      # secret-project: my-secrets-project

  - name: Use Access Token
    run: |
      echo "Authenticated as: ${{ steps.get-sa.outputs.service-account-email }}"

      # Use access token for apigeecli
      apigeecli apis list \
        --org ${{ inputs.apigee-org }} \
        --token ${{ steps.get-sa.outputs.access-token }}
```

## Inputs

| Input | Required | Description | Example |
|-------|----------|-------------|---------|
| `mal-code` | Yes | MAL code with SYSGEN prefix | `SYSGEN788836350` |
| `apigee-org` | Yes | Target Apigee organization | `gcp-prj-apigee-dev-np-01` |
| `apigee-env` | Yes | Target Apigee environment | `apicc-dev1` |
| `secret-project` | No | GCP project containing secrets (defaults to `apigee-org`) | `my-secrets-project` |

## Outputs

| Output | Description | Example |
|--------|-------------|---------|
| `service-account-email` | Email address of the service account | `sa-apigeex-mal123@....iam.gserviceaccount.com` |
| `access-token` | GCP access token for API calls | `ya29.c....` |
| `secret-name` | Name of the retrieved secret | `sa-apigeex_SYSGEN788836350_gcp-prj-apigee-dev-np-01_apicc-dev1` |## Security Considerations

- Service account keys are retrieved at runtime, never stored in GitHub
- Temporary key files are cleaned up automatically after use
- Access tokens are masked in logs
- Secrets are accessed from GCP Secret Manager with IAM controls
- Each MAL has isolated service accounts per environment

## Troubleshooting

### Error: Failed to retrieve service account secret

**Cause**: Secret does not exist in Secret Manager or wrong naming format

**Solution**:
1. Verify secret exists: `gcloud secrets list --project={project}`
2. Check naming matches: `sa-apigeex_{SYSGEN+mal-code}_{org}_{env}`
3. Ensure GitHub Actions SA has `secretmanager.secretAccessor` role### Error: Retrieved secret is not valid JSON

**Cause**: Secret value is not a complete service account JSON key

**Solution**:
1. Download a new service account key from GCP Console
2. Update the secret with the complete JSON content
3. Verify JSON is valid: `cat key.json | jq .`

### Error: Permission denied

**Cause**: GitHub Actions service account lacks permission to access secret

**Solution**:
```bash
gcloud secrets add-iam-policy-binding {secret-name} \
  --project={project} \
  --member="serviceAccount:github-actions@{project}.iam.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"
```

## Related

- **DPEAPI-18702**: Get Service Account (Jira story)
- **DPEAPI-18718**: Secrets & Service Accounts (Discovery)
- **GitOps Reference**: `deploy-proxy.yml` lines 50-80 (authentication pattern)
