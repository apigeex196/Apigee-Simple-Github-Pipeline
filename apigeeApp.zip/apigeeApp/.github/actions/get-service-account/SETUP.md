# Service Account Secret Setup Guide

This guide documents the process for creating and configuring MAL-specific service account secrets in GCP Secret Manager. This process will be automated in the future for API Producer teams.

## Overview

Each MAL (Managed API Layer) needs a dedicated service account for deploying to Apigee. These service accounts are stored in GCP Secret Manager with a standardized naming convention.

## Secret Naming Convention

```
sa-apigeex-{SYSGEN+mal-code}
```

**Example**: `sa-apigeex-SYSGEN788836350`

**Important**: The same secret name exists in each GCP org (DEV, QA, PROD), but contains that org's specific service account JSON key.

## Prerequisites

1. **Service Account Created**: The MAL service account must exist in each GCP org
   - Format: `sa-apigeex-cicd@{project-id}.iam.gserviceaccount.com`
   - Permissions: Apigee deployment permissions (varies by org)

2. **Service Account Key**: JSON key file for each org's service account

3. **gcloud CLI**: Authenticated with permissions to:
   - Create secrets (`secretmanager.secrets.create`)
   - Grant IAM permissions (`secretmanager.secrets.setIamPolicy`)

## Step-by-Step Process

### 1. Prepare Service Account Key Files

Create temporary JSON files for each environment's service account:

```bash
# DEV environment
cat > /tmp/dev-sa-key.json << 'EOF'
{
  "type": "service_account",
  "project_id": "gcp-prj-apigee-dev-np-01",
  "private_key_id": "...",
  "private_key": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n",
  "client_email": "sa-apigeex-cicd@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com",
  ...
}
EOF

# QA environment
cat > /tmp/qa-sa-key.json << 'EOF'
{
  "type": "service_account",
  "project_id": "gcp-prj-apigee-qa-np-01",
  ...
}
EOF

# PROD environment
cat > /tmp/prod-sa-key.json << 'EOF'
{
  "type": "service_account",
  "project_id": "gcp-prj-apigee-prod-01",
  ...
}
EOF
```

### 2. Create Secrets in Secret Manager

Create the secret in each GCP org's Secret Manager:

```bash
# DEV org
gcloud secrets create sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-dev-np-01 \
  --data-file=/tmp/dev-sa-key.json \
  --replication-policy=user-managed \
  --locations=us-central1

# QA org
gcloud secrets create sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-qa-np-01 \
  --data-file=/tmp/qa-sa-key.json \
  --replication-policy=user-managed \
  --locations=us-central1

# PROD org
gcloud secrets create sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-prod-01 \
  --data-file=/tmp/prod-sa-key.json \
  --replication-policy=user-managed \
  --locations=us-central1
```

**Note**: Using `user-managed` replication with explicit location due to org policy constraints on `automatic` replication.

### 3. Grant Access to GitHub Actions Service Account

Grant the CI/CD service account permission to read the secrets:

```bash
# DEV org
gcloud secrets add-iam-policy-binding sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-dev-np-01 \
  --member="serviceAccount:sa-apigeex-cicd@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"

# QA org
gcloud secrets add-iam-policy-binding sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-qa-np-01 \
  --member="serviceAccount:sa-apigeex-cicd@gcp-prj-apigee-qa-np-01.iam.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"

# PROD org
gcloud secrets add-iam-policy-binding sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-prod-01 \
  --member="serviceAccount:sa-apigeex-cicd@gcp-prj-apigee-prod-01.iam.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"
```

### 4. Clean Up Temporary Files

```bash
rm -f /tmp/dev-sa-key.json /tmp/qa-sa-key.json /tmp/prod-sa-key.json
```

### 5. Verify Setup

Test secret retrieval in each org:

```bash
# DEV
gcloud secrets versions access latest \
  --secret=sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-dev-np-01 | jq -r .client_email

# QA
gcloud secrets versions access latest \
  --secret=sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-qa-np-01 | jq -r .client_email

# PROD
gcloud secrets versions access latest \
  --secret=sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-prod-01 | jq -r .client_email
```

Expected output:
```
sa-apigeex-cicd@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com
sa-apigeex-cicd@gcp-prj-apigee-qa-np-01.iam.gserviceaccount.com
sa-apigeex-cicd@gcp-prj-apigee-prod-01.iam.gserviceaccount.com
```

## Verification Checklist

- [ ] Secret exists in DEV org Secret Manager
- [ ] Secret exists in QA org Secret Manager
- [ ] Secret exists in PROD org Secret Manager
- [ ] DEV CI/CD SA has `secretAccessor` role on DEV secret
- [ ] QA CI/CD SA has `secretAccessor` role on QA secret
- [ ] PROD CI/CD SA has `secretAccessor` role on PROD secret
- [ ] Secret retrieval test passes for all orgs
- [ ] Temporary key files deleted

## Architecture Notes

### Why Same Secret Name Across Orgs?

- **Simplicity**: Workflows use the same secret name regardless of target org
- **Isolation**: Each org's Secret Manager is isolated, so no naming conflicts
- **Org-Specific Content**: Secret value contains that org's specific service account
- **Clean Pattern**: MAL code uniquely identifies the secret within each org

### Secret Manager Per-Org Pattern

```
gcp-prj-apigee-dev-np-01
└── Secret Manager
    └── sa-apigeex-SYSGEN788836350 → DEV service account JSON

gcp-prj-apigee-qa-np-01
└── Secret Manager
    └── sa-apigeex-SYSGEN788836350 → QA service account JSON

gcp-prj-apigee-prod-01
└── Secret Manager
    └── sa-apigeex-SYSGEN788836350 → PROD service account JSON
```

### GitHub Actions Flow

1. Workflow triggered (e.g., PR to main)
2. Workflow authenticated as `sa-apigeex-cicd@{org}.iam.gserviceaccount.com`
3. Action calls: `get-service-account` with MAL code, org, and env
4. Action builds secret name: `sa-apigeex-{mal-code}`
5. Action retrieves from Secret Manager using org as project
6. Secret Manager checks: Does `sa-apigeex-cicd@{org}` have access?
7. If yes → returns service account JSON
8. Action activates service account for Apigee deployment

## Future Automation

When CCOE enables API Producer teams to create their own service accounts:

### Automated Process

1. **API Producer requests MAL** via self-service portal
2. **Automation creates service accounts** in DEV/QA/PROD orgs
   - Name: `sa-apigeex-cicd@{org}.iam.gserviceaccount.com`
   - Permissions: Apigee deployment roles for that MAL

3. **Automation generates JSON keys** for each service account

4. **Automation creates secrets** using this runbook's commands
   - Secret name: `sa-apigeex-{SYSGEN+mal}`
   - Secret value: Service account JSON key
   - Location: us-central1 (per org policy)

5. **Automation grants access** to CI/CD service accounts
   - Grant: `roles/secretmanager.secretAccessor`
   - To: `sa-apigeex-cicd@{org}.iam.gserviceaccount.com`

6. **Automation verifies** secret retrieval works

7. **API Producer notified** with MAL code and documentation

### Required Automation Components

- [ ] GCP service account creation API integration
- [ ] Secret Manager creation API integration
- [ ] IAM policy binding automation
- [ ] Verification testing
- [ ] Notification system
- [ ] Audit logging
- [ ] Rollback capability

## Security Considerations

### Secret Rotation

Service account keys should be rotated periodically:

```bash
# Create new version
gcloud secrets versions add sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-dev-np-01 \
  --data-file=/tmp/new-dev-sa-key.json

# Disable old version after testing
gcloud secrets versions disable 1 \
  --secret=sa-apigeex-SYSGEN788836350 \
  --project=gcp-prj-apigee-dev-np-01
```

### Access Control

- Secrets are **read-only** for CI/CD service accounts
- Only platform admins can create/update secrets
- Audit logs track all secret access
- Service accounts follow least-privilege principle

### Key Management

- Never commit service account keys to Git
- Always use temporary files for key creation
- Clean up temporary files immediately after use
- Use Secret Manager for all key storage

## Troubleshooting

### Error: FAILED_PRECONDITION: Constraint constraints/gcp.resourceLocations violated

**Cause**: Org policy requires explicit location for secrets

**Solution**: Use `--replication-policy=user-managed --locations=us-central1`

### Error: Permission denied when accessing secret

**Cause**: CI/CD service account lacks `secretAccessor` role

**Solution**: Run the IAM policy binding command in Step 3

### Error: Secret already exists

**Cause**: Secret was previously created

**Solution**: Either update existing secret or delete and recreate:
```bash
gcloud secrets delete sa-apigeex-SYSGEN788836350 --project={project}
```

### Error: Invalid service account key format

**Cause**: JSON is malformed or incomplete

**Solution**: Validate JSON with `jq`:
```bash
jq -e . /tmp/dev-sa-key.json
```

## Reference

- [GCP Secret Manager Documentation](https://cloud.google.com/secret-manager/docs)
- [Service Account Best Practices](https://cloud.google.com/iam/docs/best-practices-service-accounts)
- [GitHub Actions Get Service Account README](./README.md)
- [Apigee Deployment Guide](../../workflows/README.md)

## Example: Complete Setup for SYSGEN788836350

Completed on: December 10, 2025

```bash
# 1. Created secrets in all orgs
✅ DEV:  sa-apigeex-SYSGEN788836350 (version 1)
✅ QA:   sa-apigeex-SYSGEN788836350 (version 1)
✅ PROD: sa-apigeex-SYSGEN788836350 (version 1)

# 2. Granted access to CI/CD service accounts
✅ DEV:  sa-apigeex-cicd@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com
✅ QA:   sa-apigeex-cicd@gcp-prj-apigee-qa-np-01.iam.gserviceaccount.com
✅ PROD: sa-apigeex-cicd@gcp-prj-apigee-prod-01.iam.gserviceaccount.com

# 3. Verified retrieval works in all orgs
✅ All secret retrievals successful

# 4. Ready for use in workflows
✅ get-service-account action tested and working
```
