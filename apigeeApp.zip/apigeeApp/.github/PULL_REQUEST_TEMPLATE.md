## Summary

Concise description of the change and its purpose.

## Scope

- Area(s): (Workflows, Docs, Proxies, Products, Scripts)
- Repositories impacted: (applications, bundles, templates, gitops)
- Environments: (dev, test, prod)

## Changes

- Key change 1
- Key change 2
- Key change 3

## Testing

- How it was verified (local runs, CI, environment checks)
- Links to workflow runs if applicable
- Any edge cases covered

## MALs Affected

- MAL codes and proxies impacted by this change (or "None")

## Jira

- Epic / Story links

## Checklist

- [ ] Updated proxy YAML (if applicable)
- [ ] Updated product YAML (if applicable)
- [ ] Updated or added documentation
- [ ] CI workflows are passing
- [ ] Backwards compatible (or note breaking changes)
