# PR Creation Best Practices

## ✅ CORRECT: Simple Inline Body

This works reliably every time:

```bash
gh pr create \
  --title "feat(scope): Brief description" \
  --body "Simple summary without backticks or complex markdown. Can include basic formatting." \
  --base main
```

**Example**:
```bash
cd /path/to/repo && gh pr create \
  --title "feat(sa-automation): Complete SA automation" \
  --body "Completes SA automation workflow with self-service permission resolution. All 3 SAs have verified 12-role permission set. Ready for testing." \
  --base main
```

## ✅ ALTERNATIVE: Use GitHub Web UI

For PRs that need complex markdown bodies with code blocks, tables, or extensive formatting:

```bash
cd /path/to/repo && gh pr create --web
```

This opens the GitHub web interface where you can use their markdown editor.

## ❌ AVOID: Complex Inline Bodies

Do NOT use complex markdown with backticks, code blocks, or special characters inline:

```bash
# This FAILS with shell escaping issues:
gh pr create --body "Has `backticks` and **markdown** with code blocks..."
```

## ❌ AVOID: Body Files with Heredocs

Heredocs can cause terminal display corruption:

```bash
# This can cause terminal issues:
cat > /tmp/body.md << 'EOF'
...
EOF
gh pr create --body-file /tmp/body.md
```

## Summary

**Rule of Thumb**:
- Simple description = Use inline `--body`
- Complex markdown = Use `--web` flag

Keep it simple and it works every time!
