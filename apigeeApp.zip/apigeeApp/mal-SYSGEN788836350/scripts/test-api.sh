#!/bin/bash

echo "Getting token..."
TOKEN=$(curl -s -X POST "https://apicc-dev.gcl.corp.intranet/SYSGEN788836350/backend/oauth/token" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "grant_type=client_credentials&client_id=uR0sADdReNCxDuZKyAfZjE7fyudjsUOuskNomtgXiADJCvG5&client_secret=tOb1fqmnSRKmU7RHyNL4B06xBwUwqzAUID9fv5tiYfSgqy3DhKABHaebcGAYplVx&scope=test:scope" | jq -r '.access_token')

echo "Token: $TOKEN"
echo
echo "Calling stats API..."
echo

curl -s "https://apicc-dev.gcl.corp.intranet/sysgen788836350/apigee-stats/v1/apis" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Accept: application/json" | jq '.'

echo
echo "Done"
