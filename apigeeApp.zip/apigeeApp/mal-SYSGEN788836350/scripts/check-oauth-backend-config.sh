#!/bin/bash
# Extract Google service account credentials for OAuth backend
# These credentials are needed for proxies that call the Apigee Management API

set -e

echo "🔍 Extracting service account credentials..."

# Get the service account key (same one used for deployment)
TOKEN=$(gcloud auth print-access-token 2>/dev/null)
ORG="gcp-prj-apigee-dev-np-01"

# Try to get the service account from gcloud config
SA_EMAIL=$(gcloud config get-value account 2>/dev/null || echo "")

if [ -z "$SA_EMAIL" ]; then
    echo "❌ No service account configured. Please authenticate with gcloud first."
    exit 1
fi

echo "📧 Service Account Email: $SA_EMAIL"

# For Google service accounts, the client_id is the unique_id (numeric ID)
# We need to get this from the IAM API
PROJECT=$(gcloud config get-value project 2>/dev/null)

echo "🔑 Getting service account details from project: $PROJECT"

# Get service account unique ID (this is the client_id for OAuth)
SA_DETAILS=$(gcloud iam service-accounts describe "$SA_EMAIL" --project="$PROJECT" --format=json 2>/dev/null)

if [ -z "$SA_DETAILS" ]; then
    echo "❌ Could not retrieve service account details"
    exit 1
fi

CLIENT_ID=$(echo "$SA_DETAILS" | jq -r '.uniqueId')
echo "🆔 Client ID (unique_id): $CLIENT_ID"

echo ""
echo "=========================================================================="
echo "⚠️  IMPORTANT: OAuth Backend Configuration"
echo "=========================================================================="
echo ""
echo "The APIGEE-STATS-DASHBOARD proxy uses oauth-proxy-oauth-backend template,"
echo "which requires Google service account credentials to call googleapis.com."
echo ""
echo "However, Google service accounts use JWT bearer flow, NOT client credentials!"
echo "The template's KVM configuration is designed for standard OAuth 2.0,"
echo "not Google's JWT-based authentication."
echo ""
echo "📋 Current approach issues:"
echo "  1. Template expects client_id/client_secret OAuth flow"
echo "  2. Google APIs require JWT bearer tokens from service accounts"
echo "  3. The KVM stores these in wrong format for Google auth"
echo ""
echo "🔧 Recommended solutions:"
echo ""
echo "Option 1 (Simplest): Modify proxy to NOT call backend GoogleAPIs"
echo "  - Change proxy.yaml to return mock/static data instead"
echo "  - Keeps OAuth protection on proxy edge (demo requirement)"
echo "  - Avoids Google service account complexity"
echo ""
echo "Option 2 (Real data): Use apigee-go-gen with proper Google auth"
echo "  - Template needs custom policies for Google JWT auth"
echo "  - Requires ServiceCallout to get Google access tokens"
echo "  - More complex but gets real Apigee stats"
echo ""
echo "Option 3 (Hybrid): CLI tool calls Management API directly"
echo "  - demo-apigee-stats.sh already works with gcloud auth"
echo "  - Proxy just needs to be OAuth-protected (any response OK)"
echo "  - Real stats come from CLI, not proxy backend"
echo ""
echo "=========================================================================="
echo ""
echo "Current service account:"
echo "  Email: $SA_EMAIL"
echo "  Client ID: $CLIENT_ID"
echo "  Project: $PROJECT"
echo ""
echo "To proceed with Option 2, you would need to:"
echo "  1. Modify the template to use JWT bearer flow"
echo "  2. Add policies for Google token exchange"
echo "  3. Update KVM structure for service account JSON key"
echo ""
echo "=========================================================================="
