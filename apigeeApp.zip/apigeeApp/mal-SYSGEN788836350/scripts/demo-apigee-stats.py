#!/usr/bin/env python3
"""
Apigee X Stats Dashboard - CLI Demo
Demonstrates complete platform self-service workflow:
1. OAuth credential provisioning (via provision-apigee-creds.sh)
2. Token acquisition from backend service
3. Calling deployed proxy with OAuth
4. Displaying live operational metrics
"""

import requests
import json
import sys
import time
from datetime import datetime

# Configuration
OAUTH_URL = "https://apicc-dev.gcl.corp.intranet/SYSGEN788836350/backend/oauth/token"
STATS_API_URL = "https://apicc-dev.gcl.corp.intranet/sysgen788836350/apigee-stats/v1/apis"

def print_header():
    """Print demo header"""
    print("=" * 70)
    print("🚀 Apigee X Stats Dashboard - Live Demo")
    print("=" * 70)
    print("Demonstrating: OAuth → Proxy → Management API → Live Metrics")
    print()

def get_oauth_token(client_id, client_secret):
    """Obtain OAuth token from Apigee backend service"""
    print("📡 Step 1: Obtaining OAuth token from backend service...")
    print(f"   Endpoint: {OAUTH_URL}")

    payload = {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
        'scope': 'test:scope'
    }

    try:
        response = requests.post(
            OAUTH_URL,
            data=payload,
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            timeout=10
        )
        response.raise_for_status()

        token_data = response.json()
        access_token = token_data.get('access_token')
        expires_in = token_data.get('expires_in', 3600)

        print(f"   ✅ Token obtained successfully!")
        print(f"   Token: {access_token[:20]}...{access_token[-10:]}")
        print(f"   Expires in: {expires_in} seconds")
        print()

        return access_token
    except requests.exceptions.RequestException as e:
        print(f"   ❌ Failed to get OAuth token: {e}")
        sys.exit(1)

def fetch_apigee_stats(access_token):
    """Call deployed proxy to fetch Apigee statistics"""
    print("📊 Step 2: Calling deployed proxy for Apigee X statistics...")
    print(f"   Endpoint: {STATS_API_URL}")
    print(f"   Auth: Bearer token")

    try:
        response = requests.get(
            STATS_API_URL,
            headers={
                'Authorization': f'Bearer {access_token}',
                'Accept': 'application/json'
            },
            timeout=15
        )
        response.raise_for_status()

        stats_data = response.json()

        print(f"   ✅ Statistics retrieved successfully!")
        print()

        return stats_data
    except requests.exceptions.RequestException as e:
        print(f"   ❌ Failed to fetch statistics: {e}")
        if hasattr(e.response, 'text'):
            print(f"   Response: {e.response.text}")
        sys.exit(1)

def display_stats(stats_data):
    """Display statistics in a clean format"""
    print("=" * 70)
    print("📈 LIVE APIGEE X STATISTICS")
    print("=" * 70)
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()

    # Display proxies list
    proxies = stats_data.get('proxies', [])
    print(f"🔹 Total Proxies: {len(proxies)}")
    print()

    if proxies:
        print("Deployed Proxies:")
        print("-" * 70)
        for i, proxy in enumerate(proxies[:10], 1):  # Show first 10
            name = proxy.get('name', 'Unknown')
            revision = proxy.get('revision', [])
            rev_count = len(revision) if isinstance(revision, list) else 0
            print(f"  {i:2d}. {name}")
            print(f"      Revisions: {rev_count}")

        if len(proxies) > 10:
            print(f"  ... and {len(proxies) - 10} more proxies")

    print()
    print("=" * 70)
    print("✅ Demo Complete!")
    print()
    print("What this demonstrated:")
    print("  ✓ OAuth client credentials flow")
    print("  ✓ Backend token service integration")
    print("  ✓ Deployed proxy with OAuth enforcement")
    print("  ✓ Live Apigee X Management API access")
    print("  ✓ Complete platform self-service workflow")
    print("=" * 70)

def main():
    """Main execution"""
    print_header()

    # Get credentials from command line arguments
    if len(sys.argv) != 3:
        print("Usage: ./demo-apigee-stats.py <client_id> <client_secret>")
        print()
        print("Obtain credentials by running:")
        print("  ./scripts/provision-apigee-creds.sh")
        print()
        print("Example:")
        print("  ./demo-apigee-stats.py uR0sADdReNCx... tOb1fqmnSRKm...")
        sys.exit(1)

    client_id = sys.argv[1]
    client_secret = sys.argv[2]

    # Execute demo workflow
    access_token = get_oauth_token(client_id, client_secret)
    stats_data = fetch_apigee_stats(access_token)
    display_stats(stats_data)

if __name__ == "__main__":
    main()
