#!/bin/bash
# Apigee X Stats Dashboard - CLI Demo (Shell Script)
# Demonstrates complete platform self-service workflow with LIVE STREAMING stats

set -e

# Configuration
OAUTH_URL="https://apicc-dev.gcl.corp.intranet/SYSGEN788836350/backend/oauth/token"
PROXY_URL="https://apicc-dev.gcl.corp.intranet/sysgen788836350/apigee-stats/v1"
APIGEE_ORG="gcp-prj-apigee-dev-np-01"
REFRESH_INTERVAL=5  # seconds between refreshes

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Track previous count for change detection
PREV_COUNT=0

print_header() {
    clear
    echo "======================================================================"
    echo "🚀 Apigee X Stats Dashboard - LIVE STREAMING"
    echo "======================================================================"
    echo -e "${CYAN}Press Ctrl+C to stop streaming${NC}"
    echo
}

get_oauth_token() {
    local client_id=$1
    local client_secret=$2

    local response=$(curl -s -X POST "$OAUTH_URL" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "grant_type=client_credentials&client_id=${client_id}&client_secret=${client_secret}&scope=test:scope")

    local access_token=$(echo "$response" | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)

    if [ -z "$access_token" ]; then
        echo -e "${RED}❌ Failed to get OAuth token${NC}"
        echo "Response: $response"
        exit 1
    fi

    echo "$access_token"
}

fetch_apigee_stats() {
    local access_token=$1

    # Call the OAuth-protected deployed proxy and get its response
    local response=$(curl -s -X GET "$PROXY_URL" \
        -H "Authorization: Bearer $access_token" \
        -H "Accept: application/json")

    if [ -z "$response" ]; then
        echo -e "${RED}❌ Empty response from proxy${NC}" >&2
        return 1
    fi

    echo "$response"
}

display_stats() {
    local stats_data=$1
    local iteration=$2

    clear
    echo "======================================================================"
    echo -e "📈 ${GREEN}LIVE APIGEE X STATISTICS${NC} ${CYAN}(Streaming from Deployed Proxy)${NC}"
    echo "======================================================================"
    echo "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "Refresh: Every ${REFRESH_INTERVAL}s | Iteration: ${iteration} | ${CYAN}Press Ctrl+C to stop${NC}"
    echo

    # Parse proxy response data
    local proxy_timestamp=$(echo "$stats_data" | grep -o '"timestamp":"[^"]*' | cut -d'"' -f4)
    local environment=$(echo "$stats_data" | grep -o '"environment":"[^"]*' | cut -d'"' -f4)
    local organization=$(echo "$stats_data" | grep -o '"organization":"[^"]*' | cut -d'"' -f4)
    local proxy_name=$(echo "$stats_data" | grep -o '"proxy":"[^"]*' | cut -d'"' -f4)
    local total_proxies=$(echo "$stats_data" | grep -o '"totalProxies":[0-9]*' | cut -d':' -f2)
    local request_count=$(echo "$stats_data" | grep -o '"requestCount":[0-9]*' | cut -d':' -f2)

    # Detect changes in metrics
    local change_indicator=""
    if [ -n "$total_proxies" ]; then
        if [ "$total_proxies" -gt "$PREV_COUNT" ]; then
            change_indicator="${GREEN}↗${NC}"
        elif [ "$total_proxies" -lt "$PREV_COUNT" ]; then
            change_indicator="${RED}↘${NC}"
        else
            change_indicator="${YELLOW}━${NC}"
        fi
        PREV_COUNT=$total_proxies
    fi

    echo -e "${BLUE}📍 Deployed Proxy Details:${NC}"
    echo "  Organization: $organization"
    echo "  Environment: $environment"
    echo "  Proxy: $proxy_name"
    echo "  Proxy Timestamp: $proxy_timestamp"
    echo

    echo -e "${YELLOW}📊 Live Metrics (from deployed proxy):${NC}"
    echo -e "  Total Proxies: ${total_proxies} ${change_indicator}"
    echo "  Request Count: $request_count"
    echo

    echo -e "${GREEN}✅ Demo Status:${NC}"
    echo "  - OAuth protection: ACTIVE"
    echo "  - Proxy deployed: YES"
    echo "  - Real-time data: YES (changes every ${REFRESH_INTERVAL}s)"
    echo
    echo "----------------------------------------------------------------------"
    echo -e "${BLUE}Next refresh in ${REFRESH_INTERVAL} seconds...${NC}"
}

main() {
    print_header

    # Get credentials from command line arguments
    if [ $# -ne 2 ]; then
        echo "Usage: ./demo-apigee-stats.sh <client_id> <client_secret>"
        echo
        echo "Obtain credentials by running:"
        echo "  ./scripts/provision-apigee-creds.sh"
        echo
        echo "Example:"
        echo "  ./demo-apigee-stats.sh uR0sADdReNCx... tOb1fqmnSRKm..."
        exit 1
    fi

    local client_id=$1
    local client_secret=$2

    # Initial OAuth token acquisition
    echo -e "${BLUE}🔐 Authenticating with OAuth backend service...${NC}"
    local access_token=$(get_oauth_token "$client_id" "$client_secret")
    echo -e "${GREEN}✅ Authenticated successfully!${NC}"
    echo
    sleep 2

    # Start streaming loop
    local iteration=1
    while true; do
        local stats_data=$(fetch_apigee_stats "$access_token")
        display_stats "$stats_data" "$iteration"

        sleep "$REFRESH_INTERVAL"
        ((iteration++))

        # Refresh token every 50 iterations (~4 minutes with 5s refresh)
        if [ $((iteration % 50)) -eq 0 ]; then
            access_token=$(get_oauth_token "$client_id" "$client_secret")
        fi
    done
}

main "$@"
