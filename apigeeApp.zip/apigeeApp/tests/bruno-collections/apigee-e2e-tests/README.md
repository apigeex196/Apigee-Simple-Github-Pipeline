# Apigee E2E API Tests - Bruno Collection

This Bruno collection provides comprehensive API runtime testing for the Apigee platform deployment, validating that deployed APIs are functioning correctly across all environments.

## 📋 Overview

**Purpose**: Validate API runtime behavior (DPEAPI-19135)  
**Tool**: Bruno API Client  
**Coverage**: Happy path, OAuth flows, error scenarios, performance checks

## 🚀 Getting Started

### Prerequisites

1. **Bruno VS Code Extension** (already installed)
   - Open Command Palette (Ctrl+Shift+P)
   - Type "Bruno: Open Collection"
   - Navigate to `tests/bruno-collections/apigee-e2e-tests/`

2. **Alternative: Bruno CLI** (optional)
   ```powershell
   npm install -g @usebruno/cli
   ```

### Opening the Collection

**In VS Code:**
1. Open Bruno sidebar (icon in activity bar)
2. Click "Open Collection"
3. Select `tests/bruno-collections/apigee-e2e-tests/`
4. Collection will load with all test folders

**Via CLI:**
```powershell
cd tests/bruno-collections/apigee-e2e-tests
bru run --env Dev
```

## 🌍 Environments

Three environments are configured with actual Apigee hostnames:

| Environment | Hostname | Base Path |
|-------------|----------|-----------|
| **Dev** | `https://apicc-dev.gcl.corp.intranet` | `/Test/v1` |
| **Test** | `https://apicc-test1.gcl.corp.intranet` | `/Test/v1` |
| **Prod** | `https://apicc-prod.gcl.corp.intranet` | `/Test/v1` |

### Switching Environments

**In VS Code:**
- Select environment from dropdown in Bruno sidebar
- Click "Set as Active Environment"

**Via CLI:**
```powershell
bru run --env Test
bru run --env Prod
```

## 📁 Test Structure

```
apigee-e2e-tests/
├── E2E-TEST-BASIC/          # OAuth-protected proxy tests
│   ├── 01-Health-Check.bru
│   └── 02-Unauthenticated-Request.bru
├── SIMPLE-TEST/             # Basic passthrough proxy tests
│   ├── 01-Health-Check.bru
│   ├── 02-Echo-Request.bru
│   └── 03-POST-Request.bru
├── OAUTH-KVM-OAS-TEST/      # OAuth + KVM integration tests
│   ├── 01-Health-Check.bru
│   └── 02-OAuth-Protected-Endpoint-No-Token.bru
├── OAuth-Backend/           # OAuth backend endpoint tests
│   ├── 01-Token-Endpoint-Missing-Params.bru
│   └── 02-Direct-Test-No-Vars.bru
├── Error-Scenarios/         # Negative testing
│   ├── 01-Invalid-Path.bru
│   ├── 02-Invalid-Method.bru
│   └── 03-Malformed-Request.bru
├── Performance/             # Performance validation
│   └── 01-OAuth-Validation-Performance.bru
└── environments/            # Environment configurations
    ├── Dev.bru
    ├── Test.bru
    └── Prod.bru
```

## 🧪 Test Coverage

### Happy Path Tests ✅
- **SIMPLE-TEST**: Basic HTTP operations (GET, POST)
- **E2E-TEST-BASIC**: Health checks, basic routing
- **OAUTH-KVM-OAS-TEST**: OAuth integration with KVM secrets

### Security Tests 🔒
- Unauthenticated requests return 401
- OAuth token validation
- Missing credentials rejected

### Error Scenarios ❌
- Invalid paths (404)
- Invalid HTTP methods (405)
- Malformed requests (400)

### Performance Tests ⚡
- **OAuth Validation Performance**: Tests how fast proxies reject unauthenticated requests (< 1 second)
- Response time validation for OAuth rejection
- Ensures minimal latency even for failed auth

## ▶️ Running Tests

### Run All Tests (Current Environment)
**VS Code:**
- Right-click collection root
- Select "Run Collection"

**CLI:**
```powershell
bru run --env Dev
```

### Run Specific Folder
**VS Code:**
- Right-click folder (e.g., SIMPLE-TEST)
- Select "Run Folder"

**CLI:**
```powershell
bru run --env Dev --folder SIMPLE-TEST
```

### Run Single Test
**VS Code:**
- Open test file (.bru)
- Click "Send Request" button
- View response in right panel

**CLI:**
```powershell
bru run --env Dev --request "SIMPLE-TEST/01-Health-Check"
```

## 📊 Interpreting Results

### Success Indicators
- ✅ All assertions pass (green checkmarks)
- Status codes match expectations
- Response times within thresholds

### Common Issues

**Connection Refused:**
- Verify network access to `gcl.corp.intranet`
- Check VPN connection if required
- Confirm proxy is deployed to selected environment

**401 Unauthorized (Unexpected):**
- Expected for OAuth-protected endpoints without tokens
- Review test name - some tests expect 401

**404 Not Found:**
- Verify proxy is deployed: Check GitHub Actions deployment logs
- Confirm base path matches proxy configuration
- Check environment selection

**Timeout:**
- Increase timeout in test settings
- Check Apigee environment health
- Verify backend target availability

## 🔄 Multi-Environment Testing

Run same tests across all environments to verify consistency:

```powershell
# Test all environments
bru run --env Dev
bru run --env Test
bru run --env Prod
```

**Expected Behavior:**
- Same tests should pass in all environments
- Response times may vary slightly
- OAuth configurations are environment-specific

## ➕ Adding New Tests

1. **Create new .bru file** in appropriate folder:
   ```
   SIMPLE-TEST/04-New-Test.bru
   ```

2. **Use template structure:**
   ```
   meta {
     name: Test Name
     type: http
     seq: 4
   }

   get {
     url: {{apigee_host}}{{base_path}}/Simple/endpoint
     body: none
     auth: none
   }

   tests {
     test("Status code is 200", function() {
       expect(res.status).to.equal(200);
     });
   }
   ```

3. **Run to verify:**
   - Click "Send Request" in VS Code
   - Or run via CLI: `bru run --env Dev --request "SIMPLE-TEST/04-New-Test"`

## 📝 Best Practices

1. **Test Naming**: Use descriptive names indicating what's being tested
2. **Assertions**: Always test status code, response time, and key response fields
3. **Error Tests**: Clearly mark tests expecting errors (e.g., "401 Expected")
4. **Environment Variables**: Use `{{apigee_host}}` and `{{base_path}}` for portability
5. **Documentation**: Add comments in complex tests explaining logic

## 🎯 Acceptance Criteria Mapping

| Criterion | Coverage |
|-----------|----------|
| Health checks across proxies | ✅ 01-Health-Check.bru in each folder |
| Happy path API calls | ✅ SIMPLE-TEST folder |
| OAuth validation | ✅ E2E-TEST-BASIC, OAUTH-KVM-OAS-TEST |
| Error scenarios | ✅ Error-Scenarios folder |
| Performance validation | ✅ Performance folder |
| Multi-environment testing | ✅ Dev, Test, Prod environments |

## 🆘 Troubleshooting

### Bruno Won't Open Collection
- Ensure you're opening the folder containing `bruno.json`
- Check file permissions
- Restart VS Code

### Environment Variables Not Working
- Verify environment is selected in dropdown
- Check `environments/*.bru` files have correct syntax
- Reload Bruno collection

### Tests Failing Unexpectedly
1. Check proxy deployment status in GitHub Actions
2. Verify environment hostname in `environments/*.bru`
3. Test basic connectivity: `curl {{apigee_host}}`
4. Review Apigee trace logs for specific requests

## 📚 Related Documentation

- [DPEAPI-19135 Story](../../JIRA-DPEAPI-19135.md) (if exists)
- [E2E Testing Results](../../docs/E2E-TESTING-DPEAPI-18719.md)
- [Deployment Workflows](../../.github/workflows/)

## 🤝 Contributing

When adding tests:
1. Follow existing folder structure
2. Use consistent naming conventions (01-, 02-, etc.)
3. Include comprehensive assertions
4. Test in all environments before committing
5. Update this README if adding new test categories

---

**Last Updated**: January 7, 2026  
**Maintained By**: Platform Engineering Team  
**Questions**: Contact TL or check team documentation
