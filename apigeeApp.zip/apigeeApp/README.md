# Application MAL Repository Template

This repository contains the Apigee API proxy, product, and KVM configuration
skeleton for a single MAL (Managed API Layer). Each MAL folder is owned by
an application team and maps to a single Apigee organization.

This repository is **not** the platform GitOps repository. Platform-owned
shared infrastructure (SharedFlows, utility proxies, reusable bundles, etc.)
continues to live in the enterprise Apigee GitOps repo. This application
repository is focused on producer-owned configuration only.

---

## MAL Folder Layout

Each MAL lives under its own `mal-<SYSGEN_CODE>/` folder. A minimal example:

```text
mal-SYSGEN123456789/
│
├── CODEOWNERS
├── README.md
│
├── proxies/
│   └── SYSGEN123456789-my-api/
│       ├── dev/
│       │   └── SYSGEN123456789-my-api.yaml
│       ├── test/
│       │   └── SYSGEN123456789-my-api.yaml
│       └── prod/
│           └── SYSGEN123456789-my-api.yaml
│
└── orgs/                                    # ← Organization-specific configs
    └── gcp-prj-apigee-dev-np-01/
        ├── products/                        # ← MAL-scoped products
        │   └── SYSGEN123456789-my-product.yaml
        └── kvms/                            # ← Reserved for KVM config
            └── (KVM configuration files)

# Optional: Global (cross-MAL) products at repository root
global-products/
└── orgs/
    └── gcp-prj-apigee-dev-np-01/
        └── ENTERPRISE-WIDE-PRODUCT.yaml     # ← Cross-MAL products
```

### Proxies

- All MAL proxies are defined under `mal-<SYSGEN_CODE>/proxies/`.
- Each proxy has its own folder named using the SYSGEN-style convention,
  for example: `SYSGEN123456789-my-api`.
- Environment-specific configuration for that proxy lives in the
  `dev/`, `test`, and `prod/` subfolders.

This model avoids the older `base + overlays` pattern. Instead of
Each environment has its own configuration file named `{proxy-name}.yaml`
inside the appropriate folder (for example `dev/SYSGEN123456789-my-api.yaml`).

### Products

API products can be defined in **two locations** depending on their scope:

**1. MAL-Scoped Products** (Single Team)
- Location: `mal-<SYSGEN_CODE>/orgs/{org}/products/`
- Example: `mal-SYSGEN123456789/orgs/gcp-prj-apigee-dev-np-01/products/SYSGEN123456789-my-product.yaml`
- Use when: Product references only your team's proxies
- Ownership: Managed by the application team (via CODEOWNERS)

**2. Global Products** (Cross-MAL)
- Location: `global-products/orgs/{org}/`
- Example: `global-products/orgs/gcp-prj-apigee-dev-np-01/ENTERPRISE-API-GATEWAY.yaml`
- Use when: Product references proxies from multiple teams/MALs
- Ownership: Managed by platform team or cross-functional teams

Products are organization-level resources in Apigee. The repository structure
allows teams to manage their own products while also supporting enterprise-wide
products that span multiple application teams.

### KVMs

The `kvms/` folder is reserved for KeyValueMap configuration:
- Location: `mal-<SYSGEN_CODE>/orgs/{org}/kvms/`
- Follows the same org-specific structure as products
- Schema aligns with enterprise Apigee GitOps repository patterns

For now, this directory exists as a clear, consistent placeholder so that
KVM configuration has a well-defined home once teams are ready to add it.

For now, this directory exists as a clear, consistent placeholder so that
KVM configuration has a well-defined home once teams are ready to add it.

---

## Service Accounts & Secrets

Deployments for each MAL use a dedicated GCP service account per
organization and environment. Service account keys are **not** stored in
this repository.

- Keys are stored in **GCP Secret Manager** using a standard naming
  convention: `sa-apigees-<mal-code>-<org>-<env>`
- Example: `sa-apigees-123456789-gcp-prj-apigee-dev-np-01-apicc-dev`
- GitHub workflows retrieve the key at runtime via a shared
  `get-service-account` composite action.

The process for requesting and provisioning service accounts is managed
centrally by the API Enablement / DevSecOps teams and documented outside
of this template.

---

## Workflows & Deployments

This repository is designed to work with reusable GitHub Actions
workflows that:

- Validate configuration on pull requests.
- Detect which MAL folders have changed.
- Deploy only the proxies/products/KVMs that changed.
- Target the correct organization and environment based on workflow
  inputs (for example: `APIGEE_ORG`, `APIGEE_ENV`).

The reusable workflows live under `.github/workflows/` and are managed by
the platform team. Application teams generally:
- Add or modify configuration under their `mal-<SYSGEN-CODE>/` folder(s).
- Rely on the shared workflows for validation and deployment.

---

## What This Repository Does *Not* Contain

The following are intentionally **out of scope** for this application
repository and continue to live in the platform GitOps repository:

- SharedFlows
- Low-level XML proxy bundles
- Organization-level `orgs/` folder structure
- Top-level `envs/` or `global` folders
- `apigeeproxies` and `apigeesharedflows` folders
- `{proxy-name}.yaml` per environment (matches gitops pattern)

Keeping these concerns separate lets the platform team manage shared
infrastructure while application teams own their MAL-specific
configuration here.

---

## Documentation

- **[Product Structure Strategy](docs/PRODUCT-STRUCTURE-STRATEGY.md)** - Complete guide to global vs MAL-scoped products
- **[Repository Configuration](docs/repository-configuration.md)** - Repository setup and configuration
- **[Documentation Index](docs/README.md)** - Full documentation catalog

## Getting Started

For details on onboarding a new MAL folder, see [`docs/ONBOARDING.md`](docs/ONBOARDING.md).
