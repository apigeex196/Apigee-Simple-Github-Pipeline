#!/usr/bin/env python3
"""
Phase-2 POC: API Proxy Discovery Tool (ESP → schema-valid proxy.yaml)

Usage:
  python tools/apigee-discovery/discover.py extract --proxy <name> --env <env> --output <path> \
      [--sysgen <SYSGEN>] [--taxonomy "/Type/v1/Name"] [--template <template>] \
      [--base-url <ESP_BASE_URL>] [--ca-bundle <path>] [--insecure]

Auth:
  - If environment variable ESP_TOKEN is set → use Bearer auth
  - Else if ESP_USER and ESP_PASS are set → use Basic auth
  - Else → fail

Endpoint:
  GET {ESP_BASE_URL}/Enterprise/v1/SOAEnablement/apiHub/v1/apiProxyDetails?env=<env>&offset=0&limit=20&sort=+resourceTaxonomy

Notes:
  - Defensive parsing; do not assume fields exist in ESP response
  - Minimum schema fields required by apiproxy.schema.json
  - Validate against apiproxy.schema.json via jsonschema
  - Writes proxy.yaml and migration_notes.md under the provided --output path

"""
import argparse
import datetime as dt
import json
import os
import sys
from typing import Any, Dict, Optional

import requests
from jsonschema import validate, Draft7Validator
import yaml

SCHEMA_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "apiproxy.schema.json")

DEFAULT_API_VERSION = "apienable.lumen.com/v1beta1"
DEFAULT_KIND = "ApiProxy"
DEFAULT_TEMPLATE = "oauth-proxy-oauth-backend"  # choose a template that does not mandate JWT

ESP_ENDPOINT_PATH = "/Enterprise/v1/SOAEnablement/apiHub/v1/apiProxyDetails"


def _read_schema() -> Dict[str, Any]:
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _auth_headers() -> Dict[str, str]:
    token = os.environ.get("ESP_TOKEN")
    user = os.environ.get("ESP_USER")
    pw = os.environ.get("ESP_PASS")
    if token:
        return {"Authorization": f"Bearer {token}"}
    if user and pw:
        return {"Authorization": requests.auth._basic_auth_str(user, pw)}
    print("ERROR: Set ESP_TOKEN (Bearer) or ESP_USER/ESP_PASS (Basic) for authentication.", file=sys.stderr)
    sys.exit(2)


def _request(base_url: str, env: str, ca_bundle: Optional[str], insecure: bool) -> requests.Response:
    params = {
        "env": env,
        "offset": "0",
        "limit": "20",
        "sort": "+resourceTaxonomy",
    }
    url = base_url.rstrip("/") + ESP_ENDPOINT_PATH
    headers = _auth_headers()
    verify = True
    if ca_bundle:
        verify = ca_bundle
    elif insecure:
        verify = False
        print("WARNING: SSL verification disabled (--insecure)")
    try:
        resp = requests.get(url, headers=headers, params=params, timeout=20, verify=verify)
        return resp
    except requests.RequestException as e:
        print(f"ERROR: Request failed: {e}", file=sys.stderr)
        sys.exit(3)


def _match_proxy(item: Dict[str, Any], proxy_name: str) -> bool:
    # Try multiple potential fields to match name defensively
    candidates = [
        item.get("name"),
        item.get("proxyName"),
        item.get("apiName"),
        item.get("resourceTaxonomy"),
    ]
    for c in candidates:
        if isinstance(c, str) and c.strip().lower() == proxy_name.strip().lower():
            return True
    return False


def _extract_fields(item: Dict[str, Any]) -> Dict[str, Any]:
    # Defensive extraction — use common field names if present
    name = item.get("name") or item.get("proxyName") or item.get("apiName")
    description = item.get("description") or item.get("summary")
    base_path = item.get("basePath") or item.get("basepath") or item.get("path")
    virtual_host = item.get("virtualHost") or item.get("virtualHosts")
    # Some ESP payloads may have backend URL or target server hints
    target = item.get("target") or item.get("backendUrl") or item.get("targetServer")
    return {
        "name": name,
        "description": description,
        "basePath": base_path,
        "virtualHost": virtual_host,
        "target": target,
    }


def _build_resource(fields: Dict[str, Any], sysgen: str, taxonomy: str, template: str) -> Dict[str, Any]:
    metadata = {
        "name": fields.get("name") or "UNKNOWN-PROXY",
        "labels": {
            "sysgen": sysgen,
            "taxonomy": taxonomy,
        },
    }
    if fields.get("description"):
        metadata["description"] = fields["description"]

    routing: Dict[str, Any] = {
        "path": fields.get("basePath") or "/",
        "target": fields.get("target") or "UNKNOWN-TARGET",
    }

    resource = {
        "apiVersion": DEFAULT_API_VERSION,
        "kind": DEFAULT_KIND,
        "metadata": metadata,
        "spec": {
            "template": template,
            "routing": routing,
        },
    }
    return resource


def _validate_resource(resource: Dict[str, Any], schema: Dict[str, Any]) -> None:
    v = Draft7Validator(schema)
    errors = sorted(v.iter_errors(resource), key=lambda e: e.path)
    if errors:
        print("ERROR: Schema validation failed:")
        for e in errors:
            path = "/".join(str(p) for p in e.path) or "<root>"
            print(f" - {path}: {e.message}")
        sys.exit(4)


def _write_outputs(out_dir: str, resource: Dict[str, Any]) -> None:
    os.makedirs(out_dir, exist_ok=True)
    proxy_yaml_path = os.path.join(out_dir, "proxy.yaml")
    notes_path = os.path.join(out_dir, "migration_notes.md")
    with open(proxy_yaml_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(resource, f, sort_keys=False)
    with open(notes_path, "w", encoding="utf-8") as f:
        f.write("# Migration Notes (Phase-2 POC)\n\n")
        f.write("This file captures minimal notes for the extracted proxy.\n")
        f.write("Fields were defensively parsed from ESP response.\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Phase-2: Extract one proxy from ESP and generate proxy.yaml")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("extract", help="Extract proxy details and generate schema-valid proxy.yaml")
    p.add_argument("--proxy", required=True, help="Proxy name to match from ESP response")
    p.add_argument("--env", required=True, help="Environment value to pass to ESP endpoint")
    p.add_argument("--output", required=True, help="Output directory (will contain proxy.yaml and migration_notes.md)")
    p.add_argument("--sysgen", required=True, help="SYSGEN/MAL code to satisfy schema labels.sysgen")
    p.add_argument("--taxonomy", required=True, help="Taxonomy label, e.g., /Channel/v1/Portal")
    p.add_argument("--template", default=DEFAULT_TEMPLATE, help="Template to use (must be one of schema enum)")
    p.add_argument("--base-url", dest="base_url", required=True, help="ESP base URL, e.g., https://esp.corp")
    p.add_argument("--ca-bundle", dest="ca_bundle", default=None, help="Path to corporate CA bundle (PEM)")
    p.add_argument("--insecure", action="store_true", help="Disable TLS verification (dev only)")

    args = parser.parse_args()

    schema = _read_schema()

    resp = _request(args.base_url, args.env, args.ca_bundle, args.insecure)
    print(f"ESP URL: {resp.url}")
    print(f"Status: {resp.status_code}")
    ct = resp.headers.get("Content-Type", "")
    print(f"Content-Type: {ct}")

    try:
        payload = resp.json()
    except Exception:
        snippet = resp.text[:500]
        print("ERROR: Non-JSON response from ESP. First 500 chars:")
        print(snippet)
        sys.exit(5)

    if isinstance(payload, dict) and "items" in payload and isinstance(payload["items"], list):
        items = payload["items"]
    elif isinstance(payload, list):
        items = payload
    else:
        items = []

    match = None
    for item in items:
        if isinstance(item, dict) and _match_proxy(item, args.proxy):
            match = item
            break

    if not match:
        print(f"ERROR: Proxy '{args.proxy}' not found in ESP response.")
        sys.exit(6)

    fields = _extract_fields(match)
    # Build resource honoring minimal schema
    resource = _build_resource(fields, sysgen=args.sysgen, taxonomy=args.taxonomy, template=args.template)

    # Validate against schema
    _validate_resource(resource, schema)

    # Write outputs
    ts = dt.datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    out_dir = os.path.join(args.output, args.proxy, ts)
    _write_outputs(out_dir, resource)

    print("\nSuccess: proxy.yaml generated and validated.")
    print(f"Output folder: {out_dir}")
    print("Files:")
    print(" - proxy.yaml")
    print(" - migration_notes.md")


if __name__ == "__main__":
    main()
