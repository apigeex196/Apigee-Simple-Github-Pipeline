#!/usr/bin/env python3
"""
Phase-2 OPDK Management API probe

Purpose:
- Stop using ESP (8443) endpoints and switch to OPDK Management API (8080).
- Use Basic Auth only (OPDK_USER/OPDK_PASS).
- Call:
  - GET /v1/organizations/{org}/apis/{proxyName}
  - GET /v1/organizations/{org}/environments/{env}/apis/{proxyName}
- Save raw JSON to output/opdk_probe/<proxyName>/<timestamp>/
- Print a clean console summary safely.

Environment variables:
- OPDK_BASE_URL (e.g., http://4.72.75.223:8080)
- OPDK_ORG (e.g., ext or actual OPDK org name)
- OPDK_ENV (e.g., prod)
- OPDK_PROXY_NAME (e.g., Esp_ExtMed_...)
- OPDK_USER, OPDK_PASS
- OPDK_DISABLE_SSL_VERIFY=1 (optional, disables SSL verification)

Usage (Windows PowerShell):
  $env:OPDK_BASE_URL="http://4.72.75.223:8080"; \
  $env:OPDK_ORG="ext"; \
  $env:OPDK_ENV="prod"; \
  $env:OPDK_PROXY_NAME="Esp_ExtMed_34S_v1_ntfwSrvImpPort_a3c78fe9-c486-4c27-a235-35347e3315d4"; \
  $env:OPDK_USER="your-user"; $env:OPDK_PASS="your-pass"; \
  python scripts/opdk_probe.py

Usage (bash):
  OPDK_BASE_URL="http://4.72.75.223:8080" \
  OPDK_ORG="ext" \
  OPDK_ENV="prod" \
  OPDK_PROXY_NAME="Esp_ExtMed_34S_v1_ntfwSrvImpPort_a3c78fe9-c486-4c27-a235-35347e3315d4" \
  OPDK_USER="your-user" OPDK_PASS="your-pass" \
  python3 scripts/opdk_probe.py

Exit codes:
- 0 on success when both endpoints return JSON and HTTP 200
- non-zero on auth failure, 404, non-JSON, network errors, or partial failure
"""

import json
import os
import sys
import time
from typing import Any, Dict, List, Tuple

import requests
from requests.auth import HTTPBasicAuth


TIMEOUT_SECONDS = 20


def read_env() -> Dict[str, str]:
    env = {
        "base_url": os.getenv("OPDK_BASE_URL", ""),
        "org": os.getenv("OPDK_ORG", ""),
        "env": os.getenv("OPDK_ENV", ""),
        "proxy": os.getenv("OPDK_PROXY_NAME", ""),
        "user": os.getenv("OPDK_USER", ""),
        "pass": os.getenv("OPDK_PASS", ""),
        "disable_ssl_verify": os.getenv("OPDK_DISABLE_SSL_VERIFY", "") in ("1", "true", "True"),
    }
    return env


def validate_env(env: Dict[str, str]) -> Tuple[bool, List[str]]:
    missing = []
    for key in ("base_url", "org", "env", "proxy", "user", "pass"):
        if not env.get(key):
            missing.append(key)
    return (len(missing) == 0, missing)


def build_urls(base_url: str, org: str, env: str, proxy: str) -> Tuple[str, str]:
    base = base_url.rstrip("/")
    url_apis = f"{base}/v1/organizations/{org}/apis/{proxy}"
    url_env_apis = f"{base}/v1/organizations/{org}/environments/{env}/apis/{proxy}"
    return url_apis, url_env_apis


def is_json_response(resp: requests.Response) -> bool:
    ct = resp.headers.get("Content-Type", "").lower()
    if "application/json" in ct:
        return True
    # Try parsing JSON defensively
    try:
        _ = resp.json()
        return True
    except Exception:
        return False


def safe_json(resp: requests.Response) -> Any:
    try:
        return resp.json()
    except Exception:
        return None


def mkdir_p(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def write_text(path: str, content: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def write_json(path: str, obj: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def find_values(obj: Any, keys: List[str]) -> Dict[str, Any]:
    """Best-effort recursive search for specific keys (case-insensitive)."""
    results: Dict[str, Any] = {}

    def rec(o: Any):
        if isinstance(o, dict):
            for k, v in o.items():
                for target in keys:
                    if k.lower() == target.lower():
                        # Only set first occurrence per target
                        results.setdefault(target, v)
                rec(v)
        elif isinstance(o, list):
            for i in o:
                rec(i)

    rec(obj)
    return results


def summarize_json(label: str, data: Any) -> Dict[str, Any]:
    keys_to_find = [
        "revisions",  # list of revisions
        "revision",   # single revision
        "deployments",
        "deployedRevision",
        "basePath",
        "basePaths",
        "virtualHosts",
        "targetEndpoints",
        "targets",
        "backend",
        "backendurl",
    ]
    found = find_values(data, keys_to_find) if isinstance(data, (dict, list)) else {}
    return {"label": label, "found": found}


def do_get(url: str, env: Dict[str, str]) -> requests.Response:
    verify = not env["disable_ssl_verify"]
    if not verify:
        print("Warning: SSL verification disabled (OPDK_DISABLE_SSL_VERIFY=1)")
    auth = HTTPBasicAuth(env["user"], env["pass"]) if env["user"] and env["pass"] else None
    return requests.get(url, auth=auth, verify=verify, timeout=TIMEOUT_SECONDS)


def main() -> int:
    env = read_env()
    ok, missing = validate_env(env)
    if not ok:
        print("ERROR: Missing required env vars:", ", ".join(missing))
        print("Required: OPDK_BASE_URL, OPDK_ORG, OPDK_ENV, OPDK_PROXY_NAME, OPDK_USER, OPDK_PASS")
        return 2

    url_apis, url_env_apis = build_urls(env["base_url"], env["org"], env["env"], env["proxy"])
    ts = time.strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join("output", "opdk_probe", env["proxy"], ts)
    mkdir_p(out_dir)

    failures = 0

    # Call 1: /v1/organizations/{org}/apis/{proxy}
    print(f"Calling: {url_apis}")
    try:
        resp1 = do_get(url_apis, env)
        print(f"Status: {resp1.status_code}")
    except Exception as e:
        print(f"ERROR: Request failed for {url_apis}: {e}")
        write_text(os.path.join(out_dir, "errors.txt"), f"{url_apis}: {e}\n")
        return 3

    data1_path = os.path.join(out_dir, "apis.json")
    if resp1.status_code == 200 and is_json_response(resp1):
        data1 = safe_json(resp1)
        write_json(data1_path, data1)
        sum1 = summarize_json("apis", data1)
    else:
        failures += 1
        snippet = resp1.text[:300]
        write_text(os.path.join(out_dir, "errors.txt"), f"{url_apis}: non-JSON or status {resp1.status_code}\n{snippet}\n")
        sum1 = {"label": "apis", "found": {}}

    # Call 2: /v1/organizations/{org}/environments/{env}/apis/{proxy}
    print(f"Calling: {url_env_apis}")
    try:
        resp2 = do_get(url_env_apis, env)
        print(f"Status: {resp2.status_code}")
    except Exception as e:
        print(f"ERROR: Request failed for {url_env_apis}: {e}")
        write_text(os.path.join(out_dir, "errors.txt"), f"{url_env_apis}: {e}\n")
        return 3

    data2_path = os.path.join(out_dir, "env_apis.json")
    if resp2.status_code == 200 and is_json_response(resp2):
        data2 = safe_json(resp2)
        write_json(data2_path, data2)
        sum2 = summarize_json("env_apis", data2)
    else:
        failures += 1
        snippet = resp2.text[:300]
        write_text(os.path.join(out_dir, "errors.txt"), f"{url_env_apis}: non-JSON or status {resp2.status_code}\n{snippet}\n")
        sum2 = {"label": "env_apis", "found": {}}

    # Console summary
    print("")
    print("Summary:")
    print(f"- proxy: {env['proxy']}")
    print(f"- org: {env['org']}")
    print(f"- env: {env['env']}")

    def print_field(label: str, found: Dict[str, Any], key: str):
        val = found.get(key)
        if val is None:
            print(f"  - {label}: Not present")
        else:
            if isinstance(val, (dict, list)):
                try:
                    print(f"  - {label}: {json.dumps(val)[:300]}")
                except Exception:
                    print(f"  - {label}: present (complex)")
            else:
                print(f"  - {label}: {val}")

    print("- apis endpoint findings:")
    for k, lbl in (
        ("revisions", "revisions"),
        ("revision", "revision"),
        ("basePath", "basePath"),
        ("basePaths", "basePaths"),
        ("virtualHosts", "virtualHosts"),
        ("targetEndpoints", "targetEndpoints"),
        ("targets", "targets"),
        ("backend", "backend"),
        ("backendurl", "backendURL"),
    ):
        print_field(lbl, sum1["found"], k)

    print("- env_apis endpoint findings:")
    for k, lbl in (
        ("deployedRevision", "deployedRevision"),
        ("deployments", "deployments"),
        ("basePath", "basePath"),
        ("basePaths", "basePaths"),
        ("virtualHosts", "virtualHosts"),
        ("targetEndpoints", "targetEndpoints"),
        ("targets", "targets"),
        ("backend", "backend"),
        ("backendurl", "backendURL"),
    ):
        print_field(lbl, sum2["found"], k)

    if failures:
        print("")
        print(f"Probe completed with {failures} failure(s). See {os.path.join(out_dir, 'errors.txt')} if present.")
        return 1

    print("")
    print(f"Success. Raw outputs saved to {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
