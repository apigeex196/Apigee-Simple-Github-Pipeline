#!/bin/bash
# Script to extract CICD SA keys from GitHub Secrets and store them locally

set -e

echo "=========================================="
echo "🔑 Extracting CICD SA Keys from Secrets"
echo "=========================================="
echo ""

# Create directory if it doesn't exist
mkdir -p ~/.gcp

# Get the secrets and decode from base64
echo "Fetching DEV CICD SA key..."
gh secret list | grep GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01 && \
  echo "⚠️  Cannot directly read secrets via CLI - they are encrypted"

echo ""
echo "=========================================="
echo "Alternative: Use GitHub Actions to output keys"
echo "=========================================="
echo ""
echo "The CICD SA keys are stored as GitHub Secrets and cannot be"
echo "directly extracted via CLI. Here are your options:"
echo ""
echo "Option 1: Use Google Cloud Console"
echo "  1. Go to each GCP project's IAM & Admin > Service Accounts"
echo "  2. Find: sa-apigeex-cicd@gcp-prj-apigee-{env}-XX-XX.iam.gserviceaccount.com"
echo "  3. Create a new key (JSON) and download"
echo "  4. Save as ~/.gcp/sa-apigeex-cicd-{env}.json"
echo ""
echo "Option 2: Extract from Secret Manager (if stored there)"
echo "  DEV:"
echo "    gcloud secrets versions access latest --secret=GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01 --project=gcp-prj-apigee-dev-np-01 > ~/.gcp/sa-apigeex-cicd-dev.json"
echo "  QA:"
echo "    gcloud secrets versions access latest --secret=GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01 --project=gcp-prj-apigee-qa-np-01 > ~/.gcp/sa-apigeex-cicd-qa.json"
echo "  PROD:"
echo "    gcloud secrets versions access latest --secret=GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01 --project=gcp-prj-apigee-prod-01 > ~/.gcp/sa-apigeex-cicd-prod.json"
echo ""
echo "Option 3: Use existing workflow authentication"
echo "  Authenticate using your current gcloud credentials and use impersonation:"
echo "    gcloud config set auth/impersonate_service_account sa-apigeex-cicd@gcp-prj-apigee-{env}-XX-XX.iam.gserviceaccount.com"
echo ""
