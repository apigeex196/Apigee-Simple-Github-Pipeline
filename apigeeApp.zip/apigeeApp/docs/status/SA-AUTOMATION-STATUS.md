# Service Account Automation - CCOE Integration Status

**Date**: February 4, 2026 (Updated)
**Initial Meeting**: January 7, 2026
**Status**: ✅ **UNBLOCKED** - Master SA provisioned, roles verified

## 🎉 MAJOR UPDATE - February 4, 2026

✅ **CCOE PR #3509 MERGED** - Master automation SA provisioned
✅ **Eric ran `terraform apply`** - Infrastructure live in all 3 orgs
✅ **Roles verified** - All required permissions confirmed working

**Master SA Created**: `sa-apigeex-mal-provisioning@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com`

**Next Step**: Add SA key to GitHub Secret `GCP_SA_MAL_PROVISIONING` for workflow testing

---

## **Decision Summary**

✅ **APPROVED APPROACH**: Terraform-based SA provisioning via PR workflow

**CCOE Contact**: [Name from meeting]
**Terraform Repo**: `https://github.com/CenturyLink/tf-landingzones-infra--gcp-workloads-infra`

---

## **Implementation Details**

### **Target Directories** (per org)

**DEV**:
`root/nonprod/svc-nonprod-shared/nonprod-apigee/gcp-prj-apigee-dev-np-01/iam/`

**QA/TEST**:
`root/nonprod/svc-nonprod-shared/nonprod-apigee/gcp-prj-apigee-qa-np-01/iam/`

**PROD**:
`root/prod/svc-prod-shared/prod-apigee/gcp-prj-apigee-prod-01/iam/`

---

### **File Structure** (Confirmed from Repo Analysis)

CCOE mentioned **two separate files** in each directory:

#### **File 1: Service Account Creation**
**Filename**: `service-accounts.tf` (or `sa-<name>.tf`)
**Example**: [gcp-prj-apigee-dev-np-01/iam/service-accounts.tf](https://github.com/CenturyLink/tf-landingzones-infra--gcp-workloads-infra/blob/main/root/nonprod/svc-nonprod-shared/nonprod-apigee/gcp-prj-apigee-dev-np-01/iam/service-accounts.tf)

```terraform
resource "google_service_account" "sa-apigee-dev" {
  project      = var.project_id
  account_id   = "sa-apigee-dev"
  display_name = "Service Account - Apigee dev"
  description  = "service account for Apigee dev"
}

resource "google_service_account" "sa-apigee-cicd" {
  project      = var.project_id
  account_id   = "sa-apigeex-cicd"
  display_name = "CICD Service Account - Apigee dev"
  description  = "CICD service account for Apigee dev"
}
```

#### **File 2: IAM Role Bindings**
**Filename**: `iam-service-account.tf`
**Example**: [gcp-prj-apigee-dev-np-01/iam/iam-service-account.tf](https://github.com/CenturyLink/tf-landingzones-infra--gcp-workloads-infra/blob/main/root/nonprod/svc-nonprod-shared/nonprod-apigee/gcp-prj-apigee-dev-np-01/iam/iam-service-account.tf)

```terraform
resource "google_project_iam_member" "sa_apigee_mgmnt_dev" {
  project = var.project_id
  member  = "serviceAccount:sa-apigeex-mgmt-svc@${var.project_id}.iam.gserviceaccount.com"
  for_each = tomap({
    "${data.google_iam_role.Apigee_API_Admin.title}"          = data.google_iam_role.Apigee_API_Admin.name,
    "${data.google_iam_role.Apigee_Environment_Admin.title}"  = data.google_iam_role.Apigee_Environment_Admin.name,
    "${data.google_iam_role.Logs_Configuration_Writer.title}" = data.google_iam_role.Logs_Configuration_Writer.name,
  })
  role = each.value
}
```

---

## **Workflow Design**

### **High-Level Flow**

```
┌─────────────────────────────────────────────────────┐
│  1. API Producer creates MAL folder                 │
│     mal-SYSGEN788836350/                            │
└────────────────┬────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────┐
│  2. GitHub Actions detects new MAL                  │
│     Workflow: provision-service-account.yml         │
└────────────────┬────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────┐
│  3. Generate Terraform files (per org):             │
│     • SYSGEN788836350-service-account.tf            │
│     • SYSGEN788836350-iam-bindings.tf               │
└────────────────┬────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────┐
│  4. Open PR to CCOE Terraform repo                  │
│     Target: tf-landingzones-infra--gcp-*            │
│     Branches:                                       │
│     • DEV:  .../gcp-prj-apigee-dev-np-01/iam/      │
│     • QA:   .../gcp-prj-apigee-qa-np-01/iam/       │
│     • PROD: .../gcp-prj-apigee-prod-01/iam/        │
└────────────────┬────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────┐
│  5. API Enablement Team reviews/approves PR        │
│     Manual review gate                              │
└────────────────┬────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────┐
│  6. Merge PR                                        │
└────────────────┬────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────┐
│  7. CCOE Automation runs Terraform                  │
│     • Creates service account                       │
│     • Grants IAM roles                              │
│     • (Optionally) stores key in Secret Manager    │
└─────────────────────────────────────────────────────┘
```

---

## **Required Roles for API Producer SAs**

Based on existing patterns in repo:

```terraform
# Required for Apigee deployment
roles/apigee.apiAdminV2           # Deploy proxies
roles/apigee.environmentAdmin     # Manage environments
roles/secretmanager.secretAccessor # Read secrets (KVMs, OAuth)
roles/logging.logWriter            # Write logs (optional)
```

**Note**: Need to confirm exact role names with CCOE - may use custom roles like `Lumen_ApigeeX_Manager`

---

## **TODO / Open Questions**

### **HIGH PRIORITY**

- [ ] **Access Permissions**: Get write access to CCOE Terraform repo for PR creation
  - GitHub App token? PAT? Fork permissions?
  - Contact: [CCOE contact from meeting]

- [ ] **Terraform Template**: Get example/template for API producer SA files
  - What variables are available? (`var.project_id`, etc.)
  - Data sources for roles? (`data.google_iam_role.Apigee_API_Admin`)
  - Naming conventions for resources

- [ ] **SA Key Management**: ✅ **CONFIRMED** - Separate tool needed for key generation
  - **CCOE Response**: Terraform does NOT handle key generation
  - **CCOE has a separate tool** that:
    - Generates SA keys
    - Stores keys in Secret Manager automatically
  - **Two Options**:
    - **Option A**: CCOE grants us access to their key gen tool (preferred)
    - **Option B**: We build our own workflow to generate + store keys
  - **Our Requirements**:
    - Store with pattern: `sa-apigeex-{MAL_CODE}`
    - Store in same project as Apigee org (e.g., `gcp-prj-apigee-dev-np-01`)
    - Our `get-service-account` action retrieves from Secret Manager automatically
  - **Next**: Follow up with CCOE on access to their tool vs self-service

- [ ] **Multi-Org PR Strategy**: Single PR with 3 org changes or separate PRs?
  - Prefer single PR for consistency
  - Confirm CCOE automation handles multi-directory changes

- [ ] **PROD Org Path**: Confirm PROD path structure
  - Shown: `root/prod/svc-prod-shared/prod-apigee/gcp-prj-apigee-prod-01/iam/`
  - Different approval process for PROD?

### **MEDIUM PRIORITY**

- [ ] **Existing SA Pattern**: Review existing `sa-apigeex-cicd` accounts
  - Current role bindings in DEV/QA/PROD
  - Can we replicate this pattern for API producers?

- [ ] **Terraform Variables**: Understand available variables
  - `var.project_id` confirmed
  - What else? MAL code? Environment?

- [ ] **CCOE Documentation**: Request internal docs
  - Terraform module usage
  - PR workflow
  - Approval SLAs

### **LOW PRIORITY**

- [ ] **Cleanup Strategy**: What happens when MAL folder deleted?
  - Manual SA removal?
  - Automated via workflow?

- [ ] **Testing Plan**: How to test before production?
  - DEV org first
  - Dry-run capability?

---

## **Next Steps**

1. **Today**: Review CCOE documentation (waiting for permissions)
2. **This Week**: Draft Terraform template files
3. **This Week**: Create `provision-service-account.yml` workflow (draft)
4. **Next Week**: Test with one MAL in DEV org
5. **Following Week**: Roll out to remaining MALs

---

## **Reference Links**

- **CCOE Terraform Repo**: https://github.com/CenturyLink/tf-landingzones-infra--gcp-workloads-infra
- **DEV IAM Directory**: [.../gcp-prj-apigee-dev-np-01/iam/](https://github.com/CenturyLink/tf-landingzones-infra--gcp-workloads-infra/tree/main/root/nonprod/svc-nonprod-shared/nonprod-apigee/gcp-prj-apigee-dev-np-01/iam)
- **QA IAM Directory**: [.../gcp-prj-apigee-qa-np-01/iam/](https://github.com/CenturyLink/tf-landingzones-infra--gcp-workloads-infra/tree/main/root/nonprod/svc-nonprod-shared/nonprod-apigee/gcp-prj-apigee-qa-np-01/iam)
- **PROD IAM Directory**: [.../gcp-prj-apigee-prod-01/iam/](https://github.com/CenturyLink/tf-landingzones-infra--gcp-workloads-infra/tree/main/root/prod/svc-prod-shared/prod-apigee/gcp-prj-apigee-prod-01/iam)
- **CCOE Meeting Brief**: [CCOE-MEETING-BRIEF.md](./CCOE-MEETING-BRIEF.md)

---

## **Status Updates**

**Feb 4, 2026**: 🎉 **UNBLOCKED** - CCOE PR #3509 merged, terraform applied, roles verified
**Jan 7, 2026**: ✅ CCOE meeting completed - Terraform approach approved
**Jan 7, 2026**: 📋 Documented file structure from repo analysis

## **Current Blockers**

**NONE** - Infrastructure ready for testing!

**Remaining tasks**:
1. Add `sa-apigeex-mal-provisioning` key to GitHub Secret `GCP_SA_MAL_PROVISIONING`
2. Test workflow with dry-run mode
3. Test actual SA creation in DEV environment
4. Roll out to QA and PROD
