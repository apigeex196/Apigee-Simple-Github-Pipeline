# Deploy API Product Workflow

This workflow handles the automated deployment of API Products to Apigee X environments following a strict DEV → TEST → PROD promotion path.

## Overview

**Workflow File**: `.github/workflows/deploy-products.yml`  
**Purpose**: Deploy API Product definitions to Apigee X organizations  
**Execution Pattern**: Sequential deployment with environment dependencies

## Triggers

### Automatic Trigger (Push to Main)
```yaml
on:
  push:
    branches:
      - main
    paths:
      - "mal-SYSGEN*/products/*.yaml"
```

When product YAML files are pushed to `main`, the workflow automatically:
1. Detects changed product files
2. Deploys to DEV environment
3. If DEV succeeds, deploys to TEST
4. If TEST succeeds, deploys to PROD

### Manual Trigger (Workflow Dispatch)
```yaml
workflow_dispatch:
  inputs:
    environment:
      description: "Environment to deploy to"
      required: true
      type: choice
      options:
        - dev
        - test
        - prod
    changed_files:
      description: "Comma-separated list of changed product files"
      required: false
```

**Use Cases**:
- Deploy to a specific environment only
- Re-deploy specific product files
- Test deployments without pushing to main

**Example Manual Deployment**:
1. Go to **Actions** tab → **Deploy API Products**
2. Click **Run workflow**
3. Select environment: `dev`, `test`, or `prod`
4. (Optional) Specify files: `mal-SYSGEN788836350/products/my-product.yaml`
5. Click **Run workflow**

## Workflow Jobs

### Job 1: detect-changes
**Purpose**: Identify changed product files and extract metadata

**Steps**:
1. Checkout repository with full history
2. Detect changed files (via `changed-files` action or manual input)
3. Filter for product YAML files matching pattern: `mal-SYSGEN*/products/*.yaml`
4. Extract MAL code from file paths

**Outputs**:
- `changed-products`: Space-separated list of product file paths
- `has-changes`: Boolean indicating if products changed
- `mal-code`: Extracted MAL system code

### Job 2: deploy-dev
**Purpose**: Deploy products to DEV environment

**Environment**: `dev`  
**Organization**: `gcp-prj-apigee-dev-np-01`  
**Apigee Environment**: `apicc-dev`

**Execution**:
- Runs if changes detected AND (push to main OR manual with env=dev)
- Depends on: `detect-changes`

**Steps**:
1. Setup Apigee tooling (apigeecli, yq, jq)
2. Authenticate with GCP using `GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01` secret
3. For each changed product file:
   - Extract product metadata (name, display name, description)
   - Parse proxy references (handles both string arrays and object arrays)
   - **Validate all proxies are deployed** to the environment
   - Extract optional fields (approval, access, scopes, quota, environments, attributes)
   - Check if product exists (determines create vs update)
   - Build and execute `apigeecli products create/update` command
   - Report success or failure
4. Generate deployment summary with counts

### Job 3: deploy-test
**Purpose**: Deploy products to TEST environment

**Environment**: `test`  
**Organization**: `gcp-prj-apigee-qa-np-01`  
**Apigee Environment**: `apicc-test1`

**Execution**:
- Runs if changes detected AND (push to main OR manual with env=test)
- **Depends on**: `deploy-dev` (must succeed first)

**Steps**: Same as deploy-dev but deploys to TEST environment

### Job 4: deploy-prod
**Purpose**: Deploy products to PRODUCTION environment

**Environment**: `production`  
**Organization**: `gcp-prj-apigee-prod-01`  
**Apigee Environment**: `apicc-prod`

**Execution**:
- Runs if changes detected AND (push to main OR manual with env=prod)
- **Depends on**: `deploy-test` (must succeed first)

**Steps**: Same as deploy-dev but deploys to PROD with additional validation emphasis

## Product-Proxy Validation

**Critical Requirement**: All proxies referenced in a product **must be deployed** to the target environment before the product can be deployed.

### Validation Logic
For each product deployment, the workflow:
1. Extracts proxy list from `spec.proxies`
2. Checks if each proxy exists in the organization
3. Verifies each proxy is deployed to the target environment
4. **Blocks deployment** if any proxy is missing or not deployed

### Example Validation Output
```
🔍 Validating proxy deployments...
✅ Proxy 'OAUTH-KVM-OAS-TEST' deployed to apicc-dev
✅ Proxy 'SIMPLE-TEST' deployed to apicc-dev
✅ All proxies are deployed
```

### Validation Failure
```
::warning::Proxy 'MY-PROXY' not deployed to apicc-test1
::error::One or more proxies not deployed. Deploy proxies first.
```

**Resolution**: Deploy the missing proxies before attempting product deployment:
1. Ensure proxy YAML files are committed
2. Run proxy deployment workflow or wait for automatic deployment
3. Retry product deployment

## Product File Format

Products must follow the schema defined in `apiproduct.schema.json`:

```yaml
apiVersion: apigee/v1
kind: ApiProduct
metadata:
  name: MY-API-PRODUCT
  description: "API Product Description"
spec:
  displayName: "My API Product"
  approval: auto  # or manual
  access: internal  # or public, private
  proxies:
    - PROXY-NAME-1
    - PROXY-NAME-2
  scopes:
    - read
    - write
  quota:
    limit: 1000
    interval: 1
    timeUnit: minute
  environments:
    - apicc-dev
    - apicc-test1
  attributes:
    team: "platform-team"
    cost-center: "12345"
```

### Proxy Reference Formats

**Simple String Array** (recommended):
```yaml
spec:
  proxies:
    - OAUTH-KVM-OAS-TEST
    - SIMPLE-TEST
```

**Object Array** (also supported):
```yaml
spec:
  proxies:
    - name: OAUTH-KVM-OAS-TEST
    - name: SIMPLE-TEST
```

The workflow automatically detects and handles both formats.

## Deployment Sequence

### Automatic Deployment (Push to Main)
```
Push to main
    ↓
detect-changes
    ↓
deploy-dev (gcp-prj-apigee-dev-np-01)
    ↓ (on success)
deploy-test (gcp-prj-apigee-qa-np-01)
    ↓ (on success)
deploy-prod (gcp-prj-apigee-prod-01)
```

### Manual Deployment (Single Environment)
```
Workflow Dispatch (env=test)
    ↓
detect-changes
    ↓
deploy-dev (runs due to dependency)
    ↓
deploy-test (runs - target environment)
    ↓
deploy-prod (skipped)
```

**Note**: Manual deployments respect job dependencies. Due to `needs: [detect-changes, deploy-dev]`, deploying to TEST will first run DEV, then TEST. Similarly, deploying to PROD will run DEV → TEST → PROD in sequence. This ensures consistency and proper validation at each stage.

## Deployment Operations

### Create vs Update
The workflow automatically determines whether to create or update a product:

**Check**:
```bash
apigeecli products get --name "$PRODUCT_NAME" --org "$APIGEE_ORG"
```

**Action**:
- If product exists: `apigeecli products update`
- If product doesn't exist: `apigeecli products create`

### Command Construction
The workflow builds apigeecli commands dynamically based on product configuration:

**Base Command**:
```bash
apigeecli products create \
  --name "MY-PRODUCT" \
  --displayname "My API Product" \
  --org "gcp-prj-apigee-dev-np-01" \
  --token "$GCP_ACCESS_TOKEN"
```

**Optional Fields** (added if present in YAML):
- `--desc`: Product description
- `--proxies`: Comma-separated proxy list
- `--scopes`: Comma-separated OAuth scopes
- `--approval`: Approval type (auto/manual)
- `--access`: Access level (internal/public/private)
- `--quota`, `--interval`, `--unit`: Quota configuration
- `--envs`: Comma-separated environment list
- `--attrs`: Key=value attribute pairs

### Attribute Handling
Attributes are converted from YAML map to command-line format:

**YAML**:
```yaml
spec:
  attributes:
    team: platform-team
    cost-center: "12345"
    environment: dev
```

**Command**:
```bash
--attrs "team=platform-team" \
--attrs "cost-center=12345" \
--attrs "environment=dev"
```

## Output and Reporting

### Console Output
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 Deploying Products to apicc-dev
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📦 Product: MY-API-PRODUCT
📝 Display Name: My API Product
🔗 Associated Proxies: OAUTH-KVM-OAS-TEST,SIMPLE-TEST
🔍 Validating proxy deployments...
✅ All proxies are deployed
🔎 Checking if product exists...
✨ Product does not exist, will create
📝 Executing: apigeecli products create
✅ Product created successfully: MY-API-PRODUCT

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Deployment Summary
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Deployed: 1
❌ Failed: 0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎉 All products deployed successfully to apicc-dev
```

### GitHub Step Summary
Each deployment job adds a summary table to the workflow run:

```markdown
## Product Deployment - DEV

| Metric | Count |
|--------|-------|
| ✅ Deployed | 1 |
| ❌ Failed | 0 |

**Environment**: apicc-dev
**Organization**: gcp-prj-apigee-dev-np-01
```

## Error Handling

### Common Errors and Resolutions

#### 1. Proxy Not Deployed
```
::error::One or more proxies not deployed. Deploy proxies first.
```
**Resolution**: Deploy missing proxies using proxy deployment workflow

#### 2. Invalid Product Configuration
```
::error::No proxies defined for product MY-PRODUCT
```
**Resolution**: Add at least one proxy to `spec.proxies` in product YAML

#### 3. Authentication Failure
```
❌ GCP_SA_KEY secret not found for gcp-prj-apigee-dev-np-01
```
**Resolution**: Verify GCP service account secret is configured in repository settings

#### 4. Product Creation Failed
```
❌ Failed to create product: MY-PRODUCT
Error: [apigeecli error message]
```
**Resolution**: Check product configuration against schema, verify all required fields

### Exit Codes
- **0**: All products deployed successfully
- **1**: One or more products failed to deploy

The workflow fails fast on deployment errors to prevent cascading failures across environments.

## Security Considerations

### Authentication
- Uses GCP service account keys stored as GitHub secrets
- Separate service accounts per environment
- Access tokens are environment-scoped and temporary

### Secret Management
- Service account keys: `GCP_SA_KEY_GCP_PRJ_APIGEE_*`
- Keys are written to temporary files and cleaned up automatically
- Secrets are never logged or exposed in output

### Permissions
- Repository: `contents: read`
- GCP: `id-token: write` for Workload Identity (future enhancement)

## Dependencies

### GitHub Actions
- `actions/checkout@v4`: Repository checkout
- `./.github/actions/setup-apigee-tooling`: Install apigeecli, yq, jq
- `./.github/actions/changed-files`: Detect changed files

### External Tools
- `apigeecli`: Apigee X CLI for product operations
- `yq`: YAML processing and parsing
- `jq`: JSON processing for attributes
- `gcloud`: GCP authentication

### Environment Variables
Each job sets:
- `APIGEE_ORG`: Target Apigee organization
- `APIGEE_ENV`: Target Apigee environment
- `GCP_SA_KEY_PATH`: Path to service account key file
- `GCP_ACCESS_TOKEN`: Authenticated GCP token

## Best Practices

### Product File Organization
```
mal-SYSGEN788836350/
  products/
    my-api-product.yaml       # One product per file
    another-product.yaml
```

### Proxy References
- Always use exact proxy names as they appear in Apigee
- Deploy proxies before products
- Use consistent naming conventions

### Quota Configuration
```yaml
spec:
  quota:
    limit: 1000      # Number of requests
    interval: 1      # Time period count
    timeUnit: minute # minute, hour, day, month
```

### Attributes
- Use attributes for metadata and categorization
- Keep attribute values simple (strings, numbers)
- Avoid special characters in attribute keys

### Environment-Specific Products
If products vary by environment, use separate YAML files:
```
products/
  my-product-dev.yaml
  my-product-test.yaml
  my-product-prod.yaml
```

Or use conditional logic in product configuration.

## Troubleshooting

### Workflow Not Triggering
**Symptom**: Push to main doesn't trigger workflow  
**Check**:
1. File path matches: `mal-SYSGEN*/products/*.yaml`
2. Push was to `main` branch
3. Workflow file is valid YAML

### Product Deployment Stuck
**Symptom**: Deployment hangs or times out  
**Resolution**:
1. Check apigeecli command execution in logs
2. Verify GCP authentication succeeded
3. Check Apigee API status
4. Verify product configuration is valid

### Proxy Validation Fails
**Symptom**: Proxy validation fails even though proxy exists  
**Resolution**:
1. Verify proxy is deployed to the **specific environment**
2. Check proxy name matches exactly (case-sensitive)
3. Ensure proxy deployment completed successfully

### Manual Deployment Not Working
**Symptom**: Manual workflow dispatch doesn't run  
**Check**:
1. Workflow is on `main` branch
2. Specified environment is valid (dev/test/prod)
3. File paths in `changed_files` input are correct

## Related Documentation

- [API Product Schema](../../apiproduct.schema.json)
- [Validate Product Workflow](./validate-product.md)
- [Validate Proxy Workflow](./validate-proxy.md)
- [Repository Configuration](../repository-configuration.md)

## Support

For issues or questions:
1. Check workflow run logs in GitHub Actions
2. Review product YAML against schema
3. Verify proxy deployments are complete
4. Contact platform team for access issues
