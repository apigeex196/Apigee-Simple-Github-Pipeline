# Validate Product YAML Workflow

Automatically validates API product YAML configurations on pull requests.

## Trigger

- **Event**: Pull Request
- **Paths**: 
  - `mal-SYSGEN*/products/*.yaml`
  - `apiproduct.schema.json`
  - `.github/workflows/validate-product.yml`
- **Manual**: `workflow_dispatch`

## Validation Checks

### 1. YAML Syntax Validation
- Uses `yq` to validate YAML syntax
- Ensures files are well-formed YAML

### 2. Schema Validation
- Validates against `apiproduct.schema.json` using `ajv-cli`
- Ensures all required fields are present
- Validates data types and formats

### 3. Naming Convention Validation
- Product name must follow pattern: `SYSGEN[0-9]{9}-*`
- Example: `SYSGEN123456789-my-product`

### 4. Proxy Reference Validation
- Extracts `spec.proxies[]` from product YAML
- Validates each referenced proxy exists in the MAL folder
- Checks for proxy directories under `mal-SYSGEN*/proxies/`

### 5. Quota Configuration Validation
- Validates `spec.quota.limit` is a number
- Validates `spec.quota.interval` is a number
- Validates `spec.quota.timeUnit` is one of: `minute`, `hour`, `day`, `month`

### 6. OAuth Scopes Validation
- Checks for `spec.scopes[]` configuration
- Lists configured scopes

## Workflow Steps

1. **Checkout code** - Fetches repository with full history
2. **Install validation tools** - Installs ajv-cli (yq, jq pre-installed)
3. **Detect changed files** - Uses changed-files action
4. **Validate product files** - Runs all validation checks
5. **Generate summary** - Creates detailed validation report
6. **Check validation status** - Fails if any validation errors

## Outputs

### Workflow Summary
The workflow creates a detailed summary including:
- ✅ or ❌ for each validated product file
- Specific validation errors with file locations
- Proxy reference validation results
- Quota and scope configuration validation

### Exit Codes
- **0**: All validations passed
- **1**: One or more validations failed

## Example Validation Results

### Success
```markdown
## Product YAML Validation Results

### Validation Results

✅ **mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml** - All validations passed

---

✅ **All validations passed!** Products are ready for deployment.
```

### Failure with Errors
```markdown
## Product YAML Validation Results

### Validation Results

❌ **mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml** - Proxy `SYSGEN123456789-missing-api` not found in `mal-SYSGEN123456789/proxies/`

❌ **mal-SYSGEN123456789/products/bad-product.yaml** - Invalid product name: `bad-product` (must start with SYSGEN[0-9]{9}-)

---

❌ **Validation failed.** Please fix the errors above before merging.
```

## Common Validation Errors

### Invalid YAML Syntax
```
❌ **mal-SYSGEN123456789/products/my-product.yaml** - Invalid YAML syntax
```
**Fix**: Check for proper YAML indentation and syntax

### Schema Validation Failed
```
❌ **mal-SYSGEN123456789/products/my-product.yaml** - Schema validation failed
   ```
   data/metadata should have required property 'name'
   ```
```
**Fix**: Ensure all required fields are present according to apiproduct.schema.json

### Invalid Product Name
```
❌ **mal-SYSGEN123456789/products/my-product.yaml** - Invalid product name: `my-product` 
    (must start with SYSGEN[0-9]{9}-)
```
**Fix**: Rename product to follow pattern, e.g., `SYSGEN123456789-my-product`

### Proxy Reference Not Found
```
❌ **mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml** - Proxy `SYSGEN123456789-api` 
    not found in `mal-SYSGEN123456789/proxies/`
```
**Fix**: 
- Ensure the proxy directory exists: `mal-SYSGEN123456789/proxies/SYSGEN123456789-api/`
- Check the proxy name matches exactly (case-sensitive)
- Create the proxy or fix the reference in the product YAML

### Invalid Quota Configuration
```
❌ **mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml** - Invalid quota timeUnit: `weekly`
```
**Fix**: Use valid timeUnit values: `minute`, `hour`, `day`, or `month`

### No Proxy References
```
⚠️ **mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml** - No proxy references found
```
**Fix**: Add proxy references to `spec.proxies[]` array

## Product YAML Example

### Valid Product Configuration

```yaml
metadata:
  name: SYSGEN123456789-my-product
  displayName: My API Product
  description: Product for my APIs

spec:
  # Proxy references - must exist in mal-SYSGEN123456789/proxies/
  proxies:
    - SYSGEN123456789-example-api
    - SYSGEN123456789-another-api
  
  # Quota configuration (optional)
  quota:
    limit: 1000
    interval: 1
    timeUnit: day
  
  # OAuth scopes (optional)
  scopes:
    - read
    - write
  
  # Environments (optional)
  environments:
    - dev
    - test
    - prod
  
  # Attributes (optional)
  attributes:
    access: public
```

## Testing

### Manual Test
Create a PR that modifies a product YAML file:

```bash
# Make a change to product
echo "# Test change" >> mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml

# Commit and push
git add mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
git commit -m "Test: Trigger product validation workflow"
git push

# Create PR
gh pr create --title "Test Product Validation" --body "Testing product validation workflow"
```

### Test Invalid Product
To test validation errors, temporarily break a product:

```bash
# Invalid YAML syntax
echo "invalid: yaml: syntax:" >> mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml

# Invalid product name
yq eval '.metadata.name = "invalid-name"' -i mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml

# Invalid proxy reference
yq eval '.spec.proxies += ["non-existent-proxy"]' -i mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml

# Invalid quota configuration
yq eval '.spec.quota.timeUnit = "weekly"' -i mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
```

### Manual Workflow Dispatch
Trigger validation manually:

```bash
# Using GitHub CLI
gh workflow run validate-product.yml

# Or via GitHub UI:
# Actions → Validate Product YAML → Run workflow
```

## Dependencies

### Tools (Pre-installed in ubuntu-latest)
- `yq` - YAML processor
- `jq` - JSON processor
- `grep` - Text search

### Tools (Installed by workflow)
- `ajv-cli` - JSON schema validator
- `ajv-formats` - Additional format validators

### Actions
- `actions/checkout@v4` - Repository checkout
- `./.github/actions/changed-files` - Detect changed files

### Files
- `apiproduct.schema.json` - Product YAML schema

## Related Workflows

- **validate-proxy.yml** - Validates proxy YAML files
- **validate-mal-structure.yml** - Validates MAL folder structure
- **test-changed-files.yml** - Tests the changed-files action

## Next Steps

After this workflow passes:
1. Merge PR with confidence that product YAML is valid
2. Product will be deployed to environments on merge to main
3. Referenced proxies must exist and be deployed first

## Deployment Order

⚠️ **Important**: Proxies must be deployed before products that reference them.

**Correct order**:
1. Create/update proxy YAML files
2. Validate and merge proxy changes
3. Deploy proxies to target environment
4. Create/update product YAML files (referencing deployed proxies)
5. Validate and merge product changes
6. Deploy products to target environment

## Troubleshooting

### Workflow not triggering
- Ensure PR modifies files matching `mal-SYSGEN*/products/*.yaml`
- Check workflow file is on the target branch
- Verify file path follows exact pattern (no subdirectories)

### ajv-cli installation fails
- Check npm registry is accessible
- Verify ubuntu-latest runner has npm installed
- Check npm version: `npm --version`

### Proxy reference validation fails
- Verify proxy directory exists: `mal-SYSGEN123456789/proxies/{proxy-name}/`
- Check exact spelling and case (names are case-sensitive)
- Ensure proxy follows naming convention: `SYSGEN[0-9]{9}-*`
- Verify the proxy isn't in a deleted state

### No changes detected
- Ensure product file has `.yaml` extension (not `.yml`)
- Verify file is in correct location: `mal-SYSGEN*/products/`
- Check `changed-files` action output in workflow logs

### Schema validation errors
- Review `apiproduct.schema.json` for required fields
- Ensure all required metadata fields are present
- Validate data types match schema (strings, numbers, arrays)
- Check for typos in field names

## Security

### Permissions
- Workflow has `permissions: contents: read` (minimal required)
- No write permissions needed for validation
- No secrets required

### Input Validation
- All inputs are sanitized before use
- File paths are validated to prevent directory traversal
- YAML content is not executed, only validated

## Performance

### Optimization
- Only validates changed product files (not all files)
- Uses yq/jq (pre-installed tools) for fast parsing
- ajv-cli provides fast JSON schema validation
- Parallel validation (processes multiple files in loop)

### Typical Run Time
- **Empty change**: ~5 seconds
- **1 product file**: ~15-20 seconds
- **Multiple products**: +5-10 seconds per file

## Best Practices

1. **One product per file**: Keep products in separate YAML files
2. **Meaningful names**: Use descriptive product names after SYSGEN prefix
3. **Document scopes**: Add comments explaining OAuth scopes
4. **Test locally**: Validate YAML syntax locally before pushing
5. **Reference deployed proxies**: Only reference proxies that exist
6. **Set reasonable quotas**: Configure quotas based on API capacity

## Local Validation

Before pushing changes, validate locally:

```bash
# Install tools
npm install -g ajv-cli ajv-formats

# Validate YAML syntax
yq eval '.' mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml

# Convert to JSON and validate schema
yq eval -o=json '.' mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml | \
  ajv validate -s apiproduct.schema.json -d - --spec=draft7

# Check naming convention
yq eval '.metadata.name' mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml

# List proxy references
yq eval '.spec.proxies[]' mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
```

## Story Reference

**JIRA**: DPEAPI-18713  
**Epic**: DPEAPI-18215  
**Related Stories**: 
- DPEAPI-18698 (Validate Proxy YAML)
- DPEAPI-18711 (Validate Product Action)
- DPEAPI-18701 (Copy Schemas)
