# Guardrails & Validation User Stories

**Parent Feature**: DPEAPI-20555 - Template Guardrails and Validation Enhancement
**Created**: February 4, 2026
**Epic**: DPEAPI-19358 - Apigee X CI/CD Platform

> **Note**: See `GUARDRAILS-VALIDATION-ANALYSIS.md` for detailed gap analysis and technical requirements.

---

## Story Priority Classification
- 🚀 **Quick Win** - Low effort, high value, minimal risk
- ⚠️ **Requires Audit** - Needs data collection before implementation
- 🔧 **Infrastructure Dependency** - Requires external system/decision
- 📋 **Standard Implementation** - Normal complexity

---

## TIER 1: Quick Wins (Sprint-Ready)

### Story 1: Add Support Metadata Fields (SNOW Group & NET PIN)
**Story ID**: DPEAPI-XXXXX
**Type**: 🚀 Quick Win
**Parent**: DPEAPI-20555
**Priority**: High
**Estimate**: 3 points

**As a** Platform Engineer
**I want** to require support metadata fields in proxy YAML configurations
**So that** incident response teams can quickly identify the correct SNOW group and NET PIN for MTTR optimization

**Acceptance Criteria**:
- [ ] Schema updated with `metadata.support` object containing:
  - `serviceNowGroup` (required, string, pattern: `^[A-Z][A-Za-z0-9_-]+$`)
  - `netPin` (required, string, pattern: `^[A-Z0-9]{6,12}$`)
- [ ] Validation workflow checks for presence and format of both fields
- [ ] Validation fails with clear error message if fields missing or invalid
- [ ] Documentation updated with:
  - Field descriptions and purpose
  - Example values
  - How to find your team's SNOW group and NET PIN
- [ ] Deployment workflow extracts these fields and adds as custom attributes to Apigee proxy

**Technical Notes**:
```json
// Schema addition to apiproxy.schema.json
"metadata": {
  "properties": {
    "support": {
      "type": "object",
      "description": "Support and operational contact information",
      "properties": {
        "serviceNowGroup": {
          "type": "string",
          "pattern": "^[A-Z][A-Za-z0-9_-]+$",
          "description": "ServiceNow group for API Producer team (for SNOW ticket routing and incident response)"
        },
        "netPin": {
          "type": "string",
          "pattern": "^[A-Z0-9]{6,12}$",
          "description": "NET PIN for SWAT call escalation (for rapid incident response and MTTR optimization)"
        }
      },
      "required": ["serviceNowGroup", "netPin"],
      "additionalProperties": false
    }
  },
  "required": ["name", "labels", "support"]
}
```

**Validation Logic** (validate-proxy.yml):
```bash
# After YAML syntax validation
echo "Validating support metadata..."
SNOW_GROUP=$(yq eval '.metadata.support.serviceNowGroup // ""' "$proxy_file")
NET_PIN=$(yq eval '.metadata.support.netPin // ""' "$proxy_file")

if [ -z "$SNOW_GROUP" ]; then
  echo "::error file=$proxy_file::Missing required field: metadata.support.serviceNowGroup"
  PROXY_ERRORS=$((PROXY_ERRORS + 1))
fi

if [ -z "$NET_PIN" ]; then
  echo "::error file=$proxy_file::Missing required field: metadata.support.netPin"
  PROXY_ERRORS=$((PROXY_ERRORS + 1))
fi
```

**Files Changed**:
- `apiproxy.schema.json`
- `.github/workflows/validate-proxy.yml`
- `.github/actions/import-deploy-proxy/action.yml` (extract to custom attributes)
- `docs/guides/proxy-configuration.md` (documentation)

**Testing**:
- Valid proxy with both fields passes
- Missing serviceNowGroup fails validation
- Missing netPin fails validation
- Invalid format (lowercase, special chars) fails validation
- Fields appear as custom attributes on deployed proxy in Apigee

**Dependencies**: None

**Definition of Done**:
- Schema enforces both fields
- Validation workflow checks implemented
- CI/CD passes for valid configs, fails for invalid
- Fields visible in deployed Apigee proxy metadata
- Documentation complete with examples

---

### Story 2: Enforce Filename Matches Proxy Name
**Story ID**: DPEAPI-XXXXX
**Type**: 🚀 Quick Win
**Parent**: DPEAPI-20555
**Priority**: Medium
**Estimate**: 2 points

**As a** Platform Engineer
**I want** to enforce that YAML filename matches `metadata.name`
**So that** proxy configurations are consistently named and easy to locate

**Acceptance Criteria**:
- [ ] Validation checks that `basename(proxy_file, .yaml) == metadata.name`
- [ ] Clear error message shows both filename and metadata.name on mismatch
- [ ] Error message suggests correct action (rename file or update metadata.name)
- [ ] Documentation updated with naming convention examples

**Technical Implementation**:
```bash
# In validate-proxy.yml, after YAML syntax validation
echo "Validating filename matches metadata.name..."
FILENAME=$(basename "$proxy_file" .yaml)
PROXY_NAME=$(yq eval '.metadata.name' "$proxy_file")

if [ "$FILENAME" != "$PROXY_NAME" ]; then
  echo "::error file=$proxy_file::Filename mismatch - File: '$FILENAME.yaml', metadata.name: '$PROXY_NAME'"
  echo "  → Rename file to: $PROXY_NAME.yaml"
  echo "  → Or update metadata.name to: $FILENAME"
  PROXY_ERRORS=$((PROXY_ERRORS + 1))
fi
```

**Example Error Output**:
```
Error: Filename mismatch - File: 'my-old-name.yaml', metadata.name: 'SYSGEN788836350-my-api'
  → Rename file to: SYSGEN788836350-my-api.yaml
  → Or update metadata.name to: my-old-name
```

**Files Changed**:
- `.github/workflows/validate-proxy.yml`
- `docs/guides/proxy-naming-conventions.md`

**Testing**:
- Matching filename and metadata.name passes
- Mismatched names fail with helpful message
- Case sensitivity handled correctly

**Dependencies**: None

**Definition of Done**:
- Validation enforces filename = metadata.name
- Clear error messages guide remediation
- Documentation updated
- All existing proxies comply (may need one-time cleanup)

---

### Story 3: Add HTTPS Target Endpoint Enforcement
**Story ID**: DPEAPI-XXXXX
**Type**: 🚀 Quick Win (with migration coordination)
**Parent**: DPEAPI-20555
**Priority**: High (Security)
**Estimate**: 5 points

**As a** Security Engineer
**I want** to enforce HTTPS for all target endpoints
**So that** data in transit is encrypted and compliant with PCI DSS, GDPR, and NIST standards

**Acceptance Criteria**:
- [ ] Schema pattern enforces `spec.routing.target` starts with `https://`
- [ ] Validation fails for HTTP targets with security warning
- [ ] Exception field available: `spec.exceptions.targetHttpException`
- [ ] Warning-only mode for first 30 days (soft enforcement)
- [ ] Hard enforcement after grace period
- [ ] Migration guide created for API producers
- [ ] Communication sent to all proxy owners with HTTP targets

**Technical Implementation**:

**Schema Change**:
```json
"target": {
  "type": "string",
  "pattern": "^https://.*",
  "description": "Target endpoint URL. MUST use HTTPS for security compliance (PCI DSS, GDPR, NIST)."
},
"exceptions": {
  "type": "object",
  "properties": {
    "targetHttpException": {
      "type": "string",
      "pattern": "^EXC-[0-9]{10}$",
      "description": "Exception ID for non-HTTPS target endpoints (security review required)"
    }
  }
}
```

**Validation Logic** (Two-Phase):
```bash
# Phase 1: Warning only (30 days)
TARGET=$(yq eval '.spec.routing.target' "$proxy_file")
if [[ "$TARGET" =~ ^http:// ]]; then
  echo "::warning file=$proxy_file::⚠️  Security Warning: Target uses HTTP instead of HTTPS"
  echo "  Current: $TARGET"
  echo "  Required: https://${TARGET#http://}"
  echo "  ⏰ Hard enforcement begins: March 6, 2026"
  echo "  📋 Exception process: https://github.com/.../issues/new?template=exception-request.yml"
fi

# Phase 2: Error enforcement (after grace period)
TARGET=$(yq eval '.spec.routing.target' "$proxy_file")
TARGET_EXCEPTION=$(yq eval '.spec.exceptions.targetHttpException // ""' "$proxy_file")

if [[ "$TARGET" =~ ^http:// ]]; then
  if [ -z "$TARGET_EXCEPTION" ]; then
    echo "::error file=$proxy_file::🚨 Security Violation: Target endpoint must use HTTPS"
    echo "  Current: $TARGET"
    echo "  Required: https://${TARGET#http://}"
    echo "  Reason: Unencrypted HTTP violates PCI DSS, GDPR, and NIST standards"
    echo "  Action: Update backend to support HTTPS or request exception"
    PROXY_ERRORS=$((PROXY_ERRORS + 1))
  fi
fi
```

**Migration Coordination**:
1. Run audit to identify HTTP targets (see Story 4)
2. Communicate with proxy owners (email/Slack)
3. Provide migration guide and support
4. Enable warning mode (30 days)
5. Enable hard enforcement

**Files Changed**:
- `apiproxy.schema.json`
- `.github/workflows/validate-proxy.yml`
- `docs/guides/https-migration-guide.md` (new)
- `docs/guides/security-compliance.md` (update)

**Communication Template**:
```markdown
Subject: [Action Required] HTTPS Enforcement for API Target Endpoints

Your API proxy [{PROXY_NAME}] currently uses HTTP for the target endpoint.

Current Target: {TARGET_URL}
Compliance Issue: Unencrypted HTTP violates PCI DSS, GDPR, and NIST standards

Action Required by March 6, 2026:
1. Update backend to support HTTPS, OR
2. Request security exception: [Link to exception request]

Migration Guide: [Link]
Support: api-platform-team@lumen.com
```

**Testing**:
- HTTPS targets pass validation
- HTTP targets fail validation (after grace period)
- HTTP targets with valid exception ID pass
- Clear error messages guide remediation

**Dependencies**: Story 8 (Exception Management MVP) for exception validation

**Definition of Done**:
- Schema enforces HTTPS pattern
- Grace period warning mode tested
- Hard enforcement mode tested
- Migration guide published
- Communication sent to affected teams
- Exception process documented

---

### Story 4: Audit Current Proxies for Compliance Gaps
**Story ID**: DPEAPI-XXXXX
**Type**: ⚠️ Audit & Analysis
**Parent**: DPEAPI-20555
**Priority**: High (Blocks other stories)
**Estimate**: 3 points

**As a** Platform Engineer
**I want** to audit all existing proxies for compliance gaps
**So that** we can plan migrations and estimate impact of new guardrails

**Acceptance Criteria**:
- [ ] Script created to scan all proxy YAML files
- [ ] Report generated with:
  - Proxies using HTTP targets (count, list, owners)
  - Proxies with payload limits >5MB (count, list, current limits)
  - Proxies missing metadata.support fields (count, list)
  - Proxies with timeouts >60s (count, list, current timeouts)
- [ ] Report includes contact information for each proxy owner
- [ ] Summary statistics and migration effort estimate
- [ ] Report shared with stakeholders

**Technical Implementation**:

**Audit Script** (`scripts/audit-proxy-compliance.sh`):
```bash
#!/bin/bash
set -e

echo "Proxy Compliance Audit Report"
echo "Generated: $(date)"
echo "="

# Initialize counters
HTTP_COUNT=0
PAYLOAD_COUNT=0
TIMEOUT_COUNT=0
MISSING_SUPPORT=0

# Output files
HTTP_REPORT="audit-http-targets.csv"
PAYLOAD_REPORT="audit-payload-limits.csv"
TIMEOUT_REPORT="audit-timeouts.csv"
SUPPORT_REPORT="audit-missing-support.csv"

# CSV headers
echo "Proxy Name,File Path,Target URL,MAL Code,Owner" > "$HTTP_REPORT"
echo "Proxy Name,File Path,Payload Limit (MB),MAL Code,Owner" > "$PAYLOAD_REPORT"
echo "Proxy Name,File Path,Timeout (s),MAL Code,Owner" > "$TIMEOUT_REPORT"
echo "Proxy Name,File Path,MAL Code,Owner" > "$SUPPORT_REPORT"

# Scan all proxy YAML files
for proxy_file in mal-SYSGEN*/orgs/*/envs/*/proxies/*/*.yaml; do
  if [ ! -f "$proxy_file" ]; then continue; fi

  # Extract MAL code
  MAL_CODE=$(echo "$proxy_file" | grep -oE 'mal-SYSGEN[0-9]{9}')

  # Get owner from CODEOWNERS (simplified)
  OWNER=$(git log -1 --format='%ae' -- "$proxy_file" 2>/dev/null || echo "unknown")

  PROXY_NAME=$(yq eval '.metadata.name // ""' "$proxy_file")
  if [ -z "$PROXY_NAME" ]; then continue; fi

  # Check HTTP targets
  TARGET=$(yq eval '.spec.routing.target // ""' "$proxy_file")
  if [[ "$TARGET" =~ ^http:// ]]; then
    echo "$PROXY_NAME,$proxy_file,$TARGET,$MAL_CODE,$OWNER" >> "$HTTP_REPORT"
    HTTP_COUNT=$((HTTP_COUNT + 1))
  fi

  # Check payload limits >5MB
  PAYLOAD=$(yq eval '.spec.routing.payloadSizeLimit // 0' "$proxy_file")
  if [ "$PAYLOAD" -gt 5 ]; then
    echo "$PROXY_NAME,$proxy_file,$PAYLOAD,$MAL_CODE,$OWNER" >> "$PAYLOAD_REPORT"
    PAYLOAD_COUNT=$((PAYLOAD_COUNT + 1))
  fi

  # Check timeouts >60s
  TIMEOUT=$(yq eval '.spec.routing.timeout // 60' "$proxy_file")
  if [ "$TIMEOUT" -gt 60 ]; then
    echo "$PROXY_NAME,$proxy_file,$TIMEOUT,$MAL_CODE,$OWNER" >> "$TIMEOUT_REPORT"
    TIMEOUT_COUNT=$((TIMEOUT_COUNT + 1))
  fi

  # Check missing support metadata
  SNOW_GROUP=$(yq eval '.metadata.support.serviceNowGroup // ""' "$proxy_file")
  if [ -z "$SNOW_GROUP" ]; then
    echo "$PROXY_NAME,$proxy_file,$MAL_CODE,$OWNER" >> "$SUPPORT_REPORT"
    MISSING_SUPPORT=$((MISSING_SUPPORT + 1))
  fi
done

# Summary
echo ""
echo "AUDIT SUMMARY"
echo "============="
echo "HTTP Targets: $HTTP_COUNT proxies"
echo "Payload >5MB: $PAYLOAD_COUNT proxies"
echo "Timeout >60s: $TIMEOUT_COUNT proxies"
echo "Missing Support Metadata: $MISSING_SUPPORT proxies"
echo ""
echo "Detailed reports:"
echo "- $HTTP_REPORT"
echo "- $PAYLOAD_REPORT"
echo "- $TIMEOUT_REPORT"
echo "- $SUPPORT_REPORT"
```

**Report Format** (Markdown summary):
```markdown
# Proxy Compliance Audit Report

**Date**: February 4, 2026
**Total Proxies Scanned**: {COUNT}

## Executive Summary

| Compliance Gap | Count | % of Total | Migration Priority |
|---------------|-------|------------|-------------------|
| HTTP Targets | {COUNT} | {PERCENT}% | 🚨 Critical |
| Payload >5MB | {COUNT} | {PERCENT}% | ⚠️ High |
| Timeout >60s | {COUNT} | {PERCENT}% | 📋 Medium |
| Missing Support Metadata | {COUNT} | {PERCENT}% | 📋 Medium |

## Migration Effort Estimate

- **HTTP → HTTPS**: {COUNT} proxies × 2 hours = {HOURS} hours
- **Payload Limits**: {COUNT} proxies × 1 hour = {HOURS} hours
- **Support Metadata**: {COUNT} proxies × 0.5 hours = {HOURS} hours
- **Total Estimated Effort**: {TOTAL_HOURS} hours

## Detailed Findings

See attached CSV files for complete proxy lists with owners.
```

**Files Created**:
- `scripts/audit-proxy-compliance.sh`
- `docs/audits/proxy-compliance-{DATE}.md` (report)
- CSV output files for detailed findings

**Testing**:
- Script runs without errors
- All proxy files scanned
- Accurate counts and categorization
- CSV files properly formatted
- Owner information correct

**Dependencies**: None

**Definition of Done**:
- Audit script tested and working
- Report generated and reviewed
- Findings shared with platform team
- Migration effort estimated
- Stakeholders informed

---

## TIER 2: Foundation Components (Required for Other Stories)

### Story 5: Create Exception Management MVP (File-Based)
**Story ID**: DPEAPI-XXXXX
**Type**: 📋 Standard Implementation
**Parent**: DPEAPI-20555
**Priority**: High (Enables other stories)
**Estimate**: 8 points

**As a** API Producer
**I want** a formal process to request exceptions to governance policies
**So that** I can deploy APIs that don't meet standard guardrails with proper tracking and approval

**Acceptance Criteria**:
- [ ] GitHub Issue template for exception requests created
- [ ] Exception registry file (`exceptions/registry.json`) initialized
- [ ] Validation function to verify exception IDs created
- [ ] Exception approval process documented
- [ ] Exception types supported:
  - HTTP target endpoints
  - Payload limits >5MB
  - Timeouts >60s
  - Rate limits (future)
- [ ] Exception schema includes:
  - Unique ID (EXC-{timestamp})
  - Proxy name
  - Exception type
  - Reason/justification
  - Requestor
  - Approver
  - Approval date
  - Expiry date (default 6 months)
  - Status (active/expired/revoked)
  - Remediation plan

**Technical Implementation**:

**Exception Registry** (`exceptions/registry.json`):
```json
{
  "schema_version": "1.0",
  "exceptions": [
    {
      "exceptionId": "EXC-1707062400",
      "proxyName": "SYSGEN788836350-Legacy-API",
      "exceptionType": "targetHttp",
      "reason": "Legacy backend system only supports HTTP, HTTPS migration planned for Q3 2026",
      "requestor": {
        "name": "John Doe",
        "email": "john.doe@lumen.com",
        "malCode": "mal-SYSGEN123456789"
      },
      "approver": {
        "name": "Platform Team",
        "email": "api-platform@lumen.com",
        "approvalDate": "2026-02-04T10:00:00Z"
      },
      "expiryDate": "2026-08-04T10:00:00Z",
      "status": "active",
      "remediationPlan": "Backend team will enable HTTPS by end of Q2 2026. Migration scheduled for July 2026.",
      "issueUrl": "https://github.com/CenturyLink/enterprise-apigeex-applications/issues/123"
    }
  ]
}
```

**GitHub Issue Template** (`.github/ISSUE_TEMPLATE/exception-request.yml`):
```yaml
name: 🚨 Governance Exception Request
description: Request an exception to API governance policies
title: "[Exception Request] <Proxy Name> - <Exception Type>"
labels: ["exception-request", "governance"]
assignees:
  - api-platform-team

body:
  - type: markdown
    attributes:
      value: |
        ## Governance Exception Request

        Use this form to request an exception to standard API governance policies.

        **Processing Time**: 3-5 business days
        **Approval Required**: Platform Team + Security (for HTTP targets)

  - type: input
    id: proxy-name
    attributes:
      label: Proxy Name
      description: Full proxy name (e.g., SYSGEN788836350-My-API)
      placeholder: SYSGEN788836350-
    validations:
      required: true

  - type: input
    id: mal-code
    attributes:
      label: MAL Code
      description: Your MAL code (e.g., mal-SYSGEN123456789)
      placeholder: mal-SYSGEN
    validations:
      required: true

  - type: dropdown
    id: exception-type
    attributes:
      label: Exception Type
      description: What policy requires an exception?
      options:
        - HTTP Target Endpoint (Security)
        - Payload Limit >5MB
        - Timeout >60 seconds
        - Rate Limit Override
        - Other
    validations:
      required: true

  - type: textarea
    id: justification
    attributes:
      label: Business Justification
      description: Explain why this exception is necessary
      placeholder: |
        - Business requirement
        - Technical limitation
        - Migration timeline
    validations:
      required: true

  - type: textarea
    id: remediation
    attributes:
      label: Remediation Plan
      description: How and when will this be brought into compliance?
      placeholder: |
        - Target completion date
        - Steps to remediate
        - Dependencies
    validations:
      required: true

  - type: dropdown
    id: duration
    attributes:
      label: Requested Duration
      description: How long do you need this exception?
      options:
        - 3 months
        - 6 months (standard)
        - 12 months (requires additional justification)
      default: 1
    validations:
      required: true
```

**Exception Validation Function** (`.github/actions/validate-exception/action.yml`):
```yaml
name: 'Validate Exception ID'
description: 'Validates that an exception ID exists and is active'
inputs:
  exception-id:
    description: 'Exception ID to validate (e.g., EXC-1707062400)'
    required: true
  exception-type:
    description: 'Expected exception type'
    required: true

outputs:
  valid:
    description: 'Whether exception is valid'
    value: ${{ steps.validate.outputs.valid }}
  message:
    description: 'Validation message'
    value: ${{ steps.validate.outputs.message }}

runs:
  using: 'composite'
  steps:
    - name: Validate exception
      id: validate
      shell: bash
      run: |
        EXCEPTION_ID="${{ inputs.exception-id }}"
        EXCEPTION_TYPE="${{ inputs.exception-type }}"

        # Check if exception exists in registry
        EXCEPTION=$(jq --arg id "$EXCEPTION_ID" \
          '.exceptions[] | select(.exceptionId == $id)' \
          exceptions/registry.json)

        if [ -z "$EXCEPTION" ]; then
          echo "valid=false" >> $GITHUB_OUTPUT
          echo "message=Exception ID not found: $EXCEPTION_ID" >> $GITHUB_OUTPUT
          exit 0
        fi

        # Check status
        STATUS=$(echo "$EXCEPTION" | jq -r '.status')
        if [ "$STATUS" != "active" ]; then
          echo "valid=false" >> $GITHUB_OUTPUT
          echo "message=Exception is not active (status: $STATUS)" >> $GITHUB_OUTPUT
          exit 0
        fi

        # Check expiry
        EXPIRY=$(echo "$EXCEPTION" | jq -r '.expiryDate')
        NOW=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
        if [[ "$NOW" > "$EXPIRY" ]]; then
          echo "valid=false" >> $GITHUB_OUTPUT
          echo "message=Exception expired on $EXPIRY" >> $GITHUB_OUTPUT
          exit 0
        fi

        # Check type matches
        TYPE=$(echo "$EXCEPTION" | jq -r '.exceptionType')
        if [ "$TYPE" != "$EXCEPTION_TYPE" ]; then
          echo "valid=false" >> $GITHUB_OUTPUT
          echo "message=Exception type mismatch: expected $EXCEPTION_TYPE, got $TYPE" >> $GITHUB_OUTPUT
          exit 0
        fi

        # Warn if expiring soon (30 days)
        EXPIRY_EPOCH=$(date -d "$EXPIRY" +%s 2>/dev/null || date -j -f "%Y-%m-%dT%H:%M:%SZ" "$EXPIRY" +%s)
        NOW_EPOCH=$(date +%s)
        DAYS_REMAINING=$(( ($EXPIRY_EPOCH - $NOW_EPOCH) / 86400 ))

        if [ "$DAYS_REMAINING" -lt 30 ]; then
          echo "::warning::Exception $EXCEPTION_ID expires in $DAYS_REMAINING days"
        fi

        echo "valid=true" >> $GITHUB_OUTPUT
        echo "message=Valid exception (expires $EXPIRY)" >> $GITHUB_OUTPUT
```

**Files Created**:
- `.github/ISSUE_TEMPLATE/exception-request.yml`
- `exceptions/registry.json`
- `exceptions/README.md` (process documentation)
- `.github/actions/validate-exception/action.yml`
- `docs/guides/exception-process.md`

**Testing**:
- Issue template renders correctly
- Exception validation action works
- Active exception validates successfully
- Expired exception fails validation
- Invalid exception ID fails
- Type mismatch detected

**Dependencies**: None

**Definition of Done**:
- Exception request template live
- Registry initialized with sample
- Validation action tested
- Documentation complete
- Approval process defined

---

### Story 6: Enforce 5MB Payload Size Limit
**Story ID**: DPEAPI-XXXXX
**Type**: ⚠️ Requires Audit
**Parent**: DPEAPI-20555
**Priority**: High (Governance)
**Estimate**: 5 points

**As a** Platform Engineer
**I want** to enforce the 5MB enterprise payload size standard
**So that** APIs follow bulk data transfer guidelines and prevent performance issues

**Acceptance Criteria**:
- [ ] Schema maximum changed from 30MB to 5MB
- [ ] Exception field available: `spec.exceptions.payloadSizeException`
- [ ] Audit completed identifying proxies with >5MB limits (from Story 4)
- [ ] Migration plan created for affected proxies
- [ ] 30-day warning period before hard enforcement
- [ ] Documentation updated with bulk data transfer guidance

**Technical Implementation**:

**Schema Change**:
```json
"payloadSizeLimit": {
  "type": "integer",
  "minimum": 1,
  "maximum": 5,
  "default": 5,
  "description": "Maximum payload size in megabytes. Enterprise standard is 5MB per API Standard: Bulk Data Transfer."
},
"exceptions": {
  "properties": {
    "payloadSizeException": {
      "type": "string",
      "pattern": "^EXC-[0-9]{10}$",
      "description": "Exception ID for payload limits >5MB (requires platform team approval)"
    }
  }
}
```

**Validation Logic**:
```bash
PAYLOAD_LIMIT=$(yq eval '.spec.routing.payloadSizeLimit // 5' "$proxy_file")
PAYLOAD_EXCEPTION=$(yq eval '.spec.exceptions.payloadSizeException // ""' "$proxy_file")

if [ "$PAYLOAD_LIMIT" -gt 5 ]; then
  if [ -z "$PAYLOAD_EXCEPTION" ]; then
    echo "::error file=$proxy_file::Payload limit exceeds 5MB enterprise standard"
    echo "  Current: ${PAYLOAD_LIMIT}MB"
    echo "  Maximum: 5MB"
    echo "  Standard: API Standard: Bulk Data Transfer (Handling Massive Payloads)"
    echo "  For larger payloads, use async processing or chunking"
    echo "  Exception process: [URL]"
    PROXY_ERRORS=$((PROXY_ERRORS + 1))
  else
    # Validate exception
    # (use validate-exception action)
  fi
fi
```

**Migration Communication**:
```markdown
Subject: [Action Required] Payload Size Limit Enforcement (5MB Standard)

Your API proxy [{PROXY_NAME}] currently has a payload limit of {CURRENT}MB.

Enterprise Standard: 5MB maximum per request/response
Current Configuration: {CURRENT}MB

Action Required by March 6, 2026:
1. Reduce payload size to ≤5MB using chunking/pagination, OR
2. Implement async processing for large data transfers, OR
3. Request exception with business justification

Guidance: docs/guides/bulk-data-transfer.md
Exception Request: [Link]
```

**Files Changed**:
- `apiproxy.schema.json`
- `.github/workflows/validate-proxy.yml`
- `docs/guides/bulk-data-transfer.md` (new)
- `docs/guides/payload-size-limits.md` (update)

**Testing**:
- Proxies with ≤5MB pass
- Proxies with >5MB fail without exception
- Proxies with >5MB and valid exception pass
- Clear guidance in error messages

**Dependencies**:
- Story 4 (Audit)
- Story 5 (Exception Management MVP)

**Definition of Done**:
- Schema enforces 5MB limit
- Affected proxies identified
- Migration guide published
- Warning period completed
- Hard enforcement active

---

## TIER 3: Advanced Validation (Future Sprints)

### Story 7: Validate Proxy Name Alignment (Taxonomy + Path)
**Story ID**: DPEAPI-XXXXX
**Type**: 📋 Standard Implementation
**Parent**: DPEAPI-20555
**Priority**: Medium
**Estimate**: 5 points

**As a** Platform Engineer
**I want** proxy names to consistently reflect taxonomy and routing path
**So that** proxies are easily identifiable and follow organizational standards

**Acceptance Criteria**:
- [ ] Validation algorithm defined for: `SYSGEN + taxonomy + path → expected name`
- [ ] Algorithm documented with examples
- [ ] Validation checks name alignment
- [ ] Helper tool created to generate correct names
- [ ] Warning-only mode initially (not hard failure)
- [ ] Transition to hard enforcement after validation period

**Naming Algorithm Example**:
```
Input:
- SYSGEN: SYSGEN788836350
- Taxonomy: /Channel/v1/Portal
- Path: /portal/v1/users

Processing:
- Taxonomy → channel-portal (lowercase, remove version)
- Path → portal-users (extract meaningful segments)

Output:
- Expected Name: SYSGEN788836350-channel-portal-users
```

**Dependencies**: Naming algorithm consensus needed

**Definition of Done**:
- Algorithm defined and documented
- Validation implemented
- Helper tool available
- Documentation with examples

---

### Story 8: Automated Deprecation Headers (RFC 8594)
**Story ID**: DPEAPI-XXXXX
**Type**: 🔧 Infrastructure Dependency
**Parent**: DPEAPI-20555
**Priority**: Medium
**Estimate**: 8 points

**As an** API Consumer
**I want** to receive deprecation headers for deprecated API operations
**So that** I can plan migrations before APIs are sunset

**Acceptance Criteria**:
- [ ] OAS parsing extracts `deprecated: true` operations
- [ ] RFC 8594 headers generated: `Deprecation`, `Sunset`, `Link`
- [ ] AssignMessage policies created per deprecated operation
- [ ] Conditional flow logic based on request path + verb
- [ ] Template transformation includes deprecation logic
- [ ] Documentation for API producers on marking operations deprecated

**Dependencies**:
- OAS integration (may depend on central repository)
- Template transformation enhancement

**Definition of Done**:
- Deprecated operations automatically get headers
- Headers RFC 8594 compliant
- No backend code changes required
- Template transformation tested

---

## Story Summary for Import

**Total Stories**: 8
**Total Estimate**: 39 points

### Sprint 1 Candidates (Quick Wins - 13 points):
1. DPEAPI-XXXXX - Add Support Metadata Fields (3 pts) 🚀
2. DPEAPI-XXXXX - Enforce Filename Matches Proxy Name (2 pts) 🚀
3. DPEAPI-XXXXX - Add HTTPS Target Endpoint Enforcement (5 pts) 🚀
4. DPEAPI-XXXXX - Audit Current Proxies for Compliance Gaps (3 pts) ⚠️

### Sprint 2 Candidates (Foundation - 13 points):
5. DPEAPI-XXXXX - Create Exception Management MVP (8 pts) 📋
6. DPEAPI-XXXXX - Enforce 5MB Payload Size Limit (5 pts) ⚠️

### Future Sprints (Advanced - 13 points):
7. DPEAPI-XXXXX - Validate Proxy Name Alignment (5 pts) 📋
8. DPEAPI-XXXXX - Automated Deprecation Headers (8 pts) 🔧

---

## Import Instructions

### Jira CSV Format
Create CSV with columns: Summary, Description, Issue Type, Parent, Priority, Estimate

Or use Jira bulk import:
1. Create stories under parent DPEAPI-20555
2. Copy acceptance criteria to Description field
3. Add labels: `guardrails`, `validation`, `governance`
4. Set component: `Applications Repository`

---

**Next Steps**:
1. Review and refine story estimates with team
2. Prioritize based on business needs
3. Run audit (Story 4) to inform migration timelines
4. Schedule sprint planning
5. Assign stories to sprint

**Questions for Refinement**:
- Should HTTP enforcement wait for all 423 proxies to migrate?
- Is 30-day grace period sufficient?
- Who handles exception approval? Platform team only?
- When do we want hard enforcement live?

