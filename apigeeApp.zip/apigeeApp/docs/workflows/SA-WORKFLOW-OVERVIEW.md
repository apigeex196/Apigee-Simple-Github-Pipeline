# Service Account Workflow - Complete Picture

**Last Updated**: February 2, 2026
**Status**: Planning Phase

## Story Relationship

```
┌─────────────────────────────────────────────────────────────────┐
│ DPEAPI-18718: CCOE SA Automation Approval                      │
│ Status: ✅ APPROVED (Feb 2, 2026)                              │
│ Outcome: Platform team owns SA creation                        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
        ┌─────────────────────────────────────────┐
        │                                         │
        ↓                                         ↓
┌──────────────────────────────┐  ┌──────────────────────────────┐
│ DPEAPI-19473                 │  │ DPEAPI-19480                 │
│ SA Creation Automation       │→ │ SA Key Expiration Monitoring │
│ (Applications Repo)          │  │ (GitOps Repo)                │
│                              │  │                              │
│ Creates SAs with labels      │  │ Reads labels, routes alerts  │
│ Status: 📋 Planning          │  │ Status: 🚧 Complete          │
└──────────────────────────────┘  └──────────────────────────────┘
```

## What Each Story Does

### DPEAPI-18718 - CCOE Approval
**Repository**: N/A (Decision/Planning)
**Completed**: February 2, 2026

**What it achieved**:
- ✅ Got CCOE buy-in for platform team to own SA creation
- ✅ Removed blocker for automation work
- ✅ Cleared path for DPEAPI-19473 and DPEAPI-19480

### DPEAPI-19473 - SA Creation (Applications Repo)
**Repository**: `enterprise-apigeex-applications`
**Status**: Planning Complete, Implementation Next

**What it does**:
1. Detects when new `mal-{CODE}/` folder created
2. Triggers GitHub Actions workflow
3. Creates service accounts in DEV, QA, PROD orgs:
   - Name: `sa-apigeex-{MAL-CODE}@{project}.iam.gserviceaccount.com`
   - Roles: `apigee.apiAdminV2`, `secretmanager.secretAccessor`
4. Stores SA keys in Secret Manager: `sa-apigeex-{MAL-CODE}`
5. Adds labels for monitoring:
   - `owner`: `mal-{lowercase-code}`
   - `alert_channel`: `MAL_{UPPERCASE_CODE}`
6. Comments on PR with setup status

**Files to create**:
- `.github/workflows/create-mal-service-accounts.yml`
- `.github/actions/create-mal-sa/action.yml`
- `docs/workflows/SA-CREATION-AUTOMATION.md` (✅ Done)

**Example**:
When MAL SYSGEN123456789 onboards → Workflow creates 3 SAs (DEV, QA, PROD) automatically

### DPEAPI-19480 - SA Key Monitoring (GitOps Repo)
**Repository**: `enterprise-apigeex-gitops`
**Status**: Implementation Complete, Ready for Testing

**What it does**:
1. Runs daily at 9 AM MT (GitHub Actions cron)
2. Reads all secrets from Secret Manager in DEV, QA, PROD
3. For each secret with labels:
   - Checks SA key expiration date using IAM API
   - Calculates days until expiration
4. Groups keys by `alert_channel` label
5. Sends Teams alerts to appropriate channels:
   - PLATFORM channel → Platform team webhook
   - MAL_SYSGEN123456789 → That MAL's webhook
6. Alert thresholds:
   - 30 days: ⚠️ Warning
   - 7 days: 🚨 Critical

**Files created** (✅ Already done):
- `.github/workflows/sa-key-monitor.yml`
- `cloud-functions/sa-key-monitor/main_multi_channel.py`
- `cloud-functions/sa-key-monitor/IMPLEMENTATION-STATUS.md`
- `cloud-functions/sa-key-monitor/PREREQUISITES.md`

**Integration**:
Reads labels that DPEAPI-19473 writes → Routes alerts to correct team

## Complete Workflow - From Onboarding to Monitoring

### Step 1: New MAL Onboards (Manual)
API Producer team creates PR adding `mal-SYSGEN123456789/` folder

### Step 2: SA Creation (DPEAPI-19473 - Automated)
```
PR Created
   ↓
Workflow Detects New MAL Folder
   ↓
Create SA in DEV: sa-apigeex-SYSGEN123456789@gcp-prj-apigee-dev-np-01
   ↓
Grant Roles: apigee.apiAdminV2, secretmanager.secretAccessor
   ↓
Store Key in Secret Manager: sa-apigeex-SYSGEN123456789
   ↓
Add Labels:
   - owner: mal-sysgen123456789
   - alert_channel: MAL_SYSGEN123456789
   ↓
Repeat for QA and PROD orgs
   ↓
Comment on PR: "✅ SAs Created Successfully"
```

### Step 3: Deployment (Existing Workflows)
```
MAL Commits Proxy YAML
   ↓
deploy-to-dev.yml Triggered
   ↓
get-service-account Action:
   - Retrieves sa-apigeex-SYSGEN123456789 from Secret Manager (DEV org)
   ↓
Proxy Deployed to Apigee Using MAL's SA
```

### Step 4: Monitoring (DPEAPI-19480 - Automated)
```
Daily at 9 AM MT
   ↓
Read All Secrets from Secret Manager (DEV, QA, PROD)
   ↓
For sa-apigeex-SYSGEN123456789:
   - Read label: alert_channel = MAL_SYSGEN123456789
   - Check key expiration via IAM API
   ↓
If Expiring in 30 days:
   - Lookup TEAMS_WEBHOOK_MAL_SYSGEN123456789 from GitHub secrets
   - Send Teams alert with rotation instructions
```

### Step 5: Key Rotation (Manual)
```
MAL Receives Teams Alert
   ↓
Follow Key Rotation Guide (MAL-ONBOARDING-GUIDE.md)
   ↓
Platform Team or MAL Creates New Key
   ↓
Update Secret Manager (sa-apigeex-SYSGEN123456789)
   ↓
Monitoring Detects New Expiration Date
   ↓
Alerts Stop Until Next Expiration
```

## Current Status Summary

| Component | Story | Repository | Status |
|-----------|-------|------------|--------|
| CCOE Approval | DPEAPI-18718 | N/A | ✅ Complete |
| SA Creation | DPEAPI-19473 | applications | 📋 Planning |
| SA Monitoring | DPEAPI-19480 | gitops | 🚧 Code Complete |

## What's Blocking What?

### DPEAPI-19473 (SA Creation) - READY TO START
**No blockers!**
- ✅ CCOE approved
- ✅ Design complete
- 🔧 Need: Create automation SA with IAM permissions
- 🔧 Need: Implement workflow and composite action

### DPEAPI-19480 (Monitoring) - READY TO TEST
**Soft blocker**: Needs SAs with labels to monitor
- ✅ Code complete
- ✅ Design validated
- 🔧 Can test with manually-labeled platform SAs now
- 🔧 Will scale to 100+ MALs once DPEAPI-19473 complete

## Implementation Order (Recommended)

### Phase 1: DPEAPI-19473 - SA Creation (3-4 weeks)
**Why first**: Creates the infrastructure (SAs with labels) that monitoring needs

**Week 1-2: Infrastructure Setup**
- Create automation SA: `sa-apigeex-mal-provisioning@gcp-prj-apigee-dev-np-01`
- Grant cross-project IAM permissions (DEV, QA, PROD)
- Store automation SA key as GitHub secret
- Test permissions manually

**Week 3: Workflow Development**
- Create `create-mal-service-accounts.yml` workflow
- Create `create-mal-sa` composite action
- Add detection logic for new MAL folders
- Add error handling and PR comments

**Week 4: Testing & Rollout**
- Dry-run test with test MAL
- Create real test MAL and verify
- Backfill SAs for existing MALs (SYSGEN788836350)
- Document and enable for production

### Phase 2: DPEAPI-19480 - Monitoring Testing (1 week)
**Why second**: Can now test with SAs that have proper labels

**Week 5: Testing**
- Test monitoring with platform SA (manual labels)
- Test monitoring with MAL SA (from Phase 1)
- Verify alert routing works
- Add first MAL webhook
- Enable daily cron

### Phase 3: Scale to All MALs (Ongoing)
**Week 6+: Rollout**
- Onboard MALs to monitoring systematically
- Collect webhooks from each team
- Add as GitHub secrets
- Verify team-specific alerts work

## Dependencies - External

### GCP Permissions (Required for DPEAPI-19473)
**Needed from**: CCOE / GCP Admin Team

**Request**:
```
Service Account: sa-apigeex-mal-provisioning@gcp-prj-apigee-dev-np-01

Permissions in gcp-prj-apigee-dev-np-01:
- roles/iam.serviceAccountAdmin
- roles/iam.serviceAccountKeyAdmin
- roles/resourcemanager.projectIamAdmin
- roles/secretmanager.admin

Permissions in gcp-prj-apigee-qa-np-01:
- (same 4 roles)

Permissions in gcp-prj-apigee-prod-01:
- (same 4 roles)
```

**Timeline**: Need by start of Phase 1 (Week 1)

### Teams Webhooks (Required for DPEAPI-19480 at scale)
**Needed from**: Each MAL Team

**Request**: "Please provide your Teams channel incoming webhook URL"

**Timeline**: Ongoing, as teams onboard

## Success Metrics

### DPEAPI-19473 Success
- ✅ New MAL onboarded in <1 hour (vs 2-5 days manual)
- ✅ SAs created in all 3 orgs automatically
- ✅ <5% failure rate
- ✅ 10+ MALs using automated provisioning

### DPEAPI-19480 Success
- ✅ Monitoring running daily without errors
- ✅ Platform team receives alerts for platform SAs
- ✅ 10+ MAL teams receiving team-specific alerts
- ✅ Zero SA expiration incidents after full rollout

### Combined Success
- ✅ MAL onboards → SAs auto-created → Monitoring auto-configured
- ✅ Zero manual steps required
- ✅ 100+ MALs supported

## Questions?

**About SA Creation (DPEAPI-19473)**:
- See: `docs/workflows/SA-CREATION-AUTOMATION.md`
- Contact: Ryan (Platform Team)

**About SA Monitoring (DPEAPI-19480)**:
- See: `../../../enterprise-apigeex-gitops/cloud-functions/sa-key-monitor/IMPLEMENTATION-STATUS.md`
- Contact: Ryan (Platform Team)

**About CCOE Integration**:
- See: `docs/meetings/CCOE-MEETING-BRIEF.md`
- Contact: CCOE Team

---

**Next Action**: Start Phase 1 - Create automation SA and request GCP permissions
