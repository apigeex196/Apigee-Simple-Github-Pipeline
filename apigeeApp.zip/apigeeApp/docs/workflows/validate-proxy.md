# Validate Proxy YAML Workflow

Automatically validates proxy YAML configurations on pull requests.

## Trigger

- **Event**: Pull Request
- **Paths**: 
  - `mal-SYSGEN*/proxies/**/*.yaml`
  - `apiproxy.schema.json`
  - `template-mappings.json`
  - `.github/workflows/validate-proxy.yml`

## Validation Checks

### 1. YAML Syntax Validation
- Uses `yq` to validate YAML syntax
- Ensures files are well-formed YAML

### 2. Schema Validation
- Validates against `apiproxy.schema.json` using `ajv-cli`
- Ensures all required fields are present
- Validates data types and formats

### 3. Naming Convention Validation
- Proxy name must follow pattern: `SYSGEN[0-9]{9}-*`
- Example: `SYSGEN123456789-my-api`

### 4. Template Reference Validation
- Extracts `spec.template.name` from proxy YAML
- Validates template exists in `template-mappings.json`
- Lists available templates if validation fails

### 5. Template Download Test
- Downloads each unique template using gh CLI
- Verifies template extracts successfully
- Checks template directory is not empty
- Validates OAS file exists if `spec.oasValidation.enabled` is true
- Uses caching for performance

## Workflow Steps

1. **Checkout code** - Fetches repository with full history
2. **Install validation tools** - Installs ajv-cli (yq, jq pre-installed)
3. **Detect changed files** - Uses changed-files action
4. **Validate proxy files** - Runs all validation checks
5. **Extract templates to download** - Identifies unique templates from proxies
6. **Download and verify templates** - Downloads and validates each template
7. **Update summary with template results** - Adds download results to summary
8. **Check template download status** - Fails if downloads failed
9. **Generate summary** - Creates detailed validation report

## Outputs

### Workflow Summary
The workflow creates a detailed summary including:
- ✅ or ❌ for each validated proxy file
- Specific validation errors with file locations
- Template mapping validation results
- Template download test results

### Exit Codes
- **0**: All validations passed
- **1**: One or more validations failed

## Example Validation Results

```markdown
## Proxy YAML Validation Results

### Validation Results

✅ **mal-SYSGEN123456789/proxies/SYSGEN123456789-example-api/dev/base.yaml** - All validations passed

### Template Mapping Validation

✅ **jwt-proxy-ahpt-backend** - Downloaded successfully (cache: false)

### Template Download Test

✅ Successfully downloaded and verified all templates
- **Templates downloaded**: 1
- **Download errors**: 0

---

✅ **All validations passed!** Proxies are ready for deployment.
```

## Common Validation Errors

### Invalid YAML Syntax
```
❌ **mal-SYSGEN123456789/proxies/api/dev/base.yaml** - Invalid YAML syntax
```
**Fix**: Check for proper YAML indentation and syntax

### Schema Validation Failed
```
❌ **mal-SYSGEN123456789/proxies/api/dev/base.yaml** - Schema validation failed
   ```
   data/spec/template should have required property 'name'
   ```
```
**Fix**: Ensure all required fields are present according to apiproxy.schema.json

### Invalid Proxy Name
```
❌ **mal-SYSGEN123456789/proxies/my-api/dev/base.yaml** - Invalid proxy name: `my-api` 
    (must start with SYSGEN[0-9]{9}-)
```
**Fix**: Rename proxy to follow pattern, e.g., `SYSGEN123456789-my-api`

### Template Not Found
```
❌ **mal-SYSGEN123456789/proxies/api/dev/base.yaml** - Template `unknown-template` 
    not found in template-mappings.json
   Available: jwt-oauth-proxy-ahpt-backend jwt-proxy-ahpt-backend oauth-proxy-jwt-backend
```
**Fix**: Use one of the available template names from template-mappings.json

## Testing

### Manual Test
Create a PR that modifies a proxy YAML file:

```bash
# Make a change to example proxy
echo "# Test change" >> mal-SYSGEN123456789/proxies/SYSGEN123456789-example-api/dev/base.yaml

# Commit and push
git add mal-SYSGEN123456789/proxies/SYSGEN123456789-example-api/dev/base.yaml
git commit -m "Test: Trigger validation workflow"
git push

# Create PR
gh pr create --title "Test Validation" --body "Testing proxy validation workflow"
```

### Test Invalid Proxy
To test validation errors, temporarily break a proxy:

```bash
# Invalid YAML syntax
echo "invalid: yaml: syntax:" >> mal-SYSGEN123456789/proxies/SYSGEN123456789-example-api/dev/base.yaml

# Invalid template name
yq eval '.spec.template.name = "non-existent-template"' -i mal-SYSGEN123456789/proxies/SYSGEN123456789-example-api/dev/base.yaml

# Invalid proxy name
yq eval '.metadata.name = "invalid-name"' -i mal-SYSGEN123456789/proxies/SYSGEN123456789-example-api/dev/base.yaml
```

## Dependencies

### Tools (Pre-installed in ubuntu-latest)
- `yq` - YAML processor
- `jq` - JSON processor

### Tools (Installed by workflow)
- `ajv-cli` - JSON schema validator
- `ajv-formats` - Additional format validators

### Actions
- `actions/checkout@v4` - Repository checkout
- `./.github/actions/changed-files` - Detect changed files
- `./.github/actions/download-template` - Template download

### Files
- `apiproxy.schema.json` - Proxy YAML schema
- `template-mappings.json` - Template name mappings

## Related Workflows

- **test-changed-files.yml** - Tests the changed-files action
- **test-download-template.yml** - Tests template download
- **validate-mal-structure.yml** - Validates MAL folder structure (Story 7)

## Next Steps

After this workflow passes:
1. Merge PR with confidence that proxy YAML is valid
2. Proxy will be deployed to dev environment on merge to main
3. Template will be available for deployment transformation

## Troubleshooting

### Workflow not triggering
- Ensure PR modifies files matching `mal-SYSGEN*/proxies/**/*.yaml`
- Check workflow file is on the target branch

### ajv-cli installation fails
- Check npm registry is accessible
- Verify ubuntu-latest runner has npm installed

### Template download fails
- Verify template name exists in template-mappings.json
- Check GitHub token has access to template repository
- Ensure release exists in template repository

### Schema validation always fails
- Verify apiproxy.schema.json is valid JSON Schema
- Check schema version matches ajv-cli expectations (draft-07)
- Validate example proxy against schema locally:
  ```bash
  yq eval -o=json '.' proxy.yaml > proxy.json
  ajv validate -s apiproxy.schema.json -d proxy.json --spec=draft7
  ```
