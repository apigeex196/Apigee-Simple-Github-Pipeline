# Guardrails & Validation Analysis - Applications Repo CI/CD Pipeline

**Document Purpose**: Analyze Confluence requirements for pre-deployment static analysis, validation, and enforcement against current implementation in the Applications repository.

**Created**: February 4, 2026
**Status**: Analysis & Implementation Plan

---

## Executive Summary

This analysis maps Confluence-documented governance requirements to current implementation gaps in the Applications repository CI/CD workflows. Of 10 major requirement areas identified, **4 are fully implemented**, **3 are partially implemented**, and **3 require new implementation**.

### Priority Classification
- 🚨 **Critical**: Blocks production readiness
- ⚠️ **High**: Governance requirement, security impact
- 📋 **Medium**: Quality improvement, operational efficiency
- 💡 **Enhancement**: Nice-to-have, future consideration

---

## Requirement Analysis Matrix

### 1. Metadata & Logging Requirements

#### Confluence Requirements
- **supportServiceNowGroup** (required): SNOW group for API Producer team routing
- **supportNetPin** (required): NET PIN for SWAT call escalation

#### Current Implementation Status
- ❌ **Not Implemented** - Priority: 🚨 **Critical**
- Schema (`apiproxy.schema.json`) does not include these fields
- Validation workflow does not check for these attributes
- No Cloud Logging integration present

#### Gap Analysis
**Schema Changes Required**:
```json
"metadata": {
  "properties": {
    "support": {
      "type": "object",
      "description": "Support and operational contact information",
      "properties": {
        "serviceNowGroup": {
          "type": "string",
          "pattern": "^[A-Z][A-Za-z0-9_-]+$",
          "description": "ServiceNow group for API Producer team (for SNOW ticket routing)"
        },
        "netPin": {
          "type": "string",
          "pattern": "^[A-Z0-9]{6,12}$",
          "description": "NET PIN for SWAT call escalation (for MTTR optimization)"
        }
      },
      "required": ["serviceNowGroup", "netPin"],
      "additionalProperties": false
    }
  },
  "required": ["name", "labels", "support"]
}
```

**Validation Workflow Updates**:
- Add validation step in `validate-proxy.yml` after YAML syntax check
- Enforce presence of both fields
- Validate format patterns

**Deployment Updates**:
- Extract support metadata during proxy transformation
- Add as custom attributes to Apigee proxy revision
- Integrate with Cloud Logging structured logging

**Impact**:
- Improves incident response time (MTTR metric)
- Enables automated SNOW ticket routing
- Critical for production support model

**Implementation Story**: `DPEAPI-XXXXX` - Add Support Metadata Fields (Critical)

---

### 2. Proxy OAS Validation by Reference

#### Confluence Requirements
- OAS must be retrieved from central repository by reference
- Manual upload blocked
- Top governance priority for initial release

#### Current Implementation Status
- ⚠️ **Partially Implemented** - Priority: 🚨 **Critical**
- OAS validation exists (`spec.oasValidation`)
- Uses local file reference: `oas://filename.yaml`
- **Gap**: Not retrieving from central "service bundle" repository

#### Gap Analysis

**Current Pattern (Local)**:
```yaml
spec:
  oasValidation:
    enabled: true
    oasResource: "oas://my-api-spec.yaml"  # Local file in same directory
```

**Required Pattern (Central Repository)**:
```yaml
spec:
  oasValidation:
    enabled: true
    oasResource: "bundle://service-catalog/my-api/v1/spec.yaml"  # Central repository
```

**Implementation Requirements**:

1. **Service Bundle Repository Integration**
   - Define central OAS repository structure
   - Implement bundle:// URI scheme handler
   - Add authentication for private specs
   - Cache mechanism for build performance

2. **Schema Updates**:
```json
"oasResource": {
  "type": "string",
  "pattern": "^bundle://[A-Za-z0-9._/-]+\\.ya?ml$",
  "description": "Reference to OAS in central service bundle repository. Must follow pattern 'bundle://path/to/spec.yaml'"
}
```

3. **Validation Workflow Enhancement**:
   - Download OAS from central repository during validation
   - Verify checksum/integrity
   - Cache for deployment workflow
   - Block local `oas://` references in schema

4. **Deployment Workflow Enhancement**:
   - Fetch same OAS version used in validation
   - Package as resource file in proxy bundle
   - Version alignment verification

**Blockers**:
- Need to identify/establish central "service bundle" repository
- Authentication mechanism for private repositories
- Versioning strategy (how to reference specific OAS versions)

**Questions for Product Team**:
1. Where is the central "service bundle" repository? (GitHub, Artifactory, GCS?)
2. What's the URL pattern for retrieving OAS files?
3. How are OAS versions tracked and referenced?
4. Authentication method (GitHub token, service account, API key)?

**Implementation Story**: `DPEAPI-XXXXX` - Centralized OAS Repository Integration (Critical)

---

### 3. Payload Size Enforcement (5MB Limit)

#### Confluence Requirements
- Build **MUST FAIL** if payload limit exceeds 5MB enterprise standard
- No exceptions without formal process

#### Current Implementation Status
- ✅ **Implemented** - Priority: ⚠️ **High**
- Schema enforces maximum: `"maximum": 30` (30MB)
- **Gap**: Limit is 30MB, not 5MB standard

#### Gap Analysis

**Current Schema**:
```json
"payloadSizeLimit": {
  "type": "integer",
  "minimum": 10,
  "maximum": 30,  // ❌ Should be 5
  "description": "Maximum payload size in megabytes."
}
```

**Required Change**:
```json
"payloadSizeLimit": {
  "type": "integer",
  "minimum": 1,
  "maximum": 5,  // ✅ Enterprise standard
  "default": 5,
  "description": "Maximum payload size in megabytes. Enterprise standard is 5MB."
}
```

**Migration Strategy**:
1. ⚠️ **Breaking Change**: Existing proxies with >5MB limits will fail validation
2. Audit current proxies for payload limits >5MB
3. Identify proxies requiring exception process
4. Apply exception tracking (see Requirement #7)
5. Update schema and redeploy validation

**Implementation Actions**:
1. Run audit query: `find mal-*/orgs/*/envs/*/proxies -name "*.yaml" -exec yq eval '.spec.routing.payloadSizeLimit' {} \;`
2. Generate exception list for proxies with limits >5MB
3. Update schema maximum to 5
4. Coordinate with API producers for remediation

**Implementation Story**: `DPEAPI-XXXXX` - Enforce 5MB Payload Size Limit (High Priority)

---

### 4. Proxy Rate Limits from Service Bundle

#### Confluence Requirements
- Rate limits retrieved from "service bundle" instead of directly set in proxy YAML
- Centralized rate limit governance

#### Current Implementation Status
- ❌ **Not Implemented** - Priority: ⚠️ **High**
- Rate limits currently set in proxy YAML: `spec.routing.throttle` (0-400 TPS)
- No service bundle integration

#### Gap Analysis

**Current Pattern**:
```yaml
spec:
  routing:
    throttle: 50  # Set directly in YAML
```

**Required Pattern** (Option 1 - Service Bundle Reference):
```yaml
spec:
  routing:
    throttle: "bundle://rate-limits/my-service"  # Reference to centralized config
```

**Required Pattern** (Option 2 - Automatic Lookup):
```yaml
spec:
  routing:
    # Throttle automatically retrieved based on service classification
    # Omitted from YAML entirely
```

**Implementation Options**:

**Option A: Service Bundle Reference (Explicit)**
- Pros: Transparent, auditable, version controlled
- Cons: Requires service bundle repository (same as OAS)
- Schema change: `throttle` becomes string pattern for bundle reference

**Option B: Automatic Lookup (Implicit)**
- Pros: Simpler for API producers, enforces governance by default
- Cons: Less visible, requires classification system
- Implementation: Lookup based on `metadata.labels.taxonomy` or service tier

**Recommended Approach**: Option B (Automatic Lookup)
- Derive rate limit from service taxonomy or tier
- Default tier-based limits: Free (10 TPS), Standard (50 TPS), Premium (200 TPS)
- Override only via exception process

**Schema Changes**:
```json
"throttle": {
  "type": "integer",
  "minimum": 0,
  "maximum": 400,
  "description": "Throttle limit (TPS). Automatically derived from service tier. Manual override requires exception."
}
```

**Deployment Workflow Changes**:
- Add lookup logic before proxy transformation
- Map taxonomy → service tier → rate limit
- Override with exception ID if present
- Log rate limit decision for audit trail

**Implementation Story**: `DPEAPI-XXXXX` - Centralized Rate Limit Governance (High Priority)

---

### 5. Proxy Timeout Enforcement

#### Confluence Requirements
- Default timeout: 60 seconds (low value)
- Only exception-marked APIs can increase
- Exceptions tracked in "service bundle"

#### Current Implementation Status
- ✅ **Implemented** - Priority: 📋 **Medium**
- Schema enforces: `"maximum": 120`, `"default": 60`
- **Gap**: No exception tracking mechanism

#### Gap Analysis

**Current Schema**:
```json
"timeout": {
  "type": "integer",
  "minimum": 0,
  "maximum": 120,
  "default": 60,
  "description": "Timeout in seconds for the route (0-120, default 60)."
}
```

**Enhanced Schema** (with exception support):
```json
"timeout": {
  "type": "integer",
  "minimum": 0,
  "maximum": 60,  // Default max without exception
  "default": 60,
  "description": "Timeout in seconds. Default 60s. Higher values require exception."
},
"timeoutException": {
  "type": "string",
  "pattern": "^EXC-[0-9]{6,10}$",
  "description": "Exception ID for timeouts >60s. Format: EXC-XXXXXXXXXX"
}
```

**Conditional Validation** (ajv):
```json
"allOf": [
  {
    "if": {
      "properties": {
        "timeout": { "minimum": 61 }
      }
    },
    "then": {
      "required": ["timeoutException"],
      "properties": {
        "timeout": { "maximum": 120 }
      }
    },
    "else": {
      "properties": {
        "timeout": { "maximum": 60 }
      }
    }
  }
]
```

**Validation Logic**:
```bash
TIMEOUT=$(yq eval '.spec.routing.timeout' "$proxy_file")
TIMEOUT_EXCEPTION=$(yq eval '.spec.routing.timeoutException // ""' "$proxy_file")

if [ "$TIMEOUT" -gt 60 ] && [ -z "$TIMEOUT_EXCEPTION" ]; then
  echo "::error::Timeout >60s requires exception ID"
  PROXY_ERRORS=$((PROXY_ERRORS + 1))
fi

# Verify exception ID exists in exception registry
if [ -n "$TIMEOUT_EXCEPTION" ]; then
  # Query exception API/database
  if ! verify_exception "$TIMEOUT_EXCEPTION"; then
    echo "::error::Invalid or expired exception ID: $TIMEOUT_EXCEPTION"
    PROXY_ERRORS=$((PROXY_ERRORS + 1))
  fi
fi
```

**Implementation Story**: `DPEAPI-XXXXX` - Timeout Exception Tracking (Medium Priority)

---

### 6. Automated Deprecation Headers (RFC 8594)

#### Confluence Requirements
- Gateway must automatically inject RFC 8594 headers for deprecated operations
- Headers: `Deprecation`, `Sunset`
- Triggered by `deprecated: true` in OAS
- Removes human error from backend implementation

#### Current Implementation Status
- ❌ **Not Implemented** - Priority: 📋 **Medium**
- OAS validation exists, but no header injection
- No deprecation header policy in templates

#### Gap Analysis

**RFC 8594 Headers**:
- `Deprecation: @1730419200` (Unix timestamp)
- `Sunset: Sat, 01 Jan 2025 00:00:00 GMT` (HTTP date)
- `Link: <https://api.example.com/docs/deprecated>; rel="deprecation"; type="text/html"`

**Implementation Requirements**:

1. **OAS Parsing During Transformation**:
   - Extract deprecated operations from OAS
   - Parse `x-sunset-date` or calculate default (e.g., +6 months)
   - Generate header values

2. **Dynamic Policy Generation**:
   - Create `AssignMessage` policy per deprecated operation
   - Add to proxy flow based on request.verb + request.uri
   - Example:
```xml
<AssignMessage name="AM-Add-Deprecation-Headers-GET-Users">
  <AssignTo createNew="false" transport="http" type="response"/>
  <Set>
    <Headers>
      <Header name="Deprecation">@1730419200</Header>
      <Header name="Sunset">Sat, 01 Jan 2025 00:00:00 GMT</Header>
      <Header name="Link">&lt;https://developer.lumen.com/deprecated/GET-users&gt;; rel="deprecation"</Header>
    </Headers>
  </Set>
</AssignMessage>
```

3. **Conditional Flow Logic**:
```xml
<Step>
  <Name>AM-Add-Deprecation-Headers-GET-Users</Name>
  <Condition>(request.verb = "GET") and (proxy.pathsuffix MatchesPath "/users")</Condition>
</Step>
```

4. **Template Updates**:
   - Enhance all templates with deprecation header logic
   - Add to response flow (after backend call, before client response)

5. **OAS Requirements**:
   - Encourage use of `x-sunset-date` extension for explicit dates
   - Document deprecation metadata format

**Developer Experience**:
API Producers simply mark operations as deprecated in OAS:
```yaml
paths:
  /users:
    get:
      deprecated: true
      x-sunset-date: "2025-01-01T00:00:00Z"
      x-deprecation-info: "https://developer.lumen.com/migration-guide"
```

**Benefits**:
- Zero backend code changes required
- Consistent deprecation messaging
- Compliance with RFC 8594 standard
- Reduces customer support inquiries

**Implementation Story**: `DPEAPI-XXXXX` - Automated Deprecation Headers (Medium Priority)

---

### 7. Exception Process for Guardrails

#### Confluence Requirements
- Document exceptions with tracking ID
- Time-bound exceptions (e.g., 6 months)
- Dashboard visibility (API Standards dashboard)
- Exceptions require platform team approval
- Tracking ID used in proxy YAML

#### Current Implementation Status
- ❌ **Not Implemented** - Priority: 🚨 **Critical**
- No exception tracking system
- No approval process
- No dashboard integration

#### Gap Analysis

**Required Components**:

1. **Exception Registry** (Storage)
   - Central database or config file
   - Schema:
```json
{
  "exceptionId": "EXC-1234567890",
  "proxyName": "SYSGEN788836350-My-API",
  "exceptionType": "timeout|payloadSize|rateLimit|httpsTarget",
  "reason": "Legacy backend requires 120s processing time",
  "requestor": "john.doe@lumen.com",
  "approver": "platform-team@lumen.com",
  "approvalDate": "2025-02-01T00:00:00Z",
  "expiryDate": "2025-08-01T00:00:00Z",  // 6 months
  "status": "active|expired|revoked",
  "remediationPlan": "Migrate to async processing by Q3 2025"
}
```

2. **Exception Request Workflow**
   - GitHub Issue template: `.github/ISSUE_TEMPLATE/exception-request.yml`
   - Automated validation of request completeness
   - Platform team review/approval
   - Auto-generate exception ID upon approval
   - Notify requestor with exception ID

3. **Exception Validation in CI/CD**
   - Query exception registry during validation
   - Verify exception ID is valid, active, and not expired
   - Fail build if exception expired or invalid
   - Warning if exception expiring soon (<30 days)

4. **Schema Updates**:
```json
"exceptions": {
  "type": "object",
  "description": "Exception tracking for policy violations",
  "properties": {
    "payloadSizeException": {
      "type": "string",
      "pattern": "^EXC-[0-9]{10}$"
    },
    "timeoutException": {
      "type": "string",
      "pattern": "^EXC-[0-9]{10}$"
    },
    "rateLimitException": {
      "type": "string",
      "pattern": "^EXC-[0-9]{10}$"
    },
    "targetHttpException": {
      "type": "string",
      "pattern": "^EXC-[0-9]{10}$"
    }
  }
}
```

5. **API Producer YAML Usage**:
```yaml
spec:
  routing:
    timeout: 130
  exceptions:
    timeoutException: "EXC-1234567890"
```

6. **Dashboard Integration**
   - Export exception data to API Standards dashboard
   - Metrics: active exceptions, expiring exceptions, remediation status
   - Alerts for expiring exceptions

7. **Automated Expiry Handling**
   - Scheduled job (weekly) to check expiring exceptions
   - Notify owners 30/14/7 days before expiry
   - Auto-fail builds after expiry
   - Require reapplication or remediation

**Implementation Approach**:

**Phase 1: MVP (Simple File-Based)**
- Store exceptions in `exceptions-registry.json` in Applications repo
- Manual approval via PR review
- Basic validation in workflow

**Phase 2: Database-Backed**
- Migrate to Cloud Firestore or Cloud SQL
- API for querying exceptions
- Automated expiry checks
- Dashboard integration

**Phase 3: Full Lifecycle Management**
- Web UI for exception requests
- Approval workflows with notifications
- Remediation tracking
- Audit logs

**Implementation Story**: `DPEAPI-XXXXX` - Exception Management System (Critical, Multi-Phase)

---

### 8. Promotion from DEV → TEST → PROD

#### Confluence Requirements
- Ensure same proxy config promoted through environments
- Prevent configuration drift
- Enforce deployment sequence

#### Current Implementation Status
- ✅ **Implemented** - Priority: ⚠️ **High**
- Separate workflows for each environment: `deploy-to-dev.yml`, `deploy-to-test.yml`, `deploy-to-prod.yml`
- All use same transformation logic from composite actions
- **Gap**: No enforcement of "dev before test before prod" sequence

#### Gap Analysis

**Current Behavior**:
- Any commit to `main` can trigger deployment to any environment
- No verification that same version deployed to lower env first
- Potential for config drift

**Required Behavior**:
- DEV deployment happens first
- TEST deployment only if deployed to DEV successfully
- PROD deployment only if deployed to TEST successfully
- Version tracking across environments

**Implementation Options**:

**Option A: Branch-Based Promotion**
```
main → DEV (auto-deploy)
release/test → TEST (auto-deploy after PR from main)
release/prod → PROD (auto-deploy after PR from release/test)
```
- Pros: Clear promotion path, git history
- Cons: Requires branching strategy change, multiple PRs

**Option B: Deployment Tags**
```bash
# Deploy to DEV
git tag -a "mal-12345/proxy-name/dev/v1.2.3" -m "Deploy to DEV"

# Deploy to TEST (only if DEV tag exists)
git tag -a "mal-12345/proxy-name/test/v1.2.3" -m "Promote to TEST"

# Deploy to PROD (only if TEST tag exists)
git tag -a "mal-12345/proxy-name/prod/v1.2.3" -m "Promote to PROD"
```
- Pros: Single branch, explicit promotion, version tracking
- Cons: Manual tagging process

**Option C: Deployment Manifest + Checks**
- Track deployments in `deployment-manifest.json`:
```json
{
  "mal-SYSGEN788836350": {
    "orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/my-proxy/my-proxy.yaml": {
      "version": "v1.2.3",
      "commitSha": "abc123",
      "deployedAt": "2025-02-01T10:00:00Z",
      "status": "success"
    }
  }
}
```
- TEST workflow checks DEV deployment exists
- PROD workflow checks TEST deployment exists
- Pros: Flexible, comprehensive tracking
- Cons: Additional state management

**Recommended Approach**: Option C (Deployment Manifest)

**Implementation Requirements**:

1. **Deployment Manifest Generation**:
   - After successful deployment, update manifest
   - Include: commit SHA, version, timestamp, environment
   - Commit back to repo or store in artifact

2. **Promotion Validation**:
```bash
# In deploy-to-test.yml
PROXY_FILE="mal-SYSGEN12345/orgs/gcp-prj-apigee-test-np-01/envs/apicc-test/proxies/my-proxy/my-proxy.yaml"
PROXY_NAME=$(yq eval '.metadata.name' "$PROXY_FILE")
COMMIT_SHA=$(git rev-parse HEAD)

# Check if deployed to DEV
DEV_DEPLOYED=$(jq --arg proxy "$PROXY_NAME" --arg sha "$COMMIT_SHA" \
  '.deployments[] | select(.proxy == $proxy and .commitSha == $sha and .env == "dev")' \
  deployment-manifest.json)

if [ -z "$DEV_DEPLOYED" ]; then
  echo "::error::Proxy $PROXY_NAME not deployed to DEV for commit $COMMIT_SHA"
  exit 1
fi
```

3. **Workflow Changes**:
   - Add pre-deployment validation step
   - Check for prerequisite environment deployment
   - Fail fast if not deployed to lower environment

4. **Developer Experience**:
   - Clear error messages when promotion blocked
   - Documentation on promotion process
   - Optional bypass for hotfixes (with exception ID)

**Implementation Story**: `DPEAPI-XXXXX` - Environment Promotion Enforcement (High Priority)

---

### 9. Proxy Name Enforcement

#### Confluence Requirements
- YAML filename = metadata.name
- YAML filename & metadata.name match: `SYSGEN + taxonomy + routing.path` pattern
- Consistent naming across all identifiers

#### Current Implementation Status
- ✅ **Partially Implemented** - Priority: 📋 **Medium**
- Validates SYSGEN pattern: `^SYSGEN[0-9]{9}-`
- **Gap**: No validation of filename matching metadata.name
- **Gap**: No validation of name matching taxonomy + path

#### Gap Analysis

**Current Validation** (`validate-proxy.yml`):
```bash
PROXY_NAME=$(yq eval '.metadata.name' "$proxy_file")

if [[ ! "$PROXY_NAME" =~ ^SYSGEN[0-9]{9}- ]]; then
  echo "::error::Proxy name '$PROXY_NAME' does not follow SYSGEN pattern"
fi
```

**Required Validations**:

1. **Filename = metadata.name**:
```bash
# Extract filename without extension
FILENAME=$(basename "$proxy_file" .yaml)

# Extract metadata.name
PROXY_NAME=$(yq eval '.metadata.name' "$proxy_file")

if [ "$FILENAME" != "$PROXY_NAME" ]; then
  echo "::error file=$proxy_file::Filename '$FILENAME' must match metadata.name '$PROXY_NAME'"
  PROXY_ERRORS=$((PROXY_ERRORS + 1))
fi
```

2. **Name = SYSGEN + Taxonomy + Path**:
```bash
# Extract components
SYSGEN=$(yq eval '.metadata.labels.sysgen' "$proxy_file")
TAXONOMY=$(yq eval '.metadata.labels.taxonomy' "$proxy_file")  # e.g., /Channel/v1/Portal
PATH=$(yq eval '.spec.routing.path' "$proxy_file")  # e.g., /portal/v1/api

# Generate expected name
# Taxonomy: /Channel/v1/Portal → channel-portal
TAXONOMY_PART=$(echo "$TAXONOMY" | tr '/' '-' | tr '[:upper:]' '[:lower:]' | sed 's/^-//;s/v[0-9]-/-/')

# Path: /portal/v1/api → portal-api
PATH_PART=$(echo "$PATH" | tr '/' '-' | sed 's/^-//;s/v[0-9]//g;s/--/-/g')

EXPECTED_NAME="$SYSGEN-$TAXONOMY_PART-$PATH_PART"

if [ "$PROXY_NAME" != "$EXPECTED_NAME" ]; then
  echo "::error::Proxy name '$PROXY_NAME' should match pattern: $EXPECTED_NAME"
  echo "  SYSGEN: $SYSGEN"
  echo "  Taxonomy: $TAXONOMY → $TAXONOMY_PART"
  echo "  Path: $PATH → $PATH_PART"
  PROXY_ERRORS=$((PROXY_ERRORS + 1))
fi
```

**Considerations**:
- Define exact naming algorithm (case, separators, version handling)
- Document edge cases (multi-segment paths, special characters)
- Provide naming helper tool for API producers
- Balance strictness with flexibility

**Implementation Story**: `DPEAPI-XXXXX` - Enhanced Proxy Naming Validation (Medium Priority)

---

### 10. Target Endpoint HTTPS Enforcement

#### Confluence Requirements
- Proxy target endpoints must use `https://`
- HTTP violates security standards (PCI DSS, GDPR, NIST)
- Internal audit finding: 423 proxies (20%) use HTTP
- Exceptions tracked with `targetException` ID

#### Current Implementation Status
- ❌ **Not Implemented** - Priority: 🚨 **Critical**
- No HTTPS enforcement in schema or validation
- High-risk security gap

#### Gap Analysis

**Current Schema**:
```json
"target": {
  "type": "string",
  "description": "The target endpoint for routing."
}
```

**Enhanced Schema**:
```json
"target": {
  "type": "string",
  "pattern": "^https://.*",
  "description": "Target endpoint URL. MUST use HTTPS for security compliance (PCI DSS, GDPR, NIST)."
}
```

**Exception Support**:
```json
"exceptions": {
  "properties": {
    "targetHttpException": {
      "type": "string",
      "pattern": "^EXC-[0-9]{10}$",
      "description": "Exception ID for non-HTTPS target endpoints. Required for HTTP targets."
    }
  }
}
```

**Conditional Validation**:
```json
"allOf": [
  {
    "if": {
      "properties": {
        "routing": {
          "properties": {
            "target": {
              "pattern": "^http://.*"
            }
          }
        }
      }
    },
    "then": {
      "required": ["exceptions"],
      "properties": {
        "exceptions": {
          "required": ["targetHttpException"]
        }
      }
    }
  }
]
```

**Validation Workflow Enhancement**:
```bash
TARGET=$(yq eval '.spec.routing.target' "$proxy_file")
TARGET_EXCEPTION=$(yq eval '.spec.exceptions.targetHttpException // ""' "$proxy_file")

if [[ "$TARGET" =~ ^http:// ]]; then
  if [ -z "$TARGET_EXCEPTION" ]; then
    echo "::error file=$proxy_file::Target endpoint uses HTTP. HTTPS required for compliance (PCI DSS, GDPR, NIST)."
    echo "  Current: $TARGET"
    echo "  Required: https://${TARGET#http://}"
    echo "  Or provide targetHttpException ID for exception tracking"
    PROXY_ERRORS=$((PROXY_ERRORS + 1))
  else
    # Verify exception ID
    if ! verify_exception "$TARGET_EXCEPTION" "targetHttp"; then
      echo "::error::Invalid targetHttpException ID: $TARGET_EXCEPTION"
      PROXY_ERRORS=$((PROXY_ERRORS + 1))
    fi
  fi
fi
```

**Migration Strategy** (423 Existing HTTP Proxies):

1. **Audit Phase**:
   - Identify all proxies with HTTP targets
   - Contact proxy owners
   - Assess remediation effort

2. **Remediation Prioritization**:
   - **Critical**: Proxies handling PII/PCI data (immediate fix)
   - **High**: External-facing APIs (30-day deadline)
   - **Medium**: Internal APIs with HTTPS-capable backends (60-day)
   - **Low**: Legacy systems requiring HTTP (exception request)

3. **Grace Period**:
   - 90-day grace period before enforcement
   - Weekly reports to proxy owners
   - Platform team support for migrations

4. **Enforcement**:
   - Enable schema validation after grace period
   - Fail builds for HTTP targets without exception

**Implementation Story**: `DPEAPI-XXXXX` - HTTPS Target Enforcement & Migration (Critical)

---

## Implementation Priority Roadmap

### Phase 1: Critical Blockers (Sprint 1-2)
1. **Metadata & Logging** (SNOW group, NET PIN) - `DPEAPI-XXXXX`
2. **Exception Management System** (MVP file-based) - `DPEAPI-XXXXX`
3. **HTTPS Target Enforcement** (with migration plan) - `DPEAPI-XXXXX`
4. **Centralized OAS Repository Integration** - `DPEAPI-XXXXX`

### Phase 2: Governance & Compliance (Sprint 3-4)
5. **Payload Size 5MB Enforcement** - `DPEAPI-XXXXX`
6. **Centralized Rate Limit Governance** - `DPEAPI-XXXXX`
7. **Environment Promotion Enforcement** - `DPEAPI-XXXXX`

### Phase 3: Quality & Automation (Sprint 5-6)
8. **Timeout Exception Tracking** - `DPEAPI-XXXXX`
9. **Enhanced Proxy Naming Validation** - `DPEAPI-XXXXX`
10. **Automated Deprecation Headers** - `DPEAPI-XXXXX`

### Phase 4: Advanced Features (Future)
- Exception dashboard integration
- Exception lifecycle automation
- Advanced exception analytics

---

## Cross-Repository Dependencies

### Applications Repository (Primary Implementation)
- Schema updates (`apiproxy.schema.json`)
- Validation workflow enhancements (`validate-proxy.yml`)
- Deployment workflow enhancements (all `deploy-to-*.yml`)
- Exception registry initialization
- Documentation updates

### Templates Repository
- Template updates for deprecation headers
- OAS validation enhancements
- Policy generation for automated features

### GitOps Repository
- Alignment of validation logic
- Exception verification integration
- Deployment manifest coordination

---

## Technical Debt & Risks

### Technical Debt
1. **Exception Registry Architecture**: MVP file-based system won't scale beyond ~100 exceptions
   - **Mitigation**: Plan database migration in Phase 2
2. **Service Bundle Repository**: Not yet defined or established
   - **Blocker**: Requires product/architecture decision
3. **Naming Algorithm**: Complex validation logic may be fragile
   - **Mitigation**: Comprehensive testing, helper tooling

### Risks
1. **Breaking Changes**: Many guardrails will fail existing proxies
   - **Mitigation**: Grace periods, migration support, clear communication
2. **Service Bundle Dependency**: External system availability affects deployments
   - **Mitigation**: Caching, fallback mechanisms, SLA requirements
3. **Exception Management Adoption**: Teams may resist formal exception process
   - **Mitigation**: Clear documentation, streamlined approval, platform support

---

## Metrics & Success Criteria

### Deployment Metrics
- **Change Failure Rate (CFR)**: Target <5% (currently impacted by missing guardrails)
- **Lead Time for Changes**: Maintain <2 hours (guardrails shouldn't significantly increase)
- **Deployment Frequency**: Maintain current levels while improving quality

### Governance Metrics
- **Compliance Rate**: % of proxies meeting all standards (target: >95%)
- **Exception Count**: Active exceptions tracked (target: <50 active)
- **Exception Resolution Time**: Average time from expiry to remediation (target: <14 days)
- **HTTPS Adoption**: % of proxies using HTTPS targets (target: >95%)

### Operational Metrics
- **MTTR Improvement**: Faster incident response with SNOW/NetPin metadata
- **Security Incidents**: Reduction in HTTP-related vulnerabilities
- **Validation Build Time**: Keep under 5 minutes despite additional checks

---

## Next Steps & Action Items

### Immediate Actions (This Week)
1. **Socialize this analysis** with platform team and stakeholders
2. **Create Jira stories** for all 10 requirement areas
3. **Prioritize stories** based on roadmap and team capacity
4. **Identify service bundle repository** with product team
5. **Audit existing proxies** for HTTP targets and >5MB payload limits

### Short-Term Actions (Sprint 1)
1. Implement metadata fields (SNOW group, NET PIN)
2. Design exception management MVP
3. Draft exception request GitHub Issue template
4. Begin HTTPS enforcement communication with API producers

### Medium-Term Actions (Sprint 2-3)
1. Roll out exception management system
2. Implement HTTPS migration with grace period
3. Integrate centralized OAS repository
4. Enforce payload size limits

### Long-Term Actions (Sprint 4+)
1. Full environment promotion enforcement
2. Automated deprecation headers
3. Exception dashboard integration
4. Advanced analytics and reporting

---

## Appendix: Related Documentation

- **Confluence**: API SDLC Stage 3: Deployment & Release
- **Confluence**: Enterprise API Governance & Publishing Architecture
- **Confluence**: API Versioning Strategy
- **Confluence**: API Standard: Bulk Data Transfer
- **Repository**: `docs/workflows/SA-CREATION-AUTOMATION.md`
- **Repository**: `docs/PRODUCT-OWNERSHIP-MODEL.md`
- **Repository**: `IMPLEMENTATION-STATUS.md`

---

**Document Owner**: API Platform Team
**Review Cadence**: Bi-weekly during implementation
**Next Review**: February 11, 2026
