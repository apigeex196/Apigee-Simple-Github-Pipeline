# Service Account Creation Automation - DPEAPI-19473

**Story**: SA Key Monitoring - API Producer Integration
**Actual Scope**: Automated SA creation for new API Producer teams in applications repo
**Status**: Planning
**Last Updated**: February 2, 2026

## Overview

When a new API Producer team (MAL) onboards to the applications repo by creating their `mal-{CODE}/` folder, we need to automatically provision their service accounts across all Apigee environments (DEV, QA, PROD).

**Goal**: Reduce MAL onboarding from days to hours by automating SA creation.

## Current State

### What Works Today
- ✅ `.github/actions/get-service-account/` retrieves existing SAs from Secret Manager
- ✅ Workflows expect secrets named: `sa-apigeex-{MAL-CODE}`
- ✅ Multi-org deployments work when SAs exist
- ✅ Testing validated with SYSGEN788836350 MAL in all 3 orgs

### What's Manual Today
1. **Platform team manually creates** service accounts in GCP
2. **Platform team manually creates** SA keys
3. **Platform team manually stores** keys in Secret Manager (per org)
4. **Platform team manually adds** labels for monitoring
5. **Platform team manually grants** IAM roles

**Problem**: This takes days per MAL and doesn't scale to 100+ teams

## Solution Design - Phased Approach

### Phase 1: GitHub Actions Workflow (RECOMMENDED)
**Timeline**: 2-3 weeks
**Owner**: Platform Team
**Dependencies**: GCP automation SA with IAM permissions

Detect new MAL folders and create SAs using GitHub Actions + gcloud CLI.

**Pros**:
- No CCOE dependency
- Platform team owns end-to-end
- Fast to implement
- Easy to debug and iterate
- Can start immediately

**Cons**:
- Not integrated with CCOE Terraform stack
- Separate automation path

### Phase 2: Terraform Integration (FUTURE)
**Timeline**: 4-8 weeks
**Owner**: Platform Team + CCOE
**Dependencies**: CCOE repo access, Terraform module, PR workflow

Integrate SA creation into CCOE's Terraform repository for consistency.

**Pros**:
- Centralized IAM management
- Audit trail through Terraform state
- Consistent with CCOE's other resources
- Single source of truth

**Cons**:
- Requires CCOE coordination
- Longer implementation time
- More complex approval process

## Phase 1 Implementation Details

### Architecture

```
New MAL Folder Created (mal-SYSGEN123456789/)
         ↓
GitHub Actions Workflow Triggered (create-mal-service-accounts.yml)
         ↓
Create SAs in 3 Orgs (DEV, QA, PROD)
         ↓
Grant IAM Roles (apigee.apiAdminV2, etc.)
         ↓
Store SA Keys in Secret Manager (with monitoring labels)
         ↓
(Optional) Store as GitHub Secrets
         ↓
Comment on PR with Setup Instructions
```

### Required Infrastructure

#### 1. Automation Service Accounts (Per Environment)
**DEV SA**: `sa-apigeex-cicd@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com`
**QA SA**: `sa-apigeex-cicd@gcp-prj-apigee-qa-np-01.iam.gserviceaccount.com`
**PROD SA**: `sa-apigeex-cicd@gcp-prj-apigee-prod-01.iam.gserviceaccount.com`
**Purpose**: Used by GitHub Actions to create MAL service accounts in their respective environments

**Status**: ✅ **PROVISIONED** (CCOE PR #3509 merged and applied Feb 4, 2026)

**Permissions Required (granted in each org)**:
```yaml
roles/iam.serviceAccountAdmin          # Create SAs
roles/iam.serviceAccountKeyAdmin       # Create SA keys
roles/resourcemanager.projectIamAdmin  # Grant IAM roles
roles/secretmanager.admin             # Store/label secrets
```

**GitHub Secrets** (already configured):
- `GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01` - DEV environment automation
- `GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01` - QA environment automation
- `GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01` - PROD environment automation

**Note**: Each SA operates only in its own project. No cross-project permissions needed.

### Workflow Implementation

#### File: `.github/workflows/create-mal-service-accounts.yml`

**Trigger**: On PR creation/update when `mal-{CODE}/` folder added

**Jobs**:
1. **detect-new-mals**: Find new MAL folders
2. **create-service-accounts**: Create SAs in all 3 orgs (parallel)
3. **verify-and-comment**: Verify SAs work, comment on PR

**Key Features**:
- Idempotent: Safe to re-run if SA already exists
- Dry-run mode for testing
- Detailed logging for debugging
- PR comments with setup status
- Error handling and rollback

#### File: `.github/actions/create-mal-sa/action.yml`

Composite action to create a single MAL's SA in one org.

**Inputs**:
- `mal-code`: e.g., SYSGEN788836350
- `gcp-project`: e.g., gcp-prj-apigee-dev-np-01
- `apigee-org`: e.g., gcp-prj-apigee-dev-np-01
- `dry-run`: Boolean, default false

**Outputs**:
- `service-account-email`: Created SA email
- `secret-name`: Secret Manager secret name
- `status`: success/exists/failed

**Steps**:
1. Check if SA already exists
2. Create SA if needed: `sa-apigeex-{MAL-CODE}@{project}.iam.gserviceaccount.com`
3. Grant IAM roles: `apigee.apiAdminV2`, `secretmanager.secretAccessor`
4. Create SA key
5. Store key in Secret Manager: `sa-apigeex-{MAL-CODE}`
6. Add monitoring labels:
   - `owner`: `mal-{lowercase-code}` or `platform`
   - `alert_channel`: `MAL_{UPPERCASE_CODE}` or `PLATFORM`
7. Verify SA can authenticate to Apigee
8. Output creation status

### Secret Manager Schema

**Secret Name**: `sa-apigeex-{MAL-CODE}`
**Example**: `sa-apigeex-SYSGEN788836350`

**Stored In**:
- `gcp-prj-apigee-dev-np-01` (for DEV env)
- `gcp-prj-apigee-qa-np-01` (for QA env)
- `gcp-prj-apigee-prod-01` (for PROD env)

**Labels** (for monitoring integration):
```yaml
owner: "mal-sysgen788836350"          # Lowercase
alert_channel: "MAL_SYSGEN788836350"  # Uppercase for Teams webhook lookup
environment: "dev" | "qa" | "prod"
created_by: "github-actions"
created_date: "2026-02-02"
```

**IAM Roles Granted**:
- `roles/apigee.apiAdminV2` - Deploy proxies, products, manage Apigee resources
- `roles/secretmanager.secretAccessor` - Read KVM secrets

### Detection Logic

**New MAL Detection**:
```bash
# Detect new mal-*/ folders in PR
git diff --name-only origin/${{ github.base_ref }}..HEAD | \
  grep -E '^mal-[A-Z0-9]+/' | \
  sed 's|/.*||' | \
  sort -u

# Validate MAL code format
[[ $MAL_CODE =~ ^SYSGEN[0-9]{9}$ ]]
```

**When to Trigger**:
- ✅ New `mal-{CODE}/` folder created
- ✅ New `mal-{CODE}/CODEOWNERS` file added
- ❌ Changes to existing MAL files (skip)
- ❌ Changes outside mal-*/ folders (skip)

### Error Handling

**Scenario 1: SA Creation Fails**
- Log detailed error
- Comment on PR with error and instructions
- Exit with failure (block merge if desired)

**Scenario 2: SA Already Exists**
- Log "SA exists, skipping"
- Verify labels and roles are correct
- Update labels/roles if missing
- Continue (success)

**Scenario 3: Permission Denied**
- Check automation SA has required IAM roles
- Provide specific permission error
- Link to setup documentation

**Scenario 4: Secret Manager Error**
- Retry up to 3 times
- Log error details
- Provide troubleshooting steps

### PR Comment Template

When SAs are created successfully:

```markdown
## ✅ Service Accounts Created

Service accounts have been automatically provisioned for MAL `SYSGEN788836350`:

| Environment | Service Account | Secret | Status |
|-------------|----------------|--------|--------|
| DEV | `sa-apigeex-SYSGEN788836350@gcp-prj-apigee-dev-np-01...` | `sa-apigeex-SYSGEN788836350` | ✅ Created |
| QA | `sa-apigeex-SYSGEN788836350@gcp-prj-apigee-qa-np-01...` | `sa-apigeex-SYSGEN788836350` | ✅ Created |
| PROD | `sa-apigeex-SYSGEN788836350@gcp-prj-apigee-prod-01...` | `sa-apigeex-SYSGEN788836350` | ✅ Created |

**Permissions Granted**:
- ✅ `apigee.apiAdminV2` - Deploy proxies and products
- ✅ `secretmanager.secretAccessor` - Read KVM secrets

**Monitoring Setup**:
- ✅ Labels added for SA key expiration monitoring
- ✅ You'll receive Teams alerts 30 days before key expiration

**Next Steps**:
1. Your deployment workflows will automatically use these service accounts
2. No manual setup required!
3. See [MAL-ONBOARDING-GUIDE.md](../../../enterprise-apigeex-gitops/cloud-functions/sa-key-monitor/MAL-ONBOARDING-GUIDE.md) to add your Teams webhook for expiration alerts

**Questions?** Contact the API Platform team.
```

## Testing Strategy

### Phase 1: Manual Testing
1. Create test MAL folder: `mal-SYSGENTEST001/`
2. Create PR
3. Verify workflow triggers
4. Check SAs created in all 3 orgs
5. Verify labels added correctly
6. Test deployment using new SAs
7. Delete test MAL

### Phase 2: Dry-Run Mode
1. Add `dry-run: true` input
2. Run workflow
3. Verify it shows what would be created
4. No actual resources created

### Phase 3: Integration Testing
1. Create real MAL for willing API Producer team
2. Monitor full onboarding flow
3. Verify deployments work
4. Get team feedback
5. Iterate

## Security Considerations

### Principle of Least Privilege
- Automation SA has minimal required permissions
- MAL SAs only have `apigee.apiAdminV2` (not org admin)
- No SA can create other SAs
- Keys stored securely in Secret Manager (never in GitHub)

### Key Rotation
- SA keys created with 90-day expiration by default
- Monitoring system alerts 30 days before expiration
- See: `gitops/cloud-functions/sa-key-monitor/`

### Audit Trail
- All SA creation logged in GitHub Actions
- Terraform state (Phase 2) provides audit history
- GCP audit logs capture IAM changes

### Blast Radius Limitation
- Each MAL has separate SA per org
- Compromised key only affects one MAL in one org
- Easy to revoke and recreate individual SAs

## Implementation Checklist

### Prerequisites
- [ ] Create automation SA in DEV org
- [ ] Grant cross-project permissions (QA, PROD)
- [ ] Store automation SA key as GitHub secret: `GCP_SA_MAL_PROVISIONING`
- [ ] Document IAM permission requirements

### Workflow Creation
- [ ] Create `.github/workflows/create-mal-service-accounts.yml`
- [ ] Create `.github/actions/create-mal-sa/action.yml`
- [ ] Add MAL detection logic
- [ ] Add PR commenting logic
- [ ] Add error handling and retries

### Testing
- [ ] Dry-run test with existing MAL
- [ ] Create test MAL and verify SAs created
- [ ] Test deployment with new SAs
- [ ] Verify labels work with monitoring
- [ ] Test error scenarios

### Documentation
- [ ] Update README.md with SA automation section
- [ ] Create MAL onboarding guide linking to this
- [ ] Document troubleshooting steps
- [ ] Update IMPLEMENTATION-STATUS.md

### Rollout
- [ ] Test with pilot MAL
- [ ] Create SAs for existing MALs (backfill)
- [ ] Enable for all future MALs
- [ ] Monitor for issues
- [ ] Gather feedback and iterate

## Integration with Monitoring (DPEAPI-19480)

Once SAs are created with labels, they automatically integrate with the monitoring system:

1. **SA Created**: Workflow adds labels `owner` and `alert_channel`
2. **Monitoring Detects**: Daily workflow reads all secrets with labels
3. **Alert Routing**: Uses `alert_channel` label to determine Teams webhook
4. **MAL Receives Alert**: 30 days before expiration

**Result**: Zero-touch monitoring integration!

## Success Metrics

### Onboarding Time
- **Before**: 2-5 days (manual SA creation)
- **After**: <1 hour (automated)

### Error Rate
- **Target**: <5% SA creation failures
- **Measure**: GitHub Actions success rate

### Scale
- **Target**: Support 100+ MALs
- **Measure**: Concurrent SA creation time

### Team Satisfaction
- **Target**: 90% of MALs rate onboarding as "easy"
- **Measure**: Survey after first deployment

## Rollback Plan

If automation causes issues:

1. **Disable workflow**: Comment out trigger
2. **Revert to manual process**: Use documented manual steps
3. **Fix issues**: Debug and test in isolation
4. **Re-enable**: Once validated

**Manual SA Creation Process** (fallback):
See `docs/manual-sa-creation-guide.md` (to be created)

## Future Enhancements

### Phase 2: Terraform Integration
- Move SA creation to CCOE Terraform repository
- GitHub Actions creates PR in Terraform repo
- CCOE reviews and approves
- Terraform applies changes
- Benefit: Centralized IAM management

### Phase 3: Self-Service Portal
- Web UI for MAL teams to request SAs
- Auto-approval for standard requests
- Manual approval for special permissions
- Integration with ServiceNow/Jira

### Phase 4: Advanced Monitoring
- Track SA usage metrics
- Alert on unused SAs
- Auto-disable inactive SAs
- Compliance reporting

## Related Work

### DPEAPI-18718 - SA Automation (CCOE Coordination)
- **Status**: ✅ CCOE Approved (Feb 2, 2026)
- **Decision**: Platform team owns SA creation
- **Outcome**: Unblocked this work (DPEAPI-19473)

### DPEAPI-19480 - Multi-Channel SA Key Monitoring
- **Status**: 🚧 Implementation Complete
- **Location**: `gitops/cloud-functions/sa-key-monitor/`
- **Integration**: Uses labels created by this workflow

### DPEAPI-19359 - Service Account Creation Process
- **Status**: 🔄 In Progress
- **Scope**: Overall SA creation strategy
- **This Story**: Implementation of that strategy

## Questions & Decisions

### Q1: Should we create GitHub secrets too?
**Decision**: Not initially. Workflows retrieve from Secret Manager.
**Reason**: Single source of truth, easier to rotate.

### Q2: What if SA creation fails in PROD but succeeds in DEV/QA?
**Decision**: Allow partial success, document in PR comment.
**Reason**: DEV/QA can proceed, manual fix for PROD.

### Q3: Should we support custom IAM roles per MAL?
**Decision**: Not initially. Standard `apigee.apiAdminV2` only.
**Reason**: Simplicity. Add customization later if needed.

### Q4: How to handle SA key expiration?
**Decision**: Leverage existing monitoring (DPEAPI-19480).
**Reason**: Already built, team receives 30-day warning.

### Q5: Should workflow block PR merge if SA creation fails?
**Decision**: No, but require manual approval from platform team.
**Reason**: Don't block MAL onboarding completely, but ensure review.

---

**Next Steps**: Create implementation plan for Phase 1 workflow
