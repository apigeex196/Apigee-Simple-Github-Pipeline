# API Producer Core Guide

Audience: API producer teams onboarding to Apigee X via this applications repository.
Scope: Author proxies/products, validate with schemas, deploy with workflows, and test.

---

## Overview
- You work only in your MAL folder within this repo.
- You own your proxy bundles and environment YAMLs; the platform workflows validate and deploy.
- Promotion is DEV → QA → PROD by copying/updating your YAML for each org/env.

## Section 1: Getting Started
- Prerequisites: access to this repository, a MAL code (e.g., `SYSGEN788836350`), and environment service accounts provisioned by the platform.
- Tools: Git, GitHub CLI, Python 3.10+ (optional: Node.js for `ajv-cli`).
- See Quickstart (Windows) below for a copy-paste bootstrap and local validation.
- Repo structure: your work lives in `mal-<SYSGEN_CODE>/` — bundles under `bundles/proxies/` and environment YAMLs under `orgs/<org>/envs/<env>/proxies/<project>/`.

## Quickstart (Windows)
- Set variables (replace with your MAL code):

```powershell
$mal = "SYSGEN788836350"
$orgDev = "gcp-prj-apigee-dev-np-01"
$envDev = "apicc-dev"
```

- Create environment proxy YAML (schema-valid):

```powershell
New-Item -ItemType Directory -Force "mal-$mal/orgs/$orgDev/envs/$envDev/proxies/E2E-TEST-BASIC" | Out-Null
Set-Content "mal-$mal/orgs/$orgDev/envs/$envDev/proxies/E2E-TEST-BASIC/proxy.yaml" @"
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: $mal-E2E-TEST-BASIC
  description: "Basic proxy example"
  labels:
    sysgen: $mal
    taxonomy: /Test/v1/E2E
spec:
  template: oauth-proxy-oauth-backend
  routing:
    path: /sysgen788836350/e2e-test-basic/v1
    target: https://httpbin.org
    rewritePath: /anything
    timeout: 35
"@
```

- Validate locally (requires Node.js and `ajv-cli`):

```powershell
yq eval -o=json '.' "mal-$mal/orgs/$orgDev/envs/$envDev/proxies/E2E-TEST-BASIC/proxy.yaml" > proxy.json
npm install -g ajv-cli ajv-formats
ajv validate -s apiproxy.schema.json -d proxy.json --spec=draft7
```

- Commit and open a PR to trigger repository validation workflows.

## Repo Layout (MAL)
- MAL folder: `mal-<SYSGEN_CODE>/`
- Store proxy bundles under `mal-<SYSGEN>/bundles/proxies/<MAL-prefixed-proxy>/apiproxy/...`
- Store environment YAMLs under `mal-<SYSGEN>/orgs/<org>/envs/<env>/proxies/<project>/<file>.yaml`
- See the main README for examples.

## Authoring Proxies
- Proxy `metadata.name` must be MAL-prefixed (e.g., `SYSGEN788836350-My-API`).
- Labels must include `sysgen` and a `taxonomy` like `/Type/vN/Name`.
- Define `spec.template` using real names from [../template-mappings.json](../template-mappings.json).
- Define `spec.routing` with at least `path` and `target`.

### Naming & Conventions
- Proxy `metadata.name` must match `SYSGEN[0-9]{9}-*`.
- Prefer kebab-case for API/project names: `SYSGEN788836350-my-api`.
- `spec.routing.path` should start with `/your-api/{version}` and avoid trailing slashes.
- Remove `targetAudience` (not part of apiproxy.schema); use labels or environment-specific configuration instead.

## Section 2: Your First Proxy

### Choose a Template (Decision Tree)
- If you need OAuth token verification against an introspection backend → use `oauth-proxy-oauth-backend`.
- If you receive JWTs and validate locally without backend introspection → use `jwt-proxy-ahpt-backend`.
- If you need OAuth and JWT together (hybrid) → use `oauth-proxy-jwt-backend`.
- If both JWT and OAuth policies are needed for AHPT backend specifically → use `jwt-oauth-proxy-ahpt-backend`.
- If your backend is not ready and you need a stub endpoint → use the No‑Target utility proxy from the platform templates repo (not listed in template-mappings).

Template summary:

| Template | Use when | Inputs needed | Common pitfalls |
| --- | --- | --- | --- |
| `oauth-proxy-oauth-backend` | OAuth token introspection via backend | OAuth backend URL/credentials; shared flows present | Missing shared flows; misconfigured backend URL |
| `jwt-proxy-ahpt-backend` | Local JWT verification (no introspection) | JWT issuer/audience/keys; shared flows present | Key material not available; incorrect claim expectations |
| `oauth-proxy-jwt-backend` | Both OAuth and JWT required | Both sets of inputs above | Conflicting auth paths; incomplete flow ordering |
| `jwt-oauth-proxy-ahpt-backend` | Combined JWT+OAuth for AHPT backend | AHPT backend specifics; JWT and OAuth inputs | Template mismatch to backend; missing AHPT config |
| No‑Target (utility) | Stub/no backend yet | None | Not suitable for real traffic; remove before go‑live |

Reference: see [../template-mappings.json](../template-mappings.json) for available template names. Example usage in your proxy YAML:

```yaml
spec:
  template: oauth-proxy-oauth-backend
```

### Deploying Your First Proxy (walkthrough)
1. Choose a template per the decision tree and set `spec.template` in your environment YAML.
2. Create the environment YAML under `mal-<SYSGEN>/orgs/<org>/envs/<env>/proxies/<Project>/proxy.yaml`.
3. Open a PR; fix any validation failures (schema, naming, template mapping).
4. Merge to `main`; deployment to DEV runs automatically. Test endpoints and auth behavior.
5. Promote by copying YAML to QA and PROD folders and updating environment path.

## Proxy YAML (per environment)
- Define your proxy using [../apiproxy.schema.json](../apiproxy.schema.json).
- Minimal schema-valid example (DEV):

```yaml
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-my-api
  description: "Example proxy"
  labels:
    sysgen: SYSGEN788836350
    taxonomy: /Channel/v1/Portal
spec:
  template: oauth-proxy-oauth-backend
  routing:
    path: /sysgen788836350/my-api/v1
    target: https://httpbin.org
```

- Ensure labels include `sysgen` and `taxonomy`; provide a valid `template` and `routing` per schema.

### Template & OAS (optional)
- If using platform-provided templates, set `spec.template` and ensure it exists in [../template-mappings.json](../template-mappings.json).
- To enable OAS validation, see [docs/OAS-VALIDATION.md](OAS-VALIDATION.md) and include your OAS file next to the proxy YAML.
- Common pitfalls and fixes: see [API-PRODUCER-FAILURE-MODES.md](API-PRODUCER-FAILURE-MODES.md).

### OAS Requirements
- Enable OAS linting by adding under `spec`:

```yaml
oasValidation:
  enabled: true
  oasResource: oas://your-openapi.yaml
```

- File placement: store the OAS file alongside your proxy YAML, for example in
  `mal-<SYSGEN>/orgs/<org>/envs/<env>/proxies/<SYSGEN-Your-API>/your-openapi.yaml`.
- Supported specs: OpenAPI 3.x (preferred) and Swagger 2.0; linting uses Redocly `openapi-cli`.
- Build behavior: workflows inject the OAS file into `apiproxy/resources/oas/` within the bundle so policies can resolve `oas://`.
- Minimal OpenAPI 3 snippet:

```yaml
openapi: 3.0.3
info:
  title: My API
  version: 1.0.0
paths:
  /health:
    get:
      responses:
        '200':
          description: OK
```

- Common validation failures and fixes:
  - OAS file not found → verify filename and `oas://` reference; ensure it is committed next to YAML.
  - Missing required fields → ensure `info`, `paths`, and response objects exist.
  - Format errors → run `npx @redocly/openapi-cli@latest lint <file>` locally and fix reported issues.

## Products
- Products are generated by workflows based on your proxy configuration.
- Configure quotas or attributes per platform guidance; see [../apiproduct.schema.json](../apiproduct.schema.json) for supported fields if customizing.

## Section 3: API Products

### Create / Customize API Products (walkthrough)
- By default, a product is created per proxy during deployment.
- Create a Product YAML when you need custom approval mode, access level, quota/scopes, environments, or fine‑grained operations.
- Location in MAL structure:
  - `mal-<SYSGEN>/orgs/<org>/products/<SYSGEN-your-product>.yaml`
- Linking: set `spec.proxies[].name` to your MAL‑prefixed proxy name (e.g., `SYSGEN788836350-my-api`).
- Quotas: configure `spec.quota.limit`, `interval`, and `timeUnit`.
- Scopes: add `spec.scopes[]` strings for OAuth scope control.

Minimal schema‑valid Product YAML example (DEV):

```yaml
apiVersion: v1
kind: ApiProduct
metadata:
  name: SYSGEN788836350-my-product
  description: "Product for my APIs"
  sysgen: SYSGEN788836350
  owner: api-team@example.com
  approvedBySRB: true
spec:
  approval: auto
  access: public
  environments:
    - apicc-dev1
  proxies:
    - name: SYSGEN788836350-my-api
      operations:
        - path: /sysgen788836350/my-api/v1/health
          methods:
            - GET
  quota:
    limit: 1000
    interval: 1
    timeUnit: minute
  scopes:
    - read
    - write
  attributes:
    team: api-producers
```

Promote product changes DEV → QA → PROD:
1. Copy the product file to a branch and update `spec.environments` to include the target QA environment (e.g., `apicc-test1`).
2. Merge and verify product deployment in QA.
3. For PROD, include production environment names once added to schema.

> TODO: Add production environment names (e.g., `apicc-prod`, `ext-apicc-prod`) to `apiproduct.schema.json` `spec.environments.enum` to enable explicit production product targeting.

Common product failure modes (naming, proxies, quotas): see [API-PRODUCER-FAILURE-MODES.md](API-PRODUCER-FAILURE-MODES.md).

## Validation & Deployment Workflows
- Validation runs on PRs; deployment runs after merge to `main`.
- Reference: [workflows/validate-proxy.md](workflows/validate-proxy.md), [workflows/validate-product.md](workflows/validate-product.md).
- Typical flow:
  1. Create branch, add bundle and YAML.
  2. Open PR → validation checks (schema, apigeelint, naming, SA existence).
  3. Merge PR → deploy bundle, proxy, and product to target env.

### Environment Approvals
- Dev: auto-deploy on merge.
- Test: may require approval (GitHub Environments).
- Prod: requires platform approvals and wait timer; see [docs/repository-configuration.md](repository-configuration.md).

## Local Validation (recommended)
- Run apigeelint on your bundle.
- Validate YAML against schemas:
  - Proxy YAML: [../apiproxy.schema.json](../apiproxy.schema.json)
  - Product YAML: [../apiproduct.schema.json](../apiproduct.schema.json)

Example local schema validation (convert YAML to JSON and validate with `ajv-cli`):

```powershell
# Requires Node.js and ajv-cli installed globally
yq eval -o=json '.' mal-$mal/orgs/$orgDev/envs/$envDev/proxies/E2E-TEST-BASIC/proxy.yaml > proxy.json
npm install -g ajv-cli ajv-formats
ajv validate -s apiproxy.schema.json -d proxy.json --spec=draft7
```

## Secrets & Service Accounts
- Platform provisions service accounts per MAL/environment.
- See guidance: [planning/SECRETS-INVENTORY-CHECKLIST.md](../planning/SECRETS-INVENTORY-CHECKLIST.md), [docs/repository-configuration.md](repository-configuration.md).

## Testing
- Expectations and steps: [TESTING-CHECKLIST.md](../TESTING-CHECKLIST.md), [docs/E2E-TESTING-DPEAPI-18719.md](E2E-TESTING-DPEAPI-18719.md).
- Bruno collections: [tests/bruno-collections/apigee-e2e-tests/README.md](../tests/bruno-collections/apigee-e2e-tests/README.md).

### Non‑Platform Engineer Test
- Use this checklist to validate onboarding without platform assistance:
  - Name / Team / Date
  - MAL used (e.g., SYSGEN788836350)
  - Proxy name (e.g., SYSGEN788836350-my-api)
  - Time to first deploy (target: < 30 minutes)
  - Any platform help needed? (Yes/No — describe if Yes)
  - Links to PR(s) as evidence
- Reference materials:
  - [docs/demo/DEMO-REFERENCE.md](../docs/demo/DEMO-REFERENCE.md)
  - [docs/demo/PLATFORM-DEMO-PRESENTATION.md](../docs/demo/PLATFORM-DEMO-PRESENTATION.md)
  - [README.md](../README.md)

## Promotion Guidance
- DEV → QA → PROD: copy the YAML to the destination org/env folder and update env-specific fields (org, env, SA email, labels).
- Keep the same structure across environments; only environment-specific values should differ.

Example paths:

```text
mal-SYSGEN788836350/
  orgs/
    gcp-prj-apigee-dev-np-01/
      envs/apicc-dev/proxies/SYSGEN788836350-My-API/base.yaml
    gcp-prj-apigee-qa-np-01/
      envs/apicc-test1/proxies/SYSGEN788836350-My-API/base.yaml
    gcp-prj-apigee-prod-01/
      envs/apicc-prod/proxies/SYSGEN788836350-My-API/base.yaml
```

## References
- Schemas: [../apiproxy.schema.json](../apiproxy.schema.json), [../apiproduct.schema.json](../apiproduct.schema.json)
- Workflows: [workflows/validate-proxy.md](workflows/validate-proxy.md), [workflows/validate-product.md](workflows/validate-product.md)
- Testing: [../TESTING-CHECKLIST.md](../TESTING-CHECKLIST.md), [E2E-TESTING-DPEAPI-18719.md](E2E-TESTING-DPEAPI-18719.md)
- Repository config: [repository-configuration.md](repository-configuration.md)

## Troubleshooting
- Undeploy/redeploy guidance: [docs/PROXY-UNDEPLOY.md](PROXY-UNDEPLOY.md)
- General issues: [docs/archive/TROUBLESHOOTING.md](archive/TROUBLESHOOTING.md)

## Shared Flows
- Templates include FlowCallout policies that reference shared flows managed by the platform team.
- Workflows do not validate shared flow existence; imports/deployments may succeed even if a referenced shared flow is missing.
- Expected symptom: runtime faults during policy execution (e.g., FlowCallout failing with "Shared flow not found"). Producers should coordinate with the platform team to ensure required shared flows are deployed before go‑live.

## Notes
- Internal (`apicc-*`) vs external (`ext-apicc-*`) environments: choose based on consumer location; external environments may have additional controls.
- Shared flows are managed by the platform team and referenced via FlowCallout policies; ensure availability before deployment.

### Product File Location & Workflow Triggers
- Canonical product YAML location: `mal-<SYSGEN>/orgs/<org>/products/*.yaml`.
- Workflows are aligned to this location and will validate on PRs and deploy on merge:
  - Validation: [../.github/workflows/validate-product.yml](../.github/workflows/validate-product.yml)
  - Deployment: [../.github/workflows/deploy-products.yml](../.github/workflows/deploy-products.yml)
