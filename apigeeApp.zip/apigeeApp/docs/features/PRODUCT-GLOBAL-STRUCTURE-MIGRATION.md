# Jira User Story: Migrate Product Structure to Global Organization Level

## Story Summary
Migrate API Product storage from MAL-scoped folders to organization-level global directory to support cross-MAL products and align with GitOps repository structure.

---

## User Story

**As a** Platform Architect
**I want** API Products stored at the organization level (`orgs/{org}/global/products/`) instead of within MAL folders
**So that** products can reference proxies from multiple application teams and maintain consistency with the GitOps repository structure

---

## Context & Background

### Current Problem
API Products are currently stored within individual MAL folders:
```
mal-SYSGEN788836350/
└── orgs/
    └── gcp-prj-apigee-dev-np-01/
        └── products/              # ← Current location (wrong)
            └── SYSGEN788836350-E2E-TEST-PRODUCT.yaml
```

**Issues with this approach:**
1. **Cannot support cross-MAL products**: A product cannot reference proxies from multiple application teams
2. **Inconsistent with GitOps repo**: GitOps stores products at `orgs/{org}/global/products/`
3. **Confusing ownership model**: Products appear MAL-specific when they're actually org-level in Apigee
4. **Limits flexibility**: Forces 1:1 relationship between products and MALs

### Desired Structure
```
orgs/
└── gcp-prj-apigee-dev-np-01/
    └── global/
        └── products/              # ← Target location (correct)
            ├── SYSGEN788836350-single-team-product.yaml
            └── SYSGEN999999999-cross-team-product.yaml

mal-SYSGEN788836350/
└── orgs/
    └── gcp-prj-apigee-dev-np-01/
        └── envs/                  # ← Only envs remain in MAL folders
            └── apicc-dev/
                └── proxies/
```

### Benefits
- ✅ **Cross-MAL products**: Support products that reference multiple teams' proxies
- ✅ **GitOps alignment**: Identical structure across applications and gitops repos
- ✅ **Clear ownership**: Products are explicitly org-level, not MAL-specific
- ✅ **Flexible governance**: CODEOWNERS rules can handle team-specific or shared products
- ✅ **Future-proof**: Supports enterprise product strategies (composite APIs, shared services)

---

## Technical Details

### File Structure Changes

**Current (Incorrect):**
```
enterprise-apigeex-applications/
├── mal-SYSGEN123456789/
│   └── orgs/
│       ├── gcp-prj-apigee-dev-np-01/
│       │   └── products/         # ← MOVE FROM HERE
│       ├── gcp-prj-apigee-qa-np-01/
│       │   └── products/         # ← MOVE FROM HERE
│       └── gcp-prj-apigee-prod-01/
│           └── products/         # ← MOVE FROM HERE
└── mal-SYSGEN987654321/
    └── orgs/
        └── gcp-prj-apigee-dev-np-01/
            └── products/         # ← MOVE FROM HERE
```

**Target (Correct):**
```
enterprise-apigeex-applications/
├── orgs/
│   ├── gcp-prj-apigee-dev-np-01/
│   │   └── global/
│   │       └── products/         # ← MOVE TO HERE
│   ├── gcp-prj-apigee-qa-np-01/
│   │   └── global/
│   │       └── products/         # ← MOVE TO HERE
│   └── gcp-prj-apigee-prod-01/
│       └── global/
│           └── products/         # ← MOVE TO HERE
└── mal-SYSGEN*/
    └── orgs/
        └── {org}/
            └── envs/             # ← Only envs remain
                └── {env}/
                    └── proxies/
```

### Workflow Changes Required

**Files to Update:**

1. **validate-product.yml**:
   ```yaml
   # BEFORE:
   paths:
     - 'mal-SYSGEN*/products/*.yaml'

   # AFTER:
   paths:
     - 'orgs/*/global/products/*.yaml'
   ```

2. **deploy-products.yml**:
   ```yaml
   # BEFORE:
   if [[ "$file" =~ mal-SYSGEN.*/products/.*\.yaml$ ]]; then

   # AFTER:
   if [[ "$file" =~ orgs/.*/global/products/.*\.yaml$ ]]; then
   ```

3. **changed-files action**: Update path filtering logic
4. **extract-mal-metadata action**: Remove MAL extraction for products (org-level only)

### CODEOWNERS Updates

**New ownership patterns needed:**

```
# Option 1: Default platform ownership
/orgs/*/global/products/ @CenturyLink/api-enablement-team

# Option 2: Pattern-based team delegation
/orgs/*/global/products/SYSGEN123456789-* @CenturyLink/team-a
/orgs/*/global/products/SYSGEN987654321-* @CenturyLink/team-b

# Option 3: Explicit per-product (for cross-team products)
/orgs/*/global/products/SYSGEN555555555-composite-product.yaml @CenturyLink/integration-team
```

**Decision needed**: Which CODEOWNERS pattern to use for product governance?

### Documentation Updates

Files requiring updates:
- `README.md` - Update MAL folder layout section
- `docs/PRODUCT-OWNERSHIP-MODEL.md` - Already created, needs review
- `docs/workflows/validate-product.md` - Update path references
- `docs/workflows/deploy-product.md` - Update path references
- `IMPLEMENTATION-STATUS.md` - Add this story to tracking

---

## Acceptance Criteria

### Phase 1: Directory Structure & Migration

- [ ] Create `orgs/` directory structure at repository root
- [ ] Create `orgs/{org}/global/products/` for each org:
  - [ ] `orgs/gcp-prj-apigee-dev-np-01/global/products/`
  - [ ] `orgs/gcp-prj-apigee-qa-np-01/global/products/`
  - [ ] `orgs/gcp-prj-apigee-prod-01/global/products/`
- [ ] Move existing product YAML files from `mal-*/orgs/*/products/` to `orgs/*/global/products/`
- [ ] Verify all product files have unique names (no naming conflicts across MALs)
- [ ] Delete empty `mal-*/orgs/*/products/` directories

### Phase 2: Workflow Updates

- [ ] Update `validate-product.yml`:
  - [ ] Change path trigger from `mal-SYSGEN*/products/*.yaml` to `orgs/*/global/products/*.yaml`
  - [ ] Remove MAL code extraction logic (not needed for products)
  - [ ] Update file validation to expect `orgs/` prefix
  - [ ] Test validation workflow with new path
- [ ] Update `deploy-products.yml`:
  - [ ] Change path trigger from `mal-SYSGEN*/products/*.yaml` to `orgs/*/global/products/*.yaml`
  - [ ] Update changed-files filtering logic
  - [ ] Update product extraction from new path
  - [ ] Remove MAL-based metadata extraction for products
  - [ ] Test deployment workflow with new path
- [ ] Update `.github/actions/changed-files/action.yml`:
  - [ ] Add `orgs/*/global/products/` to path filters
  - [ ] Remove `mal-SYSGEN*/products/` from path filters
- [ ] Update `test-validate-product.yml`:
  - [ ] Update test file paths to use `orgs/` structure
  - [ ] Verify test suite passes with new structure

### Phase 3: CODEOWNERS & Governance

- [ ] Decide on CODEOWNERS strategy (platform, team-based, or hybrid)
- [ ] Update `CODEOWNERS` file with product ownership rules
- [ ] Test CODEOWNERS rules with sample PR
- [ ] Document ownership process in `docs/CODEOWNERS-SETUP.md`

### Phase 4: Documentation Updates

- [ ] Update `README.md`:
  - [ ] Remove products from MAL folder layout section
  - [ ] Add products to global organization structure section
  - [ ] Update diagram/examples
- [ ] Review and finalize `docs/PRODUCT-OWNERSHIP-MODEL.md`
- [ ] Update `docs/workflows/validate-product.md` with new paths
- [ ] Update `docs/workflows/deploy-product.md` with new paths
- [ ] Add entry to `IMPLEMENTATION-STATUS.md`
- [ ] Update any references in existing documentation

### Phase 5: Testing & Validation

- [ ] Test cross-MAL product scenario:
  - [ ] Create product referencing proxies from 2 different MALs
  - [ ] Validate product YAML passes validation
  - [ ] Deploy product successfully
  - [ ] Verify product references both proxies correctly
- [ ] Test single-MAL product (most common case):
  - [ ] Create product with one MAL's proxies
  - [ ] Validate and deploy successfully
- [ ] Test CODEOWNERS approval workflow:
  - [ ] Create PR with product change
  - [ ] Verify correct team is requested for review
  - [ ] Test approval/merge process
- [ ] Test multi-org deployment:
  - [ ] Change product in dev org
  - [ ] Verify deployment to dev only
  - [ ] Promote to qa/prod orgs
  - [ ] Verify matrix deployment works correctly

### Phase 6: Rollout & Communication

- [ ] Create migration guide for API producers
- [ ] Notify teams of new product location
- [ ] Update onboarding documentation
- [ ] Add examples of cross-MAL products to documentation
- [ ] Plan communication for existing product owners

---

## Dependencies

**Blockers:**
- None - this is a structural refactoring that can be done independently

**Coordination Needed:**
- **API Enablement Team**: Finalize CODEOWNERS governance strategy
- **Application Teams**: Communicate migration timeline for existing products
- **Documentation Team**: Review updated docs before rollout

**Related Stories:**
- DPEAPI-18711 (Validate Product) - Already complete, needs path updates
- DPEAPI-18712 (Deploy Product Action) - Already complete, needs path updates
- DPEAPI-18713 (Product Deployment Workflows) - Already complete, needs path updates

---

## Testing Strategy

### Unit Testing
- [x] Validate workflow syntax (YAML linting)
- [ ] Test changed-files action with new paths
- [ ] Test validation workflow with new product locations
- [ ] Test deployment workflow with new product locations

### Integration Testing
- [ ] End-to-end test: Create → Validate → Deploy → Verify
- [ ] Multi-org matrix deployment test
- [ ] Cross-MAL product deployment test
- [ ] CODEOWNERS approval gate test

### Edge Cases
- [ ] Product with no proxies (should fail validation)
- [ ] Product referencing non-existent proxy (should fail validation)
- [ ] Product with mixed MAL proxies (should succeed)
- [ ] Product name conflicts (verify uniqueness across orgs)
- [ ] Empty products directory (should handle gracefully)

---

## Risk Assessment

| Risk | Impact | Likelihood | Mitigation |
|------|--------|------------|------------|
| Breaking existing product deployments | **High** | Low | Thorough testing before rollout |
| CODEOWNERS conflicts | Medium | Medium | Clear documentation and examples |
| Confusion for API producers | Medium | Medium | Migration guide and communication |
| Workflow regression | **High** | Low | Test suite coverage before merge |
| Cross-team coordination | Low | Medium | Plan communication timeline |

---

## Success Metrics

- ✅ All existing products migrated successfully (0 failures)
- ✅ Validation and deployment workflows pass for all orgs
- ✅ Cross-MAL product example working end-to-end
- ✅ CODEOWNERS approval process functioning
- ✅ Documentation updated and accurate
- ✅ Zero support tickets from confused producers (after migration guide published)

---

## Definition of Done

- [ ] All acceptance criteria met
- [ ] All workflows updated and tested
- [ ] CODEOWNERS configured and tested
- [ ] Documentation updated (README, docs/, IMPLEMENTATION-STATUS.md)
- [ ] Cross-MAL product example created and tested
- [ ] Migration guide published
- [ ] PR reviewed and approved
- [ ] Changes merged to main
- [ ] Post-deployment verification complete
- [ ] Teams notified of changes

---

## Implementation Tasks Breakdown

### Task 1: Create Directory Structure
**Effort**: 30 minutes
```bash
mkdir -p orgs/gcp-prj-apigee-dev-np-01/global/products
mkdir -p orgs/gcp-prj-apigee-qa-np-01/global/products
mkdir -p orgs/gcp-prj-apigee-prod-01/global/products
```

### Task 2: Move Product Files
**Effort**: 1 hour
```bash
# For each MAL and org combination
find mal-SYSGEN*/orgs/*/products/ -name "*.yaml" -exec sh -c '
  for file; do
    org=$(echo "$file" | cut -d/ -f3)
    filename=$(basename "$file")
    mv "$file" "orgs/$org/global/products/$filename"
  done
' sh {} +

# Remove empty directories
find mal-SYSGEN*/orgs/*/products/ -type d -empty -delete
```

### Task 3: Update validate-product.yml
**Effort**: 2 hours
- Update path triggers
- Remove MAL extraction logic
- Update file path validation
- Test with new structure

### Task 4: Update deploy-products.yml
**Effort**: 3 hours
- Update path triggers
- Update changed-files filtering
- Remove MAL metadata extraction for products
- Update org/env derivation logic
- Test multi-org deployment

### Task 5: Update Actions
**Effort**: 2 hours
- Update changed-files action
- Update any product-specific logic
- Test action outputs

### Task 6: CODEOWNERS Strategy
**Effort**: 2 hours
- Decide on governance model
- Implement CODEOWNERS rules
- Test approval workflows
- Document process

### Task 7: Documentation
**Effort**: 3 hours
- Update README.md
- Finalize PRODUCT-OWNERSHIP-MODEL.md
- Update workflow docs
- Add IMPLEMENTATION-STATUS.md entry
- Create migration guide

### Task 8: Testing
**Effort**: 4 hours
- Unit test workflows
- Integration test deployments
- Test cross-MAL products
- Test CODEOWNERS approvals
- Multi-org validation

### Task 9: Communication & Rollout
**Effort**: 1 hour
- Notify teams
- Share migration guide
- Update onboarding docs

**Total Estimated Effort**: 18-20 hours (2-3 days)

---

## Example Product Configurations

### Single-MAL Product (Common Case)
```yaml
# orgs/gcp-prj-apigee-dev-np-01/global/products/SYSGEN123456789-customer-api-product.yaml
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProduct
metadata:
  name: SYSGEN123456789-customer-api-product
  description: Customer API Product
  owner: team-a@company.com
  sysgen: SYSGEN123456789
  approvedBySRB: true
spec:
  approval: auto
  access: internal
  environments:
    - apicc-dev
  proxies:
    - name: SYSGEN123456789-customer-api      # Team A proxy
    - name: SYSGEN123456789-customer-profile  # Team A proxy
```

### Cross-MAL Product (New Capability)
```yaml
# orgs/gcp-prj-apigee-dev-np-01/global/products/SYSGEN555555555-composite-order-product.yaml
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProduct
metadata:
  name: SYSGEN555555555-composite-order-product
  description: Composite Order Management Product
  owner: integration-team@company.com
  sysgen: SYSGEN555555555
  approvedBySRB: true
spec:
  approval: auto
  access: internal
  environments:
    - apicc-dev
  proxies:
    - name: SYSGEN123456789-customer-api     # Team A proxy
    - name: SYSGEN987654321-order-api        # Team B proxy
    - name: SYSGEN555555555-payment-api      # Integration team proxy
```

---

## References

- **Design Document**: `docs/PRODUCT-OWNERSHIP-MODEL.md`
- **GitOps Product Guide**: `enterprise-apigeex-gitops/docs/PRODUCT-WORKFLOW-GUIDE.md`
- **Related Workflows**:
  - `.github/workflows/validate-product.yml`
  - `.github/workflows/deploy-products.yml`
- **Schemas**:
  - `apiproduct.schema.json`

---

## Notes

- This migration maintains backward compatibility for proxies - only product locations change
- The migration can be done in a single PR since it's structural, not functional
- No changes required to product YAML schema or deployment logic
- Existing deployed products are unaffected - this is repository structure only
- Consider creating a "cross-MAL products" example as part of documentation

---

## Jira Fields

**Epic**: DPEAPI-19358 (Enterprise API Platform - Applications Repository)
**Story Points**: 8
**Priority**: Medium
**Assignee**: TBD
**Sprint**: TBD
**Labels**: infrastructure, migration, products, multi-org, documentation
**Components**: Workflows, Documentation, Governance
