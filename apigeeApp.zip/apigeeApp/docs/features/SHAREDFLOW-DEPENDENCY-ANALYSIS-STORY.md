# User Story: Shared Flow Dependency Analysis

**Jira ID**: TBD
**Title**: Analyze Shared Flow Usage Across Proxies
**Story Points**: 5
**Priority**: Medium
**Epic**: DPEAPI-18215 (or new Operations epic)

---

## User Story

*As a* platform engineer
*I want* to identify which API proxies are using a specific shared flow
*So that* I can assess impact before making changes and understand shared flow adoption

---

## Problem Statement

When maintaining shared flows (like OAuth, logging, error handling), we need to know which proxies depend on them before:
- Making breaking changes to the shared flow
- Deprecating or removing a shared flow
- Understanding usage patterns for optimization
- Planning rollout of new shared flow versions

Currently, there's no easy way to determine this without manually inspecting each proxy bundle.

---

## Acceptance Criteria

### Core Functionality
- [ ] Script/tool accepts shared flow name as input
- [ ] Queries all API proxies in specified Apigee organization
- [ ] Analyzes each proxy revision for FlowCallout policies referencing the shared flow
- [ ] Returns list of proxies using the shared flow with:
  - Proxy name
  - Deployed environments
  - Revision numbers using the shared flow
  - FlowCallout policy names

### Output Formats
- [ ] Console output (human-readable table)
- [ ] JSON output (machine-readable)
- [ ] CSV export option
- [ ] Markdown report option

### Multi-Org Support
- [ ] Works across all Apigee organizations (dev, qa, prod)
- [ ] Can analyze single org or all orgs
- [ ] Aggregates results across orgs

### Performance
- [ ] Handles 100+ proxies efficiently
- [ ] Provides progress indicator for long operations
- [ ] Caches proxy bundles to avoid redundant API calls

### Error Handling
- [ ] Graceful handling of missing permissions
- [ ] Clear error messages for invalid inputs
- [ ] Continues analysis if individual proxy fails

---

## Technical Approach

### Option 1: Python Script (Recommended)
```python
# Tool: analyze-sharedflow-usage.py
# Usage: python analyze-sharedflow-usage.py --sharedflow SHAREDFLOW-NAME --org APIGEE-ORG

Features:
- Uses Apigee Management API
- Leverages apigeecli for authentication
- Parallel processing for speed
- Rich output formatting with tabulate
```

**Implementation Steps**:
1. Authenticate with GCP/Apigee using service account
2. List all proxies in organization
3. For each proxy, get deployed revisions
4. Download proxy bundle (ZIP) for each revision
5. Extract and parse FlowCallout policies
6. Check if SharedFlowBundle references target shared flow
7. Aggregate results and generate report

### Option 2: Bash Script with apigeecli
```bash
# Tool: analyze-sharedflow-usage.sh
# Usage: ./analyze-sharedflow-usage.sh SHAREDFLOW-NAME APIGEE-ORG

Features:
- Uses apigeecli commands
- XML parsing with xmlstarlet
- Simpler but potentially slower
```

### Option 3: GitHub Actions Workflow
- Automated analysis on schedule or manual trigger
- Posts results as workflow summary
- Can notify via Teams/Slack if dependencies found
- Good for continuous monitoring

---

## Data Sources

### Apigee Management API Endpoints
1. **List Proxies**: `GET /v1/organizations/{org}/apis`
2. **Get Proxy Revisions**: `GET /v1/organizations/{org}/apis/{api}/revisions`
3. **Get Proxy Deployments**: `GET /v1/organizations/{org}/apis/{api}/deployments`
4. **Export Proxy Bundle**: `GET /v1/organizations/{org}/apis/{api}/revisions/{rev}?format=bundle`

### Analysis Pattern
Look for FlowCallout policies in:
- `apiproxy/proxies/*.xml` (ProxyEndpoint definitions)
- `apiproxy/targets/*.xml` (TargetEndpoint definitions)
- `apiproxy/policies/*FlowCallout*.xml` (FlowCallout policy files)

Example FlowCallout policy:
```xml
<FlowCallout name="FC-SharedFlow-OAuth">
    <SharedFlowBundle>SYSGEN788836350-OAuth-Validation</SharedFlowBundle>
</FlowCallout>
```

---

## Use Cases

### Use Case 1: Pre-Change Impact Analysis
**Scenario**: Need to update OAuth shared flow
**Action**: Run analysis to find all dependent proxies
**Result**: Know which teams to notify and which environments affected

### Use Case 2: Deprecation Planning
**Scenario**: Retiring old error handling shared flow
**Action**: Identify proxies still using old version
**Result**: Create migration plan for affected proxies

### Use Case 3: Adoption Tracking
**Scenario**: New logging shared flow deployed
**Action**: Track adoption over time
**Result**: Report on standardization progress

### Use Case 4: Environment-Specific Analysis
**Scenario**: Production shared flow has issue
**Action**: Quickly identify prod proxies affected
**Result**: Rapid incident response

---

## Output Example

### Console Output
```
Shared Flow Usage Analysis: SYSGEN788836350-OAuth-Validation
Organization: gcp-prj-apigee-dev-np-01

Found 12 proxies using this shared flow:

┌─────────────────────────────────┬──────────────┬──────────┬─────────────────────────┐
│ Proxy Name                      │ Environment  │ Revision │ FlowCallout Policy      │
├─────────────────────────────────┼──────────────┼──────────┼─────────────────────────┤
│ SYSGEN788836350-Users-API       │ apicc-dev    │ 3        │ FC-OAuth-Validation     │
│ SYSGEN788836350-Orders-API      │ apicc-dev    │ 2        │ FC-Check-OAuth          │
│ SYSGEN788836350-Payments-API    │ apicc-dev    │ 1        │ FC-OAuth-Validation     │
│ SYSGEN788836350-Users-API       │ apicc-test1  │ 3        │ FC-OAuth-Validation     │
│ ...                             │ ...          │ ...      │ ...                     │
└─────────────────────────────────┴──────────────┴──────────┴─────────────────────────┘

Summary:
- Total proxies using shared flow: 12
- Unique proxies: 8
- Environments affected: apicc-dev (8), apicc-test1 (4)
```

### JSON Output
```json
{
  "sharedFlow": "SYSGEN788836350-OAuth-Validation",
  "organization": "gcp-prj-apigee-dev-np-01",
  "analyzedAt": "2026-01-07T15:30:00Z",
  "results": [
    {
      "proxy": "SYSGEN788836350-Users-API",
      "environment": "apicc-dev",
      "revision": 3,
      "flowCallouts": [
        {
          "policyName": "FC-OAuth-Validation",
          "location": "apiproxy/proxies/default.xml"
        }
      ]
    }
  ],
  "summary": {
    "totalUsages": 12,
    "uniqueProxies": 8,
    "affectedEnvironments": ["apicc-dev", "apicc-test1"]
  }
}
```

---

## Future Enhancements

- [ ] Reverse analysis: Show all shared flows used by a specific proxy
- [ ] Dependency graph visualization
- [ ] Version tracking (which proxy uses which shared flow revision)
- [ ] Integration with CI/CD (block shared flow changes if breaking)
- [ ] API endpoint for programmatic access
- [ ] Historical usage tracking over time

---

## Related Work

- **DPEAPI-18215**: Multi-org GitOps implementation (operational tooling fits here)
- **Shared Flows**: enterprise-apigeex-bundles/sharedflows/
- **Composite Actions**: Could become reusable GitHub Action
- **API Management**: Part of platform operational excellence

---

## Dependencies

- GCP service account with Apigee API access
- apigeecli installed (if using bash approach)
- Python 3.8+ with requests library (if using Python approach)
- Access to all Apigee organizations

---

## Success Metrics

- Analysis completes in < 5 minutes for 100 proxies
- 100% accuracy in dependency detection
- Zero false positives or false negatives
- Tool used by 3+ team members
- Reduces impact analysis time from hours to minutes

---

## Testing Plan

1. **Test with known dependencies**: Use existing proxies with documented shared flow usage
2. **Test with no dependencies**: Verify no false positives
3. **Test multi-org**: Run across dev/qa/prod
4. **Test error scenarios**: Missing permissions, network issues
5. **Performance test**: Run against full production proxy inventory

---

## Documentation Requirements

- [ ] README with installation and usage
- [ ] Command-line help text
- [ ] Example outputs for each format
- [ ] Troubleshooting guide
- [ ] API reference (if programmatic access added)

---

## Estimated Effort

**Story Points**: 5
**Time Estimate**: 6-8 hours

**Breakdown**:
- Script development: 3-4 hours
- Multi-org support: 1 hour
- Output formatting: 1 hour
- Testing: 1-2 hours
- Documentation: 1 hour

---

## Priority Justification

**Medium Priority**: Operational tooling that improves maintainability but not blocking production deployment.

**Value**:
- Reduces risk of breaking changes
- Improves operational efficiency
- Enables better shared flow governance
- Foundation for future dependency management

**Dependencies**: None - can be developed independently

---

## Acceptance Testing

### Test Case 1: Find All Usages
```bash
python analyze-sharedflow-usage.py \
  --sharedflow SYSGEN788836350-OAuth-Validation \
  --org gcp-prj-apigee-dev-np-01

Expected: List of all proxies using OAuth shared flow
```

### Test Case 2: Multi-Org Analysis
```bash
python analyze-sharedflow-usage.py \
  --sharedflow SYSGEN788836350-Error-Handling \
  --all-orgs

Expected: Aggregated results across dev/qa/prod
```

### Test Case 3: JSON Export
```bash
python analyze-sharedflow-usage.py \
  --sharedflow SYSGEN788836350-Logging \
  --org gcp-prj-apigee-qa-np-01 \
  --format json > results.json

Expected: Valid JSON output saved to file
```

### Test Case 4: No Dependencies
```bash
python analyze-sharedflow-usage.py \
  --sharedflow UNUSED-SHARED-FLOW \
  --org gcp-prj-apigee-dev-np-01

Expected: Clear message indicating no proxies use this shared flow
```

---

## Implementation Location

- **Repository**: enterprise-apigeex-applications (operational scripts)
- **Path**: `scripts/analyze-sharedflow-usage.py`
- **Alternative**: api-enablement-toolkit (if general-purpose tool)

---

**Created**: January 7, 2026
**Author**: Ryan Schilmoeller
**Status**: Draft - Ready for estimation
