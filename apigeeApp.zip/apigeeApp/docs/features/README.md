# Features

Documentation for specific features, enhancements, and user stories.

## Organization

Each feature should have its own subdirectory containing:
- Feature overview and requirements
- Technical design documents
- Implementation details
- User stories and acceptance criteria
- Related PR tracking

## Naming Convention

- Directory: `{feature-name}/` or `{jira-id}/`
- Files: `{JIRA-ID}-{DOCUMENT-TYPE}.md`

Example:
```
features/
├── single-proxy-template/
│   ├── README.md
│   ├── DPEAPI-12345-DETAILED-DESIGN.md
│   ├── DPEAPI-12345-USER-STORY.md
│   └── DPEAPI-12345-IMPLEMENTATION-SUMMARY.md
└── oauth-improvements/
    ├── README.md
    └── DPEAPI-67890-DESIGN.md
```
