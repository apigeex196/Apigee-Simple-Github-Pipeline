# DPEAPI-20005: Apigee X CC | Single Proxy Template - Refactor Pipelines

## User Story

**As a** Platform Engineer
**I want** to update the GitOps and Applications repository schemas, validation, and deployment pipelines to support the Single Proxy Template with configurable proxy and backend security types
**So that** API producers can deploy proxies using any of the 11 supported security model combinations through a single, flexible template configuration

---

## Background

The API Enablement team is consolidating 4 existing proxy templates into 1 single proxy template (`SYSGEN788836350-Single_Proxy_Template`) that handles 11 different security model combinations (A-L, excluding H & M) using two new shared flows:
- `SYSGEN788836350-Proxy-Security` (frontend/proxy security)
- `SYSGEN788836350-Backend-Security` (backend security)

This story focuses on updating the **infrastructure** (schemas, validation, pipelines, examples) to support this architectural change. The actual template and shared flow development is handled by DPEAPI-19093 and related stories.

**Current State:**
- 4 hardcoded templates: `jwt-oauth-proxy-ahpt-backend`, `jwt-proxy-ahpt-backend`, `oauth-proxy-jwt-backend`, `oauth-proxy-oauth-backend`
- Each template supports only 1 specific proxy/backend security combination
- Missing use cases: LIAM OAuth, Basic Auth backend, mTLS backend

**Target State:**
- 1 configurable template: `single-proxy-template`
- 11 security model combinations supported
- API producers specify `proxySecurityType` and `backendSecurityType` in proxy YAML
- Template calls shared flows with appropriate security parameters

---

## Acceptance Criteria

### 1. Schema Updates (Both Repos)

**GitOps `apiproxy.schema.json`:**
- [ ] Add `proxySecurityType` enum field with values: `oauth`, `liamOauth`, `jwt`, `jwtLiamOauth`
- [ ] Add `backendSecurityType` enum field with values: `apigeeJwt`, `liamJwt`, `oauth`, `basicAuth`, `mtls`, `ahpt`
- [ ] Add `single-proxy-template` to `spec.template` enum (keep existing templates for backward compatibility)
- [ ] Add `spec.oauthBackend` object with `tokenEndpoint` and `kvmName` properties
- [ ] Add `spec.basicAuthBackend` object with `kvmName` property
- [ ] Add `spec.mtlsBackend` object with `certificateRef` and `kvmName` properties
- [ ] Add conditional validation: if `template` is `single-proxy-template`, require `proxySecurityType` and `backendSecurityType`
- [ ] Add conditional validation: if `proxySecurityType` includes JWT (`jwt` or `jwtLiamOauth`), require `spec.jwt` configuration
- [ ] Add conditional validation: if `backendSecurityType` is `oauth`, require `spec.oauthBackend`
- [ ] Add conditional validation: if `backendSecurityType` is `basicAuth`, require `spec.basicAuthBackend`
- [ ] Add conditional validation: if `backendSecurityType` is `mtls`, require `spec.mtlsBackend`

**Applications `apiproxy.schema.json`:**
- [ ] Mirror all schema changes from GitOps (schemas must stay synchronized)

### 2. Template Mappings (Both Repos)

- [ ] **GitOps `template-mappings.json`**: Add entry for `"single-proxy-template": "SYSGEN788836350-Single_Proxy_Template"` (keep existing mappings)
- [ ] **Applications `template-mappings.json`**: Mirror GitOps changes

### 3. Validation Logic

**GitOps `.github/workflows/validate-proxy.yml`:**
- [ ] Add step to validate `proxySecurityType` field is present and valid when using single template
- [ ] Add step to validate `backendSecurityType` field is present and valid when using single template
- [ ] Add step to validate security type combination is supported (matches matrix of 11 valid models)
- [ ] Add step to validate required conditional configuration objects are present
- [ ] Provide clear error messages for invalid combinations or missing configuration

**GitOps Validation Scripts** (new files in `.github/scripts/`):
- [ ] Create `validate-security-combination.sh` - validates proxy+backend security combination against matrix
- [ ] Create `validate-security-config.sh` - validates conditional required fields based on security types

**Applications `.github/actions/validate-proxy/action.yml`:**
- [ ] Add validation for `proxySecurityType` and `backendSecurityType` fields
- [ ] Add validation for security type combinations (reuse logic from GitOps)
- [ ] Add validation for conditional required fields
- [ ] Provide helpful error messages

**Applications `.github/workflows/validate-proxy.yml`:**
- [ ] Update to use enhanced validation action

### 4. Example Proxy YAML Files

**GitOps `examples/single-proxy-template/`** - Create 11 example files demonstrating all supported security models:

- [ ] `README.md` - Overview of single proxy template with links to all examples
- [ ] `model-a-oauth-apigeeJwt.yaml` - OAuth proxy → Apigee JWT backend
- [ ] `model-b-oauth-oauth.yaml` - OAuth proxy → OAuth backend
- [ ] `model-c-oauth-basicAuth.yaml` - OAuth proxy → Basic Auth backend (with KVM config)
- [ ] `model-d-oauth-mtls.yaml` - OAuth proxy → mTLS backend (with certificate config)
- [ ] `model-e-liamOauth-liamJwt.yaml` - LIAM OAuth proxy → LIAM JWT backend
- [ ] `model-f-liamOauth-apigeeJwt.yaml` - LIAM OAuth proxy → Apigee JWT backend
- [ ] `model-g-jwt-ahpt.yaml` - JWT proxy → Auth Header Pass Thru backend
- [ ] `model-i-jwt-oauth.yaml` - JWT proxy → OAuth backend
- [ ] `model-j-jwt-basicAuth.yaml` - JWT proxy → Basic Auth backend
- [ ] `model-k-jwt-mtls.yaml` - JWT proxy → mTLS backend
- [ ] `model-l-jwtLiamOauth-ahpt.yaml` - JWT/LIAM OAuth hybrid → AHPT backend

Each example must include:
- [ ] Complete metadata with SYSGEN naming convention
- [ ] Taxonomy label
- [ ] Template reference to `single-proxy-template`
- [ ] Appropriate `proxySecurityType` and `backendSecurityType` values
- [ ] All required conditional configuration objects (jwt, oauthBackend, basicAuthBackend, mtlsBackend)
- [ ] Routing configuration
- [ ] Comments explaining the security model

### 5. Documentation

**GitOps `README.md`:**
- [ ] Update template table to include single proxy template
- [ ] Add section explaining `proxySecurityType` and `backendSecurityType` configuration
- [ ] Add table showing old template → new security type mapping
- [ ] Mark old templates as DEPRECATED with migration guidance
- [ ] Link to example files in `/examples/single-proxy-template/`

**Applications `README.md`:**
- [ ] Mirror documentation updates from GitOps

**Migration Guide** (both repos):
- [ ] Create `docs/SINGLE-PROXY-TEMPLATE-MIGRATION.md`
- [ ] Document old template → new configuration mapping
- [ ] Provide before/after YAML examples for each old template
- [ ] Document timeline for deprecation
- [ ] Include troubleshooting section
- [ ] List new capabilities enabled by single template

### 6. Testing

- [ ] All 11 example YAML files pass schema validation
- [ ] Validation correctly accepts valid security type combinations
- [ ] Validation correctly rejects invalid security type combinations
- [ ] Validation provides helpful error messages for missing required configuration
- [ ] Backward compatibility: existing proxy YAMLs using old templates still validate successfully
- [ ] Integration test: At least 3 different security model combinations can be validated end-to-end

---

## Security Model Matrix

Based on team decision, supporting 11 models (A-L, excluding H & M):

| Model | Proxy Security Type | Backend Security Type |
|-------|-------------------|---------------------|
| **A** | `oauth` | `apigeeJwt` |
| **B** | `oauth` | `oauth` |
| **C** | `oauth` | `basicAuth` |
| **D** | `oauth` | `mtls` |
| **E** | `liamOauth` | `liamJwt` |
| **F** | `liamOauth` | `apigeeJwt` |
| **G** | `jwt` | `ahpt` |
| **I** | `jwt` | `oauth` |
| **J** | `jwt` | `basicAuth` |
| **K** | `jwt` | `mtls` |
| **L** | `jwtLiamOauth` | `ahpt` |

---

## Implementation Approach

### Phase 1: Schema & Validation (Can Start Immediately ✅)

**Confidence Level:** 100% - Based on confirmed security model matrix

**What we can implement NOW:**
1. Schema updates (new fields, enums, conditional validation)
2. Validation scripts and workflow updates
3. Example YAML files for all 11 models
4. Documentation updates (README, migration guide)

**Why we can start:** Security model matrix is finalized, schema structure is known

### Phase 2: Template Integration (Blocked ⏸️)

**Blockers:**
- Template bundle name confirmation (current assumption: `SYSGEN788836350-Single_Proxy_Template`)
- Template parameter passing mechanism TBD
- Shared flow interface contract TBD

**What we need:**
- Confirmation on how template receives `proxySecurityType` and `backendSecurityType` values
- build-template-mapping.json updates
- Deployment workflow updates

### Phase 3: End-to-End Testing (Blocked ⏸️)

**Blockers:**
- `SYSGEN788836350-Proxy-Security` shared flow must be deployed
- `SYSGEN788836350-Backend-Security` shared flow must be deployed
- Single proxy template must be released

---

## Dependencies

**Blocking (Must Complete Before This Work):**
- ✅ DPEAPI-19093: Proxy Security shared flow implementation (Troy)
- ✅ DPEAPI-19093: Backend Security shared flow implementation (Andre/Naveed)
- ✅ Jeremy: Single Proxy Template creation and release

**Coordinating (Parallel Work):**
- Jeremy: Proxy Templates KB page updates
- Troy: Proxy Security shared flows KB page updates
- Andre: Backend Security shared flows KB page updates

---

## Definition of Done

- [ ] All acceptance criteria completed
- [ ] Schema changes deployed to both GitOps and Applications repos
- [ ] All 11 example proxy YAMLs validate successfully against new schema
- [ ] Validation scripts correctly enforce security model combinations
- [ ] Migration guide documentation published in both repos
- [ ] README.md updated in both repos
- [ ] Backward compatibility verified: existing proxies still validate
- [ ] Code review completed and approved
- [ ] PR merged to main branch (both repos)
- [ ] Team walkthrough/demo completed showing all 11 examples validating

---

## Out of Scope

- Template bundle creation (DPEAPI-19093 - Jeremy)
- Shared flow implementation (DPEAPI-19093 - Troy, Andre, Naveed)
- Shared flow KB page updates (handled by shared flow owners)
- Deployment pipeline updates for passing security types to template (Phase 2 - blocked)
- End-to-end testing with deployed proxies (Phase 3 - blocked)
- Cleanup/removal of old templates from schema (separate future story after migration period)

---

## Technical Notes

### Old Template → New Configuration Mapping

| Old Template | New proxySecurityType | New backendSecurityType |
|-------------|----------------------|------------------------|
| `jwt-oauth-proxy-ahpt-backend` | `jwtLiamOauth` | `ahpt` |
| `jwt-proxy-ahpt-backend` | `jwt` | `ahpt` |
| `oauth-proxy-jwt-backend` | `oauth` | `apigeeJwt` |
| `oauth-proxy-oauth-backend` | `oauth` | `oauth` |

### Example YAML Structure

```yaml
spec:
  template: single-proxy-template
  proxySecurityType: oauth          # Frontend security
  backendSecurityType: basicAuth    # Backend security

  # Conditional configs based on security types:
  basicAuthBackend:                 # Required when backendSecurityType=basicAuth
    kvmName: my-backend-creds

  routing:
    path: /my-api/v1
    target: https://backend.example.com
```

---

## Story Points

**Estimate:** 8-13 (Large)

**Justification:**
- Touches core infrastructure (schemas) in 2 repositories
- Requires creating 11 example files with complete configurations
- Validation logic is complex (combination matrix validation)
- Documentation updates across multiple files
- Must maintain backward compatibility
- Cross-repo coordination required

---

## Priority

**HIGH** - Blocks adoption of new security models (LIAM OAuth, Basic Auth, mTLS)

---

## Sprint

**PC38.1** - Coordinate with shared flow completion timeline

---

## Related Stories

- DPEAPI-19093: Single Proxy Template - Shared Flows Implementation (Parent Epic)
- Stories for Proxy Security shared flow (Troy)
- Stories for Backend Security shared flow (Andre/Naveed)
- Jeremy's template creation work

---

## Acceptance Testing Plan

### Test Scenario 1: Schema Validation
- Create proxy YAML with `single-proxy-template` and valid security types
- Run schema validation (ajv-cli)
- **Expected:** Validation passes

### Test Scenario 2: Invalid Combination
- Create proxy YAML with invalid combination (e.g., `jwt` + `liamJwt`)
- Run validation workflow
- **Expected:** Validation fails with helpful error message

### Test Scenario 3: Missing Required Config
- Create proxy YAML with `backendSecurityType: oauth` but no `oauthBackend` config
- Run validation workflow
- **Expected:** Validation fails indicating missing required field

### Test Scenario 4: Backward Compatibility
- Use existing proxy YAML with old template name
- Run validation workflow
- **Expected:** Validation passes, no breaking changes

### Test Scenario 5: All Examples Validate
- Run validation against all 11 example YAML files
- **Expected:** All examples pass validation

---

## Open Questions (TBD - Not Blocking Phase 1)

1. **Template parameter passing mechanism** - How does template receive security types? (Needed for Phase 2)
2. **Final template bundle name** - Confirm exact name for template-mappings.json (Needed for Phase 2)
3. **Shared flow interface contract** - What variables must be set? (Needed for Phase 2)
4. **KVM structure for Basic Auth/mTLS** - Exact JSON format for credentials (Needed for example accuracy)
5. **Migration timeline** - How long to maintain backward compatibility? (Needed for Phase 3)

These will be resolved during coordination with Jeremy's team before Phase 2 implementation.

---

**See detailed design document:** [DPEAPI-20005-DETAILED-DESIGN.md](./DPEAPI-20005-DETAILED-DESIGN.md)
