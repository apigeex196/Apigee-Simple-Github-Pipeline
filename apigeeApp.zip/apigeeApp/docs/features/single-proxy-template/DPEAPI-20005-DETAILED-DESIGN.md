# DPEAPI-20005: Single Proxy Template - Pipeline Refactoring
## Detailed Design Document

**Version:** 1.0 DRAFT
**Date:** January 23, 2026
**Author:** Platform Engineering Team
**Status:** DRAFT - Pending template/shared flow finalization

---

## Executive Summary

This design document outlines the infrastructure changes required to support the Single Proxy Template architecture in both the GitOps and Applications repositories. The work enables API producers to configure proxies using any of 11 supported security model combinations through a single, flexible template.

**Key Changes:**
- Schema updates: Add `proxySecurityType` and `backendSecurityType` fields
- Template consolidation: 4 templates → 1 single template (with backward compatibility)
- Validation enhancements: Validate security type combinations
- 11 example proxy YAMLs demonstrating all supported models
- Migration documentation and tooling

---

## 1. Architecture Overview

### 1.1 Current State (4 Templates)

```
┌─────────────────────────────────────────────────────────────┐
│ API Producer writes proxy.yaml                              │
│ spec:                                                        │
│   template: oauth-proxy-jwt-backend  ← Hardcoded template   │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ Template determines BOTH proxy AND backend security         │
│ - oauth-proxy-jwt-backend                                   │
│ - oauth-proxy-oauth-backend                                 │
│ - jwt-proxy-ahpt-backend                                    │
│ - jwt-oauth-proxy-ahpt-backend                              │
└─────────────────────────────────────────────────────────────┘
```

**Limitations:**
- Only 4 combinations supported
- Missing use cases (LIAM OAuth, Basic Auth, mTLS)
- Template proliferation for each new combination

### 1.2 Target State (Single Template + Configurable Security)

```
┌─────────────────────────────────────────────────────────────┐
│ API Producer writes proxy.yaml                              │
│ spec:                                                        │
│   template: single-proxy-template                           │
│   proxySecurityType: oauth          ← Configurable          │
│   backendSecurityType: basicAuth    ← Configurable          │
│   basicAuthBackend:                 ← Conditional config    │
│     kvmName: my-backend-creds                               │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ Single Template calls shared flows with security params     │
│ - FC-Proxy-Security (handles 4 proxy security models)       │
│ - FC-Backend-Security (handles 6 backend security models)   │
└─────────────────────────────────────────────────────────────┘
```

**Benefits:**
- 11 security combinations supported immediately
- Easy to add new models (update shared flows, not templates)
- Clear separation of concerns
- Simplified template maintenance

---

## 2. Security Model Matrix

### 2.1 Supported Combinations (11 Models)

Based on the provided matrix, excluding models H and M:

| Model | Proxy Security | Backend Security | Use Case |
|-------|---------------|-----------------|----------|
| **A** | `oauth` | `apigeeJwt` | OAuth (Apigee/Entra) → Apigee JWT |
| **B** | `oauth` | `oauth` | OAuth (Apigee/Entra) → OAuth backend |
| **C** | `oauth` | `basicAuth` | OAuth → Basic Auth backend |
| **D** | `oauth` | `mtls` | OAuth → mTLS backend |
| **E** | `liamOauth` | `liamJwt` | LIAM OAuth → LIAM JWT |
| **F** | `liamOauth` | `apigeeJwt` | LIAM OAuth → Apigee JWT |
| **G** | `jwt` | `ahpt` | JWT (Portal Framework) → AHPT |
| **I** | `jwt` | `oauth` | JWT → OAuth backend |
| **J** | `jwt` | `basicAuth` | JWT → Basic Auth backend |
| **K** | `jwt` | `mtls` | JWT → mTLS backend |
| **L** | `jwtLiamOauth` | `ahpt` | JWT/LIAM OAuth hybrid → AHPT |

### 2.2 Enum Values

**`proxySecurityType`:**
- `oauth` - OAuth (Apigee-minted or Entra ID-minted tokens)
- `liamOauth` - LIAM OAuth tokens
- `jwt` - JWT (Portal Framework)
- `jwtLiamOauth` - JWT or LIAM OAuth (hybrid validation)

**`backendSecurityType`:**
- `apigeeJwt` - Apigee-minted JWT to backend
- `liamJwt` - LIAM-minted JWT to backend
- `oauth` - OAuth token to backend
- `basicAuth` - HTTP Basic Authentication to backend
- `mtls` - Mutual TLS certificate authentication to backend
- `ahpt` - Auth Header Pass Through (Portal Framework or LIAM)

---

## 3. Schema Design

### 3.1 GitOps `apiproxy.schema.json` Changes

**Location:** `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-gitops/apiproxy.schema.json`

#### 3.1.1 Add Template Enum Value

```json
{
  "spec": {
    "properties": {
      "template": {
        "type": "string",
        "description": "The proxy template name.",
        "enum": [
          "single-proxy-template",
          "jwt-oauth-proxy-ahpt-backend",
          "jwt-proxy-ahpt-backend",
          "oauth-proxy-jwt-backend",
          "oauth-proxy-oauth-backend"
        ]
      }
    }
  }
}
```

**Note:** Keep existing templates for backward compatibility during transition period.

#### 3.1.2 Add Security Type Fields

```json
{
  "spec": {
    "properties": {
      "proxySecurityType": {
        "type": "string",
        "description": "Frontend/proxy security model",
        "enum": ["oauth", "liamOauth", "jwt", "jwtLiamOauth"]
      },
      "backendSecurityType": {
        "type": "string",
        "description": "Backend security model",
        "enum": ["apigeeJwt", "liamJwt", "oauth", "basicAuth", "mtls", "ahpt"]
      }
    }
  }
}
```

#### 3.1.3 Add Backend Configuration Objects

```json
{
  "spec": {
    "properties": {
      "oauthBackend": {
        "type": "object",
        "description": "OAuth backend configuration",
        "properties": {
          "tokenEndpoint": {
            "type": "string",
            "description": "OAuth token endpoint URL",
            "pattern": "^https://.*"
          },
          "kvmName": {
            "type": "string",
            "description": "KVM name containing client_id and client_secret",
            "pattern": "^[a-zA-Z0-9_-]+$"
          }
        },
        "required": ["tokenEndpoint", "kvmName"],
        "additionalProperties": false
      },
      "basicAuthBackend": {
        "type": "object",
        "description": "Basic Auth backend configuration",
        "properties": {
          "kvmName": {
            "type": "string",
            "description": "KVM name containing username and password",
            "pattern": "^[a-zA-Z0-9_-]+$"
          }
        },
        "required": ["kvmName"],
        "additionalProperties": false
      },
      "mtlsBackend": {
        "type": "object",
        "description": "mTLS backend configuration",
        "properties": {
          "certificateRef": {
            "type": "string",
            "description": "Reference to client certificate in Apigee",
            "pattern": "^[a-zA-Z0-9_-]+$"
          },
          "kvmName": {
            "type": "string",
            "description": "KVM name containing certificate details if needed",
            "pattern": "^[a-zA-Z0-9_-]+$"
          }
        },
        "required": ["certificateRef"],
        "additionalProperties": false
      }
    }
  }
}
```

#### 3.1.4 Conditional Validation Rules

```json
{
  "spec": {
    "allOf": [
      {
        "if": {
          "properties": {
            "template": { "const": "single-proxy-template" }
          }
        },
        "then": {
          "required": ["proxySecurityType", "backendSecurityType"]
        }
      },
      {
        "if": {
          "properties": {
            "proxySecurityType": { "enum": ["jwt", "jwtLiamOauth"] }
          }
        },
        "then": {
          "required": ["jwt"]
        }
      },
      {
        "if": {
          "properties": {
            "backendSecurityType": { "const": "oauth" }
          }
        },
        "then": {
          "required": ["oauthBackend"]
        }
      },
      {
        "if": {
          "properties": {
            "backendSecurityType": { "const": "basicAuth" }
          }
        },
        "then": {
          "required": ["basicAuthBackend"]
        }
      },
      {
        "if": {
          "properties": {
            "backendSecurityType": { "const": "mtls" }
          }
        },
        "then": {
          "required": ["mtlsBackend"]
        }
      }
    ]
  }
}
```

#### 3.1.5 Security Combination Validation

**Implementation:** Custom validation in workflow (cannot be expressed purely in JSON Schema)

Valid combinations validation matrix:

```javascript
const VALID_COMBINATIONS = [
  { proxy: 'oauth', backend: 'apigeeJwt' },      // Model A
  { proxy: 'oauth', backend: 'oauth' },          // Model B
  { proxy: 'oauth', backend: 'basicAuth' },      // Model C
  { proxy: 'oauth', backend: 'mtls' },           // Model D
  { proxy: 'liamOauth', backend: 'liamJwt' },    // Model E
  { proxy: 'liamOauth', backend: 'apigeeJwt' },  // Model F
  { proxy: 'jwt', backend: 'ahpt' },             // Model G
  { proxy: 'jwt', backend: 'oauth' },            // Model I
  { proxy: 'jwt', backend: 'basicAuth' },        // Model J
  { proxy: 'jwt', backend: 'mtls' },             // Model K
  { proxy: 'jwtLiamOauth', backend: 'ahpt' }     // Model L
];
```

### 3.2 Applications `apiproxy.schema.json` Changes

**Location:** `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications/apiproxy.schema.json`

**Action:** Mirror all changes from GitOps schema (keep schemas synchronized)

---

## 4. Template Mappings

### 4.1 GitOps `template-mappings.json`

**Location:** `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-gitops/template-mappings.json`

**Current:**
```json
{
  "template_mappings": {
    "jwt-oauth-proxy-ahpt-backend": "SYSGEN788836350-JWT_and_OAuth_Proxy_AHPT_Backend_Template",
    "jwt-proxy-ahpt-backend": "SYSGEN788836350-JWT_Proxy_AHPT_Backend_Template",
    "oauth-proxy-jwt-backend": "SYSGEN788836350-OAuth_Proxy_JWT_Backend_Template",
    "oauth-proxy-oauth-backend": "SYSGEN788836350-OAuth_Proxy_OAuth_Backend_Template"
  },
  "release_repository": "CenturyLink/enterprise-apigeex-templates"
}
```

**Updated:**
```json
{
  "template_mappings": {
    "single-proxy-template": "SYSGEN788836350-Apigee_Default_Proxy_Template_V1",
    "jwt-oauth-proxy-ahpt-backend": "SYSGEN788836350-JWT_and_OAuth_Proxy_AHPT_Backend_Template",
    "jwt-proxy-ahpt-backend": "SYSGEN788836350-JWT_Proxy_AHPT_Backend_Template",
    "oauth-proxy-jwt-backend": "SYSGEN788836350-OAuth_Proxy_JWT_Backend_Template",
    "oauth-proxy-oauth-backend": "SYSGEN788836350-OAuth_Proxy_OAuth_Backend_Template"
  },
  "release_repository": "CenturyLink/enterprise-apigeex-templates"
}
```

**Note:** ✅ **FINALIZED** (Jan 24, 2026) - Template bundle name confirmed by Jeremy: `SYSGEN788836350-Apigee_Default_Proxy_Template_V1`

### 4.2 Applications `template-mappings.json`

**Location:** `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications/template-mappings.json`

**Action:** Mirror changes from GitOps

---

## 5. Validation Logic

### 5.1 GitOps Validation Workflow Updates

**Location:** `.github/workflows/validate-proxy.yml`

#### 5.1.1 Enhanced Validation Steps

```yaml
- name: Validate Security Configuration
  run: |
    TEMPLATE=$(yq eval '.spec.template' "$PROXY_FILE")

    if [ "$TEMPLATE" = "single-proxy-template" ]; then
      echo "🔍 Validating single-proxy-template configuration..."

      # Check required fields
      PROXY_SEC=$(yq eval '.spec.proxySecurityType' "$PROXY_FILE")
      BACKEND_SEC=$(yq eval '.spec.backendSecurityType' "$PROXY_FILE")

      if [ "$PROXY_SEC" = "null" ]; then
        echo "❌ Error: proxySecurityType is required for single-proxy-template"
        exit 1
      fi

      if [ "$BACKEND_SEC" = "null" ]; then
        echo "❌ Error: backendSecurityType is required for single-proxy-template"
        exit 1
      fi

      # Validate combination is supported
      ./scripts/validate-security-combination.sh "$PROXY_SEC" "$BACKEND_SEC"

      # Validate conditional requirements
      ./scripts/validate-security-config.sh "$PROXY_FILE" "$PROXY_SEC" "$BACKEND_SEC"
    fi
```

#### 5.1.2 Security Combination Validation Script

**New File:** `.github/scripts/validate-security-combination.sh`

```bash
#!/bin/bash
set -e

PROXY_SEC="$1"
BACKEND_SEC="$2"

# Valid combinations based on matrix
declare -A VALID_COMBOS
VALID_COMBOS["oauth:apigeeJwt"]="A"
VALID_COMBOS["oauth:oauth"]="B"
VALID_COMBOS["oauth:basicAuth"]="C"
VALID_COMBOS["oauth:mtls"]="D"
VALID_COMBOS["liamOauth:liamJwt"]="E"
VALID_COMBOS["liamOauth:apigeeJwt"]="F"
VALID_COMBOS["jwt:ahpt"]="G"
VALID_COMBOS["jwt:oauth"]="I"
VALID_COMBOS["jwt:basicAuth"]="J"
VALID_COMBOS["jwt:mtls"]="K"
VALID_COMBOS["jwtLiamOauth:ahpt"]="L"

COMBO="${PROXY_SEC}:${BACKEND_SEC}"

if [ -z "${VALID_COMBOS[$COMBO]}" ]; then
  echo "❌ Invalid security combination: proxySecurityType=$PROXY_SEC, backendSecurityType=$BACKEND_SEC"
  echo ""
  echo "Valid combinations:"
  for key in "${!VALID_COMBOS[@]}"; do
    echo "  - ${key} (Model ${VALID_COMBOS[$key]})"
  done
  exit 1
fi

echo "✅ Valid security combination: Model ${VALID_COMBOS[$COMBO]}"
```

#### 5.1.3 Security Configuration Validation Script

**New File:** `.github/scripts/validate-security-config.sh`

```bash
#!/bin/bash
set -e

PROXY_FILE="$1"
PROXY_SEC="$2"
BACKEND_SEC="$3"

# Validate JWT config if needed
if [[ "$PROXY_SEC" =~ ^(jwt|jwtLiamOauth)$ ]]; then
  JWT_CONFIG=$(yq eval '.spec.jwt' "$PROXY_FILE")
  if [ "$JWT_CONFIG" = "null" ]; then
    echo "❌ Error: spec.jwt configuration required for proxySecurityType=$PROXY_SEC"
    exit 1
  fi

  ALLOWED_KEY_IDS=$(yq eval '.spec.jwt.allowedKeyIds' "$PROXY_FILE")
  if [ "$ALLOWED_KEY_IDS" = "null" ]; then
    echo "❌ Error: spec.jwt.allowedKeyIds is required"
    exit 1
  fi
fi

# Validate OAuth backend config
if [ "$BACKEND_SEC" = "oauth" ]; then
  OAUTH_BACKEND=$(yq eval '.spec.oauthBackend' "$PROXY_FILE")
  if [ "$OAUTH_BACKEND" = "null" ]; then
    echo "❌ Error: spec.oauthBackend configuration required for backendSecurityType=oauth"
    exit 1
  fi

  TOKEN_ENDPOINT=$(yq eval '.spec.oauthBackend.tokenEndpoint' "$PROXY_FILE")
  KVM_NAME=$(yq eval '.spec.oauthBackend.kvmName' "$PROXY_FILE")

  if [ "$TOKEN_ENDPOINT" = "null" ] || [ "$KVM_NAME" = "null" ]; then
    echo "❌ Error: oauthBackend requires tokenEndpoint and kvmName"
    exit 1
  fi
fi

# Validate Basic Auth backend config
if [ "$BACKEND_SEC" = "basicAuth" ]; then
  BASIC_AUTH=$(yq eval '.spec.basicAuthBackend' "$PROXY_FILE")
  if [ "$BASIC_AUTH" = "null" ]; then
    echo "❌ Error: spec.basicAuthBackend configuration required for backendSecurityType=basicAuth"
    exit 1
  fi

  KVM_NAME=$(yq eval '.spec.basicAuthBackend.kvmName' "$PROXY_FILE")
  if [ "$KVM_NAME" = "null" ]; then
    echo "❌ Error: basicAuthBackend requires kvmName"
    exit 1
  fi
fi

# Validate mTLS backend config
if [ "$BACKEND_SEC" = "mtls" ]; then
  MTLS_BACKEND=$(yq eval '.spec.mtlsBackend' "$PROXY_FILE")
  if [ "$MTLS_BACKEND" = "null" ]; then
    echo "❌ Error: spec.mtlsBackend configuration required for backendSecurityType=mtls"
    exit 1
  fi

  CERT_REF=$(yq eval '.spec.mtlsBackend.certificateRef' "$PROXY_FILE")
  if [ "$CERT_REF" = "null" ]; then
    echo "❌ Error: mtlsBackend requires certificateRef"
    exit 1
  fi
fi

echo "✅ Security configuration validation passed"
```

### 5.2 Applications Validation Action Updates

**Location:** `.github/actions/validate-proxy/action.yml`

**Changes:** Add similar validation logic as GitOps workflow, reusable as composite action

---

## 6. Example Proxy YAML Files

### 6.1 Directory Structure

**GitOps Location:** `/examples/single-proxy-template/`

```
examples/
└── single-proxy-template/
    ├── README.md
    ├── model-a-oauth-apigeeJwt.yaml
    ├── model-b-oauth-oauth.yaml
    ├── model-c-oauth-basicAuth.yaml
    ├── model-d-oauth-mtls.yaml
    ├── model-e-liamOauth-liamJwt.yaml
    ├── model-f-liamOauth-apigeeJwt.yaml
    ├── model-g-jwt-ahpt.yaml
    ├── model-i-jwt-oauth.yaml
    ├── model-j-jwt-basicAuth.yaml
    ├── model-k-jwt-mtls.yaml
    └── model-l-jwtLiamOauth-ahpt.yaml
```

### 6.2 Example YAML Templates

#### Model A: OAuth → Apigee JWT

```yaml
---
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-example-model-a
  description: "Example: OAuth proxy with Apigee JWT backend (Model A)"
  labels:
    sysgen: SYSGEN788836350
    taxonomy: /Example/v1/ModelA
spec:
  template: single-proxy-template
  proxySecurityType: oauth
  backendSecurityType: apigeeJwt
  routing:
    path: /example/model-a/v1
    target: https://backend-api.example.com
    timeout: 30
```

#### Model C: OAuth → Basic Auth

```yaml
---
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-example-model-c
  description: "Example: OAuth proxy with Basic Auth backend (Model C)"
  labels:
    sysgen: SYSGEN788836350
    taxonomy: /Example/v1/ModelC
spec:
  template: single-proxy-template
  proxySecurityType: oauth
  backendSecurityType: basicAuth
  basicAuthBackend:
    kvmName: SYSGEN788836350-example-backend-creds
  routing:
    path: /example/model-c/v1
    target: https://backend-api.example.com
    timeout: 30
  secrets:
    - BACKEND_USERNAME
    - BACKEND_PASSWORD
  kvms:
    - name: SYSGEN788836350-example-backend-creds
      encrypted: true
      entries:
        - key: basic_auth_config
          value: |
            {
              "username": "${BACKEND_USERNAME}",
              "password": "${BACKEND_PASSWORD}"
            }
```

#### Model G: JWT → AHPT

```yaml
---
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-example-model-g
  description: "Example: JWT proxy with Auth Header Pass Thru (Model G)"
  labels:
    sysgen: SYSGEN788836350
    taxonomy: /Example/v1/ModelG
spec:
  template: single-proxy-template
  proxySecurityType: jwt
  backendSecurityType: ahpt
  jwt:
    allowedKeyIds: "apigateway-nonprod"
    jwks: "https://apicc-dev.gcl.corp.intranet/secutils/jwt/keys"
  routing:
    path: /example/model-g/v1
    target: https://backend-api.example.com
    timeout: 30
```

**Complete examples for all 11 models** will follow the same pattern.

---

## 7. Deployment Pipeline Changes

### 7.1 Template Parameter Passing

**Status:** ⚠️ **TBD** - Pending template finalization

**Options under consideration:**

#### Option A: apigee-go-gen Variable Substitution

```bash
# Extract security types from YAML
PROXY_SEC=$(yq eval '.spec.proxySecurityType' proxy.yaml)
BACKEND_SEC=$(yq eval '.spec.backendSecurityType' proxy.yaml)

# Pass as variables to apigee-go-gen
apigee-go-gen transform yaml-to-apiproxy \
  --input proxy.yaml \
  --template template.zip \
  --output bundle.zip \
  --set "proxySecurityType=$PROXY_SEC" \
  --set "backendSecurityType=$BACKEND_SEC"
```

#### Option B: Pre-processing with yq

```bash
# Set flow variables in template before transformation
yq eval ".spec.proxySecurityType = \"$PROXY_SEC\"" -i proxy.yaml
yq eval ".spec.backendSecurityType = \"$BACKEND_SEC\"" -i proxy.yaml

# Transform
apigee-go-gen transform yaml-to-apiproxy ...
```

**Decision Point:** Coordinate with Jeremy's template implementation approach.

### 7.2 build-template-mapping.json Updates

**Status:** ⚠️ **TBD** - Pending template structure finalization

**Likely additions:**

```json
[
  {
    "path": "Policies.[key=FlowCallout].[name=FC-Proxy-Security].Parameters.[key=Parameter].[name=proxySecurityType].-Data",
    "variable": "{{ .Values.spec.proxySecurityType }}"
  },
  {
    "path": "Policies.[key=FlowCallout].[name=FC-Backend-Security].Parameters.[key=Parameter].[name=backendSecurityType].-Data",
    "variable": "{{ .Values.spec.backendSecurityType }}"
  }
]
```

---

## 8. Documentation

### 8.1 README Updates

#### GitOps README.md

**Section to update:** Template table (around line 54-64)

**Current:**
```markdown
| Template Name                     | Description                                                     |
|-----------------------------------|-----------------------------------------------------------------|
| `jwt-oauth-proxy-ahpt-backend`    | JWT and OAuth proxy for Lumen Portal backend applications     |
| `jwt-proxy-ahpt-backend`          | JWT-only proxy for Lumen Portal backend applications          |
| `oauth-proxy-jwt-backend`         | OAuth proxy with JWT backend authentication                   |
| `oauth-proxy-oauth-backend`       | Full OAuth proxy for OAuth backend applications               |
```

**Updated:**
```markdown
| Template Name                     | Description                                                     |
|-----------------------------------|-----------------------------------------------------------------|
| `single-proxy-template`           | **NEW**: Configurable proxy with 11 security model combinations |
| `jwt-oauth-proxy-ahpt-backend`    | ⚠️ DEPRECATED: Use single-proxy-template with appropriate security types |
| `jwt-proxy-ahpt-backend`          | ⚠️ DEPRECATED: Use single-proxy-template with appropriate security types |
| `oauth-proxy-jwt-backend`         | ⚠️ DEPRECATED: Use single-proxy-template with appropriate security types |
| `oauth-proxy-oauth-backend`       | ⚠️ DEPRECATED: Use single-proxy-template with appropriate security types |

### Single Proxy Template Configuration

The `single-proxy-template` supports 11 security model combinations:

**Required Fields:**
- `spec.proxySecurityType`: Frontend security (`oauth`, `liamOauth`, `jwt`, `jwtLiamOauth`)
- `spec.backendSecurityType`: Backend security (`apigeeJwt`, `liamJwt`, `oauth`, `basicAuth`, `mtls`, `ahpt`)

**Conditional Fields:**
- `spec.jwt`: Required if proxySecurityType includes JWT
- `spec.oauthBackend`: Required if backendSecurityType is `oauth`
- `spec.basicAuthBackend`: Required if backendSecurityType is `basicAuth`
- `spec.mtlsBackend`: Required if backendSecurityType is `mtls`

See [examples/single-proxy-template/](examples/single-proxy-template/) for complete examples of all supported models.
```

### 8.2 Migration Guide

**New File:** `docs/SINGLE-PROXY-TEMPLATE-MIGRATION.md` (both repos)

```markdown
# Single Proxy Template Migration Guide

## Overview

The Single Proxy Template consolidates 4 existing templates into 1 flexible template that supports 11 security model combinations.

## Migration Mapping

| Old Template | New Configuration |
|-------------|-------------------|
| `jwt-oauth-proxy-ahpt-backend` | `template: single-proxy-template`<br>`proxySecurityType: jwtLiamOauth`<br>`backendSecurityType: ahpt` |
| `jwt-proxy-ahpt-backend` | `template: single-proxy-template`<br>`proxySecurityType: jwt`<br>`backendSecurityType: ahpt` |
| `oauth-proxy-jwt-backend` | `template: single-proxy-template`<br>`proxySecurityType: oauth`<br>`backendSecurityType: apigeeJwt` |
| `oauth-proxy-oauth-backend` | `template: single-proxy-template`<br>`proxySecurityType: oauth`<br>`backendSecurityType: oauth` |

## Before & After Examples

### Old: oauth-proxy-jwt-backend

```yaml
spec:
  template: oauth-proxy-jwt-backend
  routing:
    path: /my-api/v1
    target: https://backend.example.com
```

### New: single-proxy-template

```yaml
spec:
  template: single-proxy-template
  proxySecurityType: oauth
  backendSecurityType: apigeeJwt
  routing:
    path: /my-api/v1
    target: https://backend.example.com
```

## Timeline

- **Phase 1 (PC38.1)**: Single template available, old templates still supported
- **Phase 2 (TBD)**: Deprecation warnings added for old templates
- **Phase 3 (TBD)**: Migration period ends, old templates removed from schema

## New Capabilities

With the single template, you can now configure:

- **LIAM OAuth** proxy security (Model E, F)
- **Basic Auth** backend security (Model C, J)
- **mTLS** backend security (Model D, K)
- **Hybrid JWT/LIAM OAuth** (Model L)

See [examples/single-proxy-template/](../examples/single-proxy-template/) for all 11 supported models.
```

---

## 9. Implementation Phases

### Phase 1: Schema & Validation (Can Start Immediately ✅)

**Confidence Level:** 100% - Based on confirmed matrix

**Tasks:**
1. ✅ Update `apiproxy.schema.json` in GitOps
   - Add `proxySecurityType` and `backendSecurityType` enums
   - Add backend configuration objects
   - Add conditional validation rules
   - Add `single-proxy-template` to template enum

2. ✅ Update `apiproxy.schema.json` in Applications (mirror GitOps)

3. ✅ Create validation scripts
   - `validate-security-combination.sh`
   - `validate-security-config.sh`

4. ✅ Update validation workflows
   - GitOps `.github/workflows/validate-proxy.yml`
   - Applications `.github/actions/validate-proxy/action.yml`

5. ✅ Create 11 example YAML files in GitOps `/examples/single-proxy-template/`

6. ✅ Update README.md documentation in both repos

**Deliverables:**
- Schema validates new security type fields
- Validation enforces valid combinations
- Example YAMLs demonstrate all 11 models
- Documentation explains migration path

### Phase 2: Template Integration (Blocked - Wait for Jeremy) ⏸️

**Confidence Level:** 0% - Requires template finalization

**Tasks:**
1. ⏸️ Update `template-mappings.json` with final template name
2. ⏸️ Update `build-template-mapping.json` with security type mappings
3. ⏸️ Update deployment workflows to pass security types
4. ⏸️ Test template transformation with apigee-go-gen

**Blockers:**
- Template bundle name TBD
- FlowCallout parameter structure TBD
- Shared flow interface TBD

### Phase 3: Testing & Migration (Blocked - Wait for Shared Flows) ⏸️

**Confidence Level:** 0% - Requires shared flow deployment

**Tasks:**
1. ⏸️ Deploy test proxies to apicc-dev (3+ different models)
2. ⏸️ Validate end-to-end functionality
3. ⏸️ Create migration guide documentation
4. ⏸️ Team walkthrough/training

**Blockers:**
- `SYSGEN788836350-Proxy-Security` must be deployed
- `SYSGEN788836350-Backend-Security` must be deployed

---

## 10. Open Questions & Decisions Needed

### 10.1 Critical Questions (Block Implementation)

1. **Template Parameter Passing Mechanism** ⚠️ HIGH PRIORITY
   - How does the template receive `proxySecurityType` and `backendSecurityType`?
   - Via FlowCallout Parameters? AssignMessage variables? Other?
   - **Decision Owner:** Jeremy
   - **Needed By:** Before Phase 2 implementation

2. **Final Template Bundle Name** ✅ RESOLVED (Jan 24, 2026)
   - Confirmed name for template-mappings.json
   - **Final Name:** `SYSGEN788836350-Apigee_Default_Proxy_Template_V1`
   - **Release Tag:** `SYSGEN788836350-Apigee_Default_Proxy_Template_V1-v0.0.1`
   - **Decision Owner:** Jeremy
   - **Status:** Released to templates repo

3. **Shared Flow Interface Contract** ⚠️ HIGH PRIORITY
   - What variables must be set before calling FC-Proxy-Security?
   - What variables must be set before calling FC-Backend-Security?
   - **Decision Owner:** Troy (Proxy-Security), Andre (Backend-Security)
   - **Needed By:** Before Phase 2 implementation

### 10.2 Important Questions (Affect Design)

4. **KVM Structure for New Backend Types**
   - Basic Auth: JSON format for username/password?
   - mTLS: What certificate references are needed?
   - **Decision Owner:** Andre/Naveed
   - **Needed By:** Before example YAML creation

5. **Default Values**
   - Should security types have defaults? Or always explicit?
   - Recommendation: No defaults (force explicit configuration)
   - **Decision Owner:** Platform Engineering Team
   - **Needed By:** Before schema finalization

6. **Migration Timeline**
   - How long to maintain backward compatibility?
   - Recommendation: 2-3 sprints for migration, then deprecate
   - **Decision Owner:** Product Owner / Tech Lead
   - **Needed By:** Before Phase 3

### 10.3 Nice-to-Have Questions

7. **Environment-Specific Constraints**
   - Are certain security types restricted to certain environments?
   - Recommendation: Document but don't enforce programmatically
   - **Decision Owner:** Platform Engineering Team

8. **Test Proxy Strategy**
   - Create actual deployed test proxies or just examples?
   - Recommendation: Both (examples + 3 deployed test proxies)
   - **Decision Owner:** Platform Engineering Team

---

## 11. Risk Assessment

| Risk | Impact | Likelihood | Mitigation |
|------|--------|-----------|------------|
| Template interface changes during development | HIGH | MEDIUM | Early coordination with Jeremy, clear interface contract |
| Schema changes break existing proxies | HIGH | LOW | Maintain backward compatibility, thorough testing |
| Security combination validation too restrictive | MEDIUM | LOW | Based on confirmed matrix, easy to extend |
| Migration complexity overwhelms teams | MEDIUM | MEDIUM | Clear documentation, examples, gradual rollout |
| Performance impact of shared flow calls | LOW | LOW | Shared flows already in use, minimal overhead |

---

## 12. Success Metrics

- ✅ All 11 security models validate successfully
- ✅ Zero breaking changes to existing proxies
- ✅ 100% of example YAMLs pass schema validation
- ✅ 3+ test proxies deployed successfully to apicc-dev
- ✅ Migration guide published and reviewed by team
- ✅ Zero deployment failures due to schema changes

---

## 13. Dependencies & Coordination

### External Dependencies (Blocking)

1. **Jeremy's Team** (Template Development)
   - `SYSGEN788836350-Single_Proxy_Template` bundle created
   - Template interface contract documented
   - Released to template repository
   - **Status:** In Progress (Jan 23-27, 2026)

2. **Troy** (Proxy Security Shared Flow)
   - `SYSGEN788836350-Proxy-Security` shared flow created
   - Deployed to all environments
   - Interface contract documented
   - **Status:** In Progress

3. **Andre/Naveed** (Backend Security Shared Flow)
   - `SYSGEN788836350-Backend-Security` shared flow created
   - Deployed to all environments
   - Interface contract documented
   - **Status:** In Progress

### Internal Coordination

- **Schema changes** must be synchronized between GitOps and Applications repos
- **Validation logic** must be consistent across both repos
- **Documentation** must be updated in both repos

---

## 14. Rollback Plan

If issues are discovered after deployment:

1. **Schema rollback:** Revert schema changes via git revert
2. **Template rollback:** Old templates remain functional (backward compatibility maintained)
3. **Proxy rollback:** Existing proxies unaffected, new proxies can use old templates
4. **Communication:** Notify team of rollback, pause migrations

**Rollback triggers:**
- Critical validation bugs preventing deployments
- Template incompatibility discovered
- Shared flow issues blocking proxy functionality

---

## Appendix A: Complete Schema Diff

**GitOps `apiproxy.schema.json` - Additions:**

```json
{
  "spec": {
    "properties": {
      "template": {
        "enum": [
          "single-proxy-template",  // NEW
          "jwt-oauth-proxy-ahpt-backend",
          "jwt-proxy-ahpt-backend",
          "oauth-proxy-jwt-backend",
          "oauth-proxy-oauth-backend"
        ]
      },
      "proxySecurityType": { /* NEW - see section 3.1.2 */ },
      "backendSecurityType": { /* NEW - see section 3.1.2 */ },
      "oauthBackend": { /* NEW - see section 3.1.3 */ },
      "basicAuthBackend": { /* NEW - see section 3.1.3 */ },
      "mtlsBackend": { /* NEW - see section 3.1.3 */ }
    },
    "allOf": [ /* NEW conditional validation - see section 3.1.4 */ ]
  }
}
```

---

## Appendix B: Template Transformation Flow

**Current State:**
```
proxy.yaml → [validate] → [download template] → [apigee-go-gen] → bundle.zip
```

**Target State:**
```
proxy.yaml
  → [validate schema]
  → [validate security combination]
  → [validate conditional config]
  → [download single template]
  → [extract security types]
  → [apigee-go-gen with security params]  ← ⚠️ TBD
  → bundle.zip (with FC-Proxy-Security, FC-Backend-Security)
```

---

**Document Status:** DRAFT v1.0
**Last Updated:** January 23, 2026
**Next Review:** After template/shared flow finalization (Jan 27, 2026)
