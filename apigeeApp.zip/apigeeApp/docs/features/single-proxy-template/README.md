# Single Proxy Template - DPEAPI-20005

## Overview
Consolidates 4 hardcoded proxy templates into a single configurable template supporting 11 security model combinations through flexible security type parameters.

## 📋 Documentation Index

### Core Documents
1. **[DPEAPI-20005-DETAILED-DESIGN.md](DPEAPI-20005-DETAILED-DESIGN.md)** - Complete technical design
   - Architecture overview
   - Schema changes
   - Security model matrix
   - Validation strategy
   - Implementation phases

2. **[DPEAPI-20005-USER-STORY.md](DPEAPI-20005-USER-STORY.md)** - Jira user story
   - Acceptance criteria
   - Dependencies
   - Testing requirements

3. **[DPEAPI-20005-IMPLEMENTATION-SUMMARY.md](DPEAPI-20005-IMPLEMENTATION-SUMMARY.md)** - Implementation status
   - Phase 1: Schema & validation ✅
   - Phase 2: Template integration (blocked)
   - Phase 3: Testing & deployment (blocked)

4. **[DPEAPI-20005-PRS-CREATED.md](DPEAPI-20005-PRS-CREATED.md)** - Pull request tracking
   - GitOps PR #623
   - Applications PR #66
   - Next steps

## 🎯 Feature Summary

### Problem
Previously required 4 separate proxy templates to cover different security scenarios:
- `jwt-oauth-proxy-ahpt-backend`
- `jwt-proxy-ahpt-backend`
- `oauth-proxy-jwt-backend`
- `oauth-proxy-oauth-backend`

### Solution
Single `single-proxy-template` with configurable security types:
- **Proxy Security**: `oauth`, `liamOauth`, `jwt`, `jwtLiamOauth`
- **Backend Security**: `apigeeJwt`, `liamJwt`, `oauth`, `basicAuth`, `mtls`, `ahpt`

Supports **11 security model combinations** (Models A-L, excluding H & M).

## 🔗 Related Pull Requests

### Phase 1: Schema & Validation Infrastructure
- **GitOps**: [PR #623](https://github.com/CenturyLink/enterprise-apigeex-gitops/pull/623) - Schema changes and validation scripts
- **Applications**: [PR #66](https://github.com/CenturyLink/enterprise-apigeex-applications/pull/66) - Schema synchronization

### Future Phases
- **Phase 2**: Template integration (waiting for Jeremy's template release)
- **Phase 3**: Testing & deployment (waiting for shared flow deployment)

## 🔐 Security Models Supported

| Model | Proxy Security | Backend Security | Status |
|-------|---------------|------------------|--------|
| A | oauth | apigeeJwt | ✅ Schema ready |
| B | oauth | oauth | ✅ Schema ready |
| C | oauth | basicAuth | ✅ Schema ready |
| D | oauth | mtls | ✅ Schema ready |
| E | liamOauth | liamJwt | ✅ Schema ready |
| F | liamOauth | apigeeJwt | ✅ Schema ready |
| G | jwt | ahpt | ✅ Schema ready |
| I | jwt | oauth | ✅ Schema ready |
| J | jwt | basicAuth | ✅ Schema ready |
| K | jwt | mtls | ✅ Schema ready |
| L | jwtLiamOauth | ahpt | ✅ Schema ready |

## 📦 Dependencies

### Blocks
- Phase 2 template integration work
- Phase 3 testing and deployment
- Future proxy deployments using single template

### Blocked By
- **DPEAPI-19093**: Template bundle creation (Jeremy's team)
  - `SYSGEN788836350-Single_Proxy_Template` release
  - `SYSGEN788836350-Proxy-Security` shared flow
  - `SYSGEN788836350-Backend-Security` shared flow

## 🧪 Testing Strategy

### Phase 1 (Complete)
- ✅ Schema validation
- ✅ Validation script testing
- ✅ Backward compatibility verification

### Phase 2 (Pending)
- Create 11 example YAML files (one per security model)
- Test YAML validation with new schema
- Verify conditional validation rules

### Phase 3 (Pending)
- Deploy test proxies to apicc-dev
- End-to-end testing with real traffic
- Validate shared flow integration
- Performance testing

## 👥 Team & Stakeholders

- **Lead**: Ryan (DPEAPI-20005)
- **Template Developer**: Jeremy (DPEAPI-19093)
- **Stakeholders**: Platform Engineering team, API teams adopting templates

## 📅 Timeline

- **Phase 1**: ✅ Complete (January 2026)
- **Phase 2**: Blocked - waiting for template release
- **Phase 3**: Blocked - waiting for Phase 2 completion

## 📝 Quick Reference

### Example YAML Configuration
```yaml
apiVersion: v1
kind: APIProxy
metadata:
  name: SYSGEN123456789-my_proxy
  namespace: gcp-prj-apigee-dev-np-01
  environment: apicc-dev
spec:
  basePath: /v1/my-api
  template: single-proxy-template
  proxySecurityType: oauth
  backendSecurityType: apigeeJwt
  jwtBackend:
    targetUrl: https://backend.example.com
    audience: https://backend.example.com
```

### Related Schemas
- [apiproxy.schema.json](../../../apiproxy.schema.json) - Full proxy YAML schema
- [template-mappings.json](../../../template-mappings.json) - Template name mappings
