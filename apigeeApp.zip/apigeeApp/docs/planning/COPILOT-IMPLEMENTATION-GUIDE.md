# GitHub Copilot Implementation Guide

Quick guide for implementing remaining CI/CD stories using GitHub Copilot with the same patterns as Stories 2 & 3 (PR #7).

---

## Quick Reference

- **Stories**: `docs/planning/jira-import.csv` (26 total)
- **Status**: `IMPLEMENTATION-STATUS.md`
- **Examples**: PR #7, `.github/actions/README.md`
- **GitOps patterns**: `enterprise-apigeex-gitops` (adapt from here)

**Start with**: Story 8 (Copy Schemas - 1 pt), Story 4 (Download Template - 3 pts), or Story 5 (Validate YAML - 3 pts)

---

## Effective Copilot Prompts

### The Pattern: Be Specific + Reference Context

❌ **Bad**: "Create the download template action"

✅ **Good**:
```
I'm implementing Story 4 (DPEAPI-18697) - Download Template action.

Create .github/actions/download-template/action.yml following the pattern
from changed-files and extract-mal-metadata actions in PR #7.

Reference:
- Acceptance criteria in docs/planning/jira-import.csv
- GitOps source: enterprise-apigeex-gitops/.github/actions/download-template/

Requirements:
- Load template mappings from template-mappings.json
- Use gh CLI to fetch latest release
- Extract to output directory
- Cache downloads for speed
- Handle errors gracefully

Follow PR #7 structure: inputs, outputs, set -e, dual outputs, step summary
```

### Prompt Templates

**For Composite Actions** (Stories 4, 9-14, 21):
```
I'm implementing Story {N}: {NAME} from docs/planning/jira-import.csv.

Create .github/actions/{action-name}/action.yml as composite action.

Reference:
- Existing actions in .github/actions/
- GitOps: enterprise-apigeex-gitops/.github/actions/{action-name}/
- Acceptance criteria in jira-import.csv

Key requirements:
{List 3-5 points from acceptance criteria}

Pattern:
- Composite action with bash shell
- set -e error handling
- Dual outputs (GITHUB_OUTPUT + GITHUB_ENV)
- Grouped logging with ::group::
- Step summary output
```

**For Workflows** (Stories 5-7, 15-17):
```
I'm implementing Story {N}: {NAME} from docs/planning/jira-import.csv.

Create .github/workflows/{workflow-name}.yml.

Reference:
- .github/workflows/test-changed-files.yml
- GitOps workflows: enterprise-apigeex-gitops/.github/workflows/
- Available actions: .github/actions/README.md

Steps:
{List key workflow steps from acceptance criteria}

Triggers: {PR paths / push to main / manual dispatch}
Actions to use: {List from .github/actions/}
```

---

## Git Workflow

```bash
# 1. Create branch
git checkout main && git pull
git checkout -b DPEAPI-{story}-description

# 2. Implement using Copilot prompts

# 3. Stage + commit
git add .github/actions/{action-name}/
git add IMPLEMENTATION-STATUS.md
git commit -m "Implement Story {N}: {Title}

{brief description}

Acceptance Criteria (DPEAPI-{ID}):
- [x] {criterion 1}
- [x] {criterion 2}"

# 4. Push + create PR
git push -u origin DPEAPI-{story}-description
gh pr create --title "Story {N}: {Title}" --body "{see PR #7 for format}"

# 5. After merge, next story
git checkout main && git pull
```

---

## Code Patterns (from PR #7)

### Composite Action
```yaml
name: 'Action Name'
description: 'What it does'

inputs:
  param:
    description: 'Input desc'
    required: true

outputs:
  result:
    description: 'Output desc'
    value: ${{ steps.main.outputs.result }}

runs:
  using: 'composite'
  steps:
    - id: main
      shell: bash
      run: |
        set -e
        echo "::group::Processing"

        VALUE="${{ inputs.param }}"
        RESULT="calculated_value"

        # Dual outputs
        echo "result=$RESULT" >> $GITHUB_OUTPUT
        echo "RESULT=$RESULT" >> $GITHUB_ENV

        echo "::endgroup::"
        echo "### Results" >> $GITHUB_STEP_SUMMARY
```

### Workflow
```yaml
name: 'Workflow Name'

on:
  pull_request:
    paths: ['mal-SYSGEN*/**/*.yaml']
  workflow_dispatch:

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - uses: ./.github/actions/changed-files
        id: changes

      - if: steps.changes.outputs.has_changes == 'true'
        run: echo "Process"
```

### Error Handling
```bash
set -e  # Exit on error

if [[ ! -f "file.json" ]]; then
  echo "::error file=file.json::File not found"
  exit 1
fi
```

---

## Testing

### Test Composite Actions
```bash
# Create test workflow (or extend test-changed-files.yml)
gh workflow run test-{action}.yml

# Check results
gh run list --workflow=test-{action}.yml
```

### Test Workflows
```bash
# Modify example MAL
echo "# Test" >> mal-SYSGEN123456789/README.md
git add mal-SYSGEN123456789/ && git commit -m "Test" && git push

# Or manual trigger
gh workflow run {workflow}.yml
```

---

## Story Order & Dependencies

**Ready now** (no dependencies):
- Story 8: Copy Schemas (1 pt) → Unblocks validation
- Story 4: Download Template (3 pts) → Core deployment dependency
- Story 5: Validate Proxy YAML (3 pts)
- Story 7: Validate MAL Structure (3 pts)

**Need Story 4 first**:
- Story 6, 12

**Need Story 8 first**:
- Story 5, 18

**Need Stories 9-13 first**:
- Stories 15-17 (deployments)

**Recommended order**: 8 → 4 → 5 → 7 → 6 → 9 → 10 → 11 → 12 → 13 → 15 → 16 → 17 → rest

---

## Hands-On Example: Story 8 (Copy Schemas)

**Time**: 15-30 minutes | **Difficulty**: Easy | **Points**: 1

### Steps

```bash
# 1. Create branch
git checkout main && git pull
git checkout -b DPEAPI-18701-copy-schemas

# 2. Copy files from gitops repo
cd ~/RyanDev/GitHub/enterprise-apigeex-gitops
cp apiproxy.schema.json ../enterprise-apigeex-applications/
cp template-mappings.json ../enterprise-apigeex-applications/
cp .yamllint.yml ../enterprise-apigeex-applications/
cd ../enterprise-apigeex-applications

# 3. Test schema validation
npm install -g ajv-cli
ajv validate -s apiproxy.schema.json -d mal-SYSGEN123456789/proxies/*/dev/base.yaml

# 4. Test yamllint
pip3 install yamllint
yamllint mal-SYSGEN123456789/

# 5. Update IMPLEMENTATION-STATUS.md
# Add Story 8 section showing ✅ complete

# 6. Commit
git add apiproxy.schema.json template-mappings.json .yamllint.yml IMPLEMENTATION-STATUS.md
git commit -m "Implement Story 8: Copy Schema and Configuration Files

- Copied apiproxy.schema.json for proxy validation
- Copied template-mappings.json for template resolution
- Copied .yamllint.yml for YAML linting
- Tested with ajv-cli and yamllint

Acceptance Criteria (DPEAPI-18701):
- [x] Copy apiproxy.schema.json from gitops
- [x] Copy template-mappings.json from gitops
- [x] Copy .yamllint.yml from gitops
- [x] Test schema validation with ajv-cli
- [x] Test yamllint with example proxy"

# 7. Push + PR
git push -u origin DPEAPI-18701-copy-schemas
gh pr create --title "Story 8: Copy Schema and Configuration Files" \
  --body "Implements Story 8 - copies validation files from gitops. See commit for details."

# Done! ✅
```

---

## Common Issues

**git diff shows nothing**: Add `fetch-depth: 0` to checkout action

**Action not found**: Check path is `./.github/actions/name` and file is `action.yml` (not `.yaml`)

**Outputs empty**: Ensure step has `id:` and output name matches exactly

**Bash syntax error**: Quote GitHub expressions: `"${{ inputs.param }}"`

---

## Updating Progress

After each story, update `IMPLEMENTATION-STATUS.md`:

```markdown
## Story {N} (DPEAPI-{ID}) - {Title}
**Status**: Implemented ✅
**Location**: `.github/actions/{name}/` or `.github/workflows/{name}.yml`

**Completed**:
- [x] {Acceptance criterion 1}
- [x] {Acceptance criterion 2}

**Next**: {What this unblocks}

---
```

---

## Tips

- **Start simple**: Story 8 is easiest (copy files, test, done)
- **Reference PR #7**: Follow same structure for quality/consistency
- **Iterate with Copilot**: First pass → review → refine → add error handling
- **Test before PR**: Manual workflow runs catch issues early
- **Ask in PR reviews**: Questions? Add PR comment, don't get stuck

---

## Full Story List

| # | Story | Pts | Status | Dependencies |
|---|-------|-----|--------|--------------|
| 1 | Setup Apigee Tooling | 2 | ✅ | None |
| 2 | Changed Files Detection | 3 | ✅ | None |
| 3 | Extract MAL Metadata | 2 | ✅ | None |
| 4 | Download Template | 3 | 🟡 | None |
| 5 | Validate Proxy YAML | 3 | 🟡 | 1-3, 8 |
| 6 | Validate Template Exists | 2 | 🟡 | 4 |
| 7 | Validate MAL Structure | 3 | 🟡 | 2-3 |
| 8 | Copy Schemas | 1 | 🟡 | None |
| 9-26 | ... | ... | ⏸️ | See jira-import.csv |

**Legend**: ✅ Done | 🟡 Ready | ⏸️ Blocked

---

**Questions?** Ask Copilot or reach out in PR reviews. You've got this! 🚀
