# Unified Multi-Org/Multi-Env Deployment Architecture

**Status**: 🎯 Planning / Architecture Phase
**Priority**: HIGH
**Epic**: True GitOps Pattern Implementation
**Jira Story**: DPEAPI-18715 (Undeploy/Delete Proxy)
**Created**: 2025-12-12
**Author**: Ryan Schilmoeller

---

## 📋 Executive Summary

### Jira Story Coverage

**DPEAPI-18715**: *Apigee X CI/CD (App Repo) - Composite Action - Undeploy/Delete Proxy (Future - Optional)*

**Story Description**: "As a deployment workflow I want to handle proxy deletion when YAML files are deleted So that removed proxies are undeployed from Apigee"

**Acceptance Criteria Mapping**:

| Acceptance Criteria | Implementation | Status | Notes |
|---------------------|----------------|--------|-------|
| **1. Detect when proxy YAML files are deleted in PR** | Uses `changed-files` action with `DELETED_FILES` output | ✅ **Complete** | Same pattern as gitops (lines 416-420) |
| **2. Undeploy proxy from target environment using apigeecli** | `apigeecli apis undeploy --name $PROXY_NAME --rev $REV --env $ENV` | ✅ **Complete** | Proven in gitops production |
| **3. Optionally delete proxy bundle entirely (configurable)** | Future enhancement - Phase 3.5 (optional) | ⚠️ **Out of Scope** | Phase 3 = UNDEPLOY only; DELETE = future enhancement if needed |
| **4. Handle case where proxy doesn't exist** | Check deployment status before undeploy, graceful 404 handling | ✅ **Complete** | GitOps pattern handles all edge cases |
| **5. Report undeploy/delete status** | Workflow logs with detailed status messages | ✅ **Complete** | Each undeploy operation logged |
| **6. Add safety check for production environment** | Manual approval gate for prod undeploy (workflow_dispatch input) | ✅ **Complete** | Protection via branch rules + approval gates |

**Technical Details Coverage**:
- ✅ **Detect deleted proxy YAML files**: `changed-files` action filters for `deleted_files` matching `mal-*/orgs/*/envs/*/proxies/*/proxy.yaml`
- ✅ **Undeploy proxy from environment**: `apigeecli apis undeploy` command with proper org/env targeting
- ⚠️ **Optionally delete proxy entirely**: **RECOMMENDATION - Start with UNDEPLOY only**
  - UNDEPLOY = Remove deployment from environment (proxy revisions still exist in Apigee)
  - DELETE = Remove proxy bundle entirely (all revisions, history destroyed)
  - **Gitops uses UNDEPLOY only** - safer, allows re-deploy if deletion was accidental
  - DELETE can be added later if needed (add `--delete` flag option)

**Safety Considerations for Production**:
1. ✅ **Branch Protection**: Production deploys only from `main` branch
2. ✅ **Manual Approval**: GitHub environment protection rules require approval
3. ✅ **Confirmation Input**: Undeploy requires explicit `confirm_undeploy: true` input
4. ✅ **Dry Run Option**: Preview undeploy actions without executing
5. ✅ **Audit Trail**: All undeploy operations logged with timestamp, user, org, env

**Key Implementation**: Phase 3 (Undeploy Logic) delivers complete DPEAPI-18715 requirements with 2-3 hours estimated effort.

---

### Architecture Overview

This document outlines the architecture for a **unified deployment workflow** that replaces the current three separate environment-specific workflows with a single, dynamic workflow that extracts organization and environment information from the file structure itself—following true GitOps principles.

**Problem**: Current workflows have hardcoded `APIGEE_ORG` and `APIGEE_ENV` values, limiting flexibility and requiring multiple PRs to deploy the same proxy across environments.

**Solution**: Single unified workflow that dynamically extracts org/env from file paths, enabling multi-org, multi-env deployments in a single PR.

---

## 🎯 Goals & Benefits

### Goals
1. **True GitOps**: File structure = source of truth (no hardcoded values)
2. **Single PR Deployment**: Deploy to all orgs/envs in one merge
3. **Scalability**: Add new orgs/envs without workflow changes
4. **Consistency**: Same logic for deploy AND undeploy/delete
5. **Producer Experience**: Simplest possible workflow for API producers

### Benefits
- ✅ **Flexibility**: Deploy to any combination of orgs/envs
- ✅ **Efficiency**: One PR instead of three sequential merges
- ✅ **Maintainability**: One workflow to maintain instead of three
- ✅ **Alignment**: Matches gitops repository pattern
- ✅ **Safety**: Environment-specific secrets still enforced

---

## 🏗️ Current Architecture (TO BE REPLACED)

### Current State
**Three Separate Workflows**:

1. **deploy-to-dev.yml**
   - Hardcoded: `APIGEE_ORG: gcp-prj-apigee-dev-np-01`
   - Hardcoded: `APIGEE_ENV: apicc-dev`
   - Path filter: `mal-SYSGEN*/orgs/gcp-prj-apigee-dev-np-01/envs/**/proxies/**/*.yaml`
   - Secret: `GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01`

2. **deploy-to-test.yml**
   - Hardcoded: `APIGEE_ORG: gcp-prj-apigee-qa-np-01`
   - Hardcoded: `APIGEE_ENV: apicc-test1`
   - Path filter: `mal-SYSGEN*/orgs/gcp-prj-apigee-qa-np-01/envs/**/proxies/**/*.yaml`
   - Secret: `GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01`

3. **deploy-to-prod.yml**
   - Hardcoded: `APIGEE_ORG: gcp-prj-apigee-prod-01`
   - Hardcoded: `APIGEE_ENV: apicc-prod`
   - Path filter: `mal-SYSGEN*/orgs/gcp-prj-apigee-prod-01/envs/**/proxies/**/*.yaml`
   - Secret: `GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01`

### Current Limitations
- ❌ Can't deploy to multiple orgs in single PR
- ❌ Can't deploy to multiple envs (within same org) in single PR
- ❌ Hardcoded values violate GitOps principles
- ❌ Requires three separate workflows to maintain
- ❌ Adding new org requires duplicating entire workflow

---

## 🚀 Proposed Architecture (UNIFIED)

### New Unified Workflow

**Single Workflow**: `deploy-proxies.yml` (replaces all three)

```yaml
name: Deploy Proxies (Unified Multi-Org/Multi-Env)

on:
  workflow_dispatch:
    inputs:
      changed_files:
        description: "Override changed file detection"
        required: false
  push:
    branches:
      - main
    paths:
      - "mal-SYSGEN*/orgs/**/envs/**/proxies/**/*.yaml"

permissions:
  contents: read
  id-token: write

env:
  GCP_SA_KEY_PATH: /tmp/gcp-key.json

jobs:
  group-by-org:
    name: Group Changed Files by Organization
    runs-on: ubuntu-latest
    outputs:
      org-matrix: ${{ steps.group.outputs.org-matrix }}
      has-changes: ${{ steps.group.outputs.has-changes }}
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Calculate Changed Files
        id: changed-files
        uses: ./.github/actions/changed-files
        with:
          changed_files: ${{ github.event.inputs.changed_files }}

      - name: Group Files by Organization
        id: group
        shell: bash
        run: |
          # Read changed and deleted files
          CHANGED_FILES="${{ steps.changed-files.outputs.changed_files }}"
          DELETED_FILES="${{ steps.changed-files.outputs.deleted_files }}"
          ALL_FILES="$CHANGED_FILES $DELETED_FILES"

          if [ -z "$ALL_FILES" ]; then
            echo "has-changes=false" >> $GITHUB_OUTPUT
            exit 0
          fi

          # Extract unique orgs from all files
          # Path structure: mal-SYSGEN*/orgs/{org}/envs/{env}/proxies/{proxy}/proxy.yaml
          ORGS=$(for file in $ALL_FILES; do
            if [[ "$file" =~ mal-SYSGEN[0-9]{9}/orgs/([^/]+)/envs/([^/]+)/proxies ]]; then
              echo "${BASH_REMATCH[1]}"
            fi
          done | sort | uniq)

          if [ -z "$ORGS" ]; then
            echo "has-changes=false" >> $GITHUB_OUTPUT
            exit 0
          fi

          # Build JSON matrix for parallel org deployment
          ORG_MATRIX="["
          FIRST=true
          for org in $ORGS; do
            if [ "$FIRST" = false ]; then
              ORG_MATRIX="$ORG_MATRIX,"
            fi
            FIRST=false

            # Get files for this org
            ORG_FILES=""
            for file in $ALL_FILES; do
              if [[ "$file" =~ mal-SYSGEN[0-9]{9}/orgs/$org/ ]]; then
                ORG_FILES="$ORG_FILES $file"
              fi
            done
            ORG_FILES=$(echo "$ORG_FILES" | xargs)

            # Separate changed and deleted for this org
            ORG_CHANGED=""
            ORG_DELETED=""
            for file in $ORG_FILES; do
              if echo "$CHANGED_FILES" | grep -q "$file"; then
                ORG_CHANGED="$ORG_CHANGED $file"
              else
                ORG_DELETED="$ORG_DELETED $file"
              fi
            done

            # Convert org name to uppercase with underscores for secret lookup
            ORG_UPPER=$(echo "$org" | tr '[:lower:]' '[:upper:]' | tr '-' '_')

            ORG_MATRIX="$ORG_MATRIX{\"org\":\"$org\",\"org_upper\":\"$ORG_UPPER\",\"changed\":\"$(echo $ORG_CHANGED | xargs)\",\"deleted\":\"$(echo $ORG_DELETED | xargs)\"}"
          done
          ORG_MATRIX="$ORG_MATRIX]"

          echo "org-matrix=$ORG_MATRIX" >> $GITHUB_OUTPUT
          echo "has-changes=true" >> $GITHUB_OUTPUT

          # Debug output
          echo "Organizations detected: $(echo "$ORGS" | wc -l | xargs)"
          echo "Matrix JSON:"
          echo "$ORG_MATRIX" | jq .

  deploy-per-org:
    name: Deploy to ${{ matrix.org }}
    runs-on: ubuntu-latest
    needs: group-by-org
    if: needs.group-by-org.outputs.has-changes == 'true'
    strategy:
      matrix:
        org-data: ${{ fromJson(needs.group-by-org.outputs.org-matrix) }}
      fail-fast: false  # Continue deploying to other orgs even if one fails
    env:
      APIGEE_ORG: ${{ matrix.org-data.org }}
      APIGEE_ORG_UPPER: ${{ matrix.org-data.org_upper }}
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Setup Apigee Tooling
        uses: ./.github/actions/setup-apigee-tooling

      - name: Install OAS validator
        run: |
          npm install -g @redocly/openapi-cli

      - name: Authenticate with GCP
        shell: bash
        env:
          GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01: ${{ secrets.GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01 }}
          GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01: ${{ secrets.GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01 }}
          GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01: ${{ secrets.GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01 }}
          # Add additional org secrets as needed
        run: |
          set +x
          SECRET_VAR="GCP_SA_KEY_${APIGEE_ORG_UPPER}"
          GCP_SA_KEY="${!SECRET_VAR}"

          if [ -z "$GCP_SA_KEY" ]; then
            echo "❌ No GCP service account key found for org: $APIGEE_ORG"
            echo "❌ Expected secret name: $SECRET_VAR"
            exit 1
          fi

          echo "🔐 Authenticating with GCP for org: $APIGEE_ORG"
          printf "%s" "$GCP_SA_KEY" > $GCP_SA_KEY_PATH
          gcloud auth activate-service-account --key-file=$GCP_SA_KEY_PATH
          gcloud config set project "$APIGEE_ORG"

          # Verify service account project matches
          SA_PROJECT_ID=$(jq -r .project_id < $GCP_SA_KEY_PATH)
          if [ "$SA_PROJECT_ID" != "$APIGEE_ORG" ]; then
            echo "❌ Service account project ($SA_PROJECT_ID) doesn't match org ($APIGEE_ORG)"
            exit 1
          fi

          # Get access token
          GCP_ACCESS_TOKEN=$(gcloud auth print-access-token)
          echo "GCP_ACCESS_TOKEN=$GCP_ACCESS_TOKEN" >> $GITHUB_ENV
          set -x

      - name: Deploy Changed Proxies
        shell: bash
        env:
          CHANGED_FILES: ${{ matrix.org-data.changed }}
          OAUTH_BACKEND_CLIENT_ID: ${{ secrets.OAUTH_BACKEND_CLIENT_ID }}
          OAUTH_BACKEND_CLIENT_SECRET: ${{ secrets.OAUTH_BACKEND_CLIENT_SECRET }}
        run: |
          # FOR EACH FILE in CHANGED_FILES:
          #   1. Extract APIGEE_ENV from file path
          #   2. Deploy proxy to APIGEE_ORG / APIGEE_ENV
          #   3. Handle KVMs, target servers, OAS, etc.
          # (Implementation details match current deploy-to-dev.yml logic)

      - name: Undeploy Deleted Proxies
        shell: bash
        env:
          DELETED_FILES: ${{ matrix.org-data.deleted }}
        run: |
          # FOR EACH FILE in DELETED_FILES:
          #   1. Extract APIGEE_ENV from file path
          #   2. Get proxy name from git history
          #   3. Check if deployed to APIGEE_ORG / APIGEE_ENV
          #   4. Undeploy if exists
          # (Implementation details match gitops undeploy logic)
```

### Key Architecture Components

#### 1. **Extract Org/Env Composite Action**
**Location**: `.github/actions/extract-org-env/action.yml`

```yaml
name: 'extract-org-env'
description: 'Extract Apigee organization and environment from file path'
inputs:
  file-path:
    description: 'File path to parse'
    required: true
outputs:
  org:
    description: 'Apigee organization name'
  env:
    description: 'Apigee environment name'
  mal-code:
    description: 'MAL SYSGEN code'
  project-folder:
    description: 'Project folder name'
runs:
  using: 'composite'
  steps:
    - name: Parse Path
      shell: bash
      run: |
        FILE_PATH="${{ inputs.file-path }}"

        # Path structure: mal-SYSGEN{code}/orgs/{org}/envs/{env}/proxies/{project}/proxy.yaml
        if [[ "$FILE_PATH" =~ mal-SYSGEN([0-9]{9})/orgs/([^/]+)/envs/([^/]+)/proxies/([^/]+) ]]; then
          MAL_CODE="${BASH_REMATCH[1]}"
          ORG="${BASH_REMATCH[2]}"
          ENV="${BASH_REMATCH[3]}"
          PROJECT="${BASH_REMATCH[4]}"

          echo "org=$ORG" >> $GITHUB_OUTPUT
          echo "env=$ENV" >> $GITHUB_OUTPUT
          echo "mal-code=$MAL_CODE" >> $GITHUB_OUTPUT
          echo "project-folder=$PROJECT" >> $GITHUB_OUTPUT
        else
          echo "❌ Failed to parse path: $FILE_PATH"
          exit 1
        fi
```

#### 2. **Matrix Strategy for Parallel Org Deployment**
- Job 1: Group files by org
- Job 2: Deploy to each org in parallel (matrix strategy)
- Each org job processes all its environments sequentially

#### 3. **Per-File Environment Extraction**
Inside each org deployment:
```bash
for file in $CHANGED_FILES; do
  # Extract environment from THIS specific file
  APIGEE_ENV=$(echo "$file" | awk -F'/envs/' '{print $2}' | cut -d'/' -f1)

  # Deploy to $APIGEE_ORG / $APIGEE_ENV
  # ...
done
```

---

## 🔐 Required Secrets Inventory

### Current Secrets (Applications Repo)
✅ **Already Configured**:
```
GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01   # Dev org service account
GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01    # Test org service account
GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01     # Prod org service account
OAUTH_BACKEND_CLIENT_ID                # OAuth KVM values
OAUTH_BACKEND_CLIENT_SECRET            # OAuth KVM values
```

### GitOps Repo Secrets (For Reference)
✅ **Already Configured**:
```
GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01   # Dev org
GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01    # QA org
GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01     # Prod org
```

### ⚠️ SECRETS TO GATHER (If Adding New Orgs)

**Format for New Org Secrets**:
```
Secret Name: GCP_SA_KEY_{ORG_NAME_UPPERCASE_WITH_UNDERSCORES}
Example: GCP_SA_KEY_GCP_PRJ_APIGEE_EVAL_NP_01

Content: GCP Service Account JSON key file
```

**Steps to Create Service Account Key**:
1. Go to GCP Console for target project
2. Navigate to IAM & Admin > Service Accounts
3. Create service account (or use existing)
4. Required roles:
   - `Apigee API Admin` (for proxy deployment)
   - `Apigee Environment Admin` (for KVMs, target servers)
5. Create JSON key
6. Add to GitHub repository secrets

### KVM Secrets Inventory

**Current KVM Secrets** (used in `spec.secrets`):
```yaml
# Applications Repo:
OAUTH_BACKEND_CLIENT_ID      # Used in OAuth proxy templates
OAUTH_BACKEND_CLIENT_SECRET  # Used in OAuth proxy templates

# Per Org/Env (if needed):
{ORG}_{ENV}_OAUTH_CLIENT_ID
{ORG}_{ENV}_OAUTH_CLIENT_SECRET
```

**⚠️ TO GATHER** (if using environment-specific OAuth backends):
```
# Dev org secrets
GCP_PRJ_APIGEE_DEV_NP_01_APICC_DEV_OAUTH_CLIENT_ID
GCP_PRJ_APIGEE_DEV_NP_01_APICC_DEV_OAUTH_CLIENT_SECRET
GCP_PRJ_APIGEE_DEV_NP_01_APICC_DEV1_OAUTH_CLIENT_ID
GCP_PRJ_APIGEE_DEV_NP_01_APICC_DEV1_OAUTH_CLIENT_SECRET

# QA org secrets
GCP_PRJ_APIGEE_QA_NP_01_APICC_TEST1_OAUTH_CLIENT_ID
GCP_PRJ_APIGEE_QA_NP_01_APICC_TEST1_OAUTH_CLIENT_SECRET

# Prod org secrets
GCP_PRJ_APIGEE_PROD_01_APICC_PROD_OAUTH_CLIENT_ID
GCP_PRJ_APIGEE_PROD_01_APICC_PROD_OAUTH_CLIENT_SECRET
```

**Alternative**: Use shared secrets across envs (current approach)
```
OAUTH_BACKEND_CLIENT_ID       # Shared across all orgs/envs
OAUTH_BACKEND_CLIENT_SECRET   # Shared across all orgs/envs
```

---

## 📊 Supported Deployment Scenarios

### Scenario 1: Single Proxy, Single Env
```
PR modifies:
  mal-SYSGEN788/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/my-api/proxy.yaml

Result: ✅ Deploy to dev org, apicc-dev environment
```

### Scenario 2: Single Proxy, Multiple Envs (Same Org)
```
PR modifies:
  mal-SYSGEN788/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/my-api/proxy.yaml
  mal-SYSGEN788/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev1/proxies/my-api/proxy.yaml
  mal-SYSGEN788/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev2/proxies/my-api/proxy.yaml

Result: ✅ Deploy to dev org, 3 environments (apicc-dev, apicc-dev1, apicc-dev2)
```

### Scenario 3: Single Proxy, Multiple Orgs (Different Envs)
```
PR modifies:
  mal-SYSGEN788/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/my-api/proxy.yaml
  mal-SYSGEN788/orgs/gcp-prj-apigee-qa-np-01/envs/apicc-test1/proxies/my-api/proxy.yaml
  mal-SYSGEN788/orgs/gcp-prj-apigee-prod-01/envs/apicc-prod/proxies/my-api/proxy.yaml

Result: ✅ Deploy to 3 orgs in parallel
  - Job 1: dev org, apicc-dev
  - Job 2: qa org, apicc-test1
  - Job 3: prod org, apicc-prod
```

### Scenario 4: Multiple Proxies, Multiple Orgs/Envs
```
PR modifies:
  mal-SYSGEN788/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/api-a/proxy.yaml
  mal-SYSGEN788/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/api-b/proxy.yaml
  mal-SYSGEN788/orgs/gcp-prj-apigee-qa-np-01/envs/apicc-test1/proxies/api-a/proxy.yaml
  mal-SYSGEN788/orgs/gcp-prj-apigee-prod-01/envs/apicc-prod/proxies/api-c/proxy.yaml

Result: ✅ All deploy in parallel by org
  - Job 1: dev org (api-a and api-b to apicc-dev)
  - Job 2: qa org (api-a to apicc-test1)
  - Job 3: prod org (api-c to apicc-prod)
```

### Scenario 5: Deletion Across Multiple Orgs/Envs
```
PR deletes:
  mal-SYSGEN788/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/my-api/proxy.yaml
  mal-SYSGEN788/orgs/gcp-prj-apigee-qa-np-01/envs/apicc-test1/proxies/my-api/proxy.yaml

Result: ✅ Undeploy from both orgs in parallel
  - Job 1: Undeploy from dev org, apicc-dev
  - Job 2: Undeploy from qa org, apicc-test1
```

---

## 🚧 Implementation Plan

### Phase 1: Foundation (2-3 hours)
1. **Create extract-org-env action**
   - Parse file paths
   - Extract org, env, MAL code
   - Unit test with various path patterns

2. **Create group-by-org job**
   - Parse changed/deleted files
   - Group by organization
   - Build matrix JSON
   - Handle edge cases (no changes, malformed paths)

### Phase 2: Unified Deploy Workflow (4-5 hours)
1. **Create deploy-proxies.yml**
   - Matrix strategy for org parallelization
   - Dynamic secret lookup
   - Per-file env extraction
   - Copy existing deploy logic (KVMs, target servers, OAS)

2. **Add undeploy logic**
   - Detect deleted files per org
   - Extract env from deleted file path (via git history)
   - Check deployment status
   - Undeploy from correct org/env

### Phase 3: Testing & Validation (2-3 hours)
1. **Create test proxies**
   - Deploy to multiple orgs/envs
   - Verify parallel execution
   - Test undeploy

2. **Edge case testing**
   - Empty deployments
   - Single org
   - Multiple orgs
   - Mixed changes + deletions

### Phase 4: Migration & Deprecation (1-2 hours)
1. **Deprecate old workflows**
   - Add deprecation notices
   - Document migration path
   - Keep for 1 sprint as backup

2. **Update documentation**
   - Producer guides
   - Workflow diagrams
   - Troubleshooting guides

**Total Estimated Time**: 9-13 hours (2-3 days)

---

## 🔒 Security Considerations

### Secret Management
- ✅ **Org-specific secrets**: Each org has its own service account key
- ✅ **Secret validation**: Workflow fails if required secret missing
- ✅ **Project verification**: Validates SA key project matches target org
- ✅ **No secret exposure**: Uses `set +x` around sensitive operations

### Least Privilege
- Each service account only has access to its own org
- Cross-org deployment impossible even if secrets leaked
- Environment-specific permissions enforced at GCP IAM level

### Audit Trail
- All deployments tracked in workflow logs
- Clear org/env context in each log section
- Failed deployments don't affect other orgs (fail-fast: false)

---

## 📈 Success Metrics

### Deployment Efficiency
- **Before**: 3 separate PRs to deploy across dev/test/prod
- **After**: 1 PR deploys to all orgs/envs

### Maintainability
- **Before**: 3 workflows × ~700 lines = 2100 lines to maintain
- **After**: 1 workflow × ~800 lines = 800 lines to maintain
- **Savings**: 62% reduction in code to maintain

### Flexibility
- **Before**: Adding new org = duplicate 700-line workflow
- **After**: Adding new org = add 1 secret + update path pattern

### Producer Experience
- **Before**: Create 3 files, 3 PRs, wait for sequential deployments
- **After**: Create 3 files, 1 PR, parallel deployment

---

## 🎓 References

### GitOps Repository Pattern
- `.github/workflows/deploy-apigee-proxy.yml` (lines 1-541)
- `.github/actions/apigee-org/action.yml` (org extraction)
- Proven pattern: **ONE workflow, dynamic org detection, parallel execution**

### File Structure Pattern
```
mal-SYSGEN{9-digits}/
  orgs/{org-name}/
    envs/{env-name}/
      proxies/{project-folder}/
        proxy.yaml         # Contains all proxy config
        oas-file.yaml      # Optional OAS spec
```

### Secret Naming Pattern
```
GCP_SA_KEY_{ORG_NAME_UPPERCASE_UNDERSCORES}
Example: GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01
```

---

## ❓ Open Questions & Decisions Needed

### Q1: Parallel vs Sequential Org Deployment?
**Options**:
- **A**: Parallel (matrix strategy, fail-fast: false)
- **B**: Sequential (loop through orgs)

**Recommendation**: **A - Parallel**
- Faster overall deployment
- Failures in one org don't block others
- Better resource utilization

**Decision**: ✅ Use parallel with `fail-fast: false`

### Q2: How to Handle Org-Specific Secrets (OAuth, JWT, etc.)?
**Options**:
- **A**: Shared secrets across all orgs (current approach)
- **B**: Org-specific secrets with fallback to shared
- **C**: Fully org/env-specific secrets (most granular)

**Recommendation**: **B - Org-specific with fallback**
```bash
# Try org-specific first
SECRET_VAR="${APIGEE_ORG_UPPER}_OAUTH_CLIENT_ID"
SECRET_VALUE="${!SECRET_VAR}"

# Fallback to shared
if [ -z "$SECRET_VALUE" ]; then
  SECRET_VALUE="$OAUTH_BACKEND_CLIENT_ID"
fi
```

**Decision**: ⏳ PENDING - Need to inventory actual OAuth backends per org

### Q3: Should We Keep Old Workflows During Transition?
**Recommendation**: ✅ **YES - Keep for 1 sprint**
- Add deprecation notice
- Disable auto-trigger, keep manual dispatch
- Remove after validating unified workflow

**Decision**: ✅ Keep as backup for 1 sprint

---

## 🔄 Future Enhancements & Follow-Up Tasks

### 1. Backport to GitOps Repository (HIGH PRIORITY)

**After** applications repo unified workflow is proven and tested:

**Task**: Update `enterprise-apigeex-gitops` to support true multi-org, multi-env deployment/undeploy

**Current GitOps Limitation**:
- ❌ Lines 27-31 in `.github/actions/apigee-org/action.yml` BLOCK multi-org deployments
- ✅ Already supports multi-env (per-file env extraction)

**Changes Needed**:
1. **Remove Multi-Org Block**: Delete lines 27-31 in `apigee-org` action
2. **Add Matrix Strategy**: Group files by org, deploy in parallel
3. **Dynamic Secret Lookup**: Same pattern as applications repo
4. **Update Workflows**:
   - `deploy-apigee-proxy.yml` (utility proxies)
   - `deploy-apigee-sharedflow.yml` (shared flows)
   - `deploy-api-product.yml` (API products)

**Benefits for Platform Team**:
- Deploy utility proxies to multiple orgs in single PR
- Consistent deployment pattern across all repos
- Reduced maintenance burden

**Implementation Estimate**: 3-4 hours (copy from applications repo)

**Jira Story**: Create new story - "GitOps - Multi-Org Deployment Support"

**Success Criteria**:
- Single PR can deploy to dev, qa, prod orgs simultaneously
- Undeploy works across multiple orgs in single PR
- All existing gitops functionality preserved

---

### 2. DELETE Proxy Bundle Capability (OPTIONAL)

**Story**: DPEAPI-18715 (Enhancement - Phase 3.5)

**Current**: UNDEPLOY only (remove deployment from environment)

**Future**: Add optional DELETE (remove proxy bundle entirely)

**Implementation**:
```yaml
inputs:
  delete_proxy_bundle:
    description: 'Delete proxy bundle after undeploy (DANGEROUS)'
    required: false
    default: 'false'
    type: choice
    options:
      - 'false'
      - 'true'
```

```bash
if [ "$DELETE_PROXY_BUNDLE" = "true" ]; then
  echo "⚠️ DELETING proxy bundle $PROXY_NAME (all revisions)"
  apigeecli apis delete --name "$PROXY_NAME" --org "$APIGEE_ORG" --token "$GCP_ACCESS_TOKEN"
fi
```

**Safety Considerations**:
- Requires manual workflow_dispatch input
- Production environment requires 2 approvals
- Add confirmation prompt with 30-second delay
- Log deletion with full audit trail

**Recommendation**: Implement only if business requirement confirmed

---

### 3. Dry Run / Preview Mode

**Feature**: Preview deployment/undeploy actions without executing

**Implementation**:
```yaml
inputs:
  dry_run:
    description: 'Preview actions without executing'
    required: false
    default: 'false'
```

**Output**: Markdown summary of planned actions
- Which proxies will be deployed/undeployed
- Target orgs and environments
- Secrets that will be used
- KVMs that will be created

**Benefit**: Confidence before executing production changes

---

## 📋 Success Metrics

### Phase 1 Complete (Extract-Org-Env Action)
- ✅ Successfully parses all valid file paths
- ✅ Extracts org, env, MAL code, project folder
- ✅ Handles edge cases gracefully
- ✅ Unit tests pass for all scenarios

### Phase 2 Complete (Unified Workflow - Deploy)
- ✅ Single PR deploys to multiple orgs/envs
- ✅ Matrix strategy parallelizes org deployment
- ✅ Dynamic secret lookup works for all orgs
- ✅ KVMs created with secret substitution
- ✅ Target servers auto-created
- ✅ Proxies deployed and responding

### Phase 3 Complete (Unified Workflow - Undeploy)
- ✅ Deleted files detected correctly
- ✅ Proxies undeployed from correct org/env
- ✅ Multi-org undeploy in single PR works
- ✅ Edge cases handled (proxy not deployed, 404s, permissions)
- ✅ Full audit trail in logs

### Phase 4 Complete (Migration & Deprecation)
- ✅ Old workflows deprecated with notices
- ✅ All producers migrated to unified workflow
- ✅ No regressions in functionality
- ✅ Old workflows removed after 1 sprint

---

## 📝 Next Steps

1. **✅ Review this architecture doc** with team
2. **✅ Inventory secrets** - confirm we have all required GCP SA keys
3. **⏳ Start implementation** - Phase 1 (foundation)
4. **⏳ Test with sample proxy** - deploy to multiple orgs
5. **⏳ Validate undeploy** - delete test proxy from multiple orgs
6. **⏳ Migrate existing proxies** - update documentation
7. **⏳ Deprecate old workflows** - after 1 sprint validation

---

**Document Version**: 1.0
**Last Updated**: 2025-12-12
**Status**: 🎯 Ready for Review & Implementation
