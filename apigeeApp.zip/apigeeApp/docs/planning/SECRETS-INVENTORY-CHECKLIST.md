# Secrets Inventory Checklist - Unified Deployment Architecture

**Purpose**: Track all required GitHub secrets for multi-org/multi-env deployment
**Created**: 2025-12-12
**Status**: 🔍 Discovery Phase

---

## 📋 GCP Service Account Keys (Org Authentication)

### Applications Repository

| Secret Name | Org | Status | Notes |
|------------|-----|--------|-------|
| `GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01` | gcp-prj-apigee-dev-np-01 | ✅ EXISTS | Dev org |
| `GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01` | gcp-prj-apigee-qa-np-01 | ✅ EXISTS | Test/QA org |
| `GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01` | gcp-prj-apigee-prod-01 | ✅ EXISTS | Prod org |

**Action Required**:
- [ ] Verify all 3 primary secrets exist in GitHub repo settings
- [ ] Test each secret authenticates successfully
- [ ] Document which service account email each key belongs to
- [ ] Verify service accounts have correct IAM roles:
  - [ ] `Apigee API Admin`
  - [ ] `Apigee Environment Admin`

---

### GitOps Repository (For Reference)

| Secret Name | Org | Status | Notes |
|------------|-----|--------|-------|
| `GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01` | gcp-prj-apigee-dev-np-01 | ✅ EXISTS | Dev org |
| `GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01` | gcp-prj-apigee-qa-np-01 | ✅ EXISTS | QA org |
| `GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01` | gcp-prj-apigee-prod-01 | ✅ EXISTS | Prod org |

---

## 🔑 OAuth Backend Credentials (KVM Population)

### Shared Secrets (Current Approach)

| Secret Name | Purpose | Status | Notes |
|------------|---------|--------|-------|
| `OAUTH_BACKEND_CLIENT_ID` | OAuth client ID for all envs | ✅ EXISTS | Used in KVMs |
| `OAUTH_BACKEND_CLIENT_SECRET` | OAuth client secret for all envs | ✅ EXISTS | Used in KVMs |

**Current Behavior**:
- Same OAuth credentials used across ALL orgs/envs
- Values substituted into KVMs via `spec.secrets` reference
- Works if backend OAuth server is shared

**Question**: ❓ Do we have separate OAuth backends per org/env?

---

### Per-Org OAuth Secrets (If Needed)

**Naming Pattern**: `{ORG_UPPER}_{ENV_UPPER}_OAUTH_CLIENT_ID`

#### Dev Org (gcp-prj-apigee-dev-np-01)

| Secret Name | Env | Status | Backend URL | Notes |
|------------|-----|--------|-------------|-------|
| `GCP_PRJ_APIGEE_DEV_NP_01_APICC_DEV_OAUTH_CLIENT_ID` | apicc-dev | ⏳ TO CHECK | ? | |
| `GCP_PRJ_APIGEE_DEV_NP_01_APICC_DEV_OAUTH_CLIENT_SECRET` | apicc-dev | ⏳ TO CHECK | ? | |
| `GCP_PRJ_APIGEE_DEV_NP_01_APICC_DEV1_OAUTH_CLIENT_ID` | apicc-dev1 | ⏳ TO CHECK | ? | |
| `GCP_PRJ_APIGEE_DEV_NP_01_APICC_DEV1_OAUTH_CLIENT_SECRET` | apicc-dev1 | ⏳ TO CHECK | ? | |

#### QA Org (gcp-prj-apigee-qa-np-01)

| Secret Name | Env | Status | Backend URL | Notes |
|------------|-----|--------|-------------|-------|
| `GCP_PRJ_APIGEE_QA_NP_01_APICC_TEST1_OAUTH_CLIENT_ID` | apicc-test1 | ⏳ TO CHECK | ? | |
| `GCP_PRJ_APIGEE_QA_NP_01_APICC_TEST1_OAUTH_CLIENT_SECRET` | apicc-test1 | ⏳ TO CHECK | ? | |

#### Prod Org (gcp-prj-apigee-prod-01)

| Secret Name | Env | Status | Backend URL | Notes |
|------------|-----|--------|-------------|-------|
| `GCP_PRJ_APIGEE_PROD_01_APICC_PROD_OAUTH_CLIENT_ID` | apicc-prod | ⏳ TO CHECK | ? | |
| `GCP_PRJ_APIGEE_PROD_01_APICC_PROD_OAUTH_CLIENT_SECRET` | apicc-prod | ⏳ TO CHECK | ? | |

**Action Required**:
- [ ] Determine if OAuth backends are shared or per-org/env
- [ ] If separate: Gather all client IDs and secrets
- [ ] If separate: Create GitHub secrets with naming pattern above
- [ ] Document OAuth backend URLs for each env
- [ ] Test OAuth token generation with each credential set

---

## 🔐 JWT Private Keys (If Using JWT Backend Auth)

### Shared JWT Keys

| Secret Name | Purpose | Status | Notes |
|------------|---------|--------|-------|
| `APIGEEX_KVM_APIGEE_JWT_PRIVATE_KEY` | JWT signing key | ⏳ TO CHECK | From templates repo |

**Question**: ❓ Is JWT private key shared or per-org?

### Per-Org JWT Keys (If Needed)

| Secret Name | Org | Status | Notes |
|------------|-----|--------|-------|
| `GCP_PRJ_APIGEE_DEV_NP_01_JWT_PRIVATE_KEY` | Dev | ⏳ TO CHECK | If using separate keys |
| `GCP_PRJ_APIGEE_QA_NP_01_JWT_PRIVATE_KEY` | QA | ⏳ TO CHECK | If using separate keys |
| `GCP_PRJ_APIGEE_PROD_01_JWT_PRIVATE_KEY` | Prod | ⏳ TO CHECK | If using separate keys |

---

## 📊 Secret Lookup Strategy (Proposed)

### Hierarchical Fallback Pattern

```bash
# 1. Try org+env specific
SECRET_VAR="${APIGEE_ORG_UPPER}_${APIGEE_ENV_UPPER}_OAUTH_CLIENT_ID"
SECRET_VALUE="${!SECRET_VAR}"

# 2. Fallback to org-level
if [ -z "$SECRET_VALUE" ]; then
  SECRET_VAR="${APIGEE_ORG_UPPER}_OAUTH_CLIENT_ID"
  SECRET_VALUE="${!SECRET_VAR}"
fi

# 3. Fallback to shared
if [ -z "$SECRET_VALUE" ]; then
  SECRET_VALUE="$OAUTH_BACKEND_CLIENT_ID"
fi

# 4. Error if still not found
if [ -z "$SECRET_VALUE" ]; then
  echo "❌ No OAuth client ID found for $APIGEE_ORG / $APIGEE_ENV"
  exit 1
fi
```

**Benefits**:
- Most specific secret wins
- Graceful fallback to shared secrets
- Easy migration path (add specific secrets as needed)
- Backward compatible with current approach

---

## 🔍 Discovery Commands

### Check Existing Secrets (Applications Repo)

```bash
# List all secrets (requires admin access)
gh secret list --repo CenturyLink/enterprise-apigeex-applications

# Check specific secret exists
gh secret list --repo CenturyLink/enterprise-apigeex-applications | grep GCP_SA_KEY

# Check OAuth secrets
gh secret list --repo CenturyLink/enterprise-apigeex-applications | grep OAUTH
```

### Check GitOps Secrets (For Comparison)

```bash
gh secret list --repo CenturyLink/enterprise-apigeex-gitops | grep GCP_SA_KEY
gh secret list --repo CenturyLink/enterprise-apigeex-gitops | grep OAUTH
```

### Verify Service Account Roles

```bash
# For each org
ORG="gcp-prj-apigee-dev-np-01"

# Get service account email from key file (once authenticated)
SA_EMAIL=$(gcloud auth list --filter=status:ACTIVE --format="value(account)")

# Check IAM roles
gcloud projects get-iam-policy $ORG \
  --flatten="bindings[].members" \
  --format="table(bindings.role)" \
  --filter="bindings.members:$SA_EMAIL"

# Should see:
# - roles/apigee.apiAdmin
# - roles/apigee.environmentAdmin
```

---

## 📝 Action Items

### Immediate (Before Implementation)
- [ ] Run discovery commands to list existing secrets
- [ ] Verify 3 primary GCP SA keys exist and authenticate
- [ ] Document service account emails for each key
- [ ] Test OAuth credentials work in dev/test/prod
- [ ] Determine if OAuth backends are shared or separate
- [ ] Document OAuth backend URLs per environment

### Before First Multi-Org Deployment
- [ ] Add any missing GCP SA key secrets
- [ ] Test authentication with each service account
- [ ] Verify IAM roles on each service account
- [ ] Create org-specific OAuth secrets (if needed)
- [ ] Update workflow to use hierarchical secret lookup
- [ ] Test secret fallback logic with sample deployment

### Nice to Have (Future)
- [ ] Rotate service account keys on schedule
- [ ] Implement secret expiration monitoring
- [ ] Document secret creation process for new orgs
- [ ] Create Terraform for SA provisioning (optional)

---

## 🔒 Security Best Practices

### Secret Management
1. ✅ **Never commit secrets to Git** (obviously)
2. ✅ **Use GitHub Secrets** for all sensitive values
3. ✅ **Rotate keys regularly** (every 90 days recommended)
4. ✅ **Least privilege** - SA only has access to its org
5. ✅ **Audit trail** - Track secret usage in workflow logs

### Service Account Security
1. ✅ **One SA per org** - No cross-org access
2. ✅ **Minimal roles** - Only Apigee API Admin + Environment Admin
3. ✅ **Key rotation** - Rotate JSON keys quarterly
4. ✅ **Monitoring** - Alert on SA authentication failures
5. ✅ **Validation** - Verify SA project matches target org

### Workflow Security
1. ✅ **set +x around secrets** - Prevent logging
2. ✅ **Fail fast on missing secrets** - Clear error messages
3. ✅ **Validate all inputs** - Prevent injection attacks
4. ✅ **Read-only permissions** - Workflow can't modify repo
5. ✅ **Matrix isolation** - Failed org doesn't affect others

---

## 📞 Contact Information

**For Secret Issues**:
- Platform Team: [contact info]
- GCP IAM Admin: [contact info]
- Security Team: [contact info]

**For OAuth Backend Info**:
- OAuth Team: [contact info]
- Backend API Owners: [contact info]

---

**Document Version**: 1.0
**Last Updated**: 2025-12-12
**Next Review**: Before Phase 1 implementation
**Status**: 🔍 Awaiting Discovery Results
