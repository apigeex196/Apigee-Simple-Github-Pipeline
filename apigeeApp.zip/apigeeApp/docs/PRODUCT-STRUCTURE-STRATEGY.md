# API Product Structure Strategy

**Status**: Active
**Last Updated**: February 4, 2026
**Related Story**: [DPEAPI-19943](https://lumen.atlassian.net/browse/DPEAPI-19943)

## Overview

This document defines the directory structure and usage strategy for API Products in the `enterprise-apigeex-applications` repository. We support **two product scopes** to balance team autonomy with enterprise-wide product management.

---

## Product Structure

### 1. Global Products (Cross-MAL)

**Location**: `global-products/orgs/{org}/`

**Example**:
```
global-products/
└── orgs/
    ├── gcp-prj-apigee-dev-np-01/
    │   └── ENTERPRISE-API-GATEWAY.yaml
    ├── gcp-prj-apigee-qa-np-01/
    │   └── ENTERPRISE-API-GATEWAY.yaml
    └── gcp-prj-apigee-prod-01/
        └── ENTERPRISE-API-GATEWAY.yaml
```

**When to Use**:
- ✅ Product references proxies from **multiple teams/MALs**
- ✅ Enterprise-wide API products
- ✅ Shared services consumed by multiple applications
- ✅ Platform team manages the product lifecycle

**Ownership**:
- Managed by **platform team** or **cross-functional teams**
- CODEOWNERS can be set to platform team or designated product owners
- Requires coordination across multiple application teams

**Examples**:
- `ENTERPRISE-API-GATEWAY.yaml` - Gateway product for all public APIs
- `INTERNAL-SERVICES-PRODUCT.yaml` - Shared internal services
- `PARTNER-INTEGRATION-HUB.yaml` - Partner-facing APIs from multiple teams

---

### 2. MAL-Scoped Products (Single Team)

**Location**: `mal-SYSGEN*/orgs/{org}/products/`

**Example**:
```
mal-SYSGEN788836350/
└── orgs/
    ├── gcp-prj-apigee-dev-np-01/
    │   └── products/
    │       └── SYSGEN788836350-my-team-product.yaml
    ├── gcp-prj-apigee-qa-np-01/
    │   └── products/
    │       └── SYSGEN788836350-my-team-product.yaml
    └── gcp-prj-apigee-prod-01/
        └── products/
            └── SYSGEN788836350-my-team-product.yaml
```

**When to Use**:
- ✅ Product references **only your team's proxies**
- ✅ Team-specific products for internal or external use
- ✅ Product lifecycle managed by single application team
- ✅ Most common use case (default choice)

**Ownership**:
- Managed by **application team** (MAL owner)
- CODEOWNERS set to the team responsible for the MAL
- Team has full autonomy over product lifecycle

**Examples**:
- `SYSGEN788836350-customer-api-product.yaml` - Team's customer-facing APIs
- `SYSGEN788836350-internal-tools.yaml` - Team's internal services
- `SYSGEN788836350-mobile-backend.yaml` - Team's mobile app backend

---

## Architecture Benefits

### Consistency
Both structures use the **same `orgs/{org}/` pattern**, making it easy to understand and navigate:
- Global: `global-products/orgs/{org}/`
- MAL-scoped: `mal-SYSGEN*/orgs/{org}/products/`

### Clear Ownership
The file path immediately indicates the product scope:
- Root-level `global-products/` → Platform/cross-team ownership
- Inside `mal-SYSGEN*/` → Application team ownership

### Governance Flexibility
CODEOWNERS can enforce different approval workflows:
- Global products: Require platform team + affected team reviews
- MAL-scoped products: Single team approval sufficient

### GitOps Alignment
Global products structure mirrors the GitOps repository pattern, enabling:
- Consistent deployment workflows
- Shared automation tooling
- Cross-repository product management

---

## CI/CD Integration

Both product structures are supported by the same workflows:

**Validation**: [`.github/workflows/validate-product.yml`](../.github/workflows/validate-product.yml)
```yaml
paths:
  - 'global-products/orgs/*/*.yaml'           # Cross-MAL products
  - 'mal-SYSGEN*/orgs/*/products/*.yaml'      # MAL-scoped products
```

**Deployment**: [`.github/workflows/deploy-products.yml`](../.github/workflows/deploy-products.yml)
```yaml
paths:
  - "global-products/orgs/*/*.yaml"          # Cross-MAL products
  - "mal-SYSGEN*/orgs/*/products/*.yaml"     # MAL-scoped products
```

---

## Decision Tree

Use this flowchart to decide which product structure to use:

```
Does your product reference proxies from multiple MAL folders?
│
├─ YES → Use Global Products
│         Location: global-products/orgs/{org}/
│         Ownership: Platform team or cross-functional
│         CODEOWNERS: Platform team + affected teams
│
└─ NO → Use MAL-Scoped Products (default)
         Location: mal-SYSGEN*/orgs/{org}/products/
         Ownership: Application team
         CODEOWNERS: Your team only
```

**When in doubt**: Start with MAL-scoped. It's easier to move a product to global later if cross-team usage emerges.

---

## Migration Between Scopes

### MAL-Scoped → Global

If a MAL-scoped product needs to reference proxies from other teams:

1. **Create global product**:
   ```bash
   mkdir -p global-products/orgs/gcp-prj-apigee-dev-np-01
   cp mal-SYSGEN*/orgs/*/products/PRODUCT.yaml \
      global-products/orgs/gcp-prj-apigee-dev-np-01/
   ```

2. **Update CODEOWNERS**:
   ```
   # Before (MAL-scoped)
   mal-SYSGEN788836350/ @team-alpha

   # After (global)
   global-products/orgs/*/PRODUCT.yaml @platform-team @team-alpha @team-beta
   ```

3. **Update product spec** to reference cross-MAL proxies:
   ```yaml
   proxies:
     - SYSGEN788836350-team-alpha-api    # Original team
     - SYSGEN999888777-team-beta-api     # New team
   ```

4. **Coordinate deployment** with affected teams

5. **Delete old MAL-scoped product** after successful migration

### Global → MAL-Scoped

If a global product ends up only being used by one team:

1. **Move product file**:
   ```bash
   mkdir -p mal-SYSGEN*/orgs/{org}/products
   mv global-products/orgs/{org}/PRODUCT.yaml \
      mal-SYSGEN*/orgs/{org}/products/
   ```

2. **Update CODEOWNERS** to single team

3. **Verify product only references single MAL's proxies**

---

## CODEOWNERS Strategy

### Global Products

Require approvals from **platform team + all teams with referenced proxies**:

```
# Global products require platform + affected team reviews
global-products/orgs/*/ENTERPRISE-GATEWAY.yaml @platform-team @team-alpha @team-beta
global-products/orgs/*/PARTNER-HUB.yaml @platform-team @team-charlie
```

### MAL-Scoped Products

Single team ownership:

```
# MAL-scoped products owned by application team
mal-SYSGEN788836350/orgs/*/products/ @team-alpha
mal-SYSGEN999888777/orgs/*/products/ @team-beta
```

---

## Naming Conventions

### Global Products
- **No SYSGEN prefix** (not tied to single MAL)
- Use descriptive, enterprise-relevant names
- Examples:
  - `ENTERPRISE-API-GATEWAY.yaml`
  - `PARTNER-INTEGRATION-HUB.yaml`
  - `INTERNAL-SERVICES-PLATFORM.yaml`

### MAL-Scoped Products
- **Include SYSGEN code** from the MAL folder
- Follow pattern: `SYSGEN{code}-{description}.yaml`
- Examples:
  - `SYSGEN788836350-customer-portal-apis.yaml`
  - `SYSGEN999888777-mobile-backend.yaml`
  - `SYSGEN123456789-reporting-services.yaml`

---

## Schema Validation

Both product types use the same schema: [`apiproduct.schema.json`](../apiproduct.schema.json)

**Key validation rules**:
- `metadata.name`: Must match filename (without `.yaml`)
- `metadata.org`: Must match parent `{org}` directory name
- `spec.proxies`: Array of proxy names (must exist in repository)
- `spec.environments`: Target Apigee environments

**Example**:
```yaml
---
apiVersion: v1
kind: ApiProduct
metadata:
  name: ENTERPRISE-API-GATEWAY             # Must match filename
  org: gcp-prj-apigee-dev-np-01            # Must match directory
  displayName: "Enterprise API Gateway"
spec:
  approvalType: auto
  environments:
    - apicc-dev
  proxies:
    - SYSGEN788836350-customer-api         # Team Alpha proxy
    - SYSGEN999888777-partner-api          # Team Beta proxy
  scopes:
    - read
    - write
```

---

## Testing Strategy

### Global Products

Test cross-MAL product deployments:

1. Create product in `global-products/orgs/{org}/`
2. Reference proxies from 2+ MAL folders
3. Open PR → validate workflow runs
4. Get approvals from platform + affected teams
5. Merge → deploy workflow triggers
6. Verify product deployed to all specified orgs

### MAL-Scoped Products

Test single-team product deployments:

1. Create product in `mal-SYSGEN*/orgs/{org}/products/`
2. Reference only proxies from same MAL folder
3. Open PR → validate workflow runs
4. Get team approval (via CODEOWNERS)
5. Merge → deploy workflow triggers
6. Verify product deployed correctly

---

## Related Documentation

- [README.md](../README.md) - Repository overview and MAL folder structure
- [IMPLEMENTATION-STATUS.md](IMPLEMENTATION-STATUS.md) - Story DPEAPI-19943 implementation details
- [validate-product.yml](../.github/workflows/validate-product.yml) - Product validation workflow
- [deploy-products.yml](../.github/workflows/deploy-products.yml) - Product deployment workflow
- [apiproduct.schema.json](../apiproduct.schema.json) - Product YAML schema

---

## Questions or Issues?

For questions about product structure strategy:
- **Platform questions**: Contact API Enablement team
- **Team-specific products**: Contact your MAL owner
- **Cross-team coordination**: Reach out to both teams + platform team

For bugs or feature requests:
- Open a GitHub issue
- Reference [DPEAPI-19943](https://lumen.atlassian.net/browse/DPEAPI-19943) for context
