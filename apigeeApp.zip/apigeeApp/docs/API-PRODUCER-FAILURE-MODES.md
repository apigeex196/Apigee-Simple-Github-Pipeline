# API Producer Failure Modes

Purpose: Evidence-based answers to common failure scenarios in this repo’s validation and deployment workflows, with exact enforcement points and fixes.

---

## Executive Summary
- Workflows enforce schema, naming, template mapping, KVM/secrets, OAS linting, and product integrity.
- Failures surface in PR validation or during deployment, with actionable messages and links.
- Deleted proxy YAMLs trigger automatic undeploy/delete.

---

## Overview (Quick References)
- Proxy validation: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml)
- Product validation: [../.github/workflows/validate-product.yml](../.github/workflows/validate-product.yml)
- Dev deploy (undeploy behavior): [../.github/workflows/deploy-to-dev.yml](../.github/workflows/deploy-to-dev.yml)
- OAS guidance: [docs/OAS-VALIDATION.md](OAS-VALIDATION.md)
- Undeploy guide: [docs/PROXY-UNDEPLOY.md](PROXY-UNDEPLOY.md)

---

## 1) Proxy YAML syntax or schema invalid
- What’s detected: Invalid YAML or fails `apiproxy.schema.json` (Draft-07).
- Where enforced:
  - YAML syntax check: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L121-L137)
  - Schema check via `ajv-cli`: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L150-L181)
- Workflow behavior: Marks errors, fails job; summary includes top error lines.
- Fix: Correct YAML, then run local validation; ensure required fields match [apiproxy.schema.json](../apiproxy.schema.json).
- Evidence: “Invalid YAML syntax” and “Schema validation failed” messages are emitted and job exits with error.

## 2) Proxy naming convention failure
- What’s detected: `metadata.name` not `^SYSGEN[0-9]{9}-`.
- Where enforced: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L188-L206)
- Workflow behavior: Emits error and fails PR validation.
- Fix: Rename proxy to MAL-prefixed form (e.g., `SYSGEN788836350-my-api`).
- Evidence: Error message “Proxy name '<name>' does not follow SYSGEN[0-9]{9}- convention”.

## 3) Template mapping missing or invalid
- What’s detected: `spec.template` missing or not found in [template-mappings.json](../template-mappings.json).
- Where enforced:
  - Missing template field: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L212-L218)
  - Not in mappings: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L220-L239)
- Workflow behavior: Fails validation; lists available templates.
- Fix: Set `spec.template` to a valid name from [template-mappings.json](../template-mappings.json).
- Evidence: Error “Template '<name>' not found in template-mappings.json”.

## 4) Template download or release issues
- What’s detected: No matching release tag, no zip asset, unzip/extraction failures.
- Where enforced:
  - No release found (pattern): [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L587)
  - No zip in release: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L634-L646)
  - Extraction failed: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L652-L664)
  - Cache/template missing later: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L848-L855)
- Workflow behavior: Emits errors, updates job summary, and fails the job if download validation fails.
- Fix: Ensure template exists in [CenturyLink/enterprise-apigeex-templates](https://github.com/CenturyLink/enterprise-apigeex-templates) with expected tag prefix from [template-mappings.json](../template-mappings.json).
- Evidence: Summary contains per-template status and OAS checks.

## 5) KVM configuration and secrets issues
- What’s detected:
  - Required secrets listed in `spec.secrets[]` missing from workflow env.
  - Invalid KVM scope; incorrect entry count; missing variables.
- Where enforced:
  - Missing secrets: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L256-L266)
  - Invalid scope and entry count: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L287-L299)
  - Deployment KVM secret substitution hard-fail: [../.github/workflows/deploy-to-dev.yml](../.github/workflows/deploy-to-dev.yml#L171-L215)
- Workflow behavior: PR validation warns/errors; deployment step fails if substitution cannot resolve variables.
- Fix: Add required GitHub secrets and list them explicitly in `spec.secrets[]`; validate KVM `scope` and provide exactly one `entries` item.
- Evidence: Errors indicate missing secret names and invalid KVM settings.

## 6) OAS validation failures
- What’s detected:
  - `oasValidation.enabled: true` with missing `oasResource` file.
  - Lint errors in OpenAPI/Swagger.
- Where enforced:
  - PR validation: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L328-L361)
  - Standalone OAS linting: [../.github/workflows/validate-proxy.yml](../.github/workflows/validate-proxy.yml#L413-L459)
  - Dev deploy linting: [../.github/workflows/deploy-to-dev.yml](../.github/workflows/deploy-to-dev.yml#L677-L702)
- Workflow behavior: Emits error and fails job when OAS lint fails; warns if file missing at copy time.
- Fix: Place OAS next to proxy YAML; fix lint errors with Redocly `openapi-cli`; ensure `oas://filename.yaml` is correct.
- Evidence: See [docs/OAS-VALIDATION.md](OAS-VALIDATION.md) for expected config; errors include the path and filename.

## 7) Product YAML validation failures
- What’s detected:
  - Invalid YAML or schema.
  - Product `metadata.name` wrong prefix.
  - Proxy references not found under MAL folder.
  - Invalid quota values or timeUnit.
- Where enforced:
  - YAML/schema: [../.github/workflows/validate-product.yml](../.github/workflows/validate-product.yml#L84-L137)
  - Naming convention: [../.github/workflows/validate-product.yml](../.github/workflows/validate-product.yml#L181-L199)
  - Proxy references: [../.github/workflows/validate-product.yml](../.github/workflows/validate-product.yml#L211-L235)
  - Quota validation: [../.github/workflows/validate-product.yml](../.github/workflows/validate-product.yml#L246-L271)
- Workflow behavior: Fails PR validation with detailed errors; summary shows offending fields.
- Fix: Align to [apiproduct.schema.json](../apiproduct.schema.json); correct product name, proxies list, and quota config.
- Evidence: Error messages include proxy reference paths and quota field constraints.

## 8) Deleting proxy YAML triggers undeploy/delete
- What’s detected: Proxy YAML removed from MAL org/env path in a commit.
- Where enforced:
  - Dev undeploy step: [../.github/workflows/deploy-to-dev.yml](../.github/workflows/deploy-to-dev.yml#L535-L596)
  - Guidance doc: [docs/PROXY-UNDEPLOY.md](PROXY-UNDEPLOY.md)
- Workflow behavior: Calls `apigeecli apis delete` to undeploy from all envs and delete all revisions; continues if not found.
- Fix: If accidental, restore the YAML and merge; normal deploy will recreate and redeploy. For selective undeploy, open a change to adjust workflow logic instead of deleting the file.
- Evidence: Logs show “Undeployed and deleted proxy: <name>” or “Proxy not found”.

---

## Notes
- Service accounts are retrieved via `get-service-account` with org-specific fallbacks; see [docs/repository-configuration.md](repository-configuration.md) and [docs/E2E-TESTING-DPEAPI-18719.md](E2E-TESTING-DPEAPI-18719.md#L262-L296) for missing-secret behavior.
- Environment derivation from org is strict; invalid org naming fails early in workflows.
