#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Create New Proxy - Interactive Demo

.DESCRIPTION
    Creates a new demo proxy YAML file and guides you through the Git workflow.
    Safe script with validation and confirmation steps.

.EXAMPLE
    .\CREATE-NEW-PROXY-DEMO.ps1
#>

[CmdletBinding()]
param()

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  CREATE NEW API PROXY - INTERACTIVE DEMO" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Configuration
$MAL = "SYSGEN788836350"
$org = "gcp-prj-apigee-dev-np-01"
$env = "apicc-dev"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"

# Generate unique proxy name
$proxyName = "DEMO-LIVE-$timestamp"
$fullProxyName = "$MAL-$proxyName"
$proxyFolder = $proxyName
$proxyPath = "mal-$MAL/orgs/$org/envs/$env/proxies/$proxyFolder"

Write-Host "STEP 1: Create Proxy YAML Configuration" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray
Write-Host ""
Write-Host "Configuration:" -ForegroundColor White
Write-Host "  MAL Code:      $MAL" -ForegroundColor Gray
Write-Host "  Proxy Name:    $fullProxyName" -ForegroundColor Gray
Write-Host "  Folder:        $proxyFolder" -ForegroundColor Gray
Write-Host "  Environment:   $org / $env" -ForegroundColor Gray
Write-Host "  API Path:      /sysgen788836350/demo-live/v1" -ForegroundColor Gray
Write-Host "  Backend:       https://httpbin.org (test endpoint)" -ForegroundColor Gray
Write-Host "  Template:      oauth-proxy-oauth-backend" -ForegroundColor Gray
Write-Host ""

# Check if already exists
if (Test-Path $proxyPath) {
    Write-Host "WARNING: Proxy folder already exists at $proxyPath" -ForegroundColor Yellow
    $response = Read-Host "Overwrite existing folder? (y/N)"
    if ($response -ne 'y' -and $response -ne 'Y') {
        Write-Host "Cancelled. Exiting." -ForegroundColor Red
        exit 1
    }
    Remove-Item -Recurse -Force $proxyPath
    Write-Host "Removed existing folder" -ForegroundColor Green
}

# Confirm creation
Write-Host "Ready to create proxy configuration." -ForegroundColor Cyan
$confirm = Read-Host "Proceed? (Y/n)"
if ($confirm -eq 'n' -or $confirm -eq 'N') {
    Write-Host "Cancelled. Exiting." -ForegroundColor Red
    exit 0
}

# Create folder structure
Write-Host ""
Write-Host "Creating folder structure..." -ForegroundColor Yellow
try {
    New-Item -ItemType Directory -Force -Path $proxyPath -ErrorAction Stop | Out-Null
    Write-Host "SUCCESS: Created $proxyPath" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Failed to create folder" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    exit 1
}

# Create proxy YAML content
$yamlContent = @"
---
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: $fullProxyName
  description: "Live demo proxy created on $(Get-Date -Format 'MMMM dd, yyyy at HH:mm:ss')"
  labels:
    sysgen: $MAL
    taxonomy: /Demo/v1/Live
spec:
  template: oauth-proxy-oauth-backend
  routing:
    path: /sysgen788836350/demo-live/v1
    target: https://httpbin.org
    rewritePath: /anything
    timeout: 30
  oauth:
    enabled: true
    verifyApiKey: true
"@

# Write YAML file
$yamlFile = "$proxyPath/proxy.yaml"
try {
    Set-Content -Path $yamlFile -Value $yamlContent -ErrorAction Stop
    Write-Host "SUCCESS: Created $yamlFile" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Failed to create YAML file" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    exit 1
}

# Display the YAML
Write-Host ""
Write-Host "Proxy YAML Contents:" -ForegroundColor Cyan
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray
$lines = Get-Content $yamlFile
$lineNum = 1
foreach ($line in $lines) {
    $lineStr = ("{0,3}: {1}" -f $lineNum, $line)
    if ($line -match '^\s*(name|path|template|target):') {
        Write-Host $lineStr -ForegroundColor Green
    } elseif ($line -match '^(apiVersion|kind|metadata|spec):') {
        Write-Host $lineStr -ForegroundColor Cyan
    } else {
        Write-Host $lineStr -ForegroundColor Gray
    }
    $lineNum++
}
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray

Write-Host ""
Write-Host "SUCCESS: Proxy YAML created successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "Key Details:" -ForegroundColor White
Write-Host "  - Simple YAML: Just $($lines.Count) lines" -ForegroundColor Gray
Write-Host "  - Template handles OAuth authentication" -ForegroundColor Gray
Write-Host "  - Backend routes to https://httpbin.org" -ForegroundColor Gray
Write-Host "  - Ready for Git commit" -ForegroundColor Gray
Write-Host ""

# STEP 2: Git Workflow
Write-Host ""
Write-Host "STEP 2: Commit and Push to GitHub" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray
Write-Host ""

# Check Git status
Write-Host "Checking Git status..." -ForegroundColor White
$gitStatus = git status --porcelain "mal-$MAL/"
if (-not $gitStatus) {
    Write-Host "ERROR: No changes detected" -ForegroundColor Red
    exit 1
}

Write-Host "Changes detected:" -ForegroundColor Green
git status --short "mal-$MAL/"
Write-Host ""

# Generate branch name
$branchName = "demo/live-proxy-$timestamp"
Write-Host "Branch name: $branchName" -ForegroundColor Cyan

$proceed = Read-Host "Create Git branch and commit? (Y/n)"
if ($proceed -eq 'n' -or $proceed -eq 'N') {
    Write-Host "Skipped Git workflow. Files created but not committed." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "To commit manually:" -ForegroundColor White
    Write-Host "  git checkout -b $branchName" -ForegroundColor Gray
    Write-Host "  git add mal-$MAL/" -ForegroundColor Gray
    Write-Host "  git commit -m 'feat: add demo proxy for live demonstration'" -ForegroundColor Gray
    Write-Host "  git push -u origin $branchName" -ForegroundColor Gray
    exit 0
}

Write-Host ""

# Ensure on main branch
Write-Host "Ensuring we're on main branch..." -ForegroundColor Yellow
$currentBranch = git rev-parse --abbrev-ref HEAD
if ($currentBranch -ne "main") {
    Write-Host "Currently on branch: $currentBranch" -ForegroundColor Yellow
    $switchToMain = Read-Host "Switch to main branch? (Y/n)"
    if ($switchToMain -ne 'n' -and $switchToMain -ne 'N') {
        git checkout main
        if ($LASTEXITCODE -ne 0) {
            Write-Host "ERROR: Failed to checkout main" -ForegroundColor Red
            exit 1
        }
        Write-Host "Switched to main" -ForegroundColor Green
    }
}

# Pull latest
Write-Host "Pulling latest changes..." -ForegroundColor Yellow
git pull origin main
if ($LASTEXITCODE -ne 0) {
    Write-Host "WARNING: Pull failed or conflicts detected" -ForegroundColor Yellow
}

# Create branch
Write-Host "Creating feature branch..." -ForegroundColor Yellow
git checkout -b $branchName
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Failed to create branch" -ForegroundColor Red
    exit 1
}
Write-Host "SUCCESS: Created branch $branchName" -ForegroundColor Green

# Stage changes
Write-Host "Staging changes..." -ForegroundColor Yellow
git add "mal-$MAL/"
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Failed to stage changes" -ForegroundColor Red
    exit 1
}
Write-Host "SUCCESS: Changes staged" -ForegroundColor Green

# Commit
$commitMessage = "feat: add demo proxy for live platform demonstration $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
Write-Host "Creating commit..." -ForegroundColor Yellow
Write-Host "  Message: $commitMessage" -ForegroundColor Gray
git commit -m $commitMessage
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Failed to commit" -ForegroundColor Red
    exit 1
}
Write-Host "SUCCESS: Changes committed" -ForegroundColor Green

# Push
Write-Host ""
$pushConfirm = Read-Host "Push to GitHub? (Y/n)"
if ($pushConfirm -eq 'n' -or $pushConfirm -eq 'N') {
    Write-Host "Skipped push. To push manually:" -ForegroundColor Yellow
    Write-Host "  git push -u origin $branchName" -ForegroundColor Gray
    exit 0
}

Write-Host "Pushing to GitHub..." -ForegroundColor Yellow
git push -u origin $branchName
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Failed to push" -ForegroundColor Red
    Write-Host "Check your GitHub authentication" -ForegroundColor Yellow
    exit 1
}
Write-Host "SUCCESS: Pushed to GitHub" -ForegroundColor Green

# STEP 3: Open Pull Request
Write-Host ""
Write-Host "STEP 3: Open Pull Request" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray
Write-Host ""

$repoUrl = "https://github.com/CenturyLink/enterprise-apigeex-applications"
$prUrl = "$repoUrl/compare/main...$branchName"

Write-Host "Pull Request URL:" -ForegroundColor White
Write-Host "  $prUrl" -ForegroundColor Cyan
Write-Host ""

$openPR = Read-Host "Open browser to create PR? (Y/n)"
if ($openPR -ne 'n' -and $openPR -ne 'N') {
    try {
        Start-Process $prUrl
        Write-Host "Opened browser" -ForegroundColor Green
    } catch {
        Write-Host "Could not open browser automatically" -ForegroundColor Yellow
        Write-Host "Navigate to: $prUrl" -ForegroundColor Gray
    }
}

# STEP 4: Monitor Workflows
Write-Host ""
Write-Host "STEP 4: Watch Automated Validation" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray
Write-Host ""
Write-Host "After creating the Pull Request:" -ForegroundColor White
Write-Host "  1. GitHub Actions will automatically validate the proxy" -ForegroundColor Gray
Write-Host "  2. Look for green checkmark (success) or red X (failure)" -ForegroundColor Gray
Write-Host "  3. Validation typically takes 2-3 minutes" -ForegroundColor Gray
Write-Host ""

$actionsUrl = "$repoUrl/actions"
$openActions = Read-Host "Open GitHub Actions to monitor? (Y/n)"
if ($openActions -ne 'n' -and $openActions -ne 'N') {
    try {
        Start-Process $actionsUrl
        Write-Host "Opened GitHub Actions" -ForegroundColor Green
    } catch {
        Write-Host "Could not open browser automatically" -ForegroundColor Yellow
        Write-Host "Navigate to: $actionsUrl" -ForegroundColor Gray
    }
}

# Final Summary
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  DEMO WORKFLOW COMPLETE" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "What was demonstrated:" -ForegroundColor White
Write-Host "  [✓] Step 1: Created proxy YAML ($($lines.Count) lines)" -ForegroundColor Green
Write-Host "  [✓] Step 2: Committed to Git branch" -ForegroundColor Green
Write-Host "  [✓] Step 3: Pushed to GitHub" -ForegroundColor Green
Write-Host "  [✓] Step 4: Ready to create Pull Request" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps (manual):" -ForegroundColor Yellow
Write-Host "  5. Create PR in browser (if not already done)" -ForegroundColor White
Write-Host "  6. Wait for validation to pass (2-3 minutes)" -ForegroundColor White
Write-Host "  7. Merge PR" -ForegroundColor White
Write-Host "  8. Watch automated deployment (3-5 minutes)" -ForegroundColor White
Write-Host "  9. API will be live in Apigee Dev environment" -ForegroundColor White
Write-Host ""
Write-Host "Total time from YAML to live API: ~10 minutes" -ForegroundColor Cyan
Write-Host ""
Write-Host "Cleanup (optional):" -ForegroundColor Gray
Write-Host "  To remove this demo proxy after presentation:" -ForegroundColor DarkGray
Write-Host "  Remove-Item -Recurse -Force $proxyPath" -ForegroundColor DarkGray
Write-Host ""
