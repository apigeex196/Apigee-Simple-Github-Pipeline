#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Master Demo Script - Run Complete API Producer Demo

.DESCRIPTION
    Interactive menu-driven demo script that guides you through demonstrating
    the API Producer platform end-to-end.

.EXAMPLE
    .\RUN-DEMO.ps1
#>

[CmdletBinding()]
param()

function Show-Header {
    Clear-Host
    Write-Host "`n" -NoNewline
    Write-Host "╔════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║                                                                    ║" -ForegroundColor Cyan
    Write-Host "║          API PRODUCER PLATFORM - LIVE DEMONSTRATION                ║" -ForegroundColor Cyan
    Write-Host "║                                                                    ║" -ForegroundColor Cyan
    Write-Host "║          CenturyLink Apigee X GitOps Platform                      ║" -ForegroundColor Cyan
    Write-Host "║          February 2026                                             ║" -ForegroundColor Cyan
    Write-Host "║                                                                    ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
}

function Show-Menu {
    Write-Host "`n📋 DEMO MENU:" -ForegroundColor Yellow
    Write-Host "═══════════════════════════════════════════════════════════════════" -ForegroundColor Gray
    Write-Host "  [1] Show Existing Deployments       (Proof platform works)" -ForegroundColor White
    Write-Host "  [2] Create New Proxy                (Live YAML creation)" -ForegroundColor White
    Write-Host "  [3] Commit and Push                 (Git workflow)" -ForegroundColor White
    Write-Host "  [4] Monitor Workflows               (Validation & deployment)" -ForegroundColor White
    Write-Host "  [5] Verify Deployment               (Check deployed API)" -ForegroundColor White
    Write-Host "  " -ForegroundColor White
    Write-Host "  [A] Run All Steps (Auto-demo)       (⚠️ Creates real PR!)" -ForegroundColor Yellow
    Write-Host "  [R] Reset/Cleanup Demo Files        (Remove demo proxies)" -ForegroundColor Magenta
    Write-Host "  " -ForegroundColor White
    Write-Host "  [H] Help & Talking Points           (Demo guidance)" -ForegroundColor Cyan
    Write-Host "  [Q] Quit" -ForegroundColor Gray
    Write-Host "═══════════════════════════════════════════════════════════════════" -ForegroundColor Gray
    Write-Host ""
}

function Show-Help {
    Write-Host "`n📖 DEMO HELP & TALKING POINTS" -ForegroundColor Cyan
    Write-Host "═══════════════════════════════════════════════════════════════════" -ForegroundColor Gray
    
    Write-Host "`n🎯 DEMO OBJECTIVE:" -ForegroundColor Yellow
    Write-Host "   Prove that any API producer can deploy to Apigee X in minutes" -ForegroundColor White
    Write-Host "   by writing simple YAML and using automated GitOps workflows." -ForegroundColor White
    
    Write-Host "`n⏱️ TIMING:" -ForegroundColor Yellow
    Write-Host "   Full demo: 10-15 minutes" -ForegroundColor White
    Write-Host "   Quick demo (steps 1-2 only): 3-5 minutes" -ForegroundColor White
    
    Write-Host "`n📝 DEMO FLOW:" -ForegroundColor Yellow
    Write-Host "   Step 1: Show what's already deployed (proof it works)" -ForegroundColor White
    Write-Host "   Step 2: Create new proxy YAML live (15-20 lines)" -ForegroundColor White
    Write-Host "   Step 3: Commit and push to GitHub (Git workflow)" -ForegroundColor White
    Write-Host "   Step 4: Monitor validation & deployment (automated)" -ForegroundColor White
    Write-Host "   Step 5: Verify API is live (endpoint responding)" -ForegroundColor White
    
    Write-Host "`n💡 KEY TALKING POINTS:" -ForegroundColor Yellow
    Write-Host "   ✓ Simple YAML vs complex XML (no Apigee expertise needed)" -ForegroundColor Green
    Write-Host "   ✓ Templates handle OAuth, JWT, backend connectivity" -ForegroundColor Green
    Write-Host "   ✓ Validation catches errors before deployment" -ForegroundColor Green
    Write-Host "   ✓ Deployment is fully automated (no console clicking)" -ForegroundColor Green
    Write-Host "   ✓ Same process for Dev → QA → Prod" -ForegroundColor Green
    Write-Host "   ✓ Platform is production-ready (15 existing deployments)" -ForegroundColor Green
    
    Write-Host "`n🎤 OPENING STATEMENT:" -ForegroundColor Yellow
    Write-Host '   "Let me show you how we'"'"'ve made deploying to Apigee X as simple' -ForegroundColor Gray
    Write-Host '    as writing 15 lines of YAML. Everything else is automated."' -ForegroundColor Gray
    
    Write-Host "`n✨ CLOSING STATEMENT:" -ForegroundColor Yellow
    Write-Host '   "From YAML file to live API: under 10 minutes, zero manual steps,' -ForegroundColor Gray
    Write-Host '    fully automated, production-ready."' -ForegroundColor Gray
    
    Write-Host "`n📚 REFERENCE DOCUMENTS:" -ForegroundColor Yellow
    Write-Host "   • API Producer Live Demo Guide: docs/API-PRODUCER-LIVE-DEMO.md" -ForegroundColor Gray
    Write-Host "   • Production Readiness Evidence: docs/PRODUCTION-READINESS-EVIDENCE.md" -ForegroundColor Gray
    Write-Host "   • API Producer Core Guide: docs/api-producer-core.md" -ForegroundColor Gray
    
    Write-Host "`n❓ COMMON QUESTIONS & ANSWERS:" -ForegroundColor Yellow
    Write-Host "   Q: What if validation fails?" -ForegroundColor White
    Write-Host "   A: PR check fails with clear error. Fix YAML and push again." -ForegroundColor Gray
    
    Write-Host "`n   Q: How do you prevent team conflicts?" -ForegroundColor White
    Write-Host "   A: MAL isolation + CODEOWNERS + changed file detection." -ForegroundColor Gray
    
    Write-Host "`n   Q: What about secrets and credentials?" -ForegroundColor White
    Write-Host "   A: Service accounts + GitHub Secrets + encrypted KVMs." -ForegroundColor Gray
    
    Write-Host "`n   Q: Is this really production-ready?" -ForegroundColor White
    Write-Host "   A: Yes! 5 proxies deployed across 3 environments, 15 total" -ForegroundColor Gray
    Write-Host "      deployments, automated testing, full documentation." -ForegroundColor Gray
    
    Write-Host ""
    Read-Host "Press Enter to return to menu"
}

function Test-Prerequisites {
    Write-Host "`n🔍 Checking prerequisites..." -ForegroundColor Yellow
    
    $allGood = $true
    
    # Check for Git
    $git = Get-Command git -ErrorAction SilentlyContinue
    if ($git) {
        Write-Host "   ✓ Git installed" -ForegroundColor Green
    } else {
        Write-Host "   ❌ Git not found" -ForegroundColor Red
        $allGood = $false
    }
    
    # Check repository
    if (Test-Path "mal-SYSGEN788836350") {
        Write-Host "   ✓ In repository root" -ForegroundColor Green
    } else {
        Write-Host "   ❌ Not in repository root (looking for mal-SYSGEN788836350/)" -ForegroundColor Red
        Write-Host "      Current: $(Get-Location)" -ForegroundColor Gray
        $allGood = $false
    }
    
    # Check GitHub CLI (optional)
    $gh = Get-Command gh -ErrorAction SilentlyContinue
    if ($gh) {
        Write-Host "   ✓ GitHub CLI installed (optional)" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️  GitHub CLI not installed (optional, enhances step 4)" -ForegroundColor Yellow
    }
    
    return $allGood
}

function Run-Step {
    param(
        [string]$ScriptName,
        [string]$Description
    )
    
    Write-Host "`n🚀 Running: $Description" -ForegroundColor Cyan
    Write-Host "═══════════════════════════════════════════════════════════════════" -ForegroundColor Gray
    
    $scriptPath = Join-Path $PSScriptRoot $ScriptName
    if (Test-Path $scriptPath) {
        & $scriptPath
        Write-Host "`n═══════════════════════════════════════════════════════════════════" -ForegroundColor Gray
        Write-Host "✅ Step completed" -ForegroundColor Green
        Write-Host ""
        Read-Host "Press Enter to continue"
    } else {
        Write-Host "❌ Script not found: $scriptPath" -ForegroundColor Red
        Read-Host "Press Enter to continue"
    }
}

# Main script
Show-Header

# Check prerequisites
if (-not (Test-Prerequisites)) {
    Write-Host "`n❌ Prerequisites check failed" -ForegroundColor Red
    Write-Host "Please ensure you're in the repository root and Git is installed." -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

$running = $true
while ($running) {
    Show-Header
    Show-Menu
    
    $choice = Read-Host "Select option"
    
    switch ($choice.ToUpper()) {
        "1" {
            Run-Step "01-show-existing-deployments.ps1" "Show Existing Deployments"
        }
        "2" {
            Run-Step "02-create-new-proxy.ps1" "Create New Proxy"
        }
        "3" {
            Run-Step "03-commit-and-push.ps1" "Commit and Push"
        }
        "4" {
            Run-Step "04-monitor-workflows.ps1" "Monitor Workflows"
        }
        "5" {
            Run-Step "05-verify-deployment.ps1" "Verify Deployment"
        }
        "A" {
            Write-Host "`n⚠️  AUTO-DEMO MODE" -ForegroundColor Yellow
            Write-Host "This will run all steps and create a REAL pull request." -ForegroundColor Yellow
            $confirm = Read-Host "Are you sure? (type YES to continue)"
            
            if ($confirm -eq "YES") {
                Run-Step "01-show-existing-deployments.ps1" "Step 1: Show Existing Deployments"
                Run-Step "02-create-new-proxy.ps1" "Step 2: Create New Proxy"
                Run-Step "03-commit-and-push.ps1" "Step 3: Commit and Push"
                
                Write-Host "`n⏸️  PAUSE: Now create the Pull Request in browser" -ForegroundColor Yellow
                Write-Host "After creating PR, we'll monitor the workflows." -ForegroundColor Yellow
                Read-Host "Press Enter after PR is created"
                
                Run-Step "04-monitor-workflows.ps1" "Step 4: Monitor Workflows"
                
                Write-Host "`n⏸️  PAUSE: Wait for validation and deployment to complete" -ForegroundColor Yellow
                Write-Host "After workflows finish, we'll verify deployment." -ForegroundColor Yellow
                Read-Host "Press Enter after workflows complete"
                
                Run-Step "05-verify-deployment.ps1" "Step 5: Verify Deployment"
                
                Write-Host "`n✨ AUTO-DEMO COMPLETE!" -ForegroundColor Green
                Read-Host "Press Enter to return to menu"
            }
        }
        "R" {
            Write-Host "`n⚠️  CLEANUP MODE" -ForegroundColor Yellow
            Write-Host "This will remove demo proxy files from the repository." -ForegroundColor Yellow
            $confirm = Read-Host "Are you sure? (type YES to continue)"
            
            if ($confirm -eq "YES") {
                $malPath = "mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies"
                $demoProxies = Get-ChildItem $malPath -Directory | Where-Object { $_.Name -match "DEMO" }
                
                if ($demoProxies) {
                    Write-Host "`nFound $($demoProxies.Count) demo proxies:" -ForegroundColor Yellow
                    foreach ($proxy in $demoProxies) {
                        Write-Host "   • $($proxy.Name)" -ForegroundColor Gray
                    }
                    
                    $confirmDelete = Read-Host "`nDelete these? (y/N)"
                    if ($confirmDelete -eq 'y') {
                        foreach ($proxy in $demoProxies) {
                            Remove-Item -Recurse -Force $proxy.FullName
                            Write-Host "   ✓ Deleted: $($proxy.Name)" -ForegroundColor Green
                        }
                        Write-Host "`n✅ Cleanup complete" -ForegroundColor Green
                    }
                } else {
                    Write-Host "No demo proxies found to clean up" -ForegroundColor Gray
                }
                
                Read-Host "Press Enter to continue"
            }
        }
        "H" {
            Show-Help
        }
        "Q" {
            Write-Host "`n👋 Thanks for demoing the API Producer Platform!" -ForegroundColor Cyan
            Write-Host ""
            $running = $false
        }
        default {
            Write-Host "`n❌ Invalid option. Please try again." -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
}
