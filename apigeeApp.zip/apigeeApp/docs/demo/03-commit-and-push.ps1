#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Demo Script 3: Commit and Push Changes

.DESCRIPTION
    Commits the new proxy and pushes to a feature branch.
    Creates a branch, stages changes, commits, and pushes to GitHub.

.EXAMPLE
    .\03-commit-and-push.ps1
#>

[CmdletBinding()]
param()

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  API Producer Platform - Demo Part 3  " -ForegroundColor Cyan
Write-Host "  Commit and Push to GitHub            " -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Configuration
$MAL = "SYSGEN788836350"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$branchName = "demo/live-proxy-$timestamp"

# Check for uncommitted changes
Write-Host "🔍 Checking for changes..." -ForegroundColor Yellow
$status = git status --porcelain mal-$MAL/
if (-not $status) {
    Write-Host "❌ No changes detected in mal-$MAL/ folder" -ForegroundColor Red
    Write-Host "Did you run .\02-create-new-proxy.ps1 first?" -ForegroundColor Yellow
    exit 1
}

Write-Host "✓ Changes detected:" -ForegroundColor Green
git status --short mal-$MAL/

# Ensure we're on main and up-to-date
Write-Host "`n🔄 Updating main branch..." -ForegroundColor Yellow
$currentBranch = git rev-parse --abbrev-ref HEAD
if ($currentBranch -ne "main") {
    Write-Host "⚠️  Not on main branch (currently on: $currentBranch)" -ForegroundColor Yellow
    $response = Read-Host "Switch to main? (y/N)"
    if ($response -eq 'y' -or $response -eq 'Y') {
        git checkout main
        if ($LASTEXITCODE -ne 0) {
            Write-Host "❌ Failed to checkout main" -ForegroundColor Red
            exit 1
        }
    } else {
        Write-Host "❌ Aborted. Please switch to main branch first." -ForegroundColor Red
        exit 1
    }
}

Write-Host "✓ On main branch" -ForegroundColor Green

# Pull latest
Write-Host "`n📥 Pulling latest changes..." -ForegroundColor Yellow
git pull origin main
if ($LASTEXITCODE -ne 0) {
    Write-Host "⚠️  Pull failed or conflicts detected" -ForegroundColor Yellow
    Write-Host "Please resolve manually and re-run this script" -ForegroundColor Yellow
    exit 1
}
Write-Host "✓ Up to date with origin/main" -ForegroundColor Green

# Create and checkout new branch
Write-Host "`n🌿 Creating feature branch..." -ForegroundColor Yellow
Write-Host "   Branch name: $branchName" -ForegroundColor Gray

git checkout -b $branchName
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Failed to create branch" -ForegroundColor Red
    exit 1
}
Write-Host "✓ Created and switched to branch: $branchName" -ForegroundColor Green

# Stage changes
Write-Host "`n📦 Staging changes..." -ForegroundColor Yellow
git add mal-$MAL/
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Failed to stage changes" -ForegroundColor Red
    exit 1
}

$stagedFiles = git diff --cached --name-only
Write-Host "✓ Staged files:" -ForegroundColor Green
$stagedFiles | ForEach-Object { Write-Host "   $_" -ForegroundColor White }

# Create commit
Write-Host "`n💾 Creating commit..." -ForegroundColor Yellow
$commitMessage = "feat: add demo proxy for live platform demonstration $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
Write-Host "   Message: $commitMessage" -ForegroundColor Gray

git commit -m $commitMessage
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Failed to commit" -ForegroundColor Red
    exit 1
}
Write-Host "✓ Commit created" -ForegroundColor Green

# Show commit details
Write-Host "`n📋 Commit Details:" -ForegroundColor Cyan
git log -1 --stat

# Push to GitHub
Write-Host "`n🚀 Pushing to GitHub..." -ForegroundColor Yellow
Write-Host "   Remote: origin" -ForegroundColor Gray
Write-Host "   Branch: $branchName" -ForegroundColor Gray

git push -u origin $branchName
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Failed to push to GitHub" -ForegroundColor Red
    Write-Host "Check your GitHub authentication and network connection" -ForegroundColor Yellow
    exit 1
}
Write-Host "✓ Pushed to GitHub successfully" -ForegroundColor Green

# Generate PR URL
$repoUrl = "https://github.com/CenturyLink/enterprise-apigeex-applications"
$prUrl = "$repoUrl/compare/main...$branchName"

Write-Host "`n✅ Changes Pushed!" -ForegroundColor Green

Write-Host "`n📊 Summary:" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Gray
Write-Host "   Repository: CenturyLink/enterprise-apigeex-applications" -ForegroundColor White
Write-Host "   Branch: $branchName" -ForegroundColor White
Write-Host "   Files changed: $($stagedFiles.Count)" -ForegroundColor White
Write-Host "   Status: ✅ Pushed to GitHub" -ForegroundColor Green

Write-Host "`n🔗 GitHub Links:" -ForegroundColor Yellow
Write-Host "   Repository: $repoUrl" -ForegroundColor Gray
Write-Host "   Create PR: $prUrl" -ForegroundColor Gray

# Next steps
Write-Host "`n📋 Next Steps:" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Gray
Write-Host "   1. ✅ Code pushed to GitHub" -ForegroundColor Green
Write-Host "   2. ⏭️  Create Pull Request" -ForegroundColor Yellow
Write-Host "   3. ⏭️  Watch validation workflow run" -ForegroundColor Yellow
Write-Host "   4. ⏭️  Merge PR after validation passes" -ForegroundColor Yellow
Write-Host "   5. ⏭️  Watch deployment workflow" -ForegroundColor Yellow

Write-Host "`n💡 Talking Points:" -ForegroundColor Yellow
Write-Host "   • Changes committed with descriptive message" -ForegroundColor Gray
Write-Host "   • Pushed to feature branch (not directly to main)" -ForegroundColor Gray
Write-Host "   • Ready to open Pull Request" -ForegroundColor Gray
Write-Host "   • PR will trigger automated validation" -ForegroundColor Gray

Write-Host "`n🌐 Opening PR creation page in browser..." -ForegroundColor Cyan
Start-Sleep -Seconds 2
Start-Process $prUrl

Write-Host "`n✨ Ready to create Pull Request!" -ForegroundColor Cyan
Write-Host "`nNext: Open browser and create PR, then run .\04-monitor-workflows.ps1`n" -ForegroundColor Yellow
