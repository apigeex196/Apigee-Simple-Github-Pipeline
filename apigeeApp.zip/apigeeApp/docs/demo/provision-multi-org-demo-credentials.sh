#!/bin/bash
set -e

echo "╔════════════════════════════════════════════════════════════════════════════╗"
echo "║  Provisioning OAuth Credentials for Multi-Org Demo                        ║"
echo "╚════════════════════════════════════════════════════════════════════════════╝"
echo ""

# Get GCP access token
TOKEN=$(gcloud auth print-access-token)

PROXY_NAME="SYSGEN788836350-multi-org-applications-repo-demo"
BASEPATH="/Demo/v1/Apigee/Stats/sysgen788836350/apigee-stats/v1"

# Arrays to store credentials
ALL_CLIENT_IDS=()
ALL_CLIENT_SECRETS=()

# Process environments
for config in "dev:gcp-prj-apigee-dev-np-01:apicc-dev" "test:gcp-prj-apigee-qa-np-01:apicc-test1" "prod:gcp-prj-apigee-prod-01:apicc-prod"; do
  env_key=$(echo "$config" | cut -d: -f1)
  ORG=$(echo "$config" | cut -d: -f2)
  ENV=$(echo "$config" | cut -d: -f3)

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Provisioning: $env_key ($ORG / $ENV)"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""

  # Product name
  PRODUCT_NAME="${ENV}-multi-org-demo-product"
  DEVELOPER_EMAIL="demo.user.${ENV}@example.com"
  APP_NAME="multi-org-demo-app-${env_key}"

  # Step 1: Create or update API Product
  echo "📦 Step 1: Creating API Product: $PRODUCT_NAME"

  # Try to create (will fail if exists)
  apigeecli products create \
    --name "$PRODUCT_NAME" \
    --display-name "$PRODUCT_NAME" \
    --envs "$ENV" \
    --proxies "$PROXY_NAME" \
    --approval auto \
    --quota 10000 \
    --interval 1 \
    --unit minute \
    --org "$ORG" \
    --token "$TOKEN" 2>/dev/null && echo "   ✓ Product created" || \
  # If create failed, try update
  apigeecli products update \
    --name "$PRODUCT_NAME" \
    --display-name "$PRODUCT_NAME" \
    --envs "$ENV" \
    --proxies "$PROXY_NAME" \
    --approval auto \
    --quota 10000 \
    --interval 1 \
    --unit minute \
    --org "$ORG" \
    --token "$TOKEN" 2>/dev/null && echo "   ✓ Product updated" || echo "   ⚠ Product operation skipped"

  # Step 2: Create developer if not exists
  echo "👤 Step 2: Checking Developer: $DEVELOPER_EMAIL"
  apigeecli developers create \
    --user "$DEVELOPER_EMAIL" \
    --email "$DEVELOPER_EMAIL" \
    --first "Demo" \
    --last "User" \
    --org "$ORG" \
    --token "$TOKEN" 2>/dev/null && echo "   ✓ Developer created" || echo "   ✓ Developer exists"

  # Step 3: Create or recreate app
  echo "📱 Step 3: Creating Developer App: $APP_NAME"

  # Delete existing app if present (allow failure)
  set +e
  apigeecli apps delete \
    --name "$APP_NAME" \
    --org "$ORG" \
    --token "$TOKEN" 2>/dev/null
  set -e

  # Create new app
  APP_RESPONSE=$(apigeecli apps create \
    --name "$APP_NAME" \
    --email "$DEVELOPER_EMAIL" \
    --prods "$PRODUCT_NAME" \
    --org "$ORG" \
    --token "$TOKEN")

  # Extract credentials
  CLIENT_ID=$(echo "$APP_RESPONSE" | jq -r '.credentials[0].consumerKey')
  CLIENT_SECRET=$(echo "$APP_RESPONSE" | jq -r '.credentials[0].consumerSecret')

  ALL_CLIENT_IDS+=("$CLIENT_ID")
  ALL_CLIENT_SECRETS+=("$CLIENT_SECRET")
done

# Output summary
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅ Provisioning Complete!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📋 Update demo-proxy-enhanced.sh with these credentials:"
echo ""
echo "CLIENT_IDS=("
echo "  \"${ALL_CLIENT_IDS[0]}\""
echo "  \"${ALL_CLIENT_IDS[1]}\""
echo "  \"${ALL_CLIENT_IDS[2]}\""
echo ")"
echo ""
echo "CLIENT_SECRETS=("
echo "  \"${ALL_CLIENT_SECRETS[0]}\""
echo "  \"${ALL_CLIENT_SECRETS[1]}\""
echo "  \"${ALL_CLIENT_SECRETS[2]}\""
echo ")"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Auto-update demo script if it exists
if [ -f "demo-proxy-enhanced.sh" ]; then
  echo "🔧 Auto-updating demo-proxy-enhanced.sh..."

  # Create backup
  cp demo-proxy-enhanced.sh demo-proxy-enhanced.sh.backup

  # Update CLIENT_IDS array
  sed -i '' "/^CLIENT_IDS=/,/)$/c\\
CLIENT_IDS=(\\
  \"${ALL_CLIENT_IDS[0]}\"\\
  \"${ALL_CLIENT_IDS[1]}\"\\
  \"${ALL_CLIENT_IDS[2]}\"\\
)
" demo-proxy-enhanced.sh

  # Update CLIENT_SECRETS array
  sed -i '' "/^CLIENT_SECRETS=/,/)$/c\\
CLIENT_SECRETS=(\\
  \"${ALL_CLIENT_SECRETS[0]}\"\\
  \"${ALL_CLIENT_SECRETS[1]}\"\\
  \"${ALL_CLIENT_SECRETS[2]}\"\\
echo "✅ Ready to run demo!"
echo ""
echo "Test it now:"
echo "  ./demo-proxy-enhanced.sh"
echo ""
