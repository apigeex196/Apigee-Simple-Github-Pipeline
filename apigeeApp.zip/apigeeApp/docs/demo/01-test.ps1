﻿#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Demo Script 1: Show Existing Deployed Proxies

.DESCRIPTION
    Displays the current state of deployed proxies to prove the platform is working.
    Run this first to show what's already deployed across all 3 environments.

.EXAMPLE
    .\01-show-existing-deployments.ps1
#>

[CmdletBinding()]
param()

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  API Producer Platform - Demo Part 1  " -ForegroundColor Cyan
Write-Host "  Show Existing Deployments            " -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Configuration
$MAL = "SYSGEN788836350"
$malPath = "mal-$MAL"

# Check if in correct directory
if (-not (Test-Path $malPath)) {
    Write-Host "❌ ERROR: Must run from repository root directory" -ForegroundColor Red
    Write-Host "Current directory: $(Get-Location)" -ForegroundColor Yellow
    Write-Host "Expected to find: $malPath" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Repository found: $(Get-Location)`n" -ForegroundColor Green

# Show MAL folder structure
Write-Host "📁 MAL Folder Structure:" -ForegroundColor Yellow
Write-Host "=" * 60 -ForegroundColor Gray
tree $malPath /F /A | Select-Object -First 30
Write-Host ""

# Show deployed proxies in each environment
$environments = @(
    @{
        Name = "DEV"
        Org = "gcp-prj-apigee-dev-np-01"
        Env = "apicc-dev"
        Color = "Green"
    },
    @{
        Name = "QA (Test)"
        Org = "gcp-prj-apigee-qa-np-01"
        Env = "apicc-test1"
        Color = "Yellow"
    },
    @{
        Name = "PROD"
        Org = "gcp-prj-apigee-prod-01"
        Env = "apicc-prod"
        Color = "Red"
    }
)

Write-Host "`n📊 Deployed Proxies by Environment:" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Gray

foreach ($env in $environments) {
    Write-Host "`n🌍 $($env.Name) Environment:" -ForegroundColor $env.Color
    Write-Host "   Org: $($env.Org)" -ForegroundColor Gray
    Write-Host "   Env: $($env.Env)" -ForegroundColor Gray
    
    $proxyPath = "$malPath/orgs/$($env.Org)/envs/$($env.Env)/proxies"
    
    if (Test-Path $proxyPath) {
        $proxies = Get-ChildItem $proxyPath -Directory
        Write-Host "   Proxies: $($proxies.Count)" -ForegroundColor White
        
        foreach ($proxy in $proxies) {
            Write-Host "     ✓ $($proxy.Name)" -ForegroundColor $env.Color
            
            $yamlFile = "$proxyPath/$($proxy.Name)/proxy.yaml"
            if (Test-Path $yamlFile) {
                # Extract proxy name from YAML
                $content = Get-Content $yamlFile -Raw
                if ($content -match 'name:\s*(.+)') {
                    Write-Host "       API Name: $($matches[1].Trim())" -ForegroundColor Gray
                }
                if ($content -match 'path:\s*(.+)') {
                    Write-Host "       Path: $($matches[1].Trim())" -ForegroundColor Gray
                }
            }
        }
    } else {
        Write-Host "   ⚠️  No proxies found" -ForegroundColor Yellow
    }
}

# Show API Products
Write-Host "`n`n📦 API Products:" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Gray

foreach ($env in $environments) {
    $productPath = "$malPath/orgs/$($env.Org)/products"
    
    if (Test-Path $productPath) {
        $products = Get-ChildItem $productPath -Filter "*.yaml"
        
        if ($products.Count -gt 0) {
            Write-Host "`n🌍 $($env.Name) - $($products.Count) product(s):" -ForegroundColor $env.Color
            
            foreach ($product in $products) {
                Write-Host "   ✓ $($product.BaseName)" -ForegroundColor $env.Color
                
                # Extract product details
                $content = Get-Content $product.FullName -Raw
                if ($content -match 'description:\s*"(.+)"') {
                    Write-Host "     Description: $($matches[1])" -ForegroundColor Gray
                }
            }
        }
    }
}

# Show recent GitHub Actions workflows
Write-Host "`n`n🔄 Recent Workflow Runs:" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Gray
Write-Host "Opening GitHub Actions in browser..." -ForegroundColor Yellow

# Try to open GitHub Actions page
$repoUrl = "https://github.com/CenturyLink/enterprise-apigeex-applications/actions"
Start-Process $repoUrl

Write-Host "`n✅ Check the browser for recent workflow runs (green checkmarks = success)" -ForegroundColor Green

# Summary
Write-Host "`n`n📈 Summary:" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Gray

$totalProxies = 0
foreach ($env in $environments) {
    $proxyPath = "$malPath/orgs/$($env.Org)/envs/$($env.Env)/proxies"
    if (Test-Path $proxyPath) {
        $count = (Get-ChildItem $proxyPath -Directory).Count
        $totalProxies += $count
        Write-Host "   $($env.Name): $count proxies deployed" -ForegroundColor $env.Color
    }
}

Write-Host "`n   Total Deployments: $totalProxies" -ForegroundColor White
Write-Host "   Status: ✅ OPERATIONAL" -ForegroundColor Green

Write-Host "`n✨ Platform is working! Ready to deploy a new proxy..." -ForegroundColor Cyan
Write-Host "`nNext: Run .\02-create-new-proxy.ps1`n" -ForegroundColor Yellow

