#!/bin/bash

# Enhanced Multi-Org OAuth Protected Proxy Demo
# Demonstrates full Apigee infrastructure with weather API backend
#
# ⚠️  PRE-REQUISITE: Must be connected to Corporate VPN
# The internal Apigee endpoints (*.gcl.corp.intranet) require VPN access

set -e

# ANSI color codes
BLUE='\033[1;34m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
RED='\033[1;31m'
CYAN='\033[1;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Environment configurations
ENV_NAMES=("Dev" "Test" "Prod")
ENV_ORGS=("gcp-prj-apigee-dev-np-01" "gcp-prj-apigee-qa-np-01" "gcp-prj-apigee-prod-01")
ENV_ENVS=("apicc-dev" "apicc-test1" "apicc-prod")
ENV_HOSTS=("apicc-dev.gcl.corp.intranet" "apicc-test1.gcl.corp.intranet" "apicc-prod.gcl.corp.intranet")
ENV_LOCATIONS=("Salem, MA" "Omaha, NE" "Seattle, WA")
CLIENT_IDS=("hbxWLpQrlTNxR6RkMpG6kgMzpr6odQmH00wSFGsc2Uq50HZr" "4daqLpwYAGl7EJie1sH4V0phNSkP7JBvMq2vgVa1sOkIPcj3" "QSDbMhrrZugrOPXCTseV182VJDyuKZOqdO9LZcZwYP81RR49")
CLIENT_SECRETS=("mcfBs09P3bBzVUglYd7UXWN7tPoxAU4ySRJalPQZimRU38oHKaikgaxn8Qti4uVD" "pK9uqmL57uBeG67EOkegGGSMNe3hnkAZB2DlfdXgolEPS5cmf8jbEqvV44IisdK9" "SRV7yJRPUhAXHYusRAxGMjYespZgZtQvHx2d5W4gdOK6qFQXoDJ9ko4loGgrroNO")

# Tracking
success_count=0
failure_count=0

# Header
echo ""
echo -e "${BOLD}╔════════════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║       APIGEE X - Multi-Org OAuth Protected Proxy Demo                     ║${NC}"
echo -e "${BOLD}║       Demonstrating Full GitOps Deployment Across Environments             ║${NC}"
echo -e "${BOLD}╚════════════════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Demo each environment
for i in "${!ENV_NAMES[@]}"; do
    ENV_NAME="${ENV_NAMES[$i]}"
    ORG="${ENV_ORGS[$i]}"
    ENV="${ENV_ENVS[$i]}"
    HOST="${ENV_HOSTS[$i]}"
    LOCATION="${ENV_LOCATIONS[$i]}"
    CLIENT_ID="${CLIENT_IDS[$i]}"
    CLIENT_SECRET="${CLIENT_SECRETS[$i]}"

    echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BOLD}${CYAN}  ${ENV_NAME} Environment${NC}"
    echo -e "${CYAN}  Organization: ${ORG}${NC}"
    echo -e "${CYAN}  Environment:  ${ENV}${NC}"
    echo -e "${CYAN}  Location:     ${LOCATION}${NC}"
    echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""

    # Step 1: OAuth Token
    echo -e "${YELLOW}📋 Step 1: OAuth Authentication${NC}"
    echo -e "  ${BOLD}Infrastructure Component:${NC} Apigee OAuth Backend Proxy"
    echo -e "  ${BOLD}Endpoint:${NC} https://${HOST}/SYSGEN788836350/backend/oauth/token"
    echo -e "  ${BOLD}Method:${NC} POST (client_credentials grant)"
    echo ""
    ENV_LOWER=$(echo "$ENV" | tr '[:upper:]' '[:lower:]')
    echo -e "  ${BOLD}Application Credentials (Provisioned in ${ENV_NAME}):${NC}"
    echo -e "    Client ID: ${CLIENT_ID:0:20}..."
    echo -e "    Product:   ${ENV_LOWER}-apigee-stats-product-${ENV_LOWER}"
    echo -e "    Developer: demo.user.${ENV_LOWER}@example.com"
    echo ""

    # Get OAuth token
    TOKEN_RESPONSE=$(curl -s "https://${HOST}/SYSGEN788836350/backend/oauth/token" \
        -X POST \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "grant_type=client_credentials&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&scope=${ENV_LOWER}:scope")

    TOKEN=$(echo "$TOKEN_RESPONSE" | jq -r '.access_token')
    EXPIRES=$(echo "$TOKEN_RESPONSE" | jq -r '.expires_in')

    if [ "$TOKEN" != "null" ] && [ -n "$TOKEN" ]; then
        echo -e "  ${GREEN}✓ OAuth Token Acquired${NC}"
        echo -e "    Token: ${TOKEN:0:20}..."
        echo -e "    Expires: ${EXPIRES}s ($(($EXPIRES / 60))m)"
        echo -e "    ${BOLD}Status: OAuth backend running in ${ORG}/${ENV}${NC}"
        echo ""
    else
        echo -e "  ${RED}✗ Failed to acquire OAuth token${NC}"
        echo -e "    Response: $TOKEN_RESPONSE"
        echo ""
        ((failure_count++))
        continue
    fi

    # Step 2: Call Protected API
    echo -e "${YELLOW}📋 Step 2: Calling OAuth-Protected Proxy${NC}"
    echo -e "  ${BOLD}Infrastructure Component:${NC} SYSGEN788836350-multi-org-applications-repo-demo Proxy"
    echo -e "  ${BOLD}Endpoint:${NC} https://${HOST}/Demo/v1/Apigee/Stats/sysgen788836350/apigee-stats/v1"
    echo -e "  ${BOLD}Method:${NC} GET"
    echo -e "  ${BOLD}Authentication:${NC} Bearer Token (validated by Apigee)"
    echo -e "  ${BOLD}Backend Target:${NC} https://api.open-meteo.com (Open-Meteo Weather API)"
    echo -e "  ${BOLD}Location:${NC} ${LOCATION}"
    echo ""

    # Call API
    API_RESPONSE=$(curl -s "https://${HOST}/Demo/v1/Apigee/Stats/sysgen788836350/apigee-stats/v1" \
        -H "Authorization: Bearer ${TOKEN}")

    # Check if response is valid JSON
    if echo "$API_RESPONSE" | jq -e . >/dev/null 2>&1; then
        # Extract weather data
        TEMP=$(echo "$API_RESPONSE" | jq -r '.current.temperature_2m // empty')
        HUMIDITY=$(echo "$API_RESPONSE" | jq -r '.current.relative_humidity_2m // empty')
        WIND=$(echo "$API_RESPONSE" | jq -r '.current.wind_speed_10m // empty')
        LAT=$(echo "$API_RESPONSE" | jq -r '.latitude // empty')
        LON=$(echo "$API_RESPONSE" | jq -r '.longitude // empty')

        if [ -n "$TEMP" ]; then
            echo -e "  ${GREEN}✓ API Call Successful${NC}"
            echo ""
            echo -e "  ${BOLD}🌤️  Live Weather Data for ${LOCATION}:${NC}"
            echo -e "    Temperature:    ${TEMP}°F"
            echo -e "    Humidity:       ${HUMIDITY}%"
            echo -e "    Wind Speed:     ${WIND} mph"
            echo -e "    Coordinates:    ${LAT}, ${LON}"
            echo ""
            echo -e "  ${BOLD}✅ Infrastructure Validation:${NC}"
            echo -e "    ✓ OAuth token validated by Apigee API Product"
            echo -e "    ✓ Proxy deployed and running in ${ORG}/${ENV}"
            echo -e "    ✓ Backend routing functional (Apigee → Open-Meteo API)"
            echo -e "    ✓ Live data retrieved (${LOCATION} weather)"
            echo ""
            ((success_count++))
        else
            echo -e "  ${RED}✗ Invalid API Response${NC}"
            echo -e "    Response: $API_RESPONSE"
            echo ""
            ((failure_count++))
        fi
    else
        echo -e "  ${RED}✗ API Call Failed${NC}"
        echo -e "    Response: $API_RESPONSE"
        echo ""
        ((failure_count++))
    fi
done

# Summary
echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BOLD}  Demo Complete!${NC}"
echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${BOLD}What This Demo Proved:${NC}"
echo ""
echo -e "  ${GREEN}✓ Multi-Org Deployment${NC}"
echo -e "    → Proxy deployed to 3 separate Apigee X organizations"
echo -e "    → Each org has independent OAuth backends and API products"
echo ""
echo -e "  ${GREEN}✓ OAuth Security${NC}"
echo -e "    → Token issuance working in all environments"
echo -e "    → API Product validation enforcing access control"
echo -e "    → Developer apps correctly provisioned and validated"
echo ""
echo -e "  ${GREEN}✓ GitOps Deployment${NC}"
echo -e "    → Proxies deployed via PR-based workflow"
echo -e "    → Environment-specific configurations (different cities)"
echo -e "    → Template-based rendering (oauth-proxy-jwt-backend)"
echo ""
echo -e "  ${GREEN}✓ Backend Integration${NC}"
echo -e "    → Live data from public weather API (api.open-meteo.com)"
echo -e "    → Each environment configured for different location"
echo -e "    → Proves routing and transformation working"
echo ""
echo -e "${BOLD}Results:${NC} ${GREEN}${success_count} Successful${NC} | ${RED}${failure_count} Failed${NC}"
echo ""

# Exit with appropriate code
if [ $failure_count -gt 0 ]; then
    exit 1
fi
