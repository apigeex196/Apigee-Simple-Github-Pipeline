#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Demo Script 4: Monitor Workflow Status

.DESCRIPTION
    Monitors GitHub Actions workflow runs and shows validation/deployment progress.
    Requires GitHub CLI (gh) to be installed and authenticated.

.EXAMPLE
    .\04-monitor-workflows.ps1
#>

[CmdletBinding()]
param()

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  API Producer Platform - Demo Part 4  " -ForegroundColor Cyan
Write-Host "  Monitor Workflow Execution           " -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Check if GitHub CLI is installed
Write-Host "🔍 Checking for GitHub CLI..." -ForegroundColor Yellow
$ghInstalled = Get-Command gh -ErrorAction SilentlyContinue
if (-not $ghInstalled) {
    Write-Host "⚠️  GitHub CLI (gh) not found" -ForegroundColor Yellow
    Write-Host "`nInstall GitHub CLI:" -ForegroundColor White
    Write-Host "   Windows: winget install GitHub.cli" -ForegroundColor Gray
    Write-Host "   Or download: https://cli.github.com/" -ForegroundColor Gray
    Write-Host "`n📖 Alternative: View workflows in browser" -ForegroundColor Cyan
    $repoUrl = "https://github.com/CenturyLink/enterprise-apigeex-applications/actions"
    Write-Host "   Opening: $repoUrl" -ForegroundColor Gray
    Start-Process $repoUrl
    exit 0
}
Write-Host "✓ GitHub CLI installed" -ForegroundColor Green

# Check authentication
Write-Host "`n🔐 Checking GitHub authentication..." -ForegroundColor Yellow
gh auth status 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "⚠️  Not authenticated with GitHub" -ForegroundColor Yellow
    Write-Host "Run: gh auth login" -ForegroundColor Gray
    Write-Host "`n📖 Alternative: View workflows in browser" -ForegroundColor Cyan
    $repoUrl = "https://github.com/CenturyLink/enterprise-apigeex-applications/actions"
    Start-Process $repoUrl
    exit 0
}
Write-Host "✓ Authenticated with GitHub" -ForegroundColor Green

# Set repository context
$repo = "CenturyLink/enterprise-apigeex-applications"

# Show recent workflow runs
Write-Host "`n📊 Recent Workflow Runs:" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Gray

# Validation workflows
Write-Host "`n🔍 Validate Proxy YAML (PR checks):" -ForegroundColor Yellow
gh run list --repo $repo --workflow="validate-proxy.yml" --limit 5 --json status,conclusion,headBranch,createdAt,displayTitle | 
    ConvertFrom-Json | 
    ForEach-Object {
        $icon = if ($_.conclusion -eq "success") { "✅" } 
                elseif ($_.conclusion -eq "failure") { "❌" } 
                elseif ($_.status -eq "in_progress") { "🔄" } 
                else { "⏳" }
        $color = if ($_.conclusion -eq "success") { "Green" } 
                 elseif ($_.conclusion -eq "failure") { "Red" } 
                 else { "Yellow" }
        Write-Host "   $icon $($_.createdAt.Substring(0,19)) - $($_.headBranch) - $($_.displayTitle)" -ForegroundColor $color
    }

# Deployment workflows
Write-Host "`n🚀 Deploy to Dev:" -ForegroundColor Yellow
gh run list --repo $repo --workflow="deploy-to-dev.yml" --limit 5 --json status,conclusion,headBranch,createdAt,displayTitle | 
    ConvertFrom-Json | 
    ForEach-Object {
        $icon = if ($_.conclusion -eq "success") { "✅" } 
                elseif ($_.conclusion -eq "failure") { "❌" } 
                elseif ($_.status -eq "in_progress") { "🔄" } 
                else { "⏳" }
        $color = if ($_.conclusion -eq "success") { "Green" } 
                 elseif ($_.conclusion -eq "failure") { "Red" } 
                 else { "Yellow" }
        Write-Host "   $icon $($_.createdAt.Substring(0,19)) - $($_.displayTitle)" -ForegroundColor $color
    }

Write-Host "`n🚀 Deploy to Test:" -ForegroundColor Yellow
gh run list --repo $repo --workflow="deploy-to-test.yml" --limit 3 --json status,conclusion,createdAt,displayTitle | 
    ConvertFrom-Json | 
    ForEach-Object {
        $icon = if ($_.conclusion -eq "success") { "✅" } 
                elseif ($_.conclusion -eq "failure") { "❌" } 
                elseif ($_.status -eq "in_progress") { "🔄" } 
                else { "⏳" }
        $color = if ($_.conclusion -eq "success") { "Green" } 
                 elseif ($_.conclusion -eq "failure") { "Red" } 
                 else { "Yellow" }
        Write-Host "   $icon $($_.createdAt.Substring(0,19)) - $($_.displayTitle)" -ForegroundColor $color
    }

Write-Host "`n🚀 Deploy to Prod:" -ForegroundColor Yellow
gh run list --repo $repo --workflow="deploy-to-prod.yml" --limit 3 --json status,conclusion,createdAt,displayTitle | 
    ConvertFrom-Json | 
    ForEach-Object {
        $icon = if ($_.conclusion -eq "success") { "✅" } 
                elseif ($_.conclusion -eq "failure") { "❌" } 
                elseif ($_.status -eq "in_progress") { "🔄" } 
                else { "⏳" }
        $color = if ($_.conclusion -eq "success") { "Green" } 
                 elseif ($_.conclusion -eq "failure") { "Red" } 
                 else { "Yellow" }
        Write-Host "   $icon $($_.createdAt.Substring(0,19)) - $($_.displayTitle)" -ForegroundColor $color
    }

# Check for in-progress runs
Write-Host "`n🔄 Currently Running Workflows:" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Gray

$runningWorkflows = gh run list --repo $repo --limit 20 --json status,workflowName,url,createdAt | 
    ConvertFrom-Json | 
    Where-Object { $_.status -eq "in_progress" -or $_.status -eq "queued" }

if ($runningWorkflows) {
    foreach ($run in $runningWorkflows) {
        Write-Host "   🔄 $($run.workflowName)" -ForegroundColor Yellow
        Write-Host "      Created: $($run.createdAt.Substring(0,19))" -ForegroundColor Gray
        Write-Host "      URL: $($run.url)" -ForegroundColor Gray
    }
    
    Write-Host "`n💡 To watch a workflow in real-time:" -ForegroundColor Cyan
    Write-Host "   gh run watch <run-id>" -ForegroundColor Gray
    Write-Host "   Or click the URL above" -ForegroundColor Gray
} else {
    Write-Host "   ℹ️  No workflows currently running" -ForegroundColor Gray
}

# Open GitHub Actions in browser
Write-Host "`n🌐 Opening GitHub Actions in browser..." -ForegroundColor Cyan
$actionsUrl = "https://github.com/$repo/actions"
Start-Process $actionsUrl

# Summary
Write-Host "`n📊 Workflow Status Summary:" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Gray

$recentRuns = gh run list --repo $repo --limit 10 --json conclusion | ConvertFrom-Json
$successCount = ($recentRuns | Where-Object { $_.conclusion -eq "success" }).Count
$failureCount = ($recentRuns | Where-Object { $_.conclusion -eq "failure" }).Count
$otherCount = ($recentRuns | Where-Object { $_.conclusion -ne "success" -and $_.conclusion -ne "failure" }).Count

Write-Host "   Last 10 runs:" -ForegroundColor White
Write-Host "     ✅ Success: $successCount" -ForegroundColor Green
Write-Host "     ❌ Failure: $failureCount" -ForegroundColor $(if ($failureCount -gt 0) { "Red" } else { "Gray" })
Write-Host "     ⏳ Other: $otherCount" -ForegroundColor Yellow

if ($successCount -gt 7) {
    Write-Host "`n   ✨ Platform health: EXCELLENT" -ForegroundColor Green
} elseif ($successCount -gt 5) {
    Write-Host "`n   ⚠️  Platform health: GOOD" -ForegroundColor Yellow
} else {
    Write-Host "`n   ⚠️  Platform health: Needs attention" -ForegroundColor Red
}

# Demo talking points
Write-Host "`n💡 Demo Talking Points:" -ForegroundColor Yellow
Write-Host "=" * 80 -ForegroundColor Gray
Write-Host "   • Green checkmarks = successful deployments" -ForegroundColor Gray
Write-Host "   • Validation runs on every PR (catches errors early)" -ForegroundColor Gray
Write-Host "   • Deployment runs on merge to main (fully automated)" -ForegroundColor Gray
Write-Host "   • Separate workflows for Dev/Test/Prod (environment isolation)" -ForegroundColor Gray
Write-Host "   • All runs logged and auditable (compliance)" -ForegroundColor Gray

# Next steps
Write-Host "`n📋 Next Steps:" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Gray
Write-Host "   1. Watch PR validation complete (2-3 minutes)" -ForegroundColor White
Write-Host "   2. Review validation checks (should see green checkmarks)" -ForegroundColor White
Write-Host "   3. Merge PR after validation passes" -ForegroundColor White
Write-Host "   4. Watch deployment workflow trigger automatically" -ForegroundColor White
Write-Host "   5. Verify deployment success (3-5 minutes)" -ForegroundColor White

Write-Host "`n🔗 Useful Commands:" -ForegroundColor Yellow
Write-Host "   gh run list --limit 10              # List recent runs" -ForegroundColor Gray
Write-Host "   gh run view <run-id>                # View run details" -ForegroundColor Gray
Write-Host "   gh run watch <run-id>               # Watch run in real-time" -ForegroundColor Gray
Write-Host "   gh pr list                          # List open pull requests" -ForegroundColor Gray
Write-Host "   gh pr view <pr-number>              # View PR details" -ForegroundColor Gray

Write-Host "`n✨ Check browser for live workflow status!" -ForegroundColor Cyan
Write-Host ""
