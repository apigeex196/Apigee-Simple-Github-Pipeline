---
marp: true
theme: default
paginate: true
backgroundColor: #FFFFFF
style: |
  /* Lumen Brand Colors Applied */
  section {
    font-size: 28px;
    color: #0F3133;
    background-color: #FFFFFF;
  }
  h1 {
    color: #36C6C6;
    font-size: 48px;
    font-weight: bold;
    border-bottom: 4px solid #FB8429;
    padding-bottom: 0.3em;
  }
  h2 {
    color: #0F3133;
    font-size: 38px;
    font-weight: bold;
  }
  h3 {
    color: #36C6C6;
    font-size: 32px;
  }
  strong {
    color: #0F3133;
    font-weight: bold;
  }
  code {
    background: #CED4D9;
    color: #0F3133;
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 24px;
  }
  pre {
    background: #FFFFFF;
    color: #0F3133;
    border: 2px solid #36C6C6;
    padding: 1em;
    font-size: 20px;
  }
  pre code {
    background: transparent;
    color: #0F3133;
  }
  blockquote {
    border-left: 4px solid #FB8429;
    padding-left: 1em;
    color: #0F3133;
  }
  a {
    color: #36C6C6;
  }
  .columns {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 1rem;
  }
  /* Checkmarks and bullets with accent colors */
  ul {
    color: #0F3133;
  }
  /* Page numbers with Lumen orange */
  section::after {
    color: #FB8429;
    font-weight: bold;
  }
  /* Highlight boxes */
  mark {
    background: #B2FFF6;
    color: #0F3133;
  }
---

# Apigee X GitOps Platform Demo

**Enterprise API Deployment Made Simple**

Built throughout 2025

---

## Today's Agenda

1. **The Problem We Solved** - Manual, complex Apigee deployments
2. **Our Solution** - GitOps-based automation platform
3. **API Producer Experience** - Simple YAML, powerful results
4. **The Automation Magic** - What happens behind the scenes
5. **Live Demo** - Multi-org deployment in action
6. **Benefits** - Why this matters

---

# Part 1: The Problem We Solved

---

## The Challenge

Before this platform existed:

- 🔴 **Manual deployments** - Error-prone, time-consuming
- 🔴 **Deep Apigee expertise required** - Steep learning curve
- 🔴 **Multiple organizations** - Dev, Test, Prod management
- 🔴 **Complex configurations** - OAuth, JWT, KVMs, policies
- 🔴 **No consistency** - Each team doing it differently
- 🔴 **Slow iteration** - Days to weeks for changes

**API producers shouldn't need to be Apigee experts**

---

# Part 2: Our Solution

---

## The Platform: 4 Interconnected Repositories

**1. TEMPLATES REPO**
- Reusable proxy templates

**2. BUNDLES REPO**
- Utility proxies & shared flows

**3. GITOPS REPO** *(team infrastructure)*
- Deploy utility components

**4. APPLICATIONS REPO** ← **API Producers work here**
- Simple YAML + PR = Done

---

## Key Principle: Simplicity for Producers

**API producers only touch the Applications repo**

Everything else happens automatically

---

# Part 3: The API Producer Experience

---

## What an API Producer Sees

**🎬 SWITCH TO VS CODE: Show `mal-SYSGEN788836350/` folder structure**

Simple folder structure organized by environment:

```
mal-SYSGEN788836350/
├── orgs/
│   ├── gcp-prj-apigee-dev-np-01/
│   │   └── envs/apicc-dev/proxies/
│   │       └── SYSGEN788836350-demo-api-proxy/
│   │           └── proxy.yaml  ← Just 15 lines!
│   ├── gcp-prj-apigee-qa-np-01/
│   └── gcp-prj-apigee-prod-01/
└── template-mappings.json
```

---

## A Real Proxy Configuration

**🎬 SWITCH TO VS CODE: Open `proxy.yaml` file**

**Just 15 lines of YAML:**

```yaml
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-demo-api-proxy
  description: Demo proxy for GitOps workflow
spec:
  template: oauth-proxy-oauth-backend
  basePath: /Demo/v1/Apigee/Stats
  target:
    url: https://httpbin.org/json
```

**That's it. No XML, no complex policies, no Apigee expertise required.**

---

## What the Template Provides

Template `oauth-proxy-oauth-backend` includes:

✅ OAuth validation policies
✅ Error handling
✅ CORS configuration
✅ Rate limiting
✅ Security headers
✅ Logging and monitoring
✅ Backend routing

**API producer benefits from battle-tested, reusable logic**

---

# Part 4: The Automation Magic

---

## Step 1: Create a Pull Request

**🎬 SWITCH TO BROWSER: Show PR #45 with validation checks**

API producer pushes changes and creates a PR

**Immediate automated validation:**

✅ Validate Proxy Configuration
✅ CodeQL Security Analysis
✅ MAL Structure Validation
✅ SOX Compliance Controls
✅ Template Reference Validation

**Instant feedback - no waiting for manual reviews**

---

## Step 2: PR Merge Triggers Deployment

When PR is approved and merged:

1. **Template Rendering** - Pull referenced template from templates repo
2. **Variable Substitution** - Merge template with API producer's config
3. **Direct Deployment** - Deploy to target Apigee X org/env

```
Generic Template + Specific Config = Ready-to-Deploy Proxy
```

**Fast, simple, traceable through Git**

---

## The Repository Ecosystem

<div class="columns">
<div>

**Templates Repo**
**🎬 VS CODE: Show templates repo**
- Reusable patterns
- OAuth/JWT templates
- Shared by all teams
- API producers just reference them

**Bundles Repo**
**🎬 VS CODE: Show bundles repo**
- Utility proxies
- OAuth backends
- Shared flows
- Platform infrastructure

</div>
<div>

**GitOps Repo**
- Team infrastructure
- Utility component deployment
- NOT for API producers

**Applications Repo**
- Where API producers work
- Simple YAML files
- PR-based workflow
- Self-service deployment

</div>
</div>

---

# Part 5: Live Demo

---

## The Demo Setup

Multi-org proxy deployed to 3 environments:

- **Dev** (Salem, MA) - `gcp-prj-apigee-dev-np-01`
- **Test** (Omaha, NE) - `gcp-prj-apigee-qa-np-01`
- **Prod** (Seattle, WA) - `gcp-prj-apigee-prod-01`

Each environment:
- Independent OAuth backend
- Unique API credentials
- Different configuration
- Live weather API calls

---

## What We'll Prove

✅ **Multi-org deployment works** - 3 independent Apigee X organizations
✅ **OAuth security works** - Every call authenticated
✅ **Template system works** - One template, multiple instances
✅ **GitOps works** - All deployed through PR workflows
✅ **Environment-specific config** - Each env has unique behavior

**Same YAML files, deployed everywhere, managed through Git**

---

## Live Demo Time! 🎉

**🎬 SWITCH TO TERMINAL: Run `./demo-proxy-enhanced.sh`**

**🎬 SWITCH TO TERMINAL: Run the demo script**

```bash
./demo-proxy-enhanced.sh
```

**Watch as we:**
1. Acquire OAuth tokens from each environment
2. Call the protected proxy with authentication
3. Retrieve live weather data for 3 different cities
4. Prove the entire platform works end-to-end

---

# Part 6: The Benefits

---

## For API Producers

✅ **No Apigee expertise required** - Simple YAML files
✅ **Familiar Git workflow** - Branch, PR, merge
✅ **Fast feedback** - Validation in seconds
✅ **Self-service** - No manual deployment requests
✅ **Confidence** - Automated testing and validation

---

## For the Platform Team

✅ **Consistent deployments** - Standardized patterns
✅ **Reusable templates** - Reduce duplication
✅ **Full audit trail** - Everything in Git
✅ **Easy rollbacks** - Git revert
✅ **Scalable** - Hundreds of APIs, same workflow

---

## For Leadership

✅ **Faster time to market** - Days → Hours
✅ **Reduced operational risk** - Automated validation
✅ **Better compliance** - Full auditability
✅ **Lower cost per deployment** - Self-service automation
✅ **Platform scales** - Growth without linear cost increase

---

# What's Next

---

## Future Enhancements

Continuing to expand the platform:

- 🚀 **More templates** - Common patterns as we discover them
- 🚀 **OAS validation** - Enforce OpenAPI standards
- 🚀 **Automated testing** - Bruno test integration in CI/CD
- 🚀 **KVM management** - Secure key/value storage automation
- 🚀 **More environments** - External zones, partner APIs
- 🚀 **Self-service onboarding** - Documentation and training

---

# Questions?

---

## Common Questions

**Q: What if something custom is needed?**
A: Work with us to add it to a template, or create custom bundle

**Q: How are secrets handled?**
A: Apigee KVMs (encrypted), never in YAML files

**Q: What about rollbacks?**
A: Git-based - revert the PR or change version reference

**Q: How do we prevent naming conflicts?**
A: Unique MAL IDs, validated at PR time

---

# Summary

---

## What We've Built

A **production-ready, enterprise-grade API deployment platform** that:

1. Makes Apigee X accessible to all developers
2. Automates validation, rendering, and deployment
3. Provides reusable templates for common patterns
4. Scales to hundreds or thousands of APIs
5. Maintains full auditability and compliance

**Built throughout 2025, in production today**

---

## The Bottom Line

> "We've transformed Apigee X deployment from a manual, expert-driven process into a simple, automated, Git-based workflow that any API producer can use."

**The platform is live, it's working, and it's ready to scale with the business.**

---

# Thank You!

**Questions? Let's discuss.**

---

# Appendix: Screenshots

---

## PR Validation in Action

![width:950px height:500px](/Users/rschilm/Downloads/Gitops_Demo/screenshots/pr-validation-1.png)

---

## PR Validation Details

![width:950px height:500px](/Users/rschilm/Downloads/Gitops_Demo/screenshots/pr-validation-2.png)

---

## Live Demo: Dev Environment

![width:950px height:500px](/Users/rschilm/Downloads/Gitops_Demo/screenshots/demo-terminal-output-1.png)

---

## Live Demo: Test Environment

![width:950px height:500px](/Users/rschilm/Downloads/Gitops_Demo/screenshots/demo-terminal-output-2.png)

---

## Live Demo: Prod Environment

![width:950px height:500px](/Users/rschilm/Downloads/Gitops_Demo/screenshots/demo-terminal-output-3.png)

---

## Demo Results Summary

![width:950px height:500px](/Users/rschilm/Downloads/Gitops_Demo/screenshots/demo-terminal-output-4.png)

---

## Production Deployment

![width:950px height:500px](/Users/rschilm/Downloads/Gitops_Demo/screenshots/gcp-apigeex-prod-deploy.png)

---
