#!/usr/bin/env zsh
set -euo pipefail

# Provision temporary Apigee X credentials (product + developer + app) per environment
# Requires: gcloud (for access token), apigeecli, jq
# Usage:
#   chmod +x scripts/provision-apigee-creds.sh
#   scripts/provision-apigee-creds.sh demo.user@example.com
# Outputs a JSON summary of client_id/client_secret per environment.

DEV_EMAIL=${1:-demo.user@example.com}
PRODUCT_NAME="SYSGEN788836350-apigee-stats-product"
PRODUCT_DISPLAY="Apigee Stats Product"
# Use proxy binding for demo simplicity
STATS_PROXY_NAME="SYSGEN788836350-apigee-stats-dashboard"

# org → env mapping
# By default, provision only DEV to ensure proxy exists.
# Set ALL_ENVS=1 to include QA/PROD.
typeset -A ORG_ENV_MAP
if [[ "${ALL_ENVS:-}" = "1" ]]; then
  ORG_ENV_MAP=(
    gcp-prj-apigee-dev-np-01 apicc-dev
    gcp-prj-apigee-qa-np-01  apicc-test1
    gcp-prj-apigee-prod-01   apicc-prod
  )
else
  ORG_ENV_MAP=(
    gcp-prj-apigee-dev-np-01 apicc-dev
  )
fi

# Check dependencies
for cmd in gcloud apigeecli jq; do
  if ! command -v $cmd >/dev/null 2>&1; then
    echo "Error: $cmd is required." >&2
    exit 1
  fi
done

get_token() {
  gcloud auth print-access-token
}

create_product() {
  local org=$1 env=$2 token=$3
  # Create product if not exists
  apigeecli products get --name "$PRODUCT_NAME" --org "$org" --token "$token" >/dev/null 2>&1 || {
    # Try creating with proxy binding; if it fails (proxy missing), fall back to product without proxy
    if ! apigeecli products create \
      --name "$PRODUCT_NAME" \
      --display-name "$PRODUCT_DISPLAY" \
      --envs "$env" \
      --proxies "$STATS_PROXY_NAME" \
      --approval auto \
      --org "$org" --token "$token" >/dev/null 2>&1; then
      apigeecli products create \
        --name "$PRODUCT_NAME" \
        --display-name "$PRODUCT_DISPLAY" \
        --envs "$env" \
        --approval auto \
        --org "$org" --token "$token" >/dev/null
    fi
  }
}

create_developer() {
  local org=$1 email=$2 token=$3
  # Create developer if not exists
  apigeecli developers get --email "$email" --org "$org" --token "$token" >/dev/null 2>&1 || {
    apigeecli developers create \
      --email "$email" \
      --user "$email" \
      --first "Demo" --last "User" \
      --org "$org" --token "$token" >/dev/null
  }
}

create_app() {
  local org=$1 email=$2 env=$3 token=$4
  local appname="apigee-stats-dashboard-app-${env}"
  # Create app if not exists
  apigeecli apps get --name "$appname" --org "$org" --token "$token" >/dev/null 2>&1 || {
    apigeecli apps create \
      --email "$email" \
      --name "$appname" \
      --prods "$PRODUCT_NAME" \
      --org "$org" --token "$token" >/dev/null
  }
  # Output credentials
  apigeecli apps get --name "$appname" --org "$org" --token "$token" | jq '.[0] | {app: .name, key: .credentials[0].consumerKey, secret: .credentials[0].consumerSecret}'
}

typeset -a results
results=()
TOKEN=$(get_token)

for org env in ${(kv)ORG_ENV_MAP}; do
  echo "Provisioning for org=$org env=$env ..." >&2
  create_product "$org" "$env" "$TOKEN"
  create_developer "$org" "$DEV_EMAIL" "$TOKEN"
  cred_json=$(create_app "$org" "$DEV_EMAIL" "$env" "$TOKEN")
  combined=$(jq -n --arg org "$org" --arg env "$env" --argjson cred "$cred_json" '{org: $org, env: $env, app: $cred.app, client_id: $cred.key, client_secret: $cred.secret}')
  results+=("$combined")
done

# Print consolidated JSON array
printf '%s\n' "${results[@]}" | jq -s '.'