#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Simplified Safe Demo Script - API Producer Platform

.DESCRIPTION
    A simplified, safe demo script with no emojis and robust error handling.
    Shows existing deployments only - no modifications to repository.
    Safe to run at client site.

.EXAMPLE
    .\SIMPLE-DEMO.ps1
#>

[CmdletBinding()]
param()

# Configuration
$MAL = "SYSGEN788836350"
$malPath = "mal-$MAL"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  API PRODUCER PLATFORM - DEMONSTRATION" -ForegroundColor Cyan
Write-Host "  CenturyLink Apigee X GitOps Platform" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Validate repository location
Write-Host "Step 1: Validate Repository" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray

if (-not (Test-Path $malPath)) {
    Write-Host "ERROR: Cannot find $malPath folder" -ForegroundColor Red
    Write-Host "Current location: $(Get-Location)" -ForegroundColor Yellow
    Write-Host "Please run from repository root directory" -ForegroundColor Yellow
    exit 1
}

Write-Host "SUCCESS: Repository validated" -ForegroundColor Green
Write-Host "Location: $(Get-Location)" -ForegroundColor Gray
Write-Host ""

# Show environments configuration
Write-Host "Step 2: Platform Configuration" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray

$environments = @(
    @{Name = "DEV";  Org = "gcp-prj-apigee-dev-np-01";  Env = "apicc-dev";   Color = "Green"},
    @{Name = "QA";   Org = "gcp-prj-apigee-qa-np-01";   Env = "apicc-test1"; Color = "Yellow"},
    @{Name = "PROD"; Org = "gcp-prj-apigee-prod-01";    Env = "apicc-prod";  Color = "Red"}
)

Write-Host "Configured Environments:" -ForegroundColor White
foreach ($env in $environments) {
    Write-Host "  - $($env.Name): $($env.Org) / $($env.Env)" -ForegroundColor $env.Color
}
Write-Host ""

# Show deployed proxies by environment
Write-Host "Step 3: Deployed Proxies" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray

$totalProxies = 0
$allDeployments = @()

foreach ($env in $environments) {
    $proxyPath = "$malPath/orgs/$($env.Org)/envs/$($env.Env)/proxies"
    
    Write-Host ""
    Write-Host "$($env.Name) Environment:" -ForegroundColor $env.Color
    Write-Host "  Path: $proxyPath" -ForegroundColor Gray
    
    if (Test-Path $proxyPath) {
        $proxies = Get-ChildItem $proxyPath -Directory -ErrorAction SilentlyContinue
        
        if ($proxies -and $proxies.Count -gt 0) {
            Write-Host "  Proxies: $($proxies.Count) deployed" -ForegroundColor White
            
            foreach ($proxy in $proxies) {
                Write-Host "    > $($proxy.Name)" -ForegroundColor $env.Color
                
                $yamlFile = Join-Path $proxyPath "$($proxy.Name)/proxy.yaml"
                if (Test-Path $yamlFile) {
                    try {
                        $content = Get-Content $yamlFile -Raw -ErrorAction Stop
                        
                        if ($content -match 'name:\s*([^\r\n]+)') {
                            $proxyName = $matches[1].Trim()
                            Write-Host "      Name: $proxyName" -ForegroundColor Gray
                        }
                        
                        if ($content -match 'path:\s*([^\r\n]+)') {
                            $apiPath = $matches[1].Trim()
                            Write-Host "      Path: $apiPath" -ForegroundColor Gray
                        }
                        
                        if ($content -match 'template:\s*([^\r\n]+)') {
                            $template = $matches[1].Trim()
                            Write-Host "      Template: $template" -ForegroundColor Gray
                        }
                        
                        $allDeployments += @{
                            Environment = $env.Name
                            ProxyFolder = $proxy.Name
                            ProxyName = $proxyName
                            Path = $apiPath
                        }
                        
                    } catch {
                        Write-Host "      Warning: Could not read YAML file" -ForegroundColor Yellow
                    }
                }
                
                $totalProxies++
            }
        } else {
            Write-Host "  No proxies found" -ForegroundColor Gray
        }
    } else {
        Write-Host "  Path does not exist" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray
Write-Host "Total Deployments: $totalProxies" -ForegroundColor White
Write-Host ""

# Show API Products
Write-Host "Step 4: API Products" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray

$totalProducts = 0

foreach ($env in $environments) {
    $productPath = "$malPath/orgs/$($env.Org)/products"
    
    if (Test-Path $productPath) {
        $products = Get-ChildItem $productPath -Filter "*.yaml" -ErrorAction SilentlyContinue
        
        if ($products -and $products.Count -gt 0) {
            Write-Host ""
            Write-Host "$($env.Name) - $($products.Count) product(s):" -ForegroundColor $env.Color
            
            foreach ($product in $products) {
                Write-Host "  > $($product.BaseName)" -ForegroundColor $env.Color
                $totalProducts++
                
                try {
                    $content = Get-Content $product.FullName -Raw -ErrorAction Stop
                    if ($content -match 'description:\s*"([^"]+)"') {
                        Write-Host "    Description: $($matches[1])" -ForegroundColor Gray
                    }
                } catch {
                    Write-Host "    Warning: Could not read product file" -ForegroundColor Yellow
                }
            }
        }
    }
}

Write-Host ""
Write-Host "Total Products: $totalProducts" -ForegroundColor White
Write-Host ""

# Show sample proxy YAML
Write-Host "Step 5: Sample Proxy Configuration" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray

if ($allDeployments.Count -gt 0) {
    $sample = $allDeployments | Select-Object -First 1
    Write-Host ""
    Write-Host "Example: $($sample.ProxyName)" -ForegroundColor White
    Write-Host ""
    
    $samplePath = "$malPath/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/$($sample.ProxyFolder)/proxy.yaml"
    if (Test-Path $samplePath) {
        Write-Host "File: $samplePath" -ForegroundColor Gray
        Write-Host ""
        
        $lines = Get-Content $samplePath
        $lineNum = 1
        foreach ($line in $lines | Select-Object -First 25) {
            $lineStr = ("{0,3}: {1}" -f $lineNum, $line)
            if ($line -match '^\s*(name|path|template|target):') {
                Write-Host $lineStr -ForegroundColor Green
            } elseif ($line -match '^(apiVersion|kind|metadata|spec):') {
                Write-Host $lineStr -ForegroundColor Cyan
            } else {
                Write-Host $lineStr -ForegroundColor Gray
            }
            $lineNum++
        }
        
        if ($lines.Count -gt 25) {
            Write-Host "  ... ($($lines.Count - 25) more lines)" -ForegroundColor Gray
        }
    }
}

Write-Host ""

# Summary
Write-Host "Step 6: Platform Summary" -ForegroundColor Yellow
Write-Host "-----------------------------------------------------------" -ForegroundColor Gray
Write-Host ""
Write-Host "PLATFORM STATUS:" -ForegroundColor White
Write-Host "  Environments:       3 (Dev, QA, Prod)" -ForegroundColor Gray
Write-Host "  Total Proxies:      $totalProxies" -ForegroundColor Gray
Write-Host "  Total Products:     $totalProducts" -ForegroundColor Gray
Write-Host "  Status:             OPERATIONAL" -ForegroundColor Green
Write-Host ""

# Key benefits
Write-Host "KEY PLATFORM BENEFITS:" -ForegroundColor White
Write-Host "  [1] Simple YAML Configuration" -ForegroundColor Gray
Write-Host "      - 15-20 lines to deploy an API" -ForegroundColor DarkGray
Write-Host "      - No XML, no complex Apigee policies" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  [2] Template-Based Deployment" -ForegroundColor Gray
Write-Host "      - OAuth, JWT, backend routing automated" -ForegroundColor DarkGray
Write-Host "      - Security patterns pre-configured" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  [3] GitOps Workflow" -ForegroundColor Gray
Write-Host "      - Push to GitHub triggers deployment" -ForegroundColor DarkGray
Write-Host "      - Automated validation on Pull Requests" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  [4] Multi-Environment Support" -ForegroundColor Gray
Write-Host "      - Same YAML works across Dev/QA/Prod" -ForegroundColor DarkGray
Write-Host "      - Copy file to deploy to next environment" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  [5] Team Isolation" -ForegroundColor Gray
Write-Host "      - MAL-based folders prevent conflicts" -ForegroundColor DarkGray
Write-Host "      - CODEOWNERS ensures proper reviews" -ForegroundColor DarkGray
Write-Host ""

# GitHub Actions info
Write-Host "GitHub Actions Workflows:" -ForegroundColor White
Write-Host "  - validate-proxy.yml    (Runs on Pull Requests)" -ForegroundColor Gray
Write-Host "  - deploy-to-dev.yml     (Runs on merge to main)" -ForegroundColor Gray
Write-Host "  - deploy-to-test.yml    (Runs on merge to main)" -ForegroundColor Gray
Write-Host "  - deploy-to-prod.yml    (Runs on merge to main)" -ForegroundColor Gray
Write-Host "  - validate-product.yml  (Validates API Products)" -ForegroundColor Gray
Write-Host "  - deploy-products.yml   (Deploys API Products)" -ForegroundColor Gray
Write-Host ""

# Interactive Demo Option
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  INTERACTIVE DEMO OPTION" -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Would you like to create a NEW proxy live?" -ForegroundColor Yellow
Write-Host ""
Write-Host "This will:" -ForegroundColor White
Write-Host "  1. Create proxy YAML in mal-SYSGEN788836350/.../proxies/" -ForegroundColor Gray
Write-Host "  2. Commit and push to feature branch" -ForegroundColor Gray
Write-Host "  3. Guide you to open Pull Request" -ForegroundColor Gray
Write-Host "  4. Open GitHub Actions to watch validation" -ForegroundColor Gray
Write-Host "  5. Complete end-to-end demo workflow" -ForegroundColor Gray
Write-Host ""
Write-Host "NOTE: This will create REAL changes in your repository." -ForegroundColor Yellow
Write-Host ""

$runInteractive = Read-Host "Run interactive proxy creation demo? (y/N)"
if ($runInteractive -eq 'y' -or $runInteractive -eq 'Y') {
    Write-Host ""
    Write-Host "Launching interactive demo..." -ForegroundColor Cyan
    Write-Host ""
    
    $interactiveScript = Join-Path $PSScriptRoot "CREATE-NEW-PROXY-DEMO.ps1"
    if (Test-Path $interactiveScript) {
        & $interactiveScript
    } else {
        Write-Host "ERROR: Interactive script not found" -ForegroundColor Red
        Write-Host "Expected: $interactiveScript" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Manual steps to deploy a new API:" -ForegroundColor White
        Write-Host "  1. Create proxy YAML in mal-SYSGEN788836350/.../proxies/" -ForegroundColor Gray
        Write-Host "  2. Commit and push to feature branch" -ForegroundColor Gray
        Write-Host "  3. Open Pull Request" -ForegroundColor Gray
        Write-Host "  4. Watch automated validation run" -ForegroundColor Gray
        Write-Host "  5. Merge PR after validation passes" -ForegroundColor Gray
        Write-Host "  6. Watch automated deployment to Apigee X" -ForegroundColor Gray
        Write-Host "  7. API is live in minutes" -ForegroundColor Gray
    }
} else {
    Write-Host "Skipped interactive demo." -ForegroundColor Gray
    Write-Host ""
    Write-Host "To deploy a new API manually:" -ForegroundColor White
    Write-Host "  1. Create proxy YAML in mal-SYSGEN788836350/.../proxies/" -ForegroundColor Gray
    Write-Host "  2. Commit and push to feature branch" -ForegroundColor Gray
    Write-Host "  3. Open Pull Request" -ForegroundColor Gray
    Write-Host "  4. Watch automated validation run" -ForegroundColor Gray
    Write-Host "  5. Merge PR after validation passes" -ForegroundColor Gray
    Write-Host "  6. Watch automated deployment to Apigee X" -ForegroundColor Gray
    Write-Host "  7. API is live in minutes" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Or run the interactive script manually:" -ForegroundColor White
    Write-Host "  .\docs\demo\CREATE-NEW-PROXY-DEMO.ps1" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  DEMO COMPLETE - Platform is Production Ready" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "For more information:" -ForegroundColor Gray
Write-Host "  - API Producer Guide:     docs/api-producer-core.md" -ForegroundColor DarkGray
Write-Host "  - Production Evidence:    docs/PRODUCTION-READINESS-EVIDENCE.md" -ForegroundColor DarkGray
Write-Host "  - Live Demo Guide:        docs/API-PRODUCER-LIVE-DEMO.md" -ForegroundColor DarkGray
Write-Host "  - GitHub Actions:         https://github.com/CenturyLink/enterprise-apigeex-applications/actions" -ForegroundColor DarkGray
Write-Host ""
