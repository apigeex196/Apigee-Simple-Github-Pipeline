# Apigee X GitOps Platform Demo Script

## Demo Overview

**Objective**: Showcase the enterprise API platform the team has built throughout 2025, demonstrating how API producers can easily deploy to Apigee X using GitOps workflows.

**Audience**: Leadership, API producers, platform stakeholders

**Duration**: 15-20 minutes

**Key Message**: "We've built an enterprise platform that makes deploying to Apigee X as simple as creating a PR. All the complexity is automated."

---

## Part 1: The Problem We Solved (2 minutes)

### Opening Statement
*"Let me show you what we've built throughout 2025. Before this platform, deploying to Apigee X was manual, error-prone, and required deep Apigee expertise. We've transformed that into a simple, automated GitOps workflow that any API producer can use."*

### The Challenge
- Multiple Apigee X organizations (Dev, Test, Prod)
- Complex proxy configurations with OAuth, JWT, KVMs
- Need for consistency across environments
- API producers shouldn't need to be Apigee experts

### Our Solution: 4 Interconnected Repositories

**Show the repository landscape:**

```
┌─────────────────────────────────────────────────────────┐
│                    THE PLATFORM                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  1. TEMPLATES REPO                                      │
│     └─ Reusable proxy templates                        │
│        • oauth-proxy-jwt-backend                       │
│        • oauth-proxy-oauth-backend                     │
│        Built once, used everywhere                     │
│                                                         │
│  2. BUNDLES REPO                                        │
│     └─ Utility proxies & shared flows                 │
│        • OAuth backends, JWT services                  │
│        • Manually developed, reused by apps           │
│        • Independently versioned                       │
│                                                         │
│  3. GITOPS REPO (team infrastructure - not part of    │
│     this workflow)                                     │
│     └─ Similar repo our team uses for deploying       │
│        utility proxies, shared flows, and bundles     │
│                                                         │
│  4. APPLICATIONS REPO ← API Producers work here        │
│     └─ Simple MAL-based folder structure              │
│        • Drop in YAML + OAS                           │
│        • Create PR                                     │
│        • Platform does the rest                        │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

*"Most importantly, API producers only touch the Applications repo. Everything else happens automatically."*

---

## Part 2: The API Producer Experience (5 minutes)

### Show the Simplicity

**Navigate to Applications Repo**

```bash
cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications
```

*"Let me show you what an API producer sees. This is the applications repository."*

### Show the Structure

```bash
# Show the MAL folder structure
tree -L 3 mal-SYSGEN788836350/
```

**Explain what you're seeing:**

```
mal-SYSGEN788836350/
├── orgs/
│   ├── gcp-prj-apigee-dev-np-01/
│   │   └── envs/
│   │       └── apicc-dev/
│   │           └── proxies/
│   │               └── SYSGEN788836350-demo-api-proxy/
│   │                   └── proxy.yaml        ← Simple YAML config (15 lines)
│   ├── gcp-prj-apigee-qa-np-01/
│   └── gcp-prj-apigee-prod-01/
└── template-mappings.json                     ← Which template to use
```

*"Notice the organization: one MAL folder per application, organized by org and environment. An API producer creates this structure, drops in their YAML files, and creates a PR. That's it."*

### Show an Actual Proxy Configuration

```bash
# Show the proxy YAML - just 15 lines!
cat mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/SYSGEN788836350-demo-api-proxy/proxy.yaml
```

**Highlight key aspects:**

*"Look at how simple this is - just 15 lines of YAML:*
- *Basic metadata (name, description)*
- *Template reference: `oauth-proxy-oauth-backend`*
- *Routing config: path, target (httpbin.org for demo)*
- *That's ALL the API producer needs to provide. No complex policies, no XML, no Apigee expertise required."*

### Show the Template Mapping

```bash
# Show how templates are mapped
cat template-mappings.json | jq '.template_mappings'
```

*"The template-mappings.json shows which templates are available. When a proxy references `oauth-proxy-oauth-backend`, the platform knows exactly which template bundle to use. The template provides all the OAuth validation, CORS handling, error handling - everything an API producer would normally have to build themselves."*

---

## Part 3: The Automation Magic (6 minutes)

### What Happens Behind the Scenes

*"Now let me show you what happens when that API producer creates a PR. This is where our platform work really shines."*

### Step 1: PR Creation & Validation

**Show the actual PR**

*"Let me show you a real example. We have PR #45 open right now:"*

```bash
# Open the PR in browser
gh pr view 45 --web
```

*"Look at what happened automatically when this PR was created:*

1. ✅ **Validate Proxy Configuration** - 53 seconds
   - YAML syntax validation
   - Schema compliance check
   - Naming convention verification
   - Template reference validation
   - KVM configuration check

2. ✅ **CodeQL Analysis** - Security scanning
3. ✅ **MAL Structure Validation** - Folder structure check
4. ✅ **Changed Files Detection** - What was modified
5. ✅ **SOX Controls** - Compliance checks

*All green checkmarks. The API producer gets immediate feedback - no waiting for manual reviews."*

### Step 2: PR Merge & Deployment

*"When the PR is approved and merged, the automation kicks in:"*

**What Happens Automatically:**

1. **Template Rendering**: The system pulls the referenced template (e.g., `oauth-proxy-oauth-backend`) which contains all the proxy logic - OAuth validation policies, error handling, CORS, etc.

2. **Variable Substitution**: The platform merges the template with the API producer's simple configuration from their YAML file (target URL, backend endpoints, etc.)

3. **Direct Deployment**: The rendered proxy deploys directly to the target Apigee X organization and environment

*"Generic template + specific config = ready-to-deploy proxy. Fast, simple, traceable through Git."*

---

## Part 4: The Repository Ecosystem (3 minutes)

### Show How They Work Together

*"Let me quickly show you the actual repositories and how they interconnect."*

#### Templates Repo
```bash
cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-templates
ls -la bundles/
```

*"This is our template library. Each template is a fully-functional proxy pattern that teams can reuse. We currently have:*
- *OAuth proxy with JWT backend (what we're demoing)*
- *OAuth proxy with OAuth backend*
- *More being added as we discover common patterns*

*API producers never touch this repo - they just reference template versions in their YAML."*

#### Bundles Repo
```bash
cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-bundles
ls -la proxies/ | head -15
```

*"This is where our utility proxies and shared flows live - things like OAuth backends, JWT services, shared security flows. Notice the naming convention - every component starts with SYSGEN followed by a number. When changes are merged here:*
- *apigeelint validates the code*
- *Version tags are automatically created*
- *These get deployed independently and are referenced by application proxies*

*API producers don't work in this repo - this is for platform infrastructure components."*

#### GitOps Repo (For Context Only)

*"I want to briefly mention the GitOps repo - but this is NOT part of the API Producer workflow. This is a separate repo our platform team uses to deploy utility components like:*
- *OAuth backends*
- *Shared flows*
- *Infrastructure proxies*

*It follows a similar GitOps pattern, but API producers never interact with it. I'm mentioning it because you might see it referenced, but for today's demo, the Applications repo is what matters for API producers."*

---

## Part 5: The Live Proof - The Grand Finale! 🎉 (3-4 minutes)

*"Now for the best part - let me show you this all actually works LIVE. We have a multi-org proxy deployed to all 3 environments - Dev, Test, and Production."*

**Pre-Demo Check (run before presenting):**
```bash
# Verify the demo script is ready
cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications
ls -la demo-proxy-enhanced.sh  # Should show executable permissions
```

### Run the Live Demo

```bash
# The moment of truth!
./demo-proxy-enhanced.sh
```

### While It Runs, Narrate

*"Watch what's happening in real-time:*

**Dev Environment (Salem, MA)**
- *OAuth token acquired from our OAuth backend proxy*
- *Token validated against the API product*
- *Proxy routes to weather API with location-specific parameters*
- *Returns live weather data for Salem*

**Test Environment (Omaha, NE)**
- *COMPLETELY different Apigee X organization*
- *Different OAuth backend (independent security)*
- *Different weather location*
- *Same proxy logic, different configuration - that's the power of GitOps*

**Prod Environment (Seattle, WA)**
- *Production Apigee X organization*
- *Production OAuth backend*
- *Production weather location*
- *Fully independent from dev/test - true environment isolation*

*"All three are running RIGHT NOW, all deployed from the same YAML files, all using the same template, all managed through Git. This proves:"*

1. **Multi-org deployment works** - 3 independent Apigee X organizations
2. **OAuth security works** - Every call authenticated and validated
3. **Template system works** - One template, multiple instances
4. **GitOps works** - All deployed through PR workflows
5. **Environment-specific config works** - Each env has unique behavior

*"And remember - the API producer just created YAML files and opened a PR. Everything else - the OAuth security, the JWT validation, the routing logic, the error handling - ALL automated by the platform."*
- *Fully independent from dev/test*

*"All three deployed from the same YAML files, all using the same template, all managed through Git."*

### Point Out Key Achievements

When demo completes successfully:

*"This proves several things:*

1. **Multi-org deployment works**: Same code, 3 independent Apigee X organizations
2. **OAuth security works**: Every call is authenticated and validated
3. **Template system works**: One template definition, multiple instances
4. **GitOps works**: All deployed through PR-based workflows
5. **Environment-specific config works**: Each environment has unique behavior

*And remember - the API producer just created YAML files and opened a PR. Everything else was automated."*

---

## Part 6: The Benefits & Future (2 minutes)

### What This Means for the Organization

**For API Producers:**
- ✅ No Apigee expertise required
- ✅ Familiar Git workflow (branch, PR, merge)
- ✅ Fast feedback (validation in seconds)
- ✅ Self-service deployment
- ✅ No manual deployment requests

**For the Platform Team:**
- ✅ Consistent, validated deployments
- ✅ Reusable templates reduce duplication
- ✅ Full audit trail in Git
- ✅ Easy rollbacks
- ✅ Scalable to hundreds of APIs

**For Leadership:**
- ✅ Faster time to market for APIs
- ✅ Reduced operational risk
- ✅ Better compliance and auditability
- ✅ Lower cost per API deployment
- ✅ Platform scales with business growth

### What's Next

*"This is just the beginning. We're expanding:*

- **More templates**: Common patterns as we discover them
- **OAS validation**: Enforce OpenAPI standards
- **Automated testing**: Bruno test integration in CI/CD
- **KVM management**: Secure key/value storage automation
- **More environments**: External zones, partner APIs
- **Self-service onboarding**: API producer documentation and training

*The platform is live, it's working, and we're continuing to improve it based on feedback."*

---

## Part 7: Q&A Preparation

### Common Questions & Answers

**Q: "What if an API producer needs something custom that's not in a template?"**

*A: "Great question. They have two options:*
1. *Work with us to add it to an existing template (everyone benefits)*
2. *Create a custom bundle in the bundles repo and reference it directly*

*Most common patterns end up in templates, but we're not limiting anyone."*

**Q: "How do we handle secrets like API keys?"**

*A: "We use Apigee KVMs (Key-Value Maps). The platform can provision encrypted KVMs automatically. Secrets never go in YAML files - they're referenced by name and managed securely in Apigee."*

**Q: "What about rollbacks if something breaks in production?"**

*A: "Two approaches:*
1. *Quick: Update the gitops YAML to reference the previous version - deploys in minutes*
2. *Proper: Revert the PR in applications repo, which automatically reverts everything*

*Both are Git-based, both are auditable, both are fast."*

**Q: "How do you handle environment-specific differences like different backend URLs?"**

*A: "That's in the proxy.yaml files. Each environment folder (dev, test, prod) has its own proxy.yaml with environment-specific config. The template merges those values at deploy time."*

**Q: "What if two teams try to deploy the same proxy name?"**

*A: "Our naming convention prevents that. Each MAL (application) has a unique ID. Proxy names are: MAL-ID + descriptive name. The validation workflow checks for conflicts at PR time."*

---

## Demo Day Checklist

### 30 Minutes Before
- [ ] Run validation: `./demo-proxy-enhanced.sh` (should show 3/3 successful)
- [ ] Have all 4 repos open in browser tabs
- [ ] Have GitHub Actions page open for applications repo
- [ ] Have Apigee X console open (to show deployed proxies)
- [ ] Review talking points

### If Demo Fails
- [ ] Stay calm - you have the infrastructure to show even if live demo fails
- [ ] Show GitHub Actions logs (proves automation works)
- [ ] Show deployed proxies in Apigee console (proves deployment works)
- [ ] Run recovery: `./provision-multi-org-demo-credentials.sh`

### Key Files to Have Ready
- `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications/mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/SYSGEN788836350-multi-org-applications-repo-demo/proxy.yaml`
- `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications/template-mappings.json`
- `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications/.github/workflows/deploy-to-dev.yml`
- `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-templates/bundles/SYSGEN788836350-OAuth_Proxy_JWT_Backend_Template/`
- `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-bundles/proxies/SYSGEN788836350-multi-org-applications-repo-demo/`
- `/Users/rschilm/RyanDev/GitHub/enterprise-apigeex-gitops/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/apigeeproxies/`

---

## Closing Statement

*"What you've seen today is the result of a year of focused platform engineering throughout 2025. We've taken a complex, manual process and turned it into a simple, automated, Git-based workflow. API producers can now deploy to Apigee X as easily as they deploy code to any other system - with the same familiar PR workflow.*

*The platform is production-ready, it's extensible, and most importantly, it's being used today. This is just one example - we have multiple teams already using this system to deploy their APIs.*

*We've built the foundation for scaling our API program to hundreds or thousands of APIs, all managed consistently, all deployed reliably, all traceable through Git.*

*Questions?"*

---

**Last Updated**: 2025-12-12
**Demo Status**: ✅ Ready
**Target Audience**: Leadership, API Producers, Platform Stakeholders
