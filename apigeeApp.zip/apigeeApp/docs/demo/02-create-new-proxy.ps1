#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Demo Script 2: Create a New Proxy (Live Demo)

.DESCRIPTION
    Creates a new proxy YAML file in the Dev environment to demonstrate the API producer workflow.
    This simulates what an API producer would do to deploy a new API.

.PARAMETER ProxyName
    Optional custom proxy name (will be prefixed with SYSGEN788836350-)

.EXAMPLE
    .\02-create-new-proxy.ps1
    .\02-create-new-proxy.ps1 -ProxyName "my-custom-api"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$ProxyName
)

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  API Producer Platform - Demo Part 2  " -ForegroundColor Cyan
Write-Host "  Create New Proxy (Live)              " -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Configuration
$MAL = "SYSGEN788836350"
$org = "gcp-prj-apigee-dev-np-01"
$env = "apicc-dev"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"

# Generate proxy name
if (-not $ProxyName) {
    $ProxyName = "DEMO-LIVE-$timestamp"
}

$fullProxyName = "$MAL-$ProxyName"
$proxyFolder = $ProxyName
$proxyPath = "mal-$MAL/orgs/$org/envs/$env/proxies/$proxyFolder"

Write-Host "📋 Demo Configuration:" -ForegroundColor Yellow
Write-Host "=" * 60 -ForegroundColor Gray
Write-Host "   MAL Code: $MAL" -ForegroundColor White
Write-Host "   Proxy Name: $fullProxyName" -ForegroundColor White
Write-Host "   Folder: $proxyFolder" -ForegroundColor White
Write-Host "   Org: $org" -ForegroundColor White
Write-Host "   Environment: $env" -ForegroundColor White
Write-Host "   Timestamp: $timestamp" -ForegroundColor White

# Check if already exists
if (Test-Path $proxyPath) {
    Write-Host "`n⚠️  WARNING: Proxy folder already exists at $proxyPath" -ForegroundColor Yellow
    $response = Read-Host "Do you want to overwrite? (y/N)"
    if ($response -ne 'y' -and $response -ne 'Y') {
        Write-Host "❌ Aborted. Try a different proxy name." -ForegroundColor Red
        exit 1
    }
    Remove-Item -Recurse -Force $proxyPath
}

# Create folder structure
Write-Host "`n📁 Creating folder structure..." -ForegroundColor Yellow
New-Item -ItemType Directory -Force -Path $proxyPath | Out-Null
Write-Host "   ✓ Created: $proxyPath" -ForegroundColor Green

# Create proxy YAML
Write-Host "`n📝 Creating proxy.yaml..." -ForegroundColor Yellow

$yamlContent = @"
---
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: $fullProxyName
  description: "Live demo proxy created on $(Get-Date -Format 'MMMM dd, yyyy \at HH:mm:ss')"
  labels:
    sysgen: $MAL
    taxonomy: /Demo/v1/Live
spec:
  template: oauth-proxy-oauth-backend
  routing:
    path: /sysgen788836350/demo-live/v1
    target: https://httpbin.org
    rewritePath: /anything
    timeout: 30
  oauth:
    enabled: true
    verifyApiKey: true
"@

$yamlFile = "$proxyPath/proxy.yaml"
Set-Content -Path $yamlFile -Value $yamlContent
Write-Host "   ✓ Created: $yamlFile" -ForegroundColor Green

# Display the YAML
Write-Host "`n📄 Proxy YAML Contents:" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Gray
Get-Content $yamlFile | ForEach-Object {
    if ($_ -match '^(apiVersion|kind|metadata|spec):') {
        Write-Host $_ -ForegroundColor Yellow
    } elseif ($_ -match '^\s+(name|description|template|path|target):') {
        Write-Host $_ -ForegroundColor Green
    } else {
        Write-Host $_ -ForegroundColor Gray
    }
}
Write-Host "=" * 60 -ForegroundColor Gray

# Show what was created
Write-Host "`n✅ Proxy Created Successfully!" -ForegroundColor Green
Write-Host "`n📊 Summary:" -ForegroundColor Cyan
Write-Host "   Lines of YAML: $((Get-Content $yamlFile).Count)" -ForegroundColor White
Write-Host "   File size: $((Get-Item $yamlFile).Length) bytes" -ForegroundColor White
Write-Host "   Template: oauth-proxy-oauth-backend" -ForegroundColor White
Write-Host "   Backend: https://httpbin.org (echo service)" -ForegroundColor White
Write-Host "   API Path: /sysgen788836350/demo-live/v1" -ForegroundColor White

# Git status
Write-Host "`n🔍 Git Status:" -ForegroundColor Yellow
git status --short mal-$MAL/

# Next steps
Write-Host "`n📋 Next Steps:" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Gray
Write-Host "   1. Review the proxy.yaml file (shown above)" -ForegroundColor White
Write-Host "   2. Stage and commit the changes" -ForegroundColor White
Write-Host "   3. Push to create a branch" -ForegroundColor White
Write-Host "   4. Open a Pull Request" -ForegroundColor White
Write-Host "   5. Watch automated validation" -ForegroundColor White
Write-Host "   6. Merge and watch deployment" -ForegroundColor White

Write-Host "`n💡 Talking Points for Demo:" -ForegroundColor Yellow
Write-Host "   • Just 20 lines of simple YAML" -ForegroundColor Gray
Write-Host "   • No XML, no policies, no Apigee expertise required" -ForegroundColor Gray
Write-Host "   • Template handles OAuth, backend connectivity" -ForegroundColor Gray
Write-Host "   • Self-documenting with metadata & labels" -ForegroundColor Gray

Write-Host "`n✨ Ready to commit!" -ForegroundColor Cyan
Write-Host "`nNext: Run .\03-commit-and-push.ps1`n" -ForegroundColor Yellow

# Store proxy info for next script
$env:DEMO_PROXY_NAME = $fullProxyName
$env:DEMO_PROXY_PATH = $proxyPath
$env:DEMO_PROXY_FOLDER = $proxyFolder
