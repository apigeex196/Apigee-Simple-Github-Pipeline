# API Producer Platform - PowerShell Demo Scripts

**Location**: `docs/demo/`  
**Purpose**: Interactive PowerShell scripts for demonstrating the API Producer platform end-to-end  
**Created**: February 13, 2026

---

## 🚀 Quick Start

### Run the Master Demo Script

```powershell
cd docs/demo
.\RUN-DEMO.ps1
```

This launches an interactive menu where you can run individual demo steps or the complete demo flow.

---

## 📋 Demo Scripts Overview

| Script | Purpose | Duration | Creates Real Changes? |
|--------|---------|----------|----------------------|
| **RUN-DEMO.ps1** | Master menu-driven demo launcher | N/A | Depends on selection |
| **01-show-existing-deployments.ps1** | Show deployed proxies & products | 2 min | ❌ No (read-only) |
| **02-create-new-proxy.ps1** | Create new proxy YAML file | 1 min | ⚠️ Yes (local file) |
| **03-commit-and-push.ps1** | Commit & push to GitHub | 2 min | ✅ Yes (creates branch) |
| **04-monitor-workflows.ps1** | Monitor GitHub Actions status | 2 min | ❌ No (read-only) |
| **05-verify-deployment.ps1** | Verify deployed proxy | 2 min | ❌ No (read-only) |

---

## 🎯 Demo Flow Options

### Option 1: Safe Demo (Read-Only)

Perfect for practice or showing existing deployments:

```powershell
# Only run script 1 (no changes made)
.\01-show-existing-deployments.ps1
```

**Shows**:
- All deployed proxies across Dev/QA/Prod
- API Products
- GitHub Actions workflow history
- Platform is operational

### Option 2: Complete Live Demo

Full end-to-end demonstration (creates real PR):

```powershell
# Use the master script
.\RUN-DEMO.ps1

# Select: [A] Run All Steps (Auto-demo)
```

**What it does**:
1. Shows existing deployments (proof)
2. Creates new proxy YAML (live coding)
3. Commits and pushes to GitHub (Git workflow)
4. Pauses for you to create PR in browser
5. Monitors validation & deployment workflows
6. Verifies API endpoint is live

**⚠️ Note**: This creates a real PR and branch in GitHub!

### Option 3: Step-by-Step Manual Demo

Run scripts individually for maximum control:

```powershell
# Step 1: Show what exists
.\01-show-existing-deployments.ps1

# Step 2: Create new proxy
.\02-create-new-proxy.ps1

# Step 3: Commit and push
.\03-commit-and-push.ps1

# Step 4: Monitor workflows (after creating PR)
.\04-monitor-workflows.ps1

# Step 5: Verify deployment (after merge)
.\05-verify-deployment.ps1
```

---

## 📝 Individual Script Details

### 01-show-existing-deployments.ps1

**Purpose**: Show platform is working with existing deployments

**What it displays**:
- MAL folder structure (`tree` view)
- All proxies in Dev/QA/Prod environments
- API Products per organization
- GitHub Actions runs (opens browser)
- Summary statistics

**Usage**:
```powershell
.\01-show-existing-deployments.ps1
```

**Output Example**:
```
📁 MAL Folder Structure:
mal-SYSGEN788836350/
├── orgs/
│   ├── gcp-prj-apigee-dev-np-01/
│   │   ├── envs/apicc-dev/proxies/
│   │   │   ├── E2E-TEST-BASIC/
│   │   │   ├── SIMPLE-TEST/
│   │   │   └── OAUTH-KVM-OAS-TEST/

🌍 DEV Environment:
   Proxies: 5
     ✓ E2E-TEST-BASIC
       API Name: SYSGEN788836350-E2E-TEST-BASIC
       Path: /sysgen788836350/e2e-test-basic/v1
```

**Talking Points**:
- "Here's what's already deployed - platform is operational"
- "5 proxies across 3 environments = 15 successful deployments"
- "All managed through simple YAML files"

---

### 02-create-new-proxy.ps1

**Purpose**: Create a new proxy YAML file (live demonstration)

**What it does**:
- Creates timestamped proxy folder
- Generates schema-valid proxy YAML
- Displays the YAML with syntax highlighting
- Shows Git status

**Usage**:
```powershell
.\02-create-new-proxy.ps1

# Or with custom name
.\02-create-new-proxy.ps1 -ProxyName "my-custom-api"
```

**Generated YAML**:
```yaml
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-DEMO-LIVE-20260213-143022
  description: "Live demo proxy created on February 13, 2026 at 14:30:22"
  labels:
    sysgen: SYSGEN788836350
    taxonomy: /Demo/v1/Live
spec:
  template: oauth-proxy-oauth-backend
  routing:
    path: /sysgen788836350/demo-live/v1
    target: https://httpbin.org
    rewritePath: /anything
    timeout: 30
```

**Talking Points**:
- "Just 20 lines of YAML - no XML, no policies"
- "Template handles OAuth, backend connectivity"
- "Self-documenting with metadata and labels"
- "Backend is httpbin.org (echo service for testing)"

---

### 03-commit-and-push.ps1

**Purpose**: Commit changes and push to GitHub

**What it does**:
- Ensures on main branch
- Pulls latest changes
- Creates feature branch (`demo/live-proxy-<timestamp>`)
- Stages changes in `mal-SYSGEN788836350/`
- Creates descriptive commit
- Pushes to GitHub
- Opens PR creation URL in browser

**Usage**:
```powershell
.\03-commit-and-push.ps1
```

**Output Example**:
```
🌿 Creating feature branch...
   Branch name: demo/live-proxy-20260213-143500
✓ Created and switched to branch

💾 Creating commit...
   Message: feat: add demo proxy for live platform demonstration 2026-02-13 14:35
✓ Commit created

🚀 Pushing to GitHub...
✓ Pushed to GitHub successfully

🔗 Create PR: https://github.com/CenturyLink/.../compare/main...demo/live-proxy-...
```

**Talking Points**:
- "Committed with descriptive message"
- "Pushed to feature branch (not main)"
- "Opens PR creation page automatically"
- "This triggers automated validation"

---

### 04-monitor-workflows.ps1

**Purpose**: Show GitHub Actions workflow execution

**What it does**:
- Lists recent validation workflow runs
- Lists recent deployment workflow runs (Dev/Test/Prod)
- Shows currently running workflows
- Calculates platform health score
- Opens GitHub Actions in browser

**Prerequisites**:
- **Optional**: GitHub CLI (`gh`) for detailed output
- **Fallback**: Opens browser if `gh` not installed

**Usage**:
```powershell
.\04-monitor-workflows.ps1
```

**Output Example**:
```
🔍 Validate Proxy YAML (PR checks):
   ✅ 2026-02-13T14:35:22 - demo/live-proxy - feat: add demo proxy

🚀 Deploy to Dev:
   ✅ 2026-02-13T14:40:15 - Deploy Proxies to Dev

Last 10 runs:
  ✅ Success: 9
  ❌ Failure: 0
  ⏳ Other: 1

  ✨ Platform health: EXCELLENT
```

**Talking Points**:
- "Green checkmarks = successful deployments"
- "Validation runs automatically on PR"
- "Deployment runs automatically on merge"
- "Platform health: 90% success rate"

---

### 05-verify-deployment.ps1

**Purpose**: Verify proxy was successfully deployed

**What it does**:
- Pulls latest from main
- Lists all proxies in Dev
- Highlights demo proxies
- Shows last successful deployment
- Tests API endpoint (if accessible)

**Usage**:
```powershell
.\05-verify-deployment.ps1
```

**Output Example**:
```
📦 All Proxies in Dev Environment:

   1. DEMO-LIVE-20260213-143500
      Name: SYSGEN788836350-DEMO-LIVE-20260213-143500
      Path: /sysgen788836350/demo-live/v1
      Template: oauth-proxy-oauth-backend
      🎯 THIS IS YOUR DEMO PROXY!

🌐 API Endpoint Testing:
   Demo API Endpoint:
      https://apicc-dev.gcl.corp.intranet/sysgen788836350/demo-live/v1
   
   Testing endpoint...
      ✅ Status: 401 Unauthorized
      This is EXPECTED! OAuth token required.
      Proxy is deployed and responding correctly!
```

**Talking Points**:
- "Proxy successfully deployed to Apigee"
- "401 response = OAuth protection working correctly"
- "Total time: ~10 minutes from YAML to live API"
- "Zero manual steps in Apigee console"

---

## 🎤 Demo Tips

### Before the Demo

**Practice once** to get comfortable:
```powershell
# Dry run (doesn't create PR)
.\01-show-existing-deployments.ps1
.\02-create-new-proxy.ps1
# Stop here for practice
```

**Clean up practice files**:
```powershell
# Delete demo proxy folders
Remove-Item mal-SYSGEN788836350/orgs/*/envs/*/proxies/DEMO-* -Recurse -Force
```

### During the Demo

**Timing**:
- Script 1: 2-3 minutes (show proof)
- Script 2: 1-2 minutes (create YAML)
- Script 3: 2 minutes (commit & push)
- Script 4: 2-3 minutes (monitor - wait for workflows)
- Script 5: 2 minutes (verify)
- **Total**: 10-15 minutes

**Key Moments to Pause**:
1. After script 1: "Platform is operational with multiple deployments"
2. After script 2: "Just 20 lines of YAML - no XML complexity"
3. After script 3: "Pushed to GitHub - automation starts now"
4. After script 4: "Validation passed - ready to deploy"
5. After script 5: "API is live - end-to-end complete"

### Common Issues

**Issue**: Script can't find `mal-SYSGEN788836350/`  
**Solution**: Run from repository root, not `docs/demo/`

**Issue**: `gh` command not found  
**Solution**: Install GitHub CLI or use browser-only mode (scripts fallback automatically)

**Issue**: Git push fails  
**Solution**: Check GitHub authentication: `git config --list | Select-String user`

**Issue**: Workflows don't trigger  
**Solution**: Ensure changes are in correct path: `mal-SYSGEN*/orgs/*/envs/*dev*/proxies/**/*.yaml`

---

## 💡 Demo Variations

### Quick Demo (3 minutes)

For time-constrained presentations:
```powershell
# Show existing + create new (no PR)
.\01-show-existing-deployments.ps1
.\02-create-new-proxy.ps1
```

**Say**: *"We have existing deployments. Creating a new one is this simple - 20 lines of YAML. In production, we'd open a PR and the platform would validate and deploy automatically."*

### Executive Demo (5 minutes)

High-level overview focusing on outcomes:
```powershell
.\01-show-existing-deployments.ps1
# Show GitHub Actions (green checkmarks)
```

**Talking points**:
- "Platform is production-ready"
- "15 successful deployments"
- "Automated validation & deployment"
- "Same process for all environments"

### Technical Deep-Dive (15 minutes)

Full walkthrough with Q&A:
```powershell
.\RUN-DEMO.ps1
# Select: [A] Run All Steps
```

**Include**:
- Show YAML schema validation
- Explain template system
- Walk through workflow logs
- Answer technical questions

---

## 🎯 Success Criteria

**Demo is successful if audience sees**:
- ✅ Simple YAML (not XML)
- ✅ Automated validation (PR checks)
- ✅ Automated deployment (merge triggers)
- ✅ Green checkmarks (proof it works)
- ✅ Live API endpoint (deployed and responding)

**Demo answers the question**:
> *"Can API producers use this platform without Apigee expertise?"*

**Answer**: *"Yes. Write 20 lines of YAML, open a PR, and the platform does the rest."*

---

## 📚 Related Documentation

- **Live Demo Guide (detailed)**: [API-PRODUCER-LIVE-DEMO.md](../API-PRODUCER-LIVE-DEMO.md)
- **Production Evidence**: [PRODUCTION-READINESS-EVIDENCE.md](../PRODUCTION-READINESS-EVIDENCE.md)
- **API Producer Core**: [api-producer-core.md](../api-producer-core.md)
- **Platform Demo Script**: [PLATFORM-DEMO-SCRIPT.md](PLATFORM-DEMO-SCRIPT.md)

---

## 🔧 Prerequisites

### Required
- ✅ PowerShell 5.1+ (Windows) or PowerShell Core 7+ (cross-platform)
- ✅ Git installed and configured
- ✅ Repository cloned locally
- ✅ GitHub authentication configured

### Optional (Enhances Demo)
- **GitHub CLI** (`gh`): For workflow monitoring
  - Install: `winget install GitHub.cli`
  - Authenticate: `gh auth login`
- **Bruno VS Code Extension**: For API testing
- **Network access**: To test Apigee endpoints (VPN required)

---

## 🧹 Cleanup After Demo

### Remove Demo Proxies (Local)
```powershell
# From repository root
Get-ChildItem mal-SYSGEN788836350/orgs/*/envs/*/proxies/DEMO-* -Directory | Remove-Item -Recurse -Force
```

### Delete Demo Branches
```powershell
# List demo branches
git branch | Select-String "demo/"

# Delete local branch
git branch -D demo/live-proxy-<timestamp>

# Delete remote branch
git push origin --delete demo/live-proxy-<timestamp>
```

### Close Demo PRs
```powershell
# Via GitHub CLI
gh pr list --state open | Select-String "demo"
gh pr close <pr-number>

# Or in browser
# https://github.com/CenturyLink/enterprise-apigeex-applications/pulls
```

---

## ✨ Tips for Success

1. **Practice first** - Run through once before live demo
2. **Have backup** - Screenshots of successful runs
3. **Know your audience** - Adjust talking points accordingly
4. **Pause strategically** - Let key points sink in
5. **Handle questions** - Reference documentation for details
6. **Show confidence** - You have proof it works (15 deployments!)

---

## 📞 Support

**Questions about the demo scripts?**
- Check [API-PRODUCER-LIVE-DEMO.md](../API-PRODUCER-LIVE-DEMO.md) for detailed guidance
- Review [PRODUCTION-READINESS-EVIDENCE.md](../PRODUCTION-READINESS-EVIDENCE.md) for proof points
- See [API-PRODUCER-FAILURE-MODES.md](../API-PRODUCER-FAILURE-MODES.md) for troubleshooting

**Technical issues?**
- Ensure you're in repository root
- Check Git configuration
- Verify GitHub authentication
- Review script output for error messages

---

**Last Updated**: February 13, 2026  
**Demo Scripts Version**: 1.0  
**Status**: ✅ Ready for use
