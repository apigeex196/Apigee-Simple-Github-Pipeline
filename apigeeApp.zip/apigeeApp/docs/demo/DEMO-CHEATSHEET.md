# API Producer Platform - Demo Cheat Sheet

**Quick Reference for Client Presentations**

---

## Pre-Demo Checklist (2 minutes before)

- [ ] Open VS Code in repository root
- [ ] Open browser tabs:
  - GitHub repo: `https://github.com/CenturyLink/enterprise-apigeex-applications`
  - GitHub Actions: `https://github.com/CenturyLink/enterprise-apigeex-applications/actions`
- [ ] Navigate to `mal-SYSGEN788836350/` folder in VS Code
- [ ] Have one proxy YAML open (e.g., `SIMPLE-TEST/proxy.yaml`)
- [ ] Test PowerShell terminal: `Get-Location` should show repo root

---

## Opening Statement (30 seconds)

> "Let me show you how we've simplified deploying to Apigee X. API producers write 15-20 lines of YAML, and everything else is automated. No Apigee expertise required."

---

## Demo Flow (10 minutes total)

### Part 1: Show Existing Infrastructure (2 min)

**What to Show:**
```powershell
# Run simplified demo script
.\docs\demo\SIMPLE-DEMO.ps1
```

**OR manually show:**
- Navigate to `mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/`
- Show 5+ deployed proxies
- Explain: "Each folder = one deployed API across 3 environments"

**Talking Points:**
- ✅ Platform is **already operational** with 15 live deployments
- ✅ 5 proxies deployed across Dev, QA, and Prod
- ✅ Same structure for all API producers (team isolation via MAL codes)

---

### Part 2: Show Simple YAML (3 min)

**What to Show:**
- Open `mal-SYSGEN788836350/.../proxies/SIMPLE-TEST/proxy.yaml`

**Highlight in YAML:**
```yaml
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-SIMPLE-TEST
  description: "Simple test proxy"
spec:
  template: oauth-proxy-oauth-backend  # ← Security handled automatically
  routing:
    path: /sysgen788836350/simple-test/v1  # ← API endpoint
    target: https://httpbin.org             # ← Backend system
```

**Talking Points:**
- ✅ **Just 15-20 lines** vs. hundreds of lines of XML
- ✅ **Templates handle OAuth** - security pre-configured
- ✅ **Human-readable** - no Apigee expertise needed
- ✅ **Self-documenting** - metadata, labels, descriptions

---

### Part 3: Show GitHub Actions (2 min)

**What to Show:**
- Switch to browser: GitHub Actions tab
- Show recent workflow runs (look for green checkmarks)

**Point out:**
- **validate-proxy.yml** - Runs on every Pull Request
- **deploy-to-dev/test/prod.yml** - Runs on merge to main
- Recent runs: All green = platform healthy

**Talking Points:**
- ✅ **Validation catches errors early** (before deployment)
- ✅ **Deployment is fully automated** (no manual steps)
- ✅ **Auditable** - every deployment logged in GitHub
- ✅ **Takes 3-5 minutes** from commit to live API

---

### Part 4: Show Workflow Files (Optional, 2 min)

**What to Show:**
- Open `.github/workflows/validate-proxy.yml` in VS Code
- Scroll to lines 15-20 (path filters)

**Highlight:**
```yaml
paths:
  - 'mal-*/orgs/*/envs/*/proxies/**/*.yaml'
```

**Talking Points:**
- ✅ **Triggers automatically** when YAML files change
- ✅ **Isolated by MAL code** - only affected proxies deploy
- ✅ **Existing infrastructure** - just works

---

### Part 5: Show API Producer Workflow (1 min)

**What to Describe (don't do live):**

1. **Create** proxy YAML (15 lines, 2 minutes)
2. **Commit** to feature branch (`git commit`, `git push`)
3. **Open PR** in GitHub
4. **Watch validation** pass (automated, 2 minutes)
5. **Merge PR** (one click)
6. **Watch deployment** (automated, 3 minutes)
7. **API is live!** (test endpoint)

**Total time:** ~10 minutes from idea to production-ready API

---

## Closing Statement (30 seconds)

> "From YAML file to live API endpoint: under 10 minutes, fully automated, zero manual steps in the Apigee console. Platform is production-ready with 15 existing deployments."

---

## Common Questions & Answers

### Q: What if validation fails?
**A:** PR check shows red X with clear error message. Fix YAML, push again. Validation runs automatically.

### Q: How do you prevent team conflicts?
**A:** Three layers:
1. **MAL isolation** - each team has their own folder
2. **CODEOWNERS** - automatic reviewers assigned
3. **Changed file detection** - only affected proxies redeploy

### Q: What about secrets and credentials?
**A:** 
- **GitHub Secrets** for deployment credentials (encrypted)
- **Apigee KVMs** for backend credentials (encrypted at rest)
- **Service accounts** with least-privilege access

### Q: Is this really production-ready?
**A:** Yes! Evidence:
- ✅ 5 unique proxies deployed
- ✅ 15 total deployments (5 proxies × 3 environments)
- ✅ Automated testing (Bruno collections)
- ✅ End-to-end test results documented
- ✅ Full documentation (40+ pages)
- ✅ GitHub Actions all green

### Q: What templates are available?
**A:** Five templates covering common patterns:
1. `oauth-proxy-oauth-backend` - OAuth protected → OAuth backend
2. `jwt-proxy-ahpt-backend` - JWT protected → AHPT backend
3. `oauth-proxy-jwt-backend` - OAuth protected → JWT backend
4. `jwt-oauth-proxy-ahpt-backend` - Dual auth → AHPT backend
5. `single-proxy-template` - Basic proxy (no auth)

### Q: How long to onboard a new API producer?
**A:** 
- **30 minutes** to read documentation
- **10 minutes** to deploy first proxy
- **1 hour** total to be productive

### Q: Can you deploy to just Dev, or just Prod?
**A:** Yes! File location determines environment:
- **Dev only:** Put YAML in `.../envs/apicc-dev/proxies/`
- **QA only:** Put YAML in `.../envs/apicc-test1/proxies/`
- **Prod only:** Put YAML in `.../envs/apicc-prod/proxies/`
- **All three:** Copy YAML to all three folders

---

## If Something Goes Wrong During Demo

### Script fails to run
**Backup Plan:** 
- Manually navigate folders in VS Code
- Show YAML files directly
- Show GitHub Actions in browser
- Talk through workflow instead of running live

### Network/GitHub issues
**Backup Plan:**
- Show local files only (proxies, YAMLs)
- Reference existing GitHub Actions (screenshot if needed)
- Focus on YAML simplicity and structure

### Audience gets technical
**Pivot to:**
- Open `.github/workflows/deploy-to-dev.yml`
- Show schema files (`apiproxy.schema.json`)
- Show template mappings (`template-mappings.json`)
- Show test collections (`tests/bruno-collections/`)

---

## Post-Demo Next Steps

**For interested API producers:**
1. Share documentation: `docs/api-producer-core.md`
2. Schedule onboarding session (1 hour)
3. Grant repository access
4. Assign MAL code for their team
5. Update CODEOWNERS file

**For leadership:**
1. Share production evidence: `docs/PRODUCTION-READINESS-EVIDENCE.md`
2. Schedule architecture review
3. Discuss scaling plans (templates, additional orgs)

---

## Emergency Contacts

- **Platform Owner:** [Your Name]
- **TL Shimmy:** [Contact Info]
- **CCOE Team:** [Team Contact]
- **Slack Channel:** #apigee-platform-support

---

## Files to Have Open

**VS Code:**
1. `mal-SYSGEN788836350/orgs/.../proxies/SIMPLE-TEST/proxy.yaml`
2. `.github/workflows/validate-proxy.yml`
3. `docs/api-producer-core.md` (for reference)

**Browser:**
1. GitHub repo: https://github.com/CenturyLink/enterprise-apigeex-applications
2. GitHub Actions: https://github.com/CenturyLink/enterprise-apigeex-applications/actions

---

## Timing Variations

### 3-Minute Lightning Demo
- Show existing deployments (1 min)
- Show one YAML file (1 min)
- Show GitHub Actions green checkmarks (1 min)

### 5-Minute Executive Brief
- Platform overview + existing infrastructure (2 min)
- YAML simplicity (1.5 min)
- Automation + benefits (1.5 min)

### 10-Minute Full Demo
- Follow main demo flow above

### 15-Minute Deep Dive
- Main demo + open workflow files
- Show schema validation
- Show template structure
- Answer technical questions

---

## Key Metrics to Mention

| Metric | Value |
|--------|-------|
| Time to deploy (commit → live) | **8-10 minutes** |
| Lines of YAML required | **15-20 lines** |
| Existing deployments | **15 (5 proxies × 3 envs)** |
| Workflow success rate | **~95%+** (check GitHub Actions) |
| Onboarding time | **1 hour** |
| Templates available | **5 patterns** |
| Environments supported | **3 (Dev/QA/Prod)** |

---

## Success Indicators

You've given a successful demo if the audience says:

- "That's way simpler than I expected"
- "So we just write YAML and it deploys automatically?"
- "How do I get access to this?"
- "Can we onboard our team next week?"

---

**Last Updated:** February 13, 2026  
**Demo Script Version:** 1.0 (Safe/Tested)
