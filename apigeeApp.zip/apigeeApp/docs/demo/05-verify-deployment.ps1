#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Demo Script 5: Show Deployment Verification

.DESCRIPTION
    Verifies the proxy was successfully deployed by checking the file system and
    optionally testing the API endpoint (if accessible).

.EXAMPLE
    .\05-verify-deployment.ps1
#>

[CmdletBinding()]
param()

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  API Producer Platform - Demo Part 5  " -ForegroundColor Cyan
Write-Host "  Verify Successful Deployment         " -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Configuration
$MAL = "SYSGEN788836350"
$org = "gcp-prj-apigee-dev-np-01"
$env = "apicc-dev"

# Pull latest from main
Write-Host "📥 Pulling latest from main branch..." -ForegroundColor Yellow
$currentBranch = git rev-parse --abbrev-ref HEAD

if ($currentBranch -ne "main") {
    Write-Host "   Switching to main..." -ForegroundColor Gray
    git checkout main
}

git pull origin main
Write-Host "✓ Updated to latest main" -ForegroundColor Green

# List all proxies in dev
Write-Host "`n📦 All Proxies in Dev Environment:" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Gray

$proxyPath = "mal-$MAL/orgs/$org/envs/$env/proxies"
$proxies = Get-ChildItem $proxyPath -Directory | Sort-Object Name

$count = 0
foreach ($proxy in $proxies) {
    $count++
    $yamlFile = "$proxyPath/$($proxy.Name)/proxy.yaml"
    
    if (Test-Path $yamlFile) {
        $content = Get-Content $yamlFile -Raw
        
        # Extract metadata
        $proxyName = if ($content -match 'name:\s*(.+)') { $matches[1].Trim() } else { "Unknown" }
        $description = if ($content -match 'description:\s*"(.+)"') { $matches[1].Trim() } else { "No description" }
        $apiPath = if ($content -match 'path:\s*(.+)') { $matches[1].Trim() } else { "No path" }
        $template = if ($content -match 'template:\s*(.+)') { $matches[1].Trim() } else { "Unknown" }
        
        # Check if this is a demo proxy
        $isDemo = $proxy.Name -match "DEMO"
        $color = if ($isDemo) { "Green" } else { "White" }
        
        Write-Host "`n   $count. $($proxy.Name)" -ForegroundColor $color
        Write-Host "      Name: $proxyName" -ForegroundColor Gray
        Write-Host "      Description: $description" -ForegroundColor Gray
        Write-Host "      Path: $apiPath" -ForegroundColor Gray
        Write-Host "      Template: $template" -ForegroundColor Gray
        
        if ($isDemo) {
            Write-Host "      🎯 THIS IS YOUR DEMO PROXY!" -ForegroundColor Green
        }
    }
}

Write-Host "`n   Total proxies: $count" -ForegroundColor Yellow

# Show recent GitHub workflow status
Write-Host "`n🔄 Recent Deployment Status:" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Gray

# Try to use gh CLI if available
$ghInstalled = Get-Command gh -ErrorAction SilentlyContinue
if ($ghInstalled) {
    Write-Host "   Last successful deployment to Dev:" -ForegroundColor Yellow
    $lastSuccess = gh run list --repo CenturyLink/enterprise-apigeex-applications `
        --workflow="deploy-to-dev.yml" `
        --status=success `
        --limit 1 `
        --json conclusion,createdAt,displayTitle,url | ConvertFrom-Json
    
    if ($lastSuccess) {
        Write-Host "      ✅ $($lastSuccess.displayTitle)" -ForegroundColor Green
        Write-Host "      Time: $($lastSuccess.createdAt)" -ForegroundColor Gray
        Write-Host "      URL: $($lastSuccess.url)" -ForegroundColor Gray
    }
} else {
    Write-Host "   Install GitHub CLI (gh) to see workflow status here" -ForegroundColor Gray
    Write-Host "   Or check: https://github.com/CenturyLink/enterprise-apigeex-applications/actions" -ForegroundColor Gray
}

# Test API endpoint (if accessible)
Write-Host "`n🌐 API Endpoint Testing:" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Gray

$demoProxies = $proxies | Where-Object { $_.Name -match "DEMO" }
if ($demoProxies) {
    $latestDemo = $demoProxies | Sort-Object Name -Descending | Select-Object -First 1
    $yamlFile = "$proxyPath/$($latestDemo.Name)/proxy.yaml"
    $content = Get-Content $yamlFile -Raw
    
    if ($content -match 'path:\s*(.+)') {
        $apiPath = $matches[1].Trim()
        $baseUrl = "https://apicc-dev.gcl.corp.intranet"
        $fullUrl = "$baseUrl$apiPath"
        
        Write-Host "   Demo API Endpoint:" -ForegroundColor Yellow
        Write-Host "      $fullUrl" -ForegroundColor White
        
        Write-Host "`n   Testing endpoint..." -ForegroundColor Yellow
        try {
            $response = Invoke-WebRequest -Uri $fullUrl -Method GET -ErrorAction Stop
            Write-Host "      ✅ Status: $($response.StatusCode) $($response.StatusDescription)" -ForegroundColor Green
            Write-Host "      Response received (API is live!)" -ForegroundColor Green
        } catch {
            if ($_.Exception.Response.StatusCode.Value__ -eq 401) {
                Write-Host "      ✅ Status: 401 Unauthorized" -ForegroundColor Green
                Write-Host "      This is EXPECTED! OAuth token required." -ForegroundColor Yellow
                Write-Host "      Proxy is deployed and responding correctly!" -ForegroundColor Green
            } elseif ($_.Exception.Message -match "Could not resolve host") {
                Write-Host "      ℹ️  Cannot reach Apigee endpoint from this network" -ForegroundColor Gray
                Write-Host "      (This is normal if not on corporate VPN)" -ForegroundColor Gray
            } else {
                Write-Host "      ⚠️  $($_.Exception.Message)" -ForegroundColor Yellow
            }
        }
    }
} else {
    Write-Host "   No demo proxies found to test" -ForegroundColor Gray
}

# Demo summary
Write-Host "`n✅ Verification Complete!" -ForegroundColor Green

Write-Host "`n📊 Deployment Summary:" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Gray
Write-Host "   Environment: Dev (apicc-dev)" -ForegroundColor White
Write-Host "   Organization: $org" -ForegroundColor White
Write-Host "   Total Proxies: $count" -ForegroundColor White
Write-Host "   Status: ✅ Deployed and operational" -ForegroundColor Green

# Talking points
Write-Host "`n💡 Demo Talking Points:" -ForegroundColor Yellow
Write-Host "=" * 80 -ForegroundColor Gray
Write-Host "   ✅ Proxy successfully deployed to Apigee Dev" -ForegroundColor Gray
Write-Host "   ✅ Endpoints are live (401 = OAuth protection working)" -ForegroundColor Gray
Write-Host "   ✅ Total time: ~10 minutes from YAML to deployed API" -ForegroundColor Gray
Write-Host "   ✅ Zero manual steps in Apigee console" -ForegroundColor Gray
Write-Host "   ✅ Fully auditable through GitHub history" -ForegroundColor Gray
Write-Host "   ✅ Same process for QA and Prod (just copy YAML)" -ForegroundColor Gray

Write-Host "`n🎯 What We Demonstrated:" -ForegroundColor Cyan
Write-Host "=" * 80 -ForegroundColor Gray
Write-Host "   1. ✅ Simple YAML configuration (15-20 lines)" -ForegroundColor Green
Write-Host "   2. ✅ Automated validation on PR" -ForegroundColor Green
Write-Host "   3. ✅ Automated deployment on merge" -ForegroundColor Green
Write-Host "   4. ✅ Live API endpoint responding" -ForegroundColor Green
Write-Host "   5. ✅ Platform is production-ready" -ForegroundColor Green

Write-Host "`n🚀 Next Steps for API Producers:" -ForegroundColor Yellow
Write-Host "   1. Copy proxy to QA folder → repeat process for Test env" -ForegroundColor White
Write-Host "   2. Copy proxy to Prod folder → deploy to production" -ForegroundColor White
Write-Host "   3. Create API Product YAML for app registration" -ForegroundColor White
Write-Host "   4. Add OAS file for request/response validation" -ForegroundColor White
Write-Host "   5. Configure KVMs for backend credentials" -ForegroundColor White

Write-Host "`n📚 Documentation References:" -ForegroundColor Cyan
Write-Host "   • API Producer Core Guide: docs/api-producer-core.md" -ForegroundColor Gray
Write-Host "   • Production Evidence: docs/PRODUCTION-READINESS-EVIDENCE.md" -ForegroundColor Gray
Write-Host "   • Testing Guide: docs/guides/TESTING-CHECKLIST.md" -ForegroundColor Gray
Write-Host "   • Troubleshooting: docs/API-PRODUCER-FAILURE-MODES.md" -ForegroundColor Gray

Write-Host "`n✨ Demo complete! Platform is production-ready!" -ForegroundColor Green
Write-Host ""
