# Multi-Org Applications Repository Demo - Quick Reference

## Demo Overview

**Purpose**: Demonstrate multi-organization deployment capability using the applications repository GitOps workflow.

**What It Proves**:
- ✅ Proxy deployed to 3 separate Apigee X organizations
- ✅ OAuth security with JWT backend authentication
- ✅ GitOps workflow with environment-specific configurations
- ✅ Template-based proxy generation
- ✅ Live backend integration (Open-Meteo Weather API)

---

## Current Status

**Proxy Name**: `SYSGEN788836350-multi-org-applications-repo-demo`
**Version**: v1.0.1
**Template**: oauth-proxy-jwt-backend v0.1.18

### Deployment Status
- ✅ **Dev** (gcp-prj-apigee-dev-np-01/apicc-dev): Deployed, revision 1
- ✅ **Test** (gcp-prj-apigee-qa-np-01/apicc-test1): Deployed, revision 1
- ✅ **Prod** (gcp-prj-apigee-prod-01/apicc-prod): Deployed, revision 1

### OAuth Backend
- **Name**: SYSGEN788836350-OAuth-Backend-Test-Token-Service
- **Version**: v0.1.0
- **Endpoint**: `/SYSGEN788836350/backend/oauth/token`
- **Status**: Deployed to all 3 environments

### Weather Data Sources
- **Dev**: Salem, MA (42.5195, -70.8967)
- **Test**: Omaha, NE (41.2565, -95.9345)
- **Prod**: Seattle, WA (47.6062, -122.3321)

---

## ✅ Setup Complete - Ready to Demo!

### OAuth Credentials Status
✅ **All credentials provisioned and validated**
- Dev: Client ID ending in `...Uq50HZr`
- Test: Client ID ending in `...sOkIPcj3`
- Prod: Client ID ending in `...YP81RR49`

### Demo Script Status
✅ **demo-proxy-enhanced.sh ready with current credentials**
- Last validated: 2025-12-11
- Result: **3 Successful | 0 Failed**

### JWT Keys KVM Status
✅ **SYSGEN788836350-Apigateway-JWT-Keys exists in all environments**

---

## If Credentials Fail (Troubleshooting)

### Re-provision Credentials (if needed)

```bash
cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications

# Use the provision script
./provision-multi-org-demo-credentials.sh

# This will:
# 1. Create/update API Products in all 3 environments
# 2. Create/update Developers in all 3 environments
# 3. Create/update Developer Apps with new credentials
# 4. Automatically update demo-proxy-enhanced.sh with new credentials
```

### Manual Credential Recovery

```bash
TOKEN=$(gcloud auth print-access-token)

# Get existing credentials from each environment
curl -s -H "Authorization: Bearer $TOKEN" \
  "https://apigee.googleapis.com/v1/organizations/gcp-prj-apigee-dev-np-01/developers/demo.user.apicc-dev@example.com/apps/multi-org-demo-app-dev" | \
  jq -r '.credentials[0] | "Client ID: \(.consumerKey)\nClient Secret: \(.consumerSecret)"'

# Repeat for test and prod, then update demo-proxy-enhanced.sh
```

---

## Running the Demo

### Quick Demo Run

```bash
cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications
./demo-proxy-enhanced.sh
```

**Expected Output**:
- OAuth token acquisition for all 3 environments
- Live weather data for each location
- Infrastructure validation checklist
- **Results: 3 Successful | 0 Failed**

### Manual Testing

Test individual environments:

```bash
# 1. Get OAuth token
TOKEN=$(curl -s -X POST "https://apicc-dev.gcl.corp.intranet/SYSGEN788836350/backend/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials&client_id=YOUR_CLIENT_ID&client_secret=YOUR_CLIENT_SECRET" | \
  jq -r '.access_token')

# 2. Call protected API
curl -s "https://apicc-dev.gcl.corp.intranet/Demo/v1/Apigee/Stats/sysgen788836350/apigee-stats/v1" \
  -H "Authorization: Bearer $TOKEN" | jq
```

---

## Deployment Commands

### Check Deployment Status

```bash
TOKEN=$(gcloud auth print-access-token)

# List all deployed proxies
apigeecli apis listdeploy \
  --env "apicc-dev" \
  --org "gcp-prj-apigee-dev-np-01" \
  --token "$TOKEN"

# Check specific proxy
apigeecli apis get \
  --name "SYSGEN788836350-multi-org-applications-repo-demo" \
  --org "gcp-prj-apigee-dev-np-01" \
  --token "$TOKEN"
```

### Redeploy Proxy

```bash
# Trigger workflows via GitHub
gh workflow run "Deploy to Dev"
gh workflow run "Deploy to Test"
gh workflow run "Deploy to Prod"

# Or deploy manually
apigeecli apis deploy \
  --name "SYSGEN788836350-multi-org-applications-repo-demo" \
  --env "apicc-dev" \
  --org "gcp-prj-apigee-dev-np-01" \
  --rev 1 \
  --ovr \
  --token "$TOKEN"
```

### Undeploy Old Proxy (if needed)

```bash
TOKEN=$(gcloud auth print-access-token)

# Undeploy old proxy name
apigeecli apis undeploy \
  --name "SYSGEN788836350-apigee-stats-dashboard" \
  --env "apicc-dev" \
  --org "gcp-prj-apigee-dev-np-01" \
  --token "$TOKEN"
```

---

## Talking Points for Stakeholders

### 1. Multi-Organization Architecture
"This demo shows our proxy deployed across three separate Apigee X organizations - Dev, Test, and Production. Each organization is completely independent with its own OAuth backends, API products, and developer apps."

### 2. Security Implementation
"Notice how every API call requires OAuth authentication. The proxy validates the bearer token against the API product, ensuring only authorized applications can access the data. The backend uses JWT for service-to-service authentication."

### 3. GitOps Workflow
"All configurations are stored in Git. When we make changes and merge to main, our GitHub Actions workflows automatically deploy to the appropriate environments. This ensures consistency, traceability, and compliance."

### 4. Environment-Specific Configuration
"Each environment is configured differently - Dev pulls weather data from Salem, MA, Test from Omaha, NE, and Prod from Seattle, WA. This demonstrates how we can customize behavior per environment without duplicating code."

### 5. Template-Based Development
"Instead of manually building proxies, we use templates from our enterprise catalog. This proxy uses the `oauth-proxy-jwt-backend` template, which provides standardized OAuth validation, JWT backend authentication, and best practices out of the box."

### 6. Live Backend Integration
"The proxy successfully routes to an external weather API, fetching live data. This proves our routing, transformation, and integration capabilities are working correctly."

---

## Troubleshooting

### OAuth Token Fails with "invalid_client"
**Cause**: Wrong credentials or app doesn't have access to the API product
**Fix**:
```bash
# Verify app has correct product
TOKEN=$(gcloud auth print-access-token)
curl -s -H "Authorization: Bearer $TOKEN" \
  "https://apigee.googleapis.com/v1/organizations/gcp-prj-apigee-dev-np-01/developers/demo.user.apicc-dev@example.com/apps/multi-org-demo-app-dev" | \
  jq '.credentials[0].apiProducts'

# Should show: [{"apiproduct": "apicc-dev-multi-org-demo-product"}]

# If wrong product, re-run: ./provision-multi-org-demo-credentials.sh
```

### OAuth Token Fails with "Invalid-OAuth-Token"
**Cause**: Token issued by wrong product or proxy not in product's proxy list
**Fix**:
```bash
# Verify product has correct proxy
TOKEN=$(gcloud auth print-access-token)
curl -s -H "Authorization: Bearer $TOKEN" \
  "https://apigee.googleapis.com/v1/organizations/gcp-prj-apigee-dev-np-01/apiproducts/apicc-dev-multi-org-demo-product" | \
  jq '.proxies'

# Should show: ["SYSGEN788836350-multi-org-applications-repo-demo"]

# If wrong proxy, re-run: ./provision-multi-org-demo-credentials.sh
```

### API Call Returns 404
**Cause**: Proxy not deployed or basepath mismatch
**Fix**:
```bash
# Verify deployment
apigeecli apis listdeploy --env "apicc-dev" --org "gcp-prj-apigee-dev-np-01" --token "$TOKEN"

# Redeploy if needed
apigeecli apis deploy --name "SYSGEN788836350-multi-org-applications-repo-demo" --env "apicc-dev" --org "gcp-prj-apigee-dev-np-01" --rev 1 --ovr --token "$TOKEN"
```

### CONFLICTING_DEPLOYMENT Error
**Cause**: Old proxy still deployed with same basepath
**Fix**: Undeploy old proxy first (see commands above)

###Pre-Demo Checklist

- [x] Provision OAuth credentials for new proxy name
- [x] Update demo script with new credentials
- [x] Run full demo validation (3/3 successful ✅)
- [x] Verify all environments accessible
- [ ] Review talking points (5 minutes before demo)
- [ ] Test any stakeholder-specific scenarios

---

**Last Updated**: 2025-12-11 19:15 CST
**Status**: ✅ **DEMO READY**
**Last Validation**: 3 Successful | 0 Failed
- Dev: Salem, MA weather (23.9°F)
- Test: Omaha, NE weather (28.7°F)
- Prod: Seattle, WA weather (47.2°F)
### Workflows
- `.github/workflows/deploy-to-dev.yml`
- `.github/workflows/deploy-to-test.yml`
- `.github/workflows/deploy-to-prod.yml`

### Documentation
- Main README: `README.md`
- This reference: `DEMO-REFERENCE.md`
- Issues/improvements: `TODO.md`

---

## Next Steps (Before Demo)

- [ ] Provision OAuth credentials for new proxy name
- [ ] Update demo script with new credentials
- [ ] Run full demo validation (3/3 successful)
- [ ] Verify all environments accessible
- [ ] Review talking points
- [ ] Test any stakeholder-specific scenarios

---

**Last Updated**: 2025-12-12
**Status**: Ready for credential provisioning
**Demo Ready**: After credentials updated

For questions or issues, see [TODO.md](TODO.md) for known limitations and improvement plans.
