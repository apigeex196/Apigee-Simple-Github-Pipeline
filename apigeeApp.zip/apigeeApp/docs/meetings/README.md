# Meetings

Meeting notes, briefs, and team communication materials.

## Contents

This directory contains:
- Meeting briefs and agendas
- Discussion summaries
- Decision records
- Action item tracking

## Naming Convention

- Format: `{YYYY-MM-DD}-{meeting-type}-{topic}.md`
- Or: `{TEAM}-{TOPIC}-BRIEF.md`

Example:
```
2026-01-15-sprint-planning-notes.md
CCOE-MEETING-BRIEF.md
```
