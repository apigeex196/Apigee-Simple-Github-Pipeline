# DPEAPI-20391: Proxy Deletion Workflow - Status Update

## Current Status: ✅ SUPERSEDED by Environment-Specific Deletion

**Date**: 2026-01-30

The original scope of this story has been superseded by a better architectural approach that aligns with GitOps principles.

---

## What Was Implemented Instead

✅ **Environment-Specific Undeploy + Delete** (PRs #654 gitops, #72 applications)

**Core Principle**: GitHub is the source of truth for Apigee deployments

**Behavior**: Deleting proxy YAML from `envs/{env}/proxies/` automatically:
- Undeploys from THAT environment only
- Deletes THAT revision only (not entire proxy)
- Other environments remain unaffected

**Safety Features**:
- Environment isolation (dev/test/prod are independent)
- Revision-specific deletion (not org-wide)
- Reversible via git history + new PR
- Atomic operations (undeploy must succeed before delete)

---

## Key Architectural Decision

### Original Approach (DPEAPI-20391 Initial Scope)
- Manual workflow_dispatch trigger
- 2-person approval requirement
- 30-minute wait timer
- Complex approval tracking system
- Org-wide deletion logic

### Implemented Approach (Simpler & Safer)
- Automated based on YAML deletion (GitOps native)
- Environment-specific (not org-wide)
- Revision-specific (not entire proxy)
- No approval workflow needed (git PR is the approval)
- Aligns with declarative infrastructure principles

---

## Example: Multi-Environment Protection

```
Proxy: SYSGEN123456789-customer-api
├── Dev (apicc-dev): revision 5
├── Test (apicc-test1): revision 7
└── Prod (apicc-prod): revision 9

Action: Delete YAML from envs/apicc-dev/proxies/
Result: Only revision 5 deleted
        Revisions 7 and 9 remain intact
```

---

## Technical Implementation (Completed)

### GitOps Repo (PR #654)
- `deploy-proxy.yml`: Extract env from file path, undeploy+delete from that env only
- `deploy-apigee-proxy.yml`: Add revision deletion after undeploy

### Applications Repo (PR #72)
- `deploy-to-dev.yml`: Undeploy+delete from apicc-dev
- `deploy-to-test.yml`: Undeploy+delete from apicc-test1
- `deploy-to-prod.yml`: Undeploy+delete from apicc-prod

---

## Business Value Achieved

✅ **Clean State**: GitHub accurately reflects Apigee deployment state
✅ **No Accumulation**: Deleted YAML = deleted proxy revision
✅ **Multi-Env Safety**: Dev deletions don't affect test/prod
✅ **Developer Confidence**: Fully reversible via git history
✅ **Compliance**: Automated audit trail via git commits + PR reviews
✅ **Simplicity**: No complex approval system needed

---

## Remaining Scope for DPEAPI-20391

**Recommendation**: Refocus story to **Orphaned Proxy Cleanup**

### NEW Focus Areas

**Weekly Orphaned Proxy Detection**:
- Scheduled workflow to detect proxies with NO deployments in ANY environment
- Generates report of truly unused proxies (not in git, not deployed)
- Complements the environment-specific deletion workflow

**Why This Matters**:
- Prevents Apigee proxy accumulation over time
- Identifies proxies manually created but never deployed
- Finds proxies from old workflows or testing
- Reduces Apigee org clutter

### Proposed Acceptance Criteria (If Refocusing)

- [ ] Weekly scheduled workflow detects undeployed proxies across all orgs/envs
- [ ] Report includes: proxy name, revision count, last modified date
- [ ] Cross-reference with git repos (gitops, applications, bundles)
- [ ] Email notification to API Platform team with report
- [ ] Optional: Auto-cleanup after 30 days with confirmation email
- [ ] Dry-run mode for testing detection logic

---

## Recommendation

**Option 1** (Preferred): Close DPEAPI-20391 as superseded, create new story "DPEAPI-XXXX: Orphaned Proxy Cleanup"

**Option 2**: Refocus DPEAPI-20391 scope to orphaned proxy detection/cleanup only

---

## References

- GitOps PR #654: https://github.com/CenturyLink/enterprise-apigeex-gitops/pull/654
- Applications PR #72: https://github.com/CenturyLink/enterprise-apigeex-applications/pull/72
- IMPLEMENTATION-STATUS.md: Updated with full evolution details (2026-01-29 → 2026-01-30)
