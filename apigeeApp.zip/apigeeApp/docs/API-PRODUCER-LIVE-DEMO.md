# API Producer Platform - Live Demo Guide

**Purpose**: Step-by-step instructions to demonstrate the API producer workflow is working end-to-end  
**Duration**: 10-15 minutes  
**Audience**: Leadership, stakeholders, API producer teams  
**Date**: February 13, 2026

---

## Demo Objective

**Prove that**: Any API producer can deploy an API to Apigee X in minutes by:
1. Creating a simple YAML file
2. Opening a pull request
3. Watching automated validation and deployment

**Key Message**: "The platform handles all the complexity. Producers just write YAML."

---

## Pre-Demo Setup (5 minutes before)

### Required Access
- ✅ GitHub repository access: `enterprise-apigeex-applications`
- ✅ GitHub Actions permission (to view workflows)
- ✅ VS Code or text editor
- ✅ Git CLI or GitHub Desktop
- ✅ (Optional) Bruno VS Code extension for API testing

### Pre-Demo Checklist
```powershell
# 1. Navigate to repository
cd "d:\downloads10-05\enterprise-apigeex-applications 2\enterprise-apigeex-applications"

# 2. Ensure on main branch and up-to-date
git checkout main
git pull origin main

# 3. Verify existing deployments (shows platform already working)
ls mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/

# Should see: E2E-TEST-BASIC, SIMPLE-TEST, OAUTH-KVM-OAS-TEST, etc.
```

### Have These Ready in Browser
1. **GitHub Actions tab**: https://github.com/CenturyLink/enterprise-apigeex-applications/actions
2. **Pull Requests tab**: https://github.com/CenturyLink/enterprise-apigeex-applications/pulls
3. **This demo script** open in another window

---

## Demo Flow: "Deploy a New API in 10 Minutes"

### Part 1: Show What Exists (2 minutes)

**Script**: *"Let me first show you what's already deployed and working..."*

#### 1.1 Show Deployed Proxies

```powershell
# Navigate to MAL folder
cd mal-SYSGEN788836350

# Show org structure
tree orgs -L 4
```

**Point out**:
- Clean folder structure: `orgs/<gcp-org>/envs/<env>/proxies/<proxy-name>/`
- Multiple environments: dev, qa (test), prod
- Same proxy exists in all 3 environments

#### 1.2 Show Existing Proxy YAML (Simple)

```powershell
# View a deployed proxy
cat orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/SIMPLE-TEST/proxy.yaml
```

**Expected Output**:
```yaml
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-simple-test
  description: Simple test proxy for validation
  labels:
    sysgen: SYSGEN788836350
    taxonomy: /Test/v1/Simple
spec:
  template: oauth-proxy-oauth-backend
  routing:
    path: /sysgen788836350/simple-test/v1
    target: https://httpbin.org
    rewritePath: /get
    timeout: 35
```

**Script**: *"This is all a producer writes - 15 lines of simple YAML. No XML, no manual configuration. The platform handles template download, transformation, deployment to Apigee, and product creation."*

#### 1.3 Show GitHub Actions Workflows (Proof It's Working)

**Navigate to**: https://github.com/CenturyLink/enterprise-apigeex-applications/actions

**Point out**:
- ✅ Green checkmarks on recent runs (Deploy to Dev, Deploy to Test, Deploy to Prod)
- Recent activity timestamps (shows platform is actively used)
- Workflow names match documented workflows

**Script**: *"These green checkmarks show successful deployments. Every merge to main triggers automatic deployment to the correct environment based on file paths."*

---

### Part 2: Create a New Proxy (Live Demo) (5 minutes)

**Script**: *"Now let me show you how easy it is to deploy a NEW proxy..."*

#### 2.1 Create a Branch

```powershell
# Create demo branch
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$branchName = "demo/new-proxy-$timestamp"
git checkout -b $branchName
```

#### 2.2 Create New Proxy Folder & YAML

```powershell
# Create folder structure
$proxyName = "DEMO-PROXY-$timestamp"
$proxyPath = "mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/$proxyName"
New-Item -ItemType Directory -Force -Path $proxyPath

# Create proxy.yaml
Set-Content "$proxyPath/proxy.yaml" @"
---
apiVersion: apienable.lumen.com/v1beta1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-$proxyName
  description: "Live demo proxy created on $(Get-Date -Format 'yyyy-MM-dd')"
  labels:
    sysgen: SYSGEN788836350
    taxonomy: /Demo/v1/Live
spec:
  template: oauth-proxy-oauth-backend
  routing:
    path: /sysgen788836350/demo-proxy/v1
    target: https://httpbin.org
    rewritePath: /anything
    timeout: 30
"@
```

**Script while typing**: *"I'm creating a new proxy folder and a simple 18-line YAML file. Notice:*
- *Proxy name follows SYSGEN pattern*
- *Using the oauth-proxy-oauth-backend template*
- *Target is httpbin.org (echo service)*
- *Path defines the API endpoint: /sysgen788836350/demo-proxy/v1*
*That's it. No policy XML, no Apigee console clicking, no manual deployment."*

#### 2.3 Open the File in VS Code

```powershell
# Open in VS Code to show syntax highlighting
code "$proxyPath/proxy.yaml"
```

**Point out in VS Code**:
- YAML syntax highlighting
- Simple, readable configuration
- Self-documenting (metadata.description, labels)

#### 2.4 Stage, Commit, Push

```powershell
# Stage the new file
git add mal-SYSGEN788836350/

# Commit with descriptive message
git commit -m "feat: add demo proxy for live platform demo on $(Get-Date -Format 'yyyy-MM-dd HH:mm')"

# Push to GitHub
git push origin $branchName
```

**Script**: *"I've committed a single YAML file and pushed to GitHub. Now watch what happens automatically..."*

---

### Part 3: Show Automated Validation (3 minutes)

#### 3.1 Open Pull Request

**In Browser**:
1. Go to: https://github.com/CenturyLink/enterprise-apigeex-applications/pulls
2. Click "New Pull Request"
3. Base: `main` ← Compare: `demo/new-proxy-<timestamp>`
4. Click "Create Pull Request"

**PR Title**: `Demo: Add new proxy for live platform demonstration`  
**PR Body**:
```markdown
## Demo Pull Request

This PR demonstrates the API producer workflow:
- ✅ New proxy YAML created
- ✅ Follows naming conventions (SYSGEN-prefixed)
- ✅ Uses valid template (oauth-proxy-oauth-backend)
- ✅ Schema-compliant YAML

**Expected**: Validation workflow will automatically:
1. Validate YAML against schema
2. Check template exists in template-mappings.json
3. Verify naming conventions
4. Validate file structure

**Demo Date**: February 13, 2026
```

5. Click "Create Pull Request"

#### 3.2 Watch Validation Workflow Trigger

**Point out**:
- Yellow status indicator appears (workflow running)
- Click "Details" to show workflow log
- Highlight validation steps in workflow:
  - ✅ Checkout repository
  - ✅ Calculate changed files
  - ✅ Validate proxy YAML schema
  - ✅ Check template name
  - ✅ Verify naming conventions
  - ✅ Check service account exists

**Script**: *"Within seconds, the validation workflow automatically runs. It's checking our YAML against the schema, verifying the template exists, enforcing naming rules - all the governance we need, fully automated."*

#### 3.3 Show Validation Success

**Wait for green checkmark** (usually 2-3 minutes)

**Script**: *"Green checkmark means our proxy passed all validation gates. If there were issues - invalid template name, wrong folder structure, schema violations - the workflow would fail and tell us exactly what to fix."*

**Show the checks**:
- ✅ Validate Proxy YAML (passed)
- ✅ All checks have passed

---

### Part 4: Show Automated Deployment (2 minutes)

#### 4.1 Merge the PR

**Script**: *"Now that validation passed, let's merge. Watch what happens automatically..."*

1. Click "Merge pull request"
2. Click "Confirm merge"
3. Immediately navigate to Actions tab

#### 4.2 Watch Deploy to Dev Workflow Trigger

**Navigate to**: https://github.com/CenturyLink/enterprise-apigeex-applications/actions

**Point out**:
- New workflow run appears: "Deploy Proxies to Dev"
- Status: Running (yellow)
- Triggered by: merge to main
- Branch: main

**Click into the workflow run**, show:
- ✅ Detect Changed Proxies (finds our new proxy)
- 🔄 Deploy to gcp-prj-apigee-dev-np-01 (matrix job running)
  - Download template
  - Transform YAML → Apigee bundle
  - Import proxy to Apigee
  - Deploy proxy to apicc-dev environment

**Script**: *"The platform detected our merged file, downloaded the OAuth template, transformed our YAML into a full Apigee proxy bundle, and is now deploying it to the Dev environment. All automatic."*

#### 4.3 Show Deployment Success

**Wait for green checkmark** (3-5 minutes)

**Point out**:
- ✅ All jobs succeeded
- Deployment summary shows:
  - Proxy imported: `SYSGEN788836350-DEMO-PROXY-<timestamp>`
  - Revision: 1
  - Environment: apicc-dev
  - Status: deployed

**Script**: *"Green checkmark means our API is now live in Apigee Dev. Total time from YAML file to deployed API: less than 10 minutes."*

---

### Part 5: Verify Deployment (Optional, 2 minutes)

#### 5.1 Show File Still Exists

```powershell
# Back in terminal
git checkout main
git pull origin main

# Show our proxy is now in main
cat mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/DEMO-PROXY-*/proxy.yaml
```

**Script**: *"Our YAML file is now in the main branch, and the proxy is deployed in Apigee."*

#### 5.2 (If time/access) Test the API Endpoint

**If you have network access to Apigee**:

```powershell
# Test health/echo endpoint
curl https://apicc-dev.gcl.corp.intranet/sysgen788836350/demo-proxy/v1 `
  -H "Content-Type: application/json" `
  -X GET
```

**Expected**: 401 Unauthorized (OAuth required) OR 200 OK with echo response

**Script**: *"The endpoint is live. In production, we'd have OAuth tokens to authenticate, but the proxy is responding."*

#### 5.3 (Alternative) Show in Bruno Test Collection

**If Bruno extension installed**:
1. Open Bruno sidebar in VS Code
2. Navigate to existing test: `tests/bruno-collections/apigee-e2e-tests/SIMPLE-TEST/01-Health-Check.bru`
3. Click "Run" button
4. Show 200 OK response

**Script**: *"Here's a similar proxy being tested with our Bruno test collection. Same platform, same process."*

---

## Demo Variations

### Variation A: Show Multi-Environment Promotion

**If time permits** (adds 5 minutes):

1. **Copy proxy to QA**:
```powershell
# Create promotion branch
git checkout -b "demo/promote-to-qa-$timestamp"

# Copy dev proxy to qa
$qaProxyPath = "mal-SYSGEN788836350/orgs/gcp-prj-apigee-qa-np-01/envs/apicc-test1/proxies/DEMO-PROXY-$timestamp"
Copy-Item -Recurse $proxyPath $qaProxyPath

# Commit and push
git add mal-SYSGEN788836350/
git commit -m "feat: promote demo proxy to QA"
git push origin "demo/promote-to-qa-$timestamp"
```

2. **Open PR** → Same validation process
3. **Merge** → Deploy to Test workflow triggers (different workflow!)
4. **Point out**: Path-based filtering ensures Dev changes don't deploy to Test, and vice versa

**Script**: *"Promotion is just copying the YAML to the QA folder. The workflows automatically detect the environment from the file path and deploy to the correct Apigee org."*

### Variation B: Show Product Creation

**If time permits** (adds 3 minutes):

1. **Create product YAML**:
```powershell
$productPath = "mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/products"
New-Item -ItemType Directory -Force -Path $productPath

Set-Content "$productPath/SYSGEN788836350-DEMO-PRODUCT.yaml" @"
---
apiVersion: v1
kind: ApiProduct
metadata:
  name: SYSGEN788836350-DEMO-PRODUCT
  description: "Demo product for live presentation"
  displayName: "Demo Product"
  mal: SYSGEN788836350
  org: gcp-prj-apigee-dev-np-01
spec:
  approvalType: auto
  access: internal
  environments:
    - apicc-dev
  proxies:
    - SYSGEN788836350-DEMO-PROXY-$timestamp
  quota:
    limit: "1000"
    interval: "1"
    timeUnit: "minute"
  scopes:
    - read
"@

git add mal-SYSGEN788836350/
git commit -m "feat: add demo product"
git push
```

2. **Trigger deploy-products workflow** (separate from proxy deployment)
3. **Show**: Products and proxies deploy independently

---

## What to Emphasize

### Key Points to Highlight

1. **Simplicity**: 
   - *"15 lines of YAML, not 500 lines of XML"*
   - *"No Apigee expertise required"*
   - *"Self-service, self-documenting"*

2. **Automation**:
   - *"PR validation runs automatically"*
   - *"Deployment triggers on merge"*
   - *"No manual steps, no console clicking"*

3. **Governance**:
   - *"Schema validation enforces standards"*
   - *"Template mapping ensures consistency"*
   - *"Naming conventions prevent conflicts"*
   - *"Path-based filtering prevents mistakes"*

4. **Speed**:
   - *"From YAML to deployed API in under 10 minutes"*
   - *"Validation in 2-3 minutes"*
   - *"Deployment in 3-5 minutes"*

5. **Multi-Environment**:
   - *"Same process for Dev, QA, Prod"*
   - *"Just copy YAML to different folder"*
   - *"Workflows automatically deploy to correct environment"*

6. **Production-Ready**:
   - *"Already deployed 5 proxies across 3 environments"*
   - *"15 total successful deployments"*
   - *"Automated testing with Bruno"*
   - *"Service account automation, key rotation, monitoring"*

---

## Audience-Specific Talking Points

### For Leadership
- *"We've reduced deployment time from hours to minutes"*
- *"API producers can self-service without platform team bottlenecks"*
- *"Built-in governance prevents mistakes"*
- *"Ready to scale to hundreds of producers"*

### For API Producers
- *"You write YAML, we handle the complexity"*
- *"Templates give you OAuth, JWT, KVM out-of-the-box"*
- *"Test locally with schema validation before PR"*
- *"Same process for Dev, QA, Prod"*

### For Platform Engineers
- *"Template repository provides reusable patterns"*
- *"Schema enforcement at PR validation"*
- *"Service account automation for new MALs"*
- *"Monitoring and alerting built-in"*
- *"GitOps workflow, no manual Apigee console work"*

---

## Handling Questions

### "What if validation fails?"

**Answer**: *"The PR check fails with a clear error message. For example, if the template name is misspelled, the workflow will say 'Template xyz not found in template-mappings.json'. Fix the YAML, push again, validation re-runs automatically."*

**Demo**: Show [API-PRODUCER-FAILURE-MODES.md](API-PRODUCER-FAILURE-MODES.md) for troubleshooting guide

### "How do you prevent one team from breaking another team's APIs?"

**Answer**: 
1. *"MAL isolation - each team has their own mal-SYSGEN folder"*
2. *"CODEOWNERS file - GitHub enforces team-based reviews"*
3. *"Changed file detection - workflows only deploy modified proxies, not all proxies"*
4. *"Path filtering - Dev changes don't trigger Prod deployments"*

### "What about shared flows and dependencies?"

**Answer**: *"Templates reference shared flows maintained by the platform team in a separate bundles repository. Producers coordinate with us to ensure required shared flows are deployed before go-live. It's documented in the Shared Flows section."*

**Demo**: Show [api-producer-core.md](api-producer-core.md) section on Shared Flows

### "How do you handle secrets and credentials?"

**Answer**: 
1. *"Service accounts per MAL/environment with automated key rotation"*
2. *"GitHub Secrets for CI/CD authentication"*
3. *"Encrypted KVMs for runtime secrets (OAuth credentials, API keys)"*
4. *"No plaintext secrets in YAML files or logs"*

**Demo**: Show [PRODUCTION-READINESS-EVIDENCE.md](PRODUCTION-READINESS-EVIDENCE.md) Section 7.1

### "Can you show it actually works end-to-end?"

**Answer**: *"Yes, let me show you the test results and deployed proxies..."*

**Demo**: 
1. Show [E2E-TESTING-DPEAPI-18719.md](guides/E2E-TESTING-DPEAPI-18719.md) test results
2. Open Bruno test collection and run a test
3. Show GitHub Actions history with green checkmarks
4. Show actual deployed proxy files in mal-SYSGEN788836350/

---

## Post-Demo: What's Next

### Immediate Actions
1. ✅ **Fix documentation links** (4 broken paths in api-producer-core.md)
2. ✅ **Create 1-page Quick Start guide** (extract from api-producer-core.md)
3. ✅ **Add workflow troubleshooting section** (why workflows don't trigger)

### Before Producer Onboarding
1. **Create MAL folders** for first wave of producers
2. **Provision service accounts** (automated with SA automation script)
3. **Set up CODEOWNERS** files
4. **Schedule onboarding sessions** (use this demo as template)

### Monitoring
1. **Watch SA key expiration** (monitoring script runs weekly)
2. **Review workflow success rates** (GitHub Actions Insights)
3. **Gather producer feedback** (iterate on documentation)

---

## Success Criteria for This Demo

**✅ Demo is successful if audience sees**:
1. Simple YAML file (not XML or complex config)
2. Automated validation (no manual checks)
3. Automated deployment (no console clicking)
4. Green checkmarks (proof it works)
5. Under 10 minutes from YAML to deployed API

**✅ Demo answers the question**:
> *"Can any API producer use this platform without Apigee expertise?"*

**Answer**: *"Yes. They write 15 lines of YAML, open a PR, and the platform does the rest."*

---

## Cleanup After Demo (Optional)

```powershell
# If you want to remove the demo proxy
git checkout -b "chore/cleanup-demo-proxy-$timestamp"

# Delete demo proxy
Remove-Item -Recurse "mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/DEMO-PROXY-$timestamp"

# Commit and push
git add mal-SYSGEN788836350/
git commit -m "chore: remove demo proxy after presentation"
git push origin "chore/cleanup-demo-proxy-$timestamp"

# Open PR, merge (triggers undeploy workflow)
```

**Note**: Deleting the YAML file triggers undeploy workflow (if commit message contains "delete" or "remove")

---

## Additional Resources to Have Ready

1. **Production Readiness Evidence**: [PRODUCTION-READINESS-EVIDENCE.md](PRODUCTION-READINESS-EVIDENCE.md)
2. **API Producer Core Guide**: [api-producer-core.md](api-producer-core.md)
3. **Demo Script (detailed)**: [demo/PLATFORM-DEMO-SCRIPT.md](demo/PLATFORM-DEMO-SCRIPT.md)
4. **Test Results**: [guides/E2E-TESTING-DPEAPI-18719.md](guides/E2E-TESTING-DPEAPI-18719.md)
5. **Troubleshooting**: [API-PRODUCER-FAILURE-MODES.md](API-PRODUCER-FAILURE-MODES.md)

---

## Final Checklist

**Before starting demo**:
- [ ] Repository cloned and up-to-date
- [ ] GitHub Actions tab open in browser
- [ ] Pull Requests tab open in browser
- [ ] VS Code open with terminal ready
- [ ] This script open for reference
- [ ] Test branch cleaned up (no stale demo branches)
- [ ] (Optional) Bruno extension installed and tested

**Demo confidence boosters**:
- [ ] You've run through the demo once privately
- [ ] You know where to find validation workflow logs
- [ ] You know where to find deployment workflow logs
- [ ] You have backup examples ready (existing deployed proxies)

**Worst case fallback**:
- If live demo fails: Show existing deployed proxies + GitHub Actions history
- If network issues: Show pre-recorded workflow run (screenshot)
- If questions stump you: "Great question - it's documented in [filename], let me show you"

---

**Last Updated**: February 13, 2026  
**Next Review**: After first successful stakeholder demo  
**Feedback**: Update this guide based on demo experience
