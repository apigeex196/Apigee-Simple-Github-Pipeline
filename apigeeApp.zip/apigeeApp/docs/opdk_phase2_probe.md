# Phase-2 OPDK Management API Probe

Phase-2 uses OPDK Management API (port 8080, Basic Auth) as the source of truth.

## Requirements
- Python 3.8+
- `requests` library
- Network access to OPDK Management API host

## Environment Variables
- `OPDK_BASE_URL` (example: `http://4.72.75.223:8080`)
- `OPDK_ORG` (example: `ext` or actual org name)
- `OPDK_ENV` (example: `prod`)
- `OPDK_PROXY_NAME` (proxy to probe)
- `OPDK_USER`, `OPDK_PASS` (Basic Auth)
- `OPDK_DISABLE_SSL_VERIFY` (optional, set to `1` to disable SSL verification)

## Windows PowerShell Example
```powershell
$env:OPDK_BASE_URL="http://4.72.75.223:8080"
$env:OPDK_ORG="ext"
$env:OPDK_ENV="prod"
$env:OPDK_PROXY_NAME="Esp_ExtMed_34S_v1_ntfwSrvImpPort_a3c78fe9-c486-4c27-a235-35347e3315d4"
$env:OPDK_USER="your-user"
$env:OPDK_PASS="your-pass"
python scripts/opdk_probe.py
```

## Bash Example
```bash
OPDK_BASE_URL="http://4.72.75.223:8080" \
OPDK_ORG="ext" \
OPDK_ENV="prod" \
OPDK_PROXY_NAME="Esp_ExtMed_34S_v1_ntfwSrvImpPort_a3c78fe9-c486-4c27-a235-35347e3315d4" \
OPDK_USER="your-user" OPDK_PASS="your-pass" \
python3 scripts/opdk_probe.py
```

## Outputs
- Saves to `output/opdk_probe/<proxyName>/<timestamp>/`
  - `apis.json` — `/v1/organizations/{org}/apis/{proxy}` response
  - `env_apis.json` — `/v1/organizations/{org}/environments/{env}/apis/{proxy}` response
  - `errors.txt` — only if non-200 or non-JSON

## Console Summary
Prints key info if present:
- proxy name
- revisions
- deployed revision
- basePath
- virtualHosts
- targets / backend URLs (best-effort)

## Notes
- This probe is read-only and does not modify OPDK.
- If SSL verification needs to be disabled for testing, set `OPDK_DISABLE_SSL_VERIFY=1`.
