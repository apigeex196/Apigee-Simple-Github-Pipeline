# Repository Configuration

Documentation for GitHub repository settings configured for enterprise-apigeex-applications.

---

## General Settings

### Branch Auto-Deletion

**Setting**: Automatically delete head branches after PRs are merged

**Status**: ✅ Enabled (Dec 3, 2025)

**Command**:
```bash
gh repo edit CenturyLink/enterprise-apigeex-applications --delete-branch-on-merge
```

**Benefit**: Keeps repository clean, prevents stale branches

---

## Branch Protection Rules

### `main` Branch Protection

**Status**: ⏳ Requires manual web UI configuration

**Web UI Setup**: https://github.com/CenturyLink/enterprise-apigeex-applications/settings/branch_protection_rules/new

**Required Settings**:

#### Pull Request Requirements
- ✅ Require pull request before merging
- ✅ Require 1 approving review
- ✅ Dismiss stale reviews when new commits are pushed
- ✅ Require review from Code Owners (when CODEOWNERS exists)

#### Status Checks
- ✅ Require status checks to pass before merging
- ✅ Require branches to be up to date before merging

**Required Checks**:
- `validate-proxy` - Validates proxy YAML schema and configuration
- `validate-mal-structure` - Validates MAL folder structure and naming
- (More checks added as validation workflows are implemented)

#### Additional Rules
- ❌ Do not allow force pushes
- ❌ Do not allow deletions
- ⚠️ Do not require signed commits (optional, based on org policy)
- ⚠️ Include administrators in restrictions (recommended: false for platform team)

**Implementation Command** (run after validation workflows exist):
```bash
gh api repos/CenturyLink/enterprise-apigeex-applications/branches/main/protection \
  --method PUT \
  --field required_status_checks[strict]=true \
  --field required_status_checks[contexts][]=validate-proxy \
  --field required_status_checks[contexts][]=validate-mal-structure \
  --field required_pull_request_reviews[required_approving_review_count]=1 \
  --field required_pull_request_reviews[dismiss_stale_reviews]=true \
  --field required_pull_request_reviews[require_code_owner_reviews]=true \
  --field enforce_admins=false \
  --field required_linear_history=false \
  --field allow_force_pushes=false \
  --field allow_deletions=false
```

**Note**: Wait until Stories 5 and 7 (validation workflows) are implemented before enabling status checks.

---

## GitHub Environments

GitHub Environments provide deployment protection rules and secrets scoping.

### Development Environment

**Name**: `dev`

**Status**: ✅ Created (ID: 10399616672)

**Configuration**:
- No deployment protection rules (auto-deploy on merge to main)
- Secrets: Development service account credentials
- Target: `gcp-prj-apigee-dev-np-01` / `apicc-dev`

### Test Environment

**Name**: `test`

**Status**: ✅ Created (ID: 10399618639)

**Configuration**:
- Optional: Require reviewers (1 reviewer from platform team)
- Secrets: Test service account credentials
- Target: `gcp-prj-apigee-qa-np-01` / `apicc-test1`

**Add Protection (Web UI)**: https://github.com/CenturyLink/enterprise-apigeex-applications/settings/environments/10399618639/edit

### Production Environment

**Name**: `production`

**Status**: ✅ Created (ID: 10399620061) - ⏳ Protection rules pending

**Configuration**:
- ✅ **REQUIRED**: Manual approval from platform team
- ✅ Prevent self-review
- ✅ Wait timer: 1800 seconds (30 minutes)
- Secrets: Production service account credentials
- Target: `gcp-prj-apigee-prod-01` / `apicc-prod`

**Add Protection (Web UI)**: https://github.com/CenturyLink/enterprise-apigeex-applications/settings/environments/10399620061/edit

**Manual Setup Required**:
1. Navigate to production environment settings (link above)
2. Enable "Required reviewers" → Add yourself or API Enablement team
3. Enable "Prevent reviewers from approving their own deployments"
4. Set "Wait timer" to 1800 seconds (30 minutes)

**Production Deployment Workflow**:
1. PR merged to main → auto-deploys to dev
2. Manual trigger deploy-to-test workflow → requires test environment approval
3. Manual trigger deploy-to-prod workflow → requires production environment approval (2 reviewers)
4. Deployment blocked until approvals granted

---

## Repository Secrets

Secrets for GitHub Actions workflows.

### Organization-Level Secrets

Managed by CCOE/Platform Engineering:

- `GCP_SA_KEY_DEV` - Service account for dev deployments
- `GCP_SA_KEY_TEST` - Service account for test deployments
- `GCP_SA_KEY_PROD` - Service account for prod deployments
- `GCP_PROJECT_DEV` - GCP project ID for dev
- `GCP_PROJECT_TEST` - GCP project ID for test
- `GCP_PROJECT_PROD` - GCP project ID for prod

### Repository-Level Secrets

Managed by API Enablement team:

- Per-MAL secrets stored in GCP Secret Manager
- Naming: `sa-apigees-{mal-code}-{org}-{env}`
- Retrieved dynamically in workflows using `get-service-account` action

---

## Merge Settings

### Allowed Merge Types

**Status**: ✅ Configured (default settings)

**Recommended**:
- ✅ Allow squash merging (recommended for clean history)
- ✅ Allow merge commits (for preserving PR context)
- ⚠️ Allow rebase merging (optional, based on team preference)

**Default Merge Type**: Squash merge

**Command** (if changes needed):
```bash
gh repo edit CenturyLink/enterprise-apigeex-applications \
  --enable-squash-merge \
  --enable-merge-commit \
  --default-branch-merge-method squash
```

---

## Access Control

### Team Permissions

**Status**: ⏳ Pending team setup

**Recommended Teams**:

#### API Enablement (Maintain)
- Create/merge PRs
- Configure workflows
- Manage secrets
- Deploy to all environments

#### API Producers (Write)
- Create PRs for their MAL folders
- Trigger workflows
- View deployment status
- CODEOWNERS enforcement ensures they only modify their MAL

#### Platform Engineering (Admin)
- Repository administration
- Security settings
- Environment configuration
- Emergency deployments

**Setup**:
```bash
# Add teams (requires team IDs)
gh api repos/CenturyLink/enterprise-apigeex-applications/teams/{team-slug} \
  --method PUT \
  --field permission=maintain
```

---

## CODEOWNERS Configuration

**Status**: ⏳ Pending (configured per-MAL)

**Purpose**: Enforce that teams can only modify their own MAL folders

**Location**: Each MAL folder has its own `CODEOWNERS` file

**Example** (`mal-SYSGEN123456789/CODEOWNERS`):
```
* @CenturyLink/team-name @CenturyLink/api-enablement
```

**Enforcement**: Enabled via branch protection rule "Require review from Code Owners"

---

## Workflow Permissions

### Default GITHUB_TOKEN Permissions

**Status**: ✅ Configured (default settings acceptable)

**Current**:
- Read repository contents
- Write to packages (for caching)
- Read/write pull requests (for comments)

**Security**: Workflows use Workload Identity for GCP authentication, not long-lived tokens

---

## Implementation Checklist

### Completed ✅
- [x] Enable automatic branch deletion on merge

### Pending ⏳
- [ ] Create GitHub environments (dev, test, production)
- [ ] Configure production environment protection rules
- [ ] Enable branch protection for main (after validation workflows exist)
- [ ] Configure team access permissions
- [ ] Document secrets management process
- [ ] Set up CODEOWNERS review requirements
- [ ] Test deployment workflows with environment approvals

### Blocked 🚫
- Branch protection status checks → Blocked until Stories 5, 7 implemented
- Environment approvals → Blocked until deployment workflows exist (Stories 15-17)

---

## Testing & Validation

### Branch Protection Testing

After enabling:
1. Try to push directly to main → Should fail
2. Create PR without approval → Should block merge
3. Create PR with failing check → Should block merge
4. Create PR with approval + passing checks → Should allow merge

### Environment Protection Testing

After configuring:
1. Trigger dev deployment → Should auto-deploy
2. Trigger test deployment → Should require approval
3. Trigger prod deployment → Should require 2 approvals + wait timer
4. Self-approve prod deployment → Should fail (prevent self-review)

---

## Maintenance

### Adding New Status Checks

When new validation workflows are created:

```bash
# Get current protection rules
gh api repos/CenturyLink/enterprise-apigeex-applications/branches/main/protection

# Update with new check
gh api repos/CenturyLink/enterprise-apigeex-applications/branches/main/protection \
  --method PUT \
  --field required_status_checks[contexts][]=new-check-name \
  {other existing settings}
```

### Updating Environment Reviewers

```bash
# Update production environment reviewers
gh api repos/CenturyLink/enterprise-apigeex-applications/environments/production \
  --method PUT \
  --field reviewers[][type]=User \
  --field reviewers[][id]={user-id}
```

---

## Related Stories

- **Story 24 (DPEAPI-18717)**: Repository Configuration - Environments and Branch Protection
- **Story 5**: Validate Proxy YAML Schema (provides status check)
- **Story 7**: Validate MAL Structure (provides status check)
- **Story 15-17**: Deployment workflows (use environments)

---

## References

- [GitHub Branch Protection](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches)
- [GitHub Environments](https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment)
- [CODEOWNERS](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners)
- [GitHub API - Branch Protection](https://docs.github.com/en/rest/branches/branch-protection)
