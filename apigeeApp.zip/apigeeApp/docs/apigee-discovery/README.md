# Phase-2 POC: API Proxy Discovery Tool (ESP → proxy.yaml)

This minimal CLI extracts ONE proxy from the internal API Hub (ESP) endpoint and generates a schema-valid `proxy.yaml` per `apiproxy.schema.json`.

## Requirements
- Python 3.9+
- Install deps:

```bash
pip install -r requirements.txt
```

## Auth
- If `ESP_TOKEN` is set → uses Bearer auth
- Else if `ESP_USER` and `ESP_PASS` are set → uses Basic auth
- Else → exits with error

## Endpoint
Calls:
```
GET {ESP_BASE_URL}/Enterprise/v1/SOAEnablement/apiHub/v1/apiProxyDetails?env=<env>&offset=0&limit=20&sort=+resourceTaxonomy
```

## Usage

Windows PowerShell:
```powershell
$env:ESP_BASE_URL="https://esp.corp";
$env:ESP_USER="<username>"; $env:ESP_PASS="<password>";
python tools/apigee-discovery/discover.py extract \
  --proxy "Esp_ExtMed_34S_v1_ntfwSrvImpPort_a3c78fe9-c486-4c27-a235-35347e3315d4" \
  --env "prod" \
  --output "output/discovery" \
  --sysgen "SYSGEN788836350" \
  --taxonomy "/Channel/v1/Portal" \
  --template "oauth-proxy-oauth-backend" \
  --base-url $env:ESP_BASE_URL \
  --insecure
```

Linux/macOS bash:
```bash
export ESP_BASE_URL="https://esp.corp"
export ESP_USER="<username>"; export ESP_PASS="<password>"
python tools/apigee-discovery/discover.py extract \
  --proxy "Esp_ExtMed_34S_v1_ntfwSrvImpPort_a3c78fe9-c486-4c27-a235-35347e3315d4" \
  --env "prod" \
  --output "output/discovery" \
  --sysgen "SYSGEN788836350" \
  --taxonomy "/Channel/v1/Portal" \
  --template "oauth-proxy-oauth-backend" \
  --base-url "$ESP_BASE_URL" \
  --ca-bundle "/path/to/corp-ca.pem"
```

## Output
- Folder: `output/discovery/<proxyName>/<timestamp>/`
  - `proxy.yaml` — schema-valid per `apiproxy.schema.json`
  - `migration_notes.md` — minimal placeholder

## Notes
- Defensive parsing is used; only basic fields are mapped (name, description, basePath, target)
- If required labels (`sysgen`, `taxonomy`) are not available from ESP, provide via CLI
- Template must be one of schema enumerations; defaults to `oauth-proxy-oauth-backend`
