# Jira CSV Formatting - Quick Demo Script

## 🎯 Purpose
Show your team how to create Jira-ready CSV files with professional formatting (bold, headers, line breaks, code highlighting).

---

## 📋 Demo Flow (5 minutes)

### 1. Show the Problem (30 seconds)

**Open**: `docs/planning/jira-import.csv` (before formatting)

**Say**: "When we import plain text CSV to Jira, all formatting is lost. Look at this description - it's just one long paragraph."

**Show**: Plain text story in CSV → messy, hard to read in Jira

---

### 2. Explain the Solution (1 minute)

**Say**: "Jira supports Wiki Markup in CSV fields. We just need to use special syntax:"

| What You Want | Wiki Markup | Example |
|---------------|-------------|---------|
| Line break | `\\` | `Line 1\\Line 2` |
| Bold | `*text*` | `*As a* developer` |
| Header | `h4. Title` | `h4. ACCEPTANCE CRITERIA` |
| Code | `{{code}}` | `{{filename.yml}}` |
| List | `* Item` | `* Create file\\* Test it` |

**Show**: Quick reference from `CSV-FORMATTING-GUIDE.md`

---

### 3. Run the Automation (1 minute)

**Terminal**:
```bash
cd enterprise-apigeex-applications
python3 scripts/format-jira-csv.py
```

**Expected Output**:
```
📝 Formatting Jira CSV with Wiki Markup...
   Input: /path/to/jira-import.csv
✅ Complete!
   Formatted: 26/26 stories
```

**Say**: "The script automatically detected user stories, headers, lists, and code elements. It formatted all 26 stories in seconds."

---

### 4. Show the Results (1 minute)

**Open**: `docs/planning/jira-import.csv` (after formatting)

**Point out**:
- `*As a*` → Bold text in Jira
- `\\` → Line breaks
- `h4.` → Section headers
- `{{.github/workflows/file.yml}}` → Code formatting

**Show one story**:
```csv
"*As a* developer\\*I want* automated tools\\*So that* I save time\\\\h4. TECHNICAL DETAILS\\* *Location:* {{.github/actions/setup.yml}}\\\\h4. ACCEPTANCE CRITERIA\\* Create file\\* Install tools\\* Test it"
```

---

### 5. Import to Jira (1.5 minutes)

**Live Demo**:
1. Go to Jira → External System Import → CSV
2. Upload `jira-import.csv`
3. Map fields (Summary, Description, Story Points, etc.)
4. Import all 26 stories
5. **Open a story** → Show beautiful formatting:

**Renders as**:
> **As a** developer
> **I want** automated tools
> **So that** I save time
>
> #### TECHNICAL DETAILS
> • **Location:** `.github/actions/setup.yml`
>
> #### ACCEPTANCE CRITERIA
> • Create file
> • Install tools
> • Test it

**Say**: "Look at that! Professional formatting, clear sections, code highlighting. All from a CSV import."

---

### 6. Takeaways (30 seconds)

**Key Points**:
1. ✅ **Automated** - Script formats 26 stories in seconds
2. ✅ **Consistent** - Every story follows same formatting pattern
3. ✅ **Professional** - Stories are readable and well-structured
4. ✅ **Reusable** - Team can use script for future stories

**Resources**:
- `docs/planning/CSV-FORMATTING-GUIDE.md` - Complete guide
- `docs/planning/JIRA-IMPORT-INSTRUCTIONS.md` - Import instructions
- `scripts/format-jira-csv.py` - Automation script

---

## 🎬 Alternative: Before/After Comparison

If you want a more dramatic reveal:

### Before Formatting
```csv
"Description"
"As a developer I want tools So that I save time

TECHNICAL DETAILS:
Location: .github/actions/setup.yml
Install: yq, jq

ACCEPTANCE CRITERIA:
- Create file
- Install tools"
```

**Import to Jira** → Shows as one paragraph, no formatting

### After Formatting
```csv
"Description"
"*As a* developer\\*I want* tools\\*So that* I save time\\\\h4. TECHNICAL DETAILS\\* *Location:* {{.github/actions/setup.yml}}\\* *Install:* {{yq}}, {{jq}}\\\\h4. ACCEPTANCE CRITERIA\\* Create file\\* Install tools"
```

**Import to Jira** → Shows with headers, bold, code formatting, line breaks

---

## 💡 Common Questions

### Q: "Do we have to format manually?"
**A**: No! The script does it automatically. You write plain text, run the script, import to Jira.

### Q: "What if we need to update a story?"
**A**: Update the source, rerun the script, re-import (or update manually in Jira).

### Q: "Does this work with our Jira?"
**A**: Yes! Wiki Markup works in Jira Server, Data Center, and Cloud. It's the most compatible format.

### Q: "Can we customize the formatting?"
**A**: Yes! Edit `scripts/format-jira-csv.py` to change headers, add more code patterns, etc.

### Q: "How long does it take?"
**A**: Script runs in < 1 second for 26 stories. Import takes ~10 seconds in Jira.

---

## 📊 Impact Metrics

**Without formatting**:
- ❌ Stories are unreadable walls of text
- ❌ Hard to find acceptance criteria
- ❌ No visual hierarchy
- ❌ Manual formatting takes 2-3 min per story × 26 = 1 hour

**With automated formatting**:
- ✅ Professional, readable stories
- ✅ Clear sections with headers
- ✅ Code elements highlighted
- ✅ Automated formatting takes < 1 second for all 26 stories

**Time Saved**: ~59 minutes per import

---

## 🚀 Next Steps for Team

1. **Use the script** for all future Jira imports
2. **Customize** formatting patterns in `format-jira-csv.py`
3. **Share** this guide with other teams
4. **Standardize** on Wiki Markup for all Jira content

---

**Need Help?** See `docs/planning/CSV-FORMATTING-GUIDE.md` for detailed examples and troubleshooting.
