# Applications Repo - Multi-Org/Multi-Env Migration Analysis

## Executive Summary

The `enterprise-apigeex-applications` repository requires implementation of multi-org/multi-env deployment capabilities, following the pattern established in `enterprise-apigeex-gitops`.

**Good News**: Applications repo already outputs **space-separated** file lists, avoiding the critical comma-to-space bug that plagued gitops. However, it currently lacks:
- Matrix strategy for parallel multi-org deployments
- Isolated failure handling (`fail-fast: false`)
- Org detection logic for dynamic matrix generation

---

## Current Architecture

### Workflow Structure

Applications repo has **environment-specific deployment workflows**:
```
.github/workflows/
├── deploy-to-dev.yml       # Hardcoded to gcp-prj-apigee-dev-np-01
├── deploy-to-test.yml      # Hardcoded to QA org
├── deploy-to-prod.yml      # Hardcoded to PROD org
└── deploy-products.yml     # Manual env selection via workflow_dispatch
```

**Key Differences from GitOps**:
1. **One workflow per environment** (vs. one workflow per resource type in gitops)
2. **Hardcoded org names** in each workflow (vs. dynamic org detection)
3. **MAL-based structure** (`mal-SYSGEN*/orgs/*/envs/*/proxies/`) vs. pure org structure
4. **Space-separated outputs** from `changed-files` action (✅ no comma bug!)

### Composite Actions

Applications repo has rich composite actions:
```
.github/actions/
├── changed-files/              ✅ Outputs space-separated (no comma bug)
├── deploy-product/             Deploys single product
├── deploy-proxy/               Deploys single proxy
├── download-template/          Downloads template bundle
├── extract-mal-metadata/       Extracts MAL code
├── get-service-account/        Gets GCP SA for org
├── import-deploy-proxy/        Imports and deploys proxy
├── manage-kvms/                KVM management
├── setup-apigee-tooling/       Sets up apigeecli, yq, etc.
├── validate-mal-structure/     Validates MAL directory structure
├── validate-product/           Validates product YAML
└── validate-proxy/             Validates proxy YAML
```

---

## Required Changes

### Phase 1: Create Org Detection Action

**New File**: `.github/actions/apigee-org/action.yml`

Unlike gitops, applications repo needs to extract org from MAL-based paths:
```
mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/MyProxy/proxy.yaml
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                Extract this
```

**Implementation**:
```yaml
name: 'apigee-org'
description: 'Extract unique Apigee organizations from changed files for matrix strategy'
inputs:
  changed_files:
    description: 'Space-separated list of changed files'
    required: true
  deleted_files:
    description: 'Space-separated list of deleted files'
    required: false
outputs:
  org_matrix:
    description: 'JSON array of unique Apigee orgs for matrix strategy'
    value: ${{ steps.extract-orgs.outputs.org_matrix }}

runs:
  using: 'composite'
  steps:
    - name: Extract unique Apigee orgs
      id: extract-orgs
      shell: bash
      run: |
        set -e

        ORGS=""

        # Process changed files (space-separated - no conversion needed!)
        if [ -n "${{ inputs.changed_files }}" ]; then
          for file in ${{ inputs.changed_files }}; do
            # Extract org from path: mal-*/orgs/{ORG_NAME}/envs/...
            if [[ "$file" =~ mal-SYSGEN[0-9]{9}/orgs/([^/]+)/envs/ ]]; then
              ORG="${BASH_REMATCH[1]}"
              if [[ ! " $ORGS " =~ " $ORG " ]]; then
                ORGS="$ORGS $ORG"
              fi
            fi
          done
        fi

        # Process deleted files
        if [ -n "${{ inputs.deleted_files }}" ]; then
          for file in ${{ inputs.deleted_files }}; do
            if [[ "$file" =~ mal-SYSGEN[0-9]{9}/orgs/([^/]+)/envs/ ]]; then
              ORG="${BASH_REMATCH[1]}"
              if [[ ! " $ORGS " =~ " $ORG " ]]; then
                ORGS="$ORGS $ORG"
              fi
            fi
          done
        fi

        # Convert to JSON array
        ORGS=$(echo "$ORGS" | xargs)  # Trim whitespace
        if [ -z "$ORGS" ]; then
          ORG_MATRIX="[]"
        else
          ORG_MATRIX=$(echo "$ORGS" | jq -R 'split(" ") | map(select(length > 0))')
        fi

        echo "org_matrix=$ORG_MATRIX" >> $GITHUB_OUTPUT
        echo "Detected orgs: $ORG_MATRIX"
```

### Phase 2: Create File Filter Action

**New File**: `.github/actions/filter-files-by-org/action.yml`

Filter files to only those belonging to specific org (for matrix jobs):

```yaml
name: 'filter-files-by-org'
description: 'Filter file lists to only those belonging to a specific Apigee org'
inputs:
  changed_files:
    description: 'Space-separated list of changed files'
    required: false
  deleted_files:
    description: 'Space-separated list of deleted files'
    required: false
  org:
    description: 'Apigee organization to filter for'
    required: true
outputs:
  changed_files:
    description: 'Space-separated list of changed files for this org'
    value: ${{ steps.filter.outputs.changed_files }}
  deleted_files:
    description: 'Space-separated list of deleted files for this org'
    value: ${{ steps.filter.outputs.deleted_files }}

runs:
  using: 'composite'
  steps:
    - name: Filter files by org
      id: filter
      shell: bash
      run: |
        set -e

        ORG="${{ inputs.org }}"
        CHANGED=""
        DELETED=""

        # Filter changed files (space-separated - no conversion needed!)
        if [ -n "${{ inputs.changed_files }}" ]; then
          for file in ${{ inputs.changed_files }}; do
            if [[ "$file" =~ mal-SYSGEN[0-9]{9}/orgs/$ORG/ ]]; then
              CHANGED="$CHANGED $file"
            fi
          done
        fi

        # Filter deleted files
        if [ -n "${{ inputs.deleted_files }}" ]; then
          for file in ${{ inputs.deleted_files }}; do
            if [[ "$file" =~ mal-SYSGEN[0-9]{9}/orgs/$ORG/ ]]; then
              DELETED="$DELETED $file"
            fi
          done
        fi

        # Clean up whitespace
        CHANGED=$(echo "$CHANGED" | xargs)
        DELETED=$(echo "$DELETED" | xargs)

        echo "changed_files=$CHANGED" >> $GITHUB_OUTPUT
        echo "deleted_files=$DELETED" >> $GITHUB_OUTPUT

        echo "Filtered files for org $ORG:"
        echo "  Changed: $CHANGED"
        echo "  Deleted: $DELETED"
```

### Phase 3: Refactor Deployment Workflows

**Option A: Single Unified Workflow (Recommended)**

Create **one workflow** to replace all three environment-specific workflows:

**New File**: `.github/workflows/deploy-proxy.yml`

```yaml
---
name: Deploy API Proxies

on:
  workflow_dispatch:
    inputs:
      changed_files:
        description: "Comma-separated list of changed proxy files"
        required: false
  push:
    branches:
      - main
    paths:
      - "mal-SYSGEN*/orgs/**/proxies/**/*.yaml"

permissions:
  contents: read
  id-token: write

jobs:
  detect-changes:
    runs-on: ubuntu-latest
    outputs:
      org_matrix: ${{ steps.get-orgs.outputs.org_matrix }}
      changed_files: ${{ steps.changed-files.outputs.changed_files }}
      deleted_files: ${{ steps.changed-files.outputs.deleted_files }}
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Get changed files
        id: changed-files
        uses: ./.github/actions/changed-files
        with:
          changed_files: ${{ github.event.inputs.changed_files }}

      - name: Get Apigee organizations
        id: get-orgs
        uses: ./.github/actions/apigee-org
        with:
          changed_files: ${{ steps.changed-files.outputs.changed_files }}
          deleted_files: ${{ steps.changed-files.outputs.deleted_files }}

  deploy:
    needs: detect-changes
    if: needs.detect-changes.outputs.org_matrix != '[]'
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        org: ${{ fromJson(needs.detect-changes.outputs.org_matrix) }}
    environment:
      name: ${{ matrix.org }}
    env:
      APIGEE_ORG: ${{ matrix.org }}
    steps:
      - uses: actions/checkout@v4

      - name: Setup Apigee Tooling
        uses: ./.github/actions/setup-apigee-tooling

      - name: Filter files for this org
        id: filter
        uses: ./.github/actions/filter-files-by-org
        with:
          changed_files: ${{ needs.detect-changes.outputs.changed_files }}
          deleted_files: ${{ needs.detect-changes.outputs.deleted_files }}
          org: ${{ matrix.org }}

      - name: Get Service Account
        id: get-sa
        uses: ./.github/actions/get-service-account
        with:
          org: ${{ matrix.org }}

      - name: Authenticate with GCP
        env:
          GCP_SA_KEY: ${{ steps.get-sa.outputs.sa_key }}
        run: |
          # Authentication logic

      - name: Deploy Proxies
        env:
          CHANGED_FILES: ${{ steps.filter.outputs.changed_files }}
        run: |
          # Existing deployment logic from deploy-to-dev.yml
          # Already uses space-separated files - no changes needed!
          for file in $CHANGED_FILES; do
            # Deploy each proxy
          done
```

**Option B: Keep Separate Workflows, Add Matrix Strategy**

Modify each existing workflow (`deploy-to-dev.yml`, `deploy-to-test.yml`, `deploy-to-prod.yml`) to:
1. Add `detect-changes` job
2. Add matrix strategy (but filter to only target org)
3. Support multi-environment within that org

### Phase 4: Update Validation Workflows

**File**: `.github/workflows/validate-proxy.yml`

Add matrix detection (similar to deployment):
```yaml
jobs:
  detect-changes:
    # Same as deployment workflow

  validate:
    needs: detect-changes
    if: needs.detect-changes.outputs.org_matrix != '[]'
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        org: ${{ fromJson(needs.detect-changes.outputs.org_matrix) }}
    steps:
      # Filter files for this org
      # Run validation
```

---

## Files That Do NOT Need Changes

✅ **File iteration loops** - Already space-separated, no comma-to-space conversion needed
✅ **`.github/actions/changed-files/action.yml`** - Already outputs space-separated
✅ **Composite actions** (deploy-proxy, deploy-product, etc.) - Already handle space-separated
✅ **KVM management** - Already uses space-separated file iteration

---

## Migration Complexity Assessment

### Low Complexity ✅
- No comma-to-space bugs to fix (main issue in gitops)
- Composite actions already robust
- File iteration patterns already correct

### Medium Complexity ⚠️
- Need to create new composite actions (apigee-org, filter-files-by-org)
- Matrix strategy implementation in workflows
- Service account secret mapping (org-specific secrets)

### High Complexity 🚨
- MAL-based path structure adds complexity to org extraction
- Need to decide: unified workflow vs. per-environment workflows
- Products workflow already has some detection logic - needs alignment
- Multiple environments per org requires proper filtering

---

## Recommended Approach

### Step 1: Create Composite Actions (1-2 hours)
1. Create `.github/actions/apigee-org/action.yml`
2. Create `.github/actions/filter-files-by-org/action.yml`
3. Test both actions independently

### Step 2: Migrate One Workflow First (2-3 hours)
Start with **`deploy-products.yml`** (simplest):
1. Add `detect-changes` job
2. Add matrix strategy
3. Add file filtering
4. Test with multi-org PR

### Step 3: Migrate Proxy Deployment (3-4 hours)
Two options:
- **Option A**: Create single unified `deploy-proxy.yml` (recommended)
- **Option B**: Update all three environment workflows

### Step 4: Migrate Validation Workflows (2-3 hours)
1. Update `validate-proxy.yml`
2. Update `validate-product.yml`
3. Test with multi-org PR

### Step 5: Comprehensive Testing (4-6 hours)
1. Single-org deployment (backward compatibility)
2. Multi-org deployment (new capability)
3. Multi-environment within org
4. Isolated failure testing
5. Validation workflow testing

**Total Estimated Time**: 12-18 hours

---

## Testing Strategy

### Phase 1: Component Testing
- Test `apigee-org` action with various file paths
- Test `filter-files-by-org` action with mixed org files
- Verify output formats (JSON array for matrix)

### Phase 2: Workflow Testing
1. **Single-org PR** (backward compatibility):
   ```
   mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/test.yaml
   ```

2. **Multi-org PR** (new feature):
   ```
   mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/test.yaml
   mal-SYSGEN788836350/orgs/gcp-prj-apigee-qa-np-01/envs/apicc-test1/proxies/test.yaml
   mal-SYSGEN788836350/orgs/gcp-prj-apigee-prod-01/envs/apicc-prod/proxies/test.yaml
   ```

3. **Multi-environment, single org**:
   ```
   mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/test.yaml
   mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev1/proxies/test.yaml
   ```

4. **Isolated failure**: Include invalid resource in one org, verify others succeed

### Phase 3: Production Validation
- Use Pawel's typical multi-env PR patterns
- Verify deployments in Apigee X console
- Check GitHub Actions logs for proper matrix execution

---

## Key Differences from GitOps Implementation

| Aspect | GitOps Repo | Applications Repo |
|--------|-------------|-------------------|
| **File Output Format** | Comma-separated ❌ | Space-separated ✅ |
| **Comma-to-Space Bug** | 17 locations to fix | 0 locations (no bug) |
| **Path Structure** | `orgs/{org}/envs/{env}/apigeeproxies/` | `mal-{code}/orgs/{org}/envs/{env}/proxies/` |
| **Workflow Structure** | One per resource type | One per environment |
| **Org Detection** | Simple path parsing | Regex with MAL prefix |
| **Current Capability** | None (all new) | Environment-specific (hardcoded) |
| **Migration Complexity** | High (many bugs) | Medium (architecture change) |

---

## Risk Assessment

### Low Risk ✅
- File iteration already correct (no comma bug)
- Composite actions well-structured
- Clear separation of concerns

### Medium Risk ⚠️
- Workflow refactoring (unified vs. per-env decision)
- Service account secret management across orgs
- Existing PRs may need rebasing after migration

### High Risk 🚨
- Breaking backward compatibility if not careful
- MAL structure parsing errors could cause silent failures
- Race conditions (same as gitops - products before proxies)

### Mitigation Strategies
1. **Incremental rollout**: Products → Proxies → Validation
2. **Feature flag**: Use workflow_dispatch to enable/disable multi-org
3. **Comprehensive testing**: Test all org combinations before production
4. **Rollback plan**: Keep old workflows as `*-legacy.yml` for quick revert

---

## Open Questions

1. **Workflow Architecture**:
   - Unified workflow (one for all orgs) vs. per-environment workflows?
   - Recommendation: Start unified, easier to maintain

2. **Service Account Management**:
   - How are org-specific secrets named? (e.g., `GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01`)
   - Need composite action for dynamic secret retrieval?

3. **Environment Mapping**:
   - Does deployment always use specific env names per org?
   - Or can one PR deploy to multiple envs in one org?

4. **MAL Code**:
   - Should matrix include MAL code dimension?
   - Or is one PR always one MAL code?

5. **Product Dependencies**:
   - Same race condition as gitops (products before proxies)?
   - Need orchestration or accept retry pattern?

---

## Next Steps

1. **Review this analysis** with team
2. **Answer open questions** above
3. **Decide workflow architecture** (unified vs. per-env)
4. **Create composite actions** (apigee-org, filter-files-by-org)
5. **Implement in dev branch** for testing
6. **Test with non-production resources** first
7. **Rollout to production** after validation

---

**Analysis Date**: December 16, 2025
**Analyzed By**: GitHub Copilot
**Based On**: GitOps implementation (v1.0, production-ready)
**Status**: Ready for implementation planning
