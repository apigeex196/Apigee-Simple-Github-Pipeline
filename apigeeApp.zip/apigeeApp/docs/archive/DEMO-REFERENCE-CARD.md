# 🎴 Demo Quick Reference Card - Print This!

**Print this page and keep it next to your laptop during the demo**

---

## ⏱️ TIMING (7-10 minutes total)

| Time | Section | Key Point |
|------|---------|-----------|
| 0:00-0:30 | HOOK | "26 stories in 5 min" |
| 0:30-2:30 | COPILOT | Show chat conversation |
| 2:30-4:00 | CSV | Show Story 1 details |
| 4:00-6:00 | SCRIPT | Run automation |
| 6:00-8:00 | JIRA | Import & show formatting |
| 8:00-9:00 | DASHBOARD | Auto-updating |
| 9:00-9:30 | IMPACT | "95% time savings" |

---

## 💻 TERMINAL COMMAND

```bash
python3 scripts/format-jira-csv.py
```

**Expected output**:
```
📝 Formatting Jira CSV...
✅ Complete! Formatted: 26/26 stories
```

---

## 🌐 BROWSER TABS (in order, left to right)

1. GitHub Copilot Chat
2. VSCode (project open)
3. jira-import.csv (Excel)
4. Jira (ready to import)
5. Confluence (dashboard)

---

## 🎯 KEY TALKING POINTS

### Opening Hook
> "26 stories in 5 minutes instead of 3 hours"

### Copilot Benefit
> "Like having a thoughtful pair programming partner"

### Script Power
> "26 stories formatted in < 1 second"

### Formatting Quality
> "Headers, bold, code highlighting - all preserved"

### Dashboard Value
> "Auto-updating, zero maintenance"

### Impact Statement
> "95% time savings + higher quality"

---

## 📋 JIRA IMPORT STEPS

1. Settings → External System Import → CSV
2. Upload `jira-import.csv`
3. Map fields (Summary, Description, Points)
4. Import (takes ~10 seconds)
5. Open Story 1 → Show formatting

---

## 🔧 WIKI MARKUP EXAMPLES

| Want | Markup | Result |
|------|--------|--------|
| Line break | `\\` | New line |
| Bold | `*text*` | **text** |
| Header | `h4. Title` | #### Title |
| Code | `{{code}}` | `code` |
| List | `* Item` | • Item |

---

## 💬 Q&A RESPONSES

### "Did you edit the output?"
"Yes, 10-15 min of refinement. Still way faster than writing from scratch."

### "Does this work for any project?"
"Yes! The key is giving Copilot good context about your project."

### "Can we use this?"
"Absolutely! Script is in repo with full docs. Happy to help anyone."

### "How hard is the dashboard?"
"15 minutes. Just Jira macros in Confluence with JQL queries."

### "How to prompt Copilot?"
"Be conversational. Give context. Start broad, refine iteratively."

---

## 🚨 IF SOMETHING BREAKS

### Script fails
→ Show before/after screenshots

### Can't import to Jira
→ Show pre-imported story

### Projector fails
→ Gather around laptop screen

### Forgot your line
→ Glance at this card!

### Awkward silence
→ Ask "Questions so far?"

---

## ✅ RESOURCES TO SHARE

**After demo, share these**:

- GitHub repo link
- `docs/planning/CSV-FORMATTING-GUIDE.md`
- `docs/planning/DEMO-SCRIPT.md`
- `scripts/format-jira-csv.py`
- Your availability for office hours

---

## 🎯 SUCCESS = THESE REACTIONS

- "I want to try this!"
- "Can you share that script?"
- "How do I learn Copilot better?"
- "We should standardize on this"

---

## 💪 CONFIDENCE REMINDERS

✅ You built this whole workflow
✅ You have documentation and backups
✅ Real work with measurable impact
✅ You know this better than anyone
✅ Your team wants you to succeed

---

## 🎬 OPENING LINES (if you blank)

> "I want to show you something that changed how I work this week."

> "I had to create 26 user stories. Normally takes 2-3 hours."

> "I did it in 5 minutes. Let me show you how."

---

## 🏁 CLOSING LINES (for strong finish)

> "26 stories generated, formatted, and imported."

> "5 minutes of work instead of 3 hours."

> "That's a 95% time savings."

> "And the stories came out better quality."

> "The script and docs are in our repo. Happy to help anyone try it."

> "Questions?"

---

## 📊 THE IMPACT NUMBERS (memorize these)

- **26** user stories generated
- **5 minutes** total time (new way)
- **3 hours** total time (old way)
- **95%** time savings
- **< 1 second** to format all stories
- **10 seconds** to import to Jira

---

## 🎤 PRESENTER REMINDERS

### Before You Start
- Deep breath
- Smile
- Make eye contact
- You've got this!

### While Presenting
- Speak up (project to back)
- Slow down (especially for numbers)
- Pause after reveals
- Look at audience, not screen

### Energy Level
- Enthusiastic but not over-top
- Friendly and approachable
- Confident, not arrogant
- Excited to share

---

## 🔄 RECOVERY PHRASES (if you mess up)

> "Let me try that again..."

> "Whoops, let me go back..."

> "Actually, even better..."

> "You know what, let me show you..."

**Don't apologize excessively! Just recover and move on.**

---

## ⚡ FINAL PRE-DEMO CHECK

Physical:
- [ ] Laptop charged
- [ ] Adapters packed
- [ ] This card printed
- [ ] Water nearby

Technical:
- [ ] Browser tabs open
- [ ] Terminal ready
- [ ] Font sizes large
- [ ] Notifications off

Mental:
- [ ] Deep breath
- [ ] Visualize success
- [ ] Remember: Team wants you to succeed
- [ ] You know your stuff!

---

## 🎉 YOU'VE GOT THIS!

Remember:
- The work is solid
- You're prepared
- You have backups
- Your team will benefit

**Now go deliver a killer demo!** 🚀

---

**Fold this page in half and keep next to laptop → Glance when needed → Confidence boost!**
