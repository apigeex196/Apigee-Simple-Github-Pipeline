# ✅ Demo Day Checklist - Don't Present Without This!

## 🌅 The Day Before

### Technical Setup
- [ ] **Run the script once** to verify it works
  ```bash
  cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications
  python3 scripts/format-jira-csv.py
  ```
- [ ] **Verify Jira access** - Can you log in? Import CSV?
- [ ] **Check Confluence access** - Dashboard loads correctly?
- [ ] **Test on presentation machine** - If different from dev machine
- [ ] **Clear terminal history** - Start with clean slate
- [ ] **Increase terminal font size** - Readable from back of room
- [ ] **Clear browser tabs** - Only what you need open
- [ ] **Disable notifications** - Slack, email, calendar

### Content Preparation
- [ ] **Review DEMO-PRACTICE-SCRIPT.md** - Read through 2-3 times
- [ ] **Time yourself** - Should be 7-10 minutes
- [ ] **Prepare backup plan** - Screenshots if live demo fails
- [ ] **Create slide deck** (optional) - Use DEMO-SLIDES-OUTLINE.md
- [ ] **Bookmark resources** - Ready to share links

### Physical Preparation
- [ ] **Charge laptop** - Don't rely on battery alone
- [ ] **Bring power adapter** - Just in case
- [ ] **Bring HDMI/USB-C adapter** - For projector
- [ ] **Print DEMO-CHEATSHEET.md** - Quick reference on paper
- [ ] **Get good sleep** - Seriously, don't stay up late

---

## 🌄 Morning Of Demo

### Personal Prep
- [ ] **Eat something** - Don't present hungry
- [ ] **Coffee/tea** (if that's your thing) - Alert but not jittery
- [ ] **Review cheat sheet** - Quick 5-minute refresh
- [ ] **Visualize success** - Imagine the demo going well
- [ ] **Deep breaths** - You've got this

### Final Checks
- [ ] **Laptop fully charged**
- [ ] **All cables packed**
- [ ] **Cheat sheet printed or on phone**
- [ ] **Backup screenshots on USB drive** (paranoid, but smart)

---

## ⏰ 30 Minutes Before Demo

### Arrival
- [ ] **Arrive early** - Scout the room, reduce anxiety
- [ ] **Test projector connection** - HDMI? Wireless? Resolution?
- [ ] **Test audio** (if presenting remotely) - Mic, speakers working?
- [ ] **Check room temperature** - Adjust if needed
- [ ] **Find water** - Have some nearby

### Technical Final Check
- [ ] **Connect to WiFi** - Verify internet access
- [ ] **Close unnecessary apps** - Free up RAM, reduce distractions
- [ ] **Disable auto-sleep** - Keep screen active during demo
- [ ] **Set Do Not Disturb** - No pop-ups during demo

### Browser Setup
- [ ] **Open tabs in order** (left to right):
  1. GitHub Copilot Chat
  2. VSCode with project open
  3. jira-import.csv (Excel or text editor)
  4. Jira (ready to import)
  5. Confluence dashboard
- [ ] **Zoom to 125%** - Readable from audience
- [ ] **Test each tab** - Everything loads correctly?

### Terminal Setup
- [ ] **Open terminal at project root**
  ```bash
  cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications
  ```
- [ ] **Increase font size** - Cmd + + until readable
- [ ] **Clear screen** - `clear` command for clean start
- [ ] **Test script** (optional) - Quick run to verify

### VSCode Setup
- [ ] **Open project folder**
- [ ] **Increase font size** - Zoom to 150-175%
- [ ] **Close unnecessary panels** - Focus on files
- [ ] **Have key files ready**:
  - `scripts/format-jira-csv.py`
  - `docs/planning/jira-import.csv`
  - `docs/planning/DEMO-CHEATSHEET.md`

---

## ⏰ 5 Minutes Before Demo

### Mental Prep
- [ ] **Deep breaths** - In for 4, hold for 4, out for 4
- [ ] **Review opening hook** - First 30 seconds matter most
- [ ] **Smile** - Friendly, approachable energy
- [ ] **Visualize success** - See yourself nailing it

### Final Visual Check
- [ ] **Screen mirroring correctly** - Audience sees what you see?
- [ ] **Everything readable** - Font sizes good?
- [ ] **Cheat sheet accessible** - Glance down if needed
- [ ] **Water nearby** - Stay hydrated

### Tech Double-Check
- [ ] **Phone on silent** - Seriously, double-check this
- [ ] **Slack/Teams quit** - No notification pop-ups
- [ ] **Calendar closed** - No meeting reminders
- [ ] **Terminal ready** - At project root, large font

---

## 🎬 During Demo

### Opening (0:00-0:30)
- [ ] **Make eye contact**
- [ ] **Speak clearly**
- [ ] **Deliver hook**: "26 stories in 5 minutes"
- [ ] **Pause for effect**

### Act 1: Copilot Chat (0:30-2:30)
- [ ] **Switch to Copilot Chat tab**
- [ ] **Scroll through conversation**
- [ ] **Explain context given to Copilot**
- [ ] **Show iterative refinement**

### Act 2: CSV Output (2:30-4:00)
- [ ] **Switch to CSV tab**
- [ ] **Show Story 1**
- [ ] **Point out key fields**
- [ ] **Explain formatting problem**

### Act 3: Automation (4:00-6:00)
- [ ] **Switch to terminal**
- [ ] **Run script**: `python3 scripts/format-jira-csv.py`
- [ ] **Show output**
- [ ] **Switch back to CSV**
- [ ] **Show Wiki Markup codes**

### Act 4: Jira Import (6:00-8:00)
- [ ] **Switch to Jira tab**
- [ ] **Navigate to CSV import**
- [ ] **Upload file**
- [ ] **Map fields**
- [ ] **Import**
- [ ] **Open imported story**
- [ ] **Show beautiful formatting**
- [ ] **Pause to let it sink in**

### Act 5: Dashboard (8:00-9:00)
- [ ] **Switch to Confluence tab**
- [ ] **Show dashboard sections**
- [ ] **Explain auto-updating**

### Closing (9:00-9:30)
- [ ] **Step away from screen**
- [ ] **Deliver impact numbers**: 5 min vs 3 hours = 95% savings
- [ ] **Mention quality benefits**
- [ ] **Offer to share resources**
- [ ] **Open for questions**

---

## 🔥 If Something Goes Wrong

### Script Doesn't Run
- **Backup**: Show before/after screenshots
- **Explain**: "I ran this earlier, here's what it produced"
- **Show**: The formatted CSV anyway

### Can't Import to Jira
- **Backup**: Show pre-imported story
- **Explain**: "I imported earlier, here's how it looks"
- **Show**: The formatted Jira story

### Projector Fails
- **Backup**: Use your laptop screen, gather around
- **Backup**: Email slides/screenshots to team
- **Backup**: Reschedule if needed (don't force it)

### Forgot Your Line
- **Glance**: At cheat sheet (that's why you printed it)
- **Pause**: Take a breath, collect thoughts
- **Recover**: "Let me show you..." and move to next part

### Audience Looks Confused
- **Pause**: Ask "Does this make sense so far?"
- **Clarify**: Address confusion before moving on
- **Slow down**: You might be going too fast

### Awkward Silence
- **That's OK**: Silence isn't bad, especially after big reveals
- **Let it land**: Give people time to process
- **Ask**: "Questions so far?" to break silence

---

## ✅ After Demo

### Immediate (While Everyone's There)
- [ ] **Answer all questions**
- [ ] **Share screen for links** - Type them in chat
- [ ] **Offer office hours** - "Happy to pair with anyone"
- [ ] **Thank everyone** - Appreciate their time

### Within 1 Hour
- [ ] **Share recording** (if recorded) - Post to Slack/Teams
- [ ] **Share links**:
  - GitHub repo
  - Documentation path: `docs/planning/`
  - Specific guides: DEMO-SCRIPT.md, CSV-FORMATTING-GUIDE.md
- [ ] **Offer availability**: "Ping me if you want to try this"

### Within 24 Hours
- [ ] **Follow up on action items** - Anyone who expressed interest
- [ ] **Schedule office hours** - If multiple people interested
- [ ] **Share to wider audience** - Other teams, leadership
- [ ] **Write quick summary** - Post to internal blog/wiki

### Within 1 Week
- [ ] **Pair with interested teammates** - Help them try it
- [ ] **Collect feedback** - What worked? What didn't?
- [ ] **Iterate on documentation** - Improve based on feedback
- [ ] **Consider broader presentation** - Eng all-hands?

---

## 📊 Success Indicators

### Immediate Reactions (During/After Demo)
- ✅ "Wow, that's fast!"
- ✅ "Can I try this on my project?"
- ✅ "How do I get better at prompting Copilot?"
- ✅ "We should standardize on this"
- ✅ Engaged questions (not just polite silence)

### Follow-Up Engagement
- ✅ Multiple people reach out to try it
- ✅ Someone schedules pairing session
- ✅ Script gets used on other projects
- ✅ Documentation gets read/referenced
- ✅ Team adopts this workflow

### Long-Term Impact
- ✅ Faster sprint planning across team
- ✅ More Copilot usage on team
- ✅ Fewer manual Jira formatting tasks
- ✅ Other teams ask to see the demo
- ✅ Becomes "the way we do this"

---

## 🎯 Confidence Boosters

### You Know Your Stuff
- ✅ You built this whole workflow
- ✅ You've used it successfully
- ✅ You have documentation and backups
- ✅ You can answer technical questions

### The Content Is Solid
- ✅ Real work, not a toy example
- ✅ Measurable impact (95% time savings)
- ✅ Practical and immediately useful
- ✅ Reproducible by teammates

### You're Prepared
- ✅ You've practiced
- ✅ You have cheat sheets
- ✅ You have backups
- ✅ You know what can go wrong

### The Stakes Are Low
- ✅ This is your team, not a conference
- ✅ Everyone wants you to succeed
- ✅ Even if something breaks, you can recover
- ✅ The work speaks for itself

---

## 🗣️ Pre-Presentation Affirmations

Read these before you start:

> "I built something useful and I'm excited to share it."

> "I know this material better than anyone else in the room."

> "If something goes wrong, I have backup plans."

> "My team will benefit from learning this."

> "I'm helping people save time and work smarter."

> "I've got this."

---

## 📞 Emergency Contacts

**If you need help day-of**:
- Tech support: [Your team's support channel]
- Backup presenter: [Colleague who knows the material]
- A/V support: [IT contact for projector issues]

**If you need to reschedule**:
- It's OK! Better to reschedule than rush a bad demo
- "Sorry team, technical issues - I'll reschedule for tomorrow"
- Use the time to fix issues and prepare better

---

## 🎉 Final Reminders

### You've Already Won
- ✅ You built a killer workflow
- ✅ You documented it thoroughly
- ✅ You saved yourself 95% of time
- ✅ The demo is just sharing what you did

### The Demo Is About Them
- Not showing off your skills
- Helping teammates work smarter
- Sharing tools and techniques
- Building team capability

### Perfection Isn't Required
- Live demos have hiccups - that's normal
- Your enthusiasm matters more than polish
- The content is strong - lean on that
- You can always share recording/docs after

---

## ✨ You're Ready!

**Final check**: Do you have...
- [ ] Laptop (charged)
- [ ] Power adapter
- [ ] HDMI/USB-C adapter
- [ ] Printed cheat sheet
- [ ] Water
- [ ] Confidence

**If you checked all boxes, you're ready to deliver a killer demo. Go get 'em!** 🚀

---

**P.S.** After you nail this demo, come back and check these off:

- [ ] Demo delivered successfully ✅
- [ ] Team was impressed 🎉
- [ ] Resources shared 📚
- [ ] Follow-ups scheduled 📅
- [ ] Feeling proud 💪

**You've got this!**
