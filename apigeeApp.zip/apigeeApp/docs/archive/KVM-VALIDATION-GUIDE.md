# KVM Validation Guide

## Overview

KVM (Key-Value Map) creation failures can cause proxy deployments to fail. This guide explains how we prevent KVM-related deployment failures through comprehensive PR-time validation.

## What We Validate

### 1. **Secret Availability** (PR Time)

The `validate-proxy.yml` workflow checks that all secrets required by a proxy are available in the workflow's environment block.

**Validation checks:**
- Extracts `spec.secrets[]` from proxy YAML
- Compares against available secrets in `deploy-to-dev.yml` env block
- Reports missing secrets as validation errors

**Currently available secrets:**
```yaml
env:
  OAUTH_BACKEND_CLIENT_ID: ${{ secrets.OAUTH_BACKEND_CLIENT_ID }}
  OAUTH_BACKEND_CLIENT_SECRET: ${{ secrets.OAUTH_BACKEND_CLIENT_SECRET }}
```

**GitHub Secrets Status:**
```bash
$ gh secret list
OAUTH_BACKEND_CLIENT_ID              ✅ Exists
OAUTH_BACKEND_CLIENT_SECRET          ✅ Exists
```

### 2. **KVM Structure Validation** (PR Time)

Validates each KVM configuration in the proxy YAML:

**Checks performed:**
- ✅ KVM scope is valid (`organization` or `environment`)
- ✅ KVM has exactly 1 entry (per schema requirement)
- ✅ Entry value syntax is correct
- ✅ Variable substitution uses proper format: `${VAR_NAME}`
- ✅ All variables used are declared in `spec.secrets[]`

**Example validation output:**
```bash
Validating KVM configuration and required secrets...
Proxy has KVMs defined, validating...
Proxy requires secrets: OAUTH_BACKEND_CLIENT_ID OAUTH_BACKEND_CLIENT_SECRET
✓ All required secrets are available in workflow

Found 1 KVM(s) to validate
  KVM 1: SYSGEN788836350-oauth-kvm-oas-test (scope: environment, encrypted: true, entries: 1)
  Entry uses variable substitution: ${OAUTH_BACKEND_CLIENT_ID} ${OAUTH_BACKEND_CLIENT_SECRET}
✓ KVM configuration validation complete
```

### 3. **Runtime KVM Management** (Deploy Time)

The `deploy-to-dev.yml` workflow handles actual KVM creation:

**What happens:**
1. Checks if KVM exists using `apigeecli kvms get`
2. If missing, creates encrypted KVM via Management API
3. Performs variable substitution: `${VAR_NAME}` → actual secret value
4. Creates/updates KVM entries with substituted values

**Built-in safety checks:**
```bash
# Check for missing secrets
if [ -z "$SECRET_VALUE" ]; then
  echo "::error ::Required secret not found: $SECRET_NAME"
  exit 1
fi

# Validate scope
if [ "$KVM_SCOPE" != "organization" ] && [ "$KVM_SCOPE" != "environment" ]; then
  echo "::error ::Invalid KVM scope: $KVM_SCOPE"
  exit 1
fi
```

## How to Add New Secrets

When a team needs a new secret for their proxy KVMs:

### Step 1: Add Secret to GitHub

```bash
# Via GitHub UI
Settings → Secrets and variables → Actions → New repository secret

# Or via CLI
gh secret set NEW_SECRET_NAME
```

### Step 2: Add Secret to deploy-to-dev.yml

Edit `.github/workflows/deploy-to-dev.yml`:

```yaml
- name: Manage KVMs for Proxies
  env:
    OAUTH_BACKEND_CLIENT_ID: ${{ secrets.OAUTH_BACKEND_CLIENT_ID }}
    OAUTH_BACKEND_CLIENT_SECRET: ${{ secrets.OAUTH_BACKEND_CLIENT_SECRET }}
    NEW_SECRET_NAME: ${{ secrets.NEW_SECRET_NAME }}  # ← Add here
```

### Step 3: Update validate-proxy.yml Available Secrets List

Edit `.github/workflows/validate-proxy.yml` (around line 150):

```bash
# List of secrets available in deploy-to-dev.yml workflow env block
# This must be kept in sync with the actual workflow
AVAILABLE_SECRETS="OAUTH_BACKEND_CLIENT_ID OAUTH_BACKEND_CLIENT_SECRET NEW_SECRET_NAME"  # ← Add here
```

### Step 4: Use Secret in Proxy YAML

```yaml
apiVersion: v1
kind: ApiProxy
metadata:
  name: SYSGEN788836350-my-proxy
spec:
  template:
    name: oauth-proxy-oauth-backend

  secrets:
    - OAUTH_BACKEND_CLIENT_ID
    - OAUTH_BACKEND_CLIENT_SECRET
    - NEW_SECRET_NAME  # ← Declare here

  kvms:
    - name: SYSGEN788836350-my-proxy-config
      scope: environment
      encrypted: true
      entries:
        - key: oauth_config
          value: |
            {
              "client_id": "${OAUTH_BACKEND_CLIENT_ID}",
              "client_secret": "${OAUTH_BACKEND_CLIENT_SECRET}",
              "new_setting": "${NEW_SECRET_NAME}"  # ← Use here
            }
```

## Validation Workflow

```mermaid
graph TD
    A[PR Created] --> B[validate-proxy.yml runs]
    B --> C[Check spec.secrets]
    C --> D{All secrets<br/>in workflow?}
    D -->|No| E[❌ Validation fails<br/>Missing: NEW_SECRET]
    D -->|Yes| F[✅ Check KVM structure]
    F --> G{Valid scope?<br/>Exactly 1 entry?}
    G -->|No| H[❌ Validation fails<br/>Invalid KVM config]
    G -->|Yes| I{Variables in<br/>spec.secrets?}
    I -->|No| J[⚠️ Warning:<br/>Undeclared variable]
    I -->|Yes| K[✅ Validation passed]

    K --> L[PR Merged]
    L --> M[deploy-to-dev.yml runs]
    M --> N[Build secrets context<br/>from env vars]
    N --> O{Secret values<br/>exist?}
    O -->|No| P[❌ Deploy fails:<br/>Secret not found]
    O -->|Yes| Q[Create/update KVM]
    Q --> R[Substitute variables]
    R --> S[✅ Deploy succeeds]
```

## What Can Still Fail?

Even with comprehensive validation, these scenarios could cause KVM failures:

### 1. **Secret Value Format Issues**
- **Problem**: Secret value is not valid JSON when proxy expects JSON
- **Prevention**: Manual testing of secret values in non-prod environments
- **Detection**: Deploy-time error when creating KVM entries

### 2. **GCP Permissions**
- **Problem**: Service account lacks `apigee.keyvaluemaps.create` permission
- **Prevention**: Verify service account has Apigee API Admin role
- **Check**:
  ```bash
  gcloud projects get-iam-policy gcp-prj-apigee-dev-np-01 \
    --filter="bindings.members:sa-apigeex-788836350@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com" \
    --format=yaml
  ```

### 3. **API Rate Limits**
- **Problem**: Too many API calls in short time
- **Prevention**: Workflows include retry logic and reasonable delays
- **Detection**: 429 error from Apigee Management API

### 4. **Secret Value Updates**
- **Problem**: Secret value in GitHub is outdated
- **Prevention**: Document secret rotation procedures
- **Detection**: Runtime proxy errors (401 Unauthorized from backend)

## Testing KVM Creation Locally

Before pushing to PR, test KVM creation locally:

```bash
# 1. Authenticate with GCP
export GCP_SA_KEY_PATH=/path/to/service-account-key.json
gcloud auth activate-service-account --key-file="$GCP_SA_KEY_PATH"
export GCP_ACCESS_TOKEN=$(gcloud auth print-access-token)

# 2. Create test KVM
export APIGEE_ORG="gcp-prj-apigee-dev-np-01"
export APIGEE_ENV="apicc-dev"
export KVM_NAME="SYSGEN788836350-test-kvm"

curl -X POST "https://apigee.googleapis.com/v1/organizations/$APIGEE_ORG/environments/$APIGEE_ENV/keyvaluemaps" \
  -H "Authorization: Bearer $GCP_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"'"$KVM_NAME"'","encrypted":true}'

# 3. Create test entry
export ENTRY_VALUE='{"client_id":"test123","client_secret":"secret456"}'

apigeecli kvms entries create \
  --org "$APIGEE_ORG" \
  --env "$APIGEE_ENV" \
  --map "$KVM_NAME" \
  --key "oauth_config" \
  --value "$ENTRY_VALUE" \
  --token "$GCP_ACCESS_TOKEN"

# 4. Verify entry
apigeecli kvms entries get \
  --org "$APIGEE_ORG" \
  --env "$APIGEE_ENV" \
  --map "$KVM_NAME" \
  --key "oauth_config" \
  --token "$GCP_ACCESS_TOKEN"

# 5. Cleanup
apigeecli kvms delete \
  --org "$APIGEE_ORG" \
  --env "$APIGEE_ENV" \
  --name "$KVM_NAME" \
  --token "$GCP_ACCESS_TOKEN"
```

## Summary

**Validation Coverage:**
- ✅ Secret availability (PR time)
- ✅ KVM structure (PR time)
- ✅ Variable substitution syntax (PR time)
- ✅ Secret value existence (deploy time)
- ✅ GCP authentication (deploy time)
- ✅ KVM creation (deploy time)

**Confidence Level:** 🟢 **High**

The combination of PR-time validation and deploy-time safety checks ensures that KVM-related failures are extremely unlikely. The most common issues (missing secrets, invalid configuration) are caught before merge.
