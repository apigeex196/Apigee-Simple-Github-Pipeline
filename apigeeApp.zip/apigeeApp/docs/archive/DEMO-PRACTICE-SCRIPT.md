# 🎤 Demo Practice Script - Word-for-Word Walkthrough

## 🎯 Use This To Practice

Read this out loud a few times before your demo. Time yourself. Adjust to match your natural speaking style.

**Target Time**: 7-10 minutes

---

## 🎬 OPENING (30 seconds)

**[Stand confidently, make eye contact, smile]**

> "Hey everyone, thanks for being here. I want to show you something that literally changed how I work this week.
>
> I had to create 26 user stories for our infrastructure project. If you've done this before, you know it's tedious - usually takes 2 to 3 hours of writing, formatting, and organizing in Jira.
>
> I did it in **5 minutes**.
>
> And honestly, the stories came out better than if I'd written them manually. Let me show you how."

**[Pause for effect, let that sink in]**

---

## 🤖 ACT 1: THE COPILOT CONVERSATION (2 minutes)

**[Switch to browser, open GitHub Copilot Chat]**

> "So I started here, in GitHub Copilot Chat. This is where it all began.
>
> I didn't write any code. I just... talked to it. Like I'd talk to a teammate.
>
> Here's what I said..."

**[Scroll to show your initial prompt]**

> "I gave Copilot context about our project - we're building an applications repository for Apigee X, we need composite actions, workflows, validation - and I asked it to break the work into user stories.
>
> And look at this response..."

**[Scroll through Copilot's breakdown]**

> "It understood our domain. It created stories with proper acceptance criteria, technical details, story point estimates. It even organized them into parallel tracks for two engineers.
>
> This isn't just generating text - it's actually thinking through the work structure."

**[Scroll to follow-up messages]**

> "Then I asked it to refine things. 'Add more detail to the technical specs.' 'Create this as a Jira CSV import file.' 'Add labels and epic links.'
>
> It's conversational. Back and forth, just like pair programming."

**[Pause, look at audience]**

> "In about 10 minutes of conversation, I had 26 complete user stories. Let me show you what they look like."

---

## 📊 ACT 2: THE GENERATED OUTPUT (1.5 minutes)

**[Switch to jira-import.csv in Excel or VSCode]**

> "Here's the CSV file Copilot generated. 26 rows, one for each story.
>
> Let's look at one..."

**[Click on Story 1 or scroll to show it clearly]**

> "Story 1: 'Setup Composite Action - Setup Apigee Tooling'
>
> Look at the description field. It's got:
> - The user story format: 'As a developer, I want...'
> - Technical details: location, tools to install, version numbers
> - Acceptance criteria: specific, testable requirements
> - Story points: 2 points estimated
> - Labels for filtering
>
> This is production-ready. I could copy this straight into Jira and start working."

**[Scroll to show a few more stories]**

> "And it's like this for all 26 stories. Consistent format, good detail, proper categorization.
>
> But..."

**[Pause for dramatic effect]**

> "There's a problem. If I import this plain text CSV to Jira, all the formatting gets lost. Everything becomes one giant paragraph. No line breaks, no headers, no structure.
>
> So I asked Copilot to solve that problem too."

---

## ⚡ ACT 3: THE AUTOMATION MAGIC (2 minutes)

**[Switch to terminal, make sure it's visible with large font]**

> "Copilot wrote me this Python script that converts plain text to Jira Wiki Markup. Watch this..."

**[Type or have command ready]**

```bash
python3 scripts/format-jira-csv.py
```

**[Press Enter, let it run]**

> "26 stories, formatted in..."

**[Wait for output to appear]**

```
📝 Formatting Jira CSV with Wiki Markup...
✅ Complete! Formatted: 26/26 stories
```

**[Look up at audience]**

> "...less than one second.
>
> Let's see what changed."

**[Switch back to CSV file, show the same story]**

> "Now look at this description field. It looks messy here, but watch - it's full of special formatting codes:
>
> - `*As a*` - that's bold text in Jira
> - `\\` - these double backslashes are line breaks
> - `h4.` - that's a header
> - `{{file.yml}}` - that's code formatting
>
> The script found every user story, every header, every file path, every environment variable - and wrapped them in the right Jira markup.
>
> Automatically. For all 26 stories.
>
> Now watch what happens when we import this to Jira..."

---

## 📋 ACT 4: THE JIRA IMPORT (2 minutes)

**[Switch to Jira, navigate to import]**

> "In Jira, I go to Settings, External System Import, CSV."

**[Navigate through menus]**

> "Upload the file..."

**[Select jira-import.csv]**

> "Map the fields - Summary, Description, Story Points..."

**[Quickly map the obvious fields]**

> "And import."

**[Click Import, show progress]**

> "This takes about 10 seconds for all 26 stories."

**[Wait for completion, then navigate to issues]**

> "Alright, import complete. Let's open Story 1..."

**[Click on the imported story]**

> "And... look at this."

**[Let the formatting speak for itself, pause]**

> "Beautiful formatting.
>
> **Bold** user story labels.
> Clean line breaks.
> Section headers for TECHNICAL DETAILS and ACCEPTANCE CRITERIA.
> Code highlighting on file paths and tool names.
>
> This is ONE of 26 stories, all formatted exactly the same way. All imported from that CSV.
>
> No manual formatting. No copying and pasting. No tedious clicking around in Jira.
>
> Just... done."

---

## 📊 ACT 5: THE DASHBOARD (1 minute)

**[Switch to Confluence dashboard]**

> "And here's the cherry on top.
>
> I also created this auto-updating dashboard in Confluence. It uses Jira macros with JQL queries to show:
> - Progress on both epics
> - Active work across the team
> - Recently completed stories
> - High priority or blocked items
>
> The best part? It auto-updates. Every time someone opens this page, it pulls current data from Jira.
>
> No manual updates. No stale status. No more asking 'what's the current progress?'
>
> The team always has visibility."

---

## 💥 THE BIG FINISH (30 seconds)

**[Look at audience, step away from screen if possible]**

> "So let's recap what we just saw:
>
> 1. **10 minutes** chatting with Copilot - generated 26 professional user stories
> 2. **1 second** running the automation script - formatted for Jira
> 3. **10 seconds** importing to Jira - perfect formatting preserved
> 4. **Auto-updating dashboard** - team visibility with zero maintenance
>
> Total time: about **5 minutes** of actual work.
>
> The traditional approach would have taken me 3 to 4 hours.
>
> That's a **95% time savings**."

**[Pause for effect]**

> "And honestly? The stories are higher quality. Copilot helped me think through acceptance criteria and technical details I might have missed. It's like having a really thorough pair programming partner.
>
> The script, the documentation, the examples - it's all in our repo. I'll share links afterward. And I'm happy to help anyone who wants to try this on their next project."

**[Smile]**

> "Questions?"

---

## 💬 HANDLING QUESTIONS (Ad lib based on Q&A)

### Q: "Did you have to edit the Copilot output?"

> "Yeah, I spent maybe 10 to 15 minutes refining things after Copilot generated them. I adjusted a couple of story point estimates, added some technical details it didn't know about, reordered a few dependencies.
>
> But that's still way faster than writing from scratch. And honestly, the editing process helped me think through the work better."

---

### Q: "Does this work for any project, or just Apigee?"

> "It works for any project. The key is giving Copilot good context.
>
> I showed it our project structure, our naming conventions, examples from our existing repos. The better the context, the better the output.
>
> You could use this for web development, infrastructure, data pipelines - whatever. Just describe what you're building and what you need."

---

### Q: "Can our team use this script?"

> "Absolutely! It's in our repo at `scripts/format-jira-csv.py`. There's a complete guide at `docs/planning/CSV-FORMATTING-GUIDE.md` that walks through the Wiki Markup format and how to customize the script.
>
> I'm also happy to pair with anyone who wants to try it. It's pretty straightforward once you see it in action."

---

### Q: "What about the Confluence dashboard - how hard is that to set up?"

> "Not hard at all. It's just Jira macros in Confluence. No code needed.
>
> You create a Confluence page, add a Jira Issues macro, and configure it with a JQL query like 'parent = EPIC-123'. The macro handles all the auto-updating.
>
> It took me about 15 minutes to set up. I have documentation for that too if anyone wants it."

---

### Q: "How do you learn to prompt Copilot effectively?"

> "Great question. Honestly, I just started using it and learned by doing.
>
> The main thing is to be conversational and give context. Don't try to write perfect commands. Just explain what you're trying to do, like you'd explain to a teammate.
>
> Start broad - 'I need to break down this project into user stories' - then refine: 'Add more detail to the acceptance criteria,' 'Include story point estimates,' etc.
>
> It's iterative. And Copilot usually gets better as the conversation goes on because it builds up context."

---

### Q: "Is this replacing developers?"

> "No, not at all. This is a tool that makes **us** more productive.
>
> I still had to:
> - Know what we're building
> - Understand the technical requirements
> - Review and refine the stories
> - Make decisions about prioritization and dependencies
>
> Copilot just took care of the tedious parts - writing it all out, formatting, organizing into CSV.
>
> Think of it like code completion, but for the entire development workflow. It's augmenting our work, not replacing our thinking."

---

### Q: "What's the catch? This seems too good to be true."

> "**[Laugh]** Fair question!
>
> The catch is that you need to know what you're doing. Copilot can generate bad code or wrong information if you don't review it.
>
> In this case, I reviewed every story. I checked the acceptance criteria, the technical details, the dependencies. I know our system well enough to spot if something was off.
>
> So it's not magic. It's a power tool. And like any power tool, you need to use it carefully and verify the output.
>
> But when you do, it's incredibly powerful."

---

## 🎓 CLOSING REMARKS (If needed)

> "Alright, I know I've taken up enough of your time.
>
> Here's what I'll do: I'll share the recording of this demo, links to all the documentation, and the script itself. I'll post it in our team Slack.
>
> If anyone wants to try this on their next sprint planning, reach out. I'm happy to pair program or just answer questions.
>
> Thanks for listening, and I hope you try it out!"

**[Smile, open for final questions or informal chat]**

---

## 🎯 Practice Tips

### Read It Out Loud
- Don't memorize word-for-word
- Use this script to find your natural rhythm
- Adapt phrases to match your speaking style

### Time Yourself
- Read through 2-3 times
- Aim for 7-10 minutes total (without Q&A)
- Mark where you can speed up or slow down

### Record Yourself
- Use your phone or computer
- Watch/listen for:
  - Filler words ("um", "uh", "like")
  - Energy level (enthusiastic vs monotone)
  - Pacing (too fast vs too slow)
  - Clarity (are you clear or confusing?)

### Practice With a Friend
- Find a colleague to listen
- Ask for honest feedback
- Try the Q&A section

### Adjust for Your Audience
- **More technical audience**: Dive deeper into the script details
- **Less technical audience**: Focus more on the time savings
- **Leadership audience**: Emphasize impact and scalability

---

## ⏱️ Timing Checkpoints

| Checkpoint | Target Time | What You Should Have Covered |
|------------|-------------|------------------------------|
| Opening hook | 0:30 | "26 stories in 5 minutes" |
| After Copilot chat | 2:30 | Showed conversation, explained approach |
| After CSV output | 4:00 | Showed generated stories, explained problem |
| After automation | 6:00 | Ran script, showed formatting |
| After Jira import | 8:00 | Imported, showed beautiful formatting |
| After dashboard | 9:00 | Showed auto-updating visibility |
| Final recap | 9:30 | Summarized impact, opened for Q&A |

**If you're running long**: Cut the CSV output section or skip showing multiple stories

**If you're running short**: Add more detail to the Copilot prompting tips

---

## 🎤 Delivery Tips

### Vocal
- **Volume**: Speak up, project to back of room
- **Pace**: Slower than you think, especially for technical terms
- **Pause**: After key reveals, let information land
- **Energy**: Enthusiastic but not over-the-top

### Physical
- **Stand**: If possible, don't sit
- **Move**: Use natural hand gestures
- **Eye contact**: Scan the room, make connections
- **Screen**: Look at audience more than screen

### Mental
- **Breathe**: Take deep breaths before starting
- **Smile**: Friendly, approachable energy
- **Confidence**: You know this stuff - own it
- **Recover**: If something breaks, laugh it off and continue

---

## 🚀 The Night Before

### Technical
- [ ] Test script on another machine if possible
- [ ] Verify Jira access and permissions
- [ ] Make backup screenshots/recording
- [ ] Clear browser cache/history for clean demo

### Mental
- [ ] Read through script one more time
- [ ] Visualize successful demo
- [ ] Get good sleep
- [ ] Don't stress - you've got this!

### Logistics
- [ ] Know where you're presenting
- [ ] Arrive 10 minutes early
- [ ] Test projector/screen
- [ ] Have water available

---

**You've prepared well. The content is solid. Just breathe, be yourself, and show them what you built. Good luck! 🚀**
