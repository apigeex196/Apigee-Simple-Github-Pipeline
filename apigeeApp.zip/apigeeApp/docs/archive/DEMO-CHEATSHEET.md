# 🎯 Demo Cheat Sheet - Quick Reference

## ⚡ The One-Liner Hook
> "I created 26 professional Jira stories in 5 minutes. Here's how."

---

## 📝 Pre-Demo Checklist

### Terminal Ready
```bash
cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications
# Font size large (Cmd + +)
```

### Browser Tabs Open (in order)
1. ✅ GitHub Copilot Chat
2. ✅ VSCode with project
3. ✅ jira-import.csv (Excel/text editor)
4. ✅ Jira (ready to import)
5. ✅ Confluence dashboard

---

## 🎬 Demo Script (7 mins)

| Time | Action | Say This | Show This |
|------|--------|----------|-----------|
| 0:00-0:30 | **Hook** | "26 stories in 5 min vs 3 hours" | Energy! |
| 0:30-2:30 | **Copilot Chat** | "Started with a conversation" | Chat history, scroll through |
| 2:30-4:00 | **CSV Output** | "26 professional stories generated" | Open CSV, show Story 1 |
| 4:00-5:30 | **Automation** | "Now the magic..." | Run script, show formatted CSV |
| 5:30-7:00 | **Jira Import** | "Watch the formatting..." | Import, open Story 1 in Jira |
| 7:00-7:30 | **Dashboard** | "Auto-updating visibility" | Show Confluence dashboard |

---

## 💻 Terminal Commands

### Run Formatting Script
```bash
python3 scripts/format-jira-csv.py
```

**Expected Output**:
```
📝 Formatting Jira CSV with Wiki Markup...
✅ Complete! Formatted: 26/26 stories
```

---

## 🎯 Key Points to Hit

### Problem Statement
- ❌ Manual story creation takes 2-3 hours
- ❌ Formatting in Jira is tedious
- ❌ Easy to miss details

### The Solution
- ✅ Copilot generates stories from conversation
- ✅ Automated script formats for Jira
- ✅ Import preserves all formatting
- ✅ Dashboard auto-updates

### The Impact
- **Time**: 5 minutes vs 3 hours = **95% savings**
- **Quality**: Acceptance criteria, technical details, dependencies
- **Visibility**: Auto-updating dashboard

---

## 📊 Jira Import Steps

1. Settings → External System Import → CSV
2. Upload `jira-import.csv`
3. Map fields:
   - Summary → Summary
   - Description → Description
   - Story Points → Story Points
4. Import (takes ~10 seconds)
5. Open Story 1 to show formatting

---

## 💬 Answer Key Questions

### "Did you edit the stories?"
"Yes, about 10-15 minutes of refinement. Still way faster than writing from scratch."

### "Does this work for any project?"
"Yes! The key is good context. Show Copilot your project structure and examples."

### "Can we use this?"
"Absolutely! Script is at `scripts/format-jira-csv.py` with full documentation."

### "How do you prompt Copilot?"
"Start broad, then refine. It's conversational - like working with a teammate."

---

## 🎨 Wiki Markup Quick Reference

| Want | Markup | Example |
|------|--------|---------|
| Line break | `\\` | `Line 1\\Line 2` |
| Bold | `*text*` | `*As a* developer` |
| Header | `h4. Title` | `h4. TECHNICAL DETAILS` |
| Code | `{{code}}` | `{{file.yml}}` |
| List | `* Item` | `* Create file` |

---

## 🚀 Post-Demo Actions

### Share Immediately
- [ ] Link to repo
- [ ] Path: `docs/planning/`
- [ ] Offer to help teammates

### Follow-Up
- [ ] Share recording
- [ ] Schedule office hours
- [ ] Write internal blog

---

## ⚡ Backup Plan (if live demo fails)

1. **Show screenshots** - Before/after formatting
2. **Show pre-imported story** - Already in Jira
3. **Talk through process** - Use DEMO-PREP.md
4. **Still show dashboard** - Easiest to demo

---

## 🔥 The Killer Stats

- **26 stories** generated
- **5 minutes** total time (vs 3 hours)
- **95% time savings**
- **< 1 second** to format all stories
- **10 seconds** to import to Jira

---

## 🎓 Pro Presenter Tips

### Energy
- Start strong
- Build excitement before each reveal
- End on the impact number

### Pacing
- Don't rush the "wow" moments
- Pause after running the script
- Let formatting sink in

### Authenticity
- Share the struggle
- Be honest about refinements
- Show real work

---

## 📁 Resource Files

### In Repo
- `docs/planning/DEMO-PREP.md` - Full demo guide
- `docs/planning/DEMO-SCRIPT.md` - Original walkthrough
- `docs/planning/CSV-FORMATTING-GUIDE.md` - Formatting reference
- `docs/planning/jira-import.csv` - The 26 stories
- `scripts/format-jira-csv.py` - Automation script

### To Share
- GitHub repo link
- Documentation path
- Offer to pair program

---

## ⏱️ Simplified 5-Minute Version

If short on time:

1. Show CSV (30s) - "26 stories generated"
2. Run script (30s) - "Automated formatting"
3. Show Jira story (1m) - Pre-imported
4. Show dashboard (1m) - Auto-updating
5. Impact (30s) - "5 min vs 3 hours"
6. Q&A (1.5m)

**Skip**: Live Copilot chat, live Jira import, detailed Wiki Markup

---

## 🎯 Success = These Reactions

- "I want to try this!"
- "Can you share that script?"
- "How do I learn Copilot?"
- "We should standardize on this"

---

## 🔑 The One Thing to Remember

**Show the transformation**:
- Before: Hours of manual work, boring formatting
- After: Minutes of automated work, perfect formatting

The demo shows **AI as a practical tool**, not magic. That's what makes it compelling.

---

**You've got this! 🚀**
