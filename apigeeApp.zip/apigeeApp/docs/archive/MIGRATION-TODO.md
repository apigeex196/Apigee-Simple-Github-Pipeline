# Applications Repository - Migration To-Do List

**Purpose**: Complete the migration from `gitops` to `applications` repository for API producer self-service.

**Current Status**: Skeleton structure in PR #2 (DPEAPI-18548-design-layout)

**Repository Model**:
- **MAL-based structure**: Each application team gets their own `mal-SYSGEN#/` folder
- **Environment-specific configs**: Each proxy has `dev/`, `test/`, `prod/` folders (no base+overlays)
- **Scoped to API producers**: No sharedflows, no utility proxies, no templates - only application proxies and products

---

## 🎯 Critical Path - Divide & Conquer

### Person A: Core Infrastructure & Workflows

#### A1. GitHub Actions Workflows ⚙️
- [ ] **Migrate `validate-proxy` workflow** from gitops
  - Source: `gitops/.github/workflows/validate-proxy.yml`
  - Adapt for MAL-based structure (`mal-SYSGEN*/proxies/**/*.yaml`)
  - Remove sharedflow validation logic
  - Update to detect changed MAL folders instead of org/env paths
  - Test with example MAL proxy files

- [ ] **Migrate `deploy-proxy` workflow** from gitops
  - Source: `gitops/.github/workflows/deploy-proxy.yml`
  - Adapt for MAL-based structure
  - Deploy to dev/test/prod based on which workflow is triggered
  - Update to read env configs from `mal-*/proxies/*/dev|test|prod/{proxy-name}.yaml`
  - Remove sharedflow deployment logic

- [ ] **Implement `deploy-to-dev.yml`** (currently placeholder)
  - Detect changed MAL folders on main branch push
  - For each changed MAL, deploy proxies from `*/dev/{proxy-name}.yaml`
  - Call deploy-proxy composite action
  - Target: `gcp-prj-apigee-dev-np-01` / `apicc-dev`

- [ ] **Implement `deploy-to-test.yml`** (currently placeholder)
  - Mirror dev deployment but for test environment
  - Target: `gcp-prj-apigee-qa-np-01` / `apicc-test1`

- [ ] **Implement `deploy-to-prod.yml`** (currently placeholder)
  - Mirror dev/test but for production
  - Add manual approval gate (environment protection rules)
  - Target: `gcp-prj-apigee-prod-01` / `apicc-prod`

- [ ] **Implement `validate-org-env.yml`** (currently placeholder)
  - Validate MAL folder structure on PRs
  - Check YAML schema compliance
  - Verify SYSGEN naming conventions
  - Ensure required files exist (CODEOWNERS, etc.)

- [ ] **Configure branch protection rules**
  - Require PR reviews
  - Require status checks to pass (validation workflow)
  - Restrict who can push to main
  - Configure environment protection for prod deployments

#### A2. Composite Actions ⚙️
- [ ] **Implement `validate-proxy` action** (currently placeholder)
  - Source: `gitops/.github/actions/setup-apigee-tooling` + validation logic from workflow
  - Install apigee-go-gen, apigeecli, yq, jq
  - Validate YAML against schema
  - Check template references exist
  - Validate proxy naming conventions
  - Test with example proxy YAML

- [ ] **Implement `deploy-proxy` action** (currently placeholder)
  - Source: Deployment logic from `gitops/.github/workflows/deploy-proxy.yml`
  - Download template from bundles repo
  - Transform template using apigee-go-gen
  - Apply YAML configuration
  - Import proxy to Apigee
  - Deploy to environment
  - Handle errors and rollback

- [ ] **Implement `get-service-account` action** (currently placeholder)
  - Retrieve service account key from GCP Secret Manager
  - Use naming convention: `sa-apigees-<mal-code>-<org>-<env>`
  - Authenticate gcloud
  - Export access token for apigeecli
  - Test with dev environment

- [ ] **Implement `manage-kvms` action** (currently placeholder)
  - Source: `gitops/.github/actions/manage-kvms`
  - Create/update KVMs for each proxy
  - Handle secret substitution from GitHub secrets
  - Support environment-scoped KVMs
  - Test with example KVM configuration

- [ ] **Migrate `download-template` action** from gitops
  - Source: `gitops/.github/actions/download-template`
  - Download template bundles from enterprise-apigeex-templates releases
  - Cache templates to speed up workflows
  - Handle template versioning

#### A3. Schema & Validation Files 📋
- [ ] **Copy and adapt `apiproxy.schema.json`** from gitops
  - Simplify if needed for application use case
  - Ensure it matches MAL proxy YAML structure
  - Add to repository root

- [ ] **Copy `.yamllint.yml`** from gitops
  - Place at repository root
  - Update for MAL-based structure if needed

- [ ] **Create `scripts/validate-structure.sh`**
  - Check MAL folder naming convention
  - Verify required folders exist (proxies/, products/, kvms/)
  - Check CODEOWNERS file exists
  - Validate proxy folder structure (dev/test/prod)
  - Can be run locally or in CI

---

### Person B: Documentation & Developer Experience

#### B1. Documentation 📚
- [ ] **Complete README.md**
  - Expand current template README
  - Add "Quick Start" section for new teams
  - Explain MAL concept clearly
  - Link to all doc files
  - Add architecture diagram (MAL structure)
  - Add workflow diagram (PR → Validate → Deploy)

- [ ] **Enhance `docs/ONBOARDING.md`**
  - Expand current template
  - Step-by-step guide with screenshots
  - How to create first proxy
  - How to select template
  - How to configure environment-specific settings
  - How to test deployment
  - Expected timeline (hours/days to first deployment)

- [ ] **Complete `docs/DEPLOYMENT-GUIDE.md`** (currently placeholder)
  - How deployments work (dev → test → prod)
  - How to promote between environments
  - How to rollback
  - Manual approval process for prod
  - Monitoring deployments

- [ ] **Complete `docs/TROUBLESHOOTING.md`** (currently placeholder)
  - Common validation errors and fixes
  - Deployment failures and solutions
  - Authentication/permissions issues
  - Template errors
  - Link to validation error catalog from gitops

- [ ] **Create `docs/YAML-REFERENCE.md`**
  - Complete proxy YAML structure reference
  - All required and optional fields
  - Environment-specific configuration options
  - Examples for each template type
  - KVM configuration reference

- [ ] **Create `docs/TEMPLATE-SELECTION.md`**
  - When to use JWT vs OAuth templates
  - Decision matrix/flowchart
  - Authentication patterns explained
  - Template feature comparison table
  - Link to template repo for details

- [ ] **Create `docs/FAQ.md`**
  - Compile common questions
  - "What's a MAL?"
  - "How is this different from gitops repo?"
  - "Can I deploy to multiple orgs?"
  - "How do I add secrets?"
  - "How do I test locally?"

#### B2. Examples & Templates 📋
- [ ] **Create complete working example MAL**
  - Replace `mal-SYSGEN123456789` with realistic example
  - Include JWT-based proxy example
  - Include OAuth-based proxy example
  - Include product configuration
  - Include KVM configuration
  - Add README in MAL folder explaining examples

- [ ] **Create example for each template type**
  - `mal-EXAMPLES/jwt-oauth-example/` - Full JWT+OAuth setup
  - `mal-EXAMPLES/jwt-only-example/` - JWT-only setup
  - `mal-EXAMPLES/oauth-jwt-backend-example/` - OAuth frontend, JWT backend
  - `mal-EXAMPLES/oauth-oauth-backend-example/` - End-to-end OAuth
  - Each with complete dev/test/prod configs

- [ ] **Create `.github/ISSUE_TEMPLATE/` files**
  - `new-mal-request.md` - Request new MAL folder
  - `deployment-issue.md` - Report deployment problems
  - `question.md` - Ask questions
  - `access-request.md` - Request repository/secret access

- [ ] **Create `.github/PULL_REQUEST_TEMPLATE.md`**
  - Already exists but may need enhancement
  - Checklist: What changed? Which environments? Testing done?
  - Deployment plan
  - Rollback plan

#### B3. Developer Tools & Setup 🔧
- [ ] **Create `scripts/setup-mal-folder.sh`** (currently placeholder)
  - Interactive script to create new MAL folder
  - Prompts for MAL code, team name, etc.
  - Creates folder structure
  - Generates CODEOWNERS file
  - Creates placeholder proxy configs
  - Creates README template

- [ ] **Create `scripts/local-validation.sh`**
  - Run schema validation locally before committing
  - Check YAML syntax
  - Verify naming conventions
  - Similar to pre-commit hook in gitops

- [ ] **Create `.githooks/pre-commit`**
  - Run local validation on commit
  - Fast feedback before pushing
  - Can be bypassed with --no-verify

- [ ] **Create `scripts/setup-dev-environment.sh`**
  - Install required tools (yq, jq, ajv-cli, yamllint)
  - Set up git hooks
  - Verify installation
  - Similar to gitops setup script

- [ ] **Create VS Code workspace settings**
  - `.vscode/settings.json` for YAML validation
  - Schema association for proxy YAMLs
  - Recommended extensions
  - `.vscode/extensions.json`

---

### Shared Tasks (Either Person)

#### S1. Repository Configuration 🔐
- [ ] **Set up GitHub environments**
  - Create `dev`, `test`, `prod` environments
  - Configure environment protection rules for prod
  - Add required reviewers for prod deployments

- [ ] **Configure GitHub secrets**
  - Document required secrets for workflows
  - Set up test secrets for validation
  - Create secret naming convention guide
  - Add secrets management documentation

- [ ] **Implement CODEOWNERS merge workflow**
  - Source: `.github/workflows/merge-codeowners.yml` (exists as placeholder)
  - Aggregate MAL-level CODEOWNERS into root CODEOWNERS
  - Run on PR to keep root CODEOWNERS in sync
  - Test with multiple MAL folders

- [ ] **Set up service account access**
  - Verify service accounts exist for dev/test/prod
  - Test retrieval from GCP Secret Manager
  - Document service account naming convention
  - Test get-service-account action

#### S2. Testing & Validation ✅
- [ ] **End-to-end workflow testing**
  - Create test MAL folder
  - Test validation workflow on PR
  - Test deployment to dev
  - Test deployment to test
  - Test deployment to prod (with approval)
  - Verify rollback works

- [ ] **Error scenario testing**
  - Invalid YAML structure
  - Missing required fields
  - Invalid template reference
  - Naming convention violations
  - Deployment failures
  - Document all error messages and solutions

- [ ] **Multi-MAL testing**
  - Create multiple MAL folders
  - Test that changes to MAL A don't affect MAL B
  - Test CODEOWNERS isolation
  - Test concurrent deployments

---

## 📋 Dependencies & Prerequisites

### Before Starting Migration
- [ ] Verify access to all three repos: gitops, bundles, templates, applications
- [ ] Ensure service accounts exist for dev environment at minimum
- [ ] Confirm GCP Secret Manager naming convention with DevSecOps team
- [ ] Review template repo release structure
- [ ] Understand current gitops workflow deeply

### External Dependencies
- **Template repo** must have stable releases with bundles
- **Bundle repo** must have current utility proxies deployed
- **GCP Secret Manager** must have service accounts provisioned
- **GitHub org settings** must allow environment protection rules

---

## 🎯 Success Criteria

### Milestone 1: Basic Workflows (Week 1)
- [ ] Validation workflow works end-to-end on PR
- [ ] Deploy to dev workflow works on main branch merge
- [ ] Can deploy example proxy successfully
- [ ] Documentation covers basic onboarding

### Milestone 2: Complete Platform (Week 2)
- [ ] All three environment deployments work (dev/test/prod)
- [ ] KVM management works
- [ ] Product deployment works
- [ ] All documentation complete
- [ ] Examples for all template types exist

### Milestone 3: Production Ready (Week 3)
- [ ] End-to-end testing with real team complete
- [ ] All error scenarios documented
- [ ] Support processes established
- [ ] Training materials ready

---

## 🔀 Migration Strategy

### Key Differences from GitOps Repo

| Aspect | GitOps Repo | Applications Repo |
|--------|-------------|-------------------|
| **Structure** | `orgs/{org}/envs/{env}/proxies/{app}/` | `mal-{code}/proxies/{proxy}/{env}/` |
| **Ownership** | Platform team | Application teams |
| **Scope** | Proxies, sharedflows, products, utility proxies | Proxies and products only |
| **Templates** | Not used directly | Core feature |
| **Deployment** | Org/env based | MAL based, multi-env |
| **CODEOWNERS** | Single file | Per-MAL + aggregated root |

### What NOT to Migrate
- ❌ Sharedflow workflows and actions
- ❌ Apigee utility proxy workflows (apigee-proxy, apigee-sharedflow schemas)
- ❌ Template creation/validation workflows
- ❌ Product deployment (unless adapted for MAL structure)

### What MUST be Adapted (Not Direct Copy)
- ✅ Proxy validation - change from org/env to MAL structure
- ✅ Proxy deployment - support dev/test/prod in single MAL
- ✅ KVM management - work with MAL-based paths
- ✅ Changed files detection - detect MAL folders not org paths
- ✅ Schema validation - use apiproxy.schema.json only

---

## 📝 Notes & Decisions

### Architectural Decisions
1. **MAL-based structure** isolates teams and simplifies permissions
2. **Environment folders** (dev/test/prod) instead of base+overlays for clarity
3. **Service accounts in Secret Manager** (not GitHub Secrets) for better security
4. **Template-based proxies only** - no custom bundles from applications repo
5. **CODEOWNERS aggregation** enables per-team ownership with centralized enforcement

### Open Questions
- [ ] How do teams request new secrets for their KVMs?
- [ ] What's the approval process for production deployments?
- [ ] Can teams deploy to multiple orgs from one MAL?
- [ ] What monitoring/alerting is available post-deployment?
- [ ] How do we handle template version updates for existing proxies?

### Risks & Mitigations
- **Risk**: Service account retrieval from Secret Manager fails
  - *Mitigation*: Test thoroughly in dev, document fallback process
- **Risk**: MAL folder structure becomes inconsistent
  - *Mitigation*: Strict validation in validate-structure.sh
- **Risk**: Teams confused by differences from gitops repo
  - *Mitigation*: Clear documentation, training, examples

---

## 🗓️ Timeline Estimate

### Week 1: Foundation
- **Person A**: A1.1-A1.3 (core workflows), A2.1 (validate action)
- **Person B**: B1.1-B1.3 (README, onboarding, deployment guide), B2.1 (working example)

### Week 2: Complete Features
- **Person A**: A1.4-A1.6 (remaining workflows), A2.2-A2.5 (all actions), A3 (schemas)
- **Person B**: B1.4-B1.6 (troubleshooting, YAML ref, templates), B2.2 (template examples)

### Week 3: Polish & Test
- **Both**: S1 (repo config), S2 (testing), remaining B3 tasks (dev tools)
- Integration testing
- Documentation review and refinement
- Pilot team testing

---

## ✅ Pre-Pilot Checklist

Before inviting first API producer team:
- [ ] All Person A tasks complete (workflows + actions)
- [ ] All Person B tasks complete (docs + examples)
- [ ] Shared tasks complete (config + testing)
- [ ] End-to-end deployment tested successfully
- [ ] Documentation reviewed by someone unfamiliar with system
- [ ] Support channel established
- [ ] Rollback tested
- [ ] Error scenarios documented
- [ ] Success criteria for pilot defined

---

## Document Control
- **Created**: December 1, 2025
- **Last Updated**: December 1, 2025
- **Owner**: API Enablement Team
- **Related PR**: #2 (DPEAPI-18548-design-layout)
