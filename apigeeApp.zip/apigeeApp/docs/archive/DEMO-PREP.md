# 🎯 Killer Demo Preparation - Copilot Jira Story Generation

## 🎬 Demo Overview

**Topic**: "From Copilot Chat to Jira Stories in 60 Seconds"

**Duration**: 7-10 minutes

**Wow Factor**: Show how Copilot can generate 26 professional Jira stories, format them automatically, and import them in less time than it takes to manually create ONE story.

---

## 📋 Pre-Demo Checklist

### 1. Environment Setup (Do this before demo)

**Terminal Prep**:
```bash
cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications

# Make sure script is executable
chmod +x scripts/format-jira-csv.py

# Have terminal ready at project root
# Increase font size for visibility (Cmd + +)
```

**Browser Tabs** (Open in order you'll use them):
1. **GitHub Copilot Chat** - Ready to show conversation history
2. **VSCode** with project open - Show generated files
3. **jira-import.csv** - Before formatting (in Excel or text editor)
4. **Your Jira instance** - Ready for import demo
5. **Confluence dashboard** - Show the auto-updating dashboard you just built

**Files to Highlight**:
- `docs/planning/jira-import.csv` - The 26 generated stories
- `scripts/format-jira-csv.py` - The automation magic
- `docs/planning/DEMO-SCRIPT.md` - This walkthrough (for reference)

### 2. Backup Plan

**In case live demo fails**:
- Have screenshots of before/after story formatting
- Have a pre-imported Jira story ready to show
- Keep this prep guide open for quick reference

---

## 🎪 The Killer Demo Flow

### Opening Hook (30 seconds)

**SAY**:
> "I need to show you something that changed how I work with Jira.
>
> Last week, I needed to create 26 user stories for our infrastructure work. Normally that's 2-3 hours of copying, pasting, and formatting in Jira.
>
> I did it in **under 5 minutes**. Let me show you how."

---

### Act 1: The Copilot Conversation (2 minutes)

**SHOW**: GitHub Copilot Chat conversation history

**SAY**:
> "I started with a simple conversation with Copilot. I gave it context about our project structure, our goals, and asked it to break down the work."

**SHOW IN COPILOT CHAT**:
1. Initial prompt: "I need to implement a new applications repo for Apigee X. Break this into user stories."
2. Copilot's response with story breakdown
3. Follow-up: "Create these as a Jira CSV import file with proper formatting"
4. Copilot generates the CSV

**KEY POINT**:
> "Notice how Copilot understood our domain - Apigee X, composite actions, workflows. It created stories with acceptance criteria, technical details, story points - everything we need."

**DEMO TIP**: Scroll through the chat to show the iteration/refinement process

---

### Act 2: The Generated Output (1.5 minutes)

**OPEN**: `docs/planning/jira-import.csv` in Excel or VSCode

**SAY**:
> "Copilot generated 26 stories in this CSV. Let's look at one..."

**SHOW ONE STORY** (pick Story 1 - Setup Apigee Tooling):
- **Summary**: Clear, descriptive
- **Description**: Full user story format with acceptance criteria
- **Story Points**: Estimated
- **Labels**: Categorized
- **Epic Link**: Organized

**SAY**:
> "This is professional quality. But there's a problem - if we import this plain text to Jira, all the formatting gets lost. Everything becomes one big paragraph."

---

### Act 3: The Automation Magic (2 minutes)

**SAY**:
> "So I asked Copilot to solve that problem too. It created a formatting script that converts plain text to Jira Wiki Markup."

**RUN IN TERMINAL** (make sure font is large):
```bash
python3 scripts/format-jira-csv.py
```

**EXPECTED OUTPUT**:
```
📝 Formatting Jira CSV with Wiki Markup...
   Input: /Users/rschilm/.../jira-import.csv
✅ Complete!
   Formatted: 26/26 stories
```

**SAY**:
> "26 stories formatted in less than a second. Let's see what changed..."

**OPEN**: `jira-import.csv` again, show one formatted story:
```csv
"*As a* developer\\*I want* automated installation\\*So that* I don't repeat work\\\\h4. TECHNICAL DETAILS\\* *Location:* {{.github/actions/setup/action.yml}}\\\\h4. ACCEPTANCE CRITERIA\\* Create action\\* Install {{apigeecli}}, {{yq}}, {{jq}}"
```

**POINT OUT**:
- `*As a*` = Bold text
- `\\` = Line breaks
- `h4.` = Headers
- `{{code}}` = Code formatting

**SAY**:
> "This looks messy here, but watch what happens in Jira..."

---

### Act 4: The Jira Import (2 minutes)

**GO TO JIRA**:
1. Settings → System → External System Import → CSV
2. Upload `jira-import.csv`
3. Map fields:
   - Summary → Summary
   - Description → Description
   - Story Points → Story Points
   - Epic Link → Epic Link
   - Labels → Labels
4. Click Import

**WAIT** for import to complete (should be ~10 seconds)

**OPEN ONE STORY** (same Story 1):

**SHOW HOW IT RENDERS**:
> **As a** developer
> **I want** automated installation
> **So that** I don't repeat work
>
> #### TECHNICAL DETAILS
> • **Location:** `.github/actions/setup/action.yml`
>
> #### ACCEPTANCE CRITERIA
> • Create action
> • Install `apigeecli`, `yq`, `jq`

**SAY**:
> "Look at that formatting! Headers, bold text, code highlighting, bullet lists - all preserved from the CSV import.
>
> And this is ONE of 26 stories. All formatted exactly the same way."

---

### Act 5: The Dashboard Connection (1 minute)

**OPEN**: Your Confluence dashboard

**SAY**:
> "And here's the best part - I also created an auto-updating dashboard that tracks all these stories across our two epics.
>
> No manual updates needed. It pulls directly from Jira using JQL queries."

**SHOW**:
- Epic progress sections
- Active work section
- Recently completed section

**SAY**:
> "The team always has visibility into progress. No more asking 'what's the status?'"

---

### The Big Finish (30 seconds)

**SAY**:
> "So to recap:
>
> 1. **Copilot generated** 26 professional user stories from a conversation
> 2. **Automated script** formatted them for Jira in 1 second
> 3. **Imported to Jira** with perfect formatting in 10 seconds
> 4. **Auto-updating dashboard** gives the team real-time visibility
>
> **Total time**: About 5 minutes
>
> **Traditional approach**: 2-3 hours
>
> That's a **95% time savings**. And the stories are higher quality because Copilot helped think through acceptance criteria, dependencies, and technical details I might have missed."

---

## 💡 Handling Questions

### "Did you have to edit the stories?"

**A**: "A little - maybe 10-15 minutes of refinement after the initial generation. I adjusted some story points, added a couple of missing technical details. But that's still way faster than writing from scratch."

### "Does this work for any project?"

**A**: "Yes! The key is giving Copilot good context. I showed it our project structure, our naming conventions, examples from our gitops repo. The better the context, the better the output."

### "Can we use this for our team?"

**A**: "Absolutely! The script is in our repo at `scripts/format-jira-csv.py`. There's a complete guide at `docs/planning/CSV-FORMATTING-GUIDE.md`. I can help anyone get started."

### "What about the Confluence dashboard?"

**A**: "I have documentation for that too, but the short version: Use Jira macros in Confluence with JQL queries. No code needed - just copy the right queries and configure the macros. Takes about 15 minutes."

### "How do you know what to ask Copilot?"

**A**: "Start broad, then refine. I usually begin with 'Help me break down this work' and then ask follow-ups like 'Create this as a CSV' or 'Add more detail to the acceptance criteria.' It's conversational - just like working with a teammate."

---

## 🎯 Demo Success Metrics

**If you nail this, your team will say**:
- "I want to try this on my next project"
- "Can you share that script?"
- "How do I get better at prompting Copilot?"
- "We should standardize on this approach"

**Share after demo**:
- Link to the repo
- Path to documentation: `docs/planning/`
- Offer to pair with anyone who wants to learn

---

## 🚀 Post-Demo Actions

### Immediate
1. Share demo recording (if recorded)
2. Share links to documentation
3. Post in team Slack/Teams with key points

### Follow-Up
1. Schedule "Copilot Office Hours" for Q&A
2. Create template repo with script for other teams
3. Write internal blog post or wiki page
4. Consider presenting at broader engineering meeting

---

## 📚 Demo Resources Checklist

**Available in repo**:
- ✅ `docs/planning/DEMO-SCRIPT.md` - Step-by-step walkthrough
- ✅ `docs/planning/CSV-FORMATTING-GUIDE.md` - Complete formatting reference
- ✅ `docs/planning/jira-import.csv` - The 26 formatted stories
- ✅ `scripts/format-jira-csv.py` - The automation script
- ✅ `docs/planning/JIRA-IMPORT-INSTRUCTIONS.md` - Import how-to

**To create** (optional):
- Screenshots of before/after story formatting
- Screen recording of the demo
- Quick reference card with Wiki Markup syntax
- Template Copilot prompts for generating stories

---

## 🎬 Director's Notes

### Pacing
- **Keep it punchy** - 7-10 minutes max
- **Show, don't tell** - Live demos beat slides
- **Build suspense** - Problem → Magic → Wow

### Energy
- **Start strong** - "Changed how I work" hooks attention
- **Build excitement** - "Watch this..." before each reveal
- **End high** - "95% time savings" + team benefit

### Authenticity
- **Share the struggle** - "I used to spend hours on this"
- **Show real work** - Actual stories from your project
- **Be honest** - "Had to refine a bit" = credibility

### Engagement
- **Pause for reactions** - Let people react to the automation
- **Ask questions** - "How long would this take you manually?"
- **Invite participation** - "Anyone want to try this?"

---

## ⚡ Quick Start for Nervous Presenters

**If you're short on time or nervous about live demo**:

### Simplified 5-Minute Version

1. **Show the CSV** (30 sec) - "Copilot generated 26 stories"
2. **Run the script** (30 sec) - "Automated formatting"
3. **Show one Jira story** (already imported, 1 min) - "Perfect formatting"
4. **Show dashboard** (1 min) - "Auto-updating visibility"
5. **Impact** (30 sec) - "5 minutes vs 3 hours"
6. **Q&A** (1.5 min)

**No need to**:
- Show Copilot chat (just mention it)
- Do live Jira import (pre-import one story)
- Explain all Wiki Markup details (just show the result)

---

## 🎓 Pro Tips

### Make It Visual
- Use large fonts in terminal (Cmd + + in VSCode)
- Use split screen to show before/after
- Use browser zoom for Jira stories
- Consider screen recording as backup

### Make It Relatable
- Start with pain point everyone knows
- Use exact numbers (26 stories, 5 minutes, 95% savings)
- Show real work, not toy examples

### Make It Actionable
- End with "Here's how you can do this"
- Share documentation links
- Offer to help teammates get started

### Make It Memorable
- One killer soundbite: "From chat to Jira in 60 seconds"
- One shocking stat: "95% time savings"
- One clear benefit: "Higher quality + way faster"

---

## 🔥 Bonus: The "Holy Sh*t" Moment

**If you really want to blow minds**, show this comparison:

### Manual Approach (Old Way)
1. Read requirements - 30 min
2. Break into stories - 45 min
3. Write each story - 2-3 min × 26 = 52-78 min
4. Format in Jira - 1-2 min × 26 = 26-52 min
5. Create dashboard - 30 min
6. **Total: 3-4 hours**

### Copilot Approach (New Way)
1. Chat with Copilot - 10 min
2. Refine stories - 15 min
3. Run format script - 1 sec
4. Import to Jira - 10 sec
5. Create dashboard - 15 min
6. **Total: 40 minutes**

**Savings: 140-200 minutes per sprint planning**

---

**Good luck! You've got this. The work is already done - now just show it off!** 🎉
