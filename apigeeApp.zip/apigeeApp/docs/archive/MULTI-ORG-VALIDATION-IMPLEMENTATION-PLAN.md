# Multi-Org Validation Implementation Plan

## Status: 📋 Planning Phase

### Completed ✅
- Multi-org deployment workflows (deploy-products, deploy-to-dev, deploy-to-test, deploy-to-prod)
- Composite actions (apigee-org, filter-files-by-org, get-service-account)
- GitOps validation workflows (validate-apigee-proxy, validate-apigee-sharedflow)

### Remaining Work 🚧
- Applications validation workflows (validate-proxy.yml, validate-product.yml)

---

## Objective

Implement matrix strategy for validation workflows in applications repo to enable:
- **Multi-org PRs**: Single PR can modify proxies/products across multiple orgs
- **Parallel validation**: Each org validated independently and in parallel
- **Isolated failures**: One org's validation failure doesn't block other orgs
- **Consistent pattern**: Match gitops validation implementation

--- 

## Reference Implementation

### GitOps validate-apigee-proxy.yml Structure

```yaml
jobs:
  detect-changes:
    outputs:
      org_matrix: ${{ steps.apigee-org.outputs.org_matrix }}
      changed_files: ${{ steps.changed-files.outputs.changed_files }}
      deleted_files: ${{ steps.changed-files.outputs.deleted_files }}
    steps:
      - uses: actions/checkout@v4
      - uses: ./.github/actions/changed-files
      - uses: ./.github/actions/apigee-org
        with:
          changed_files: ${{ steps.changed-files.outputs.changed_files }}
          deleted_files: ${{ steps.changed-files.outputs.deleted_files }}

  validate:
    needs: detect-changes
    if: needs.detect-changes.outputs.org_matrix != '[]'
    strategy:
      fail-fast: false
      matrix:
        org: ${{ fromJson(needs.detect-changes.outputs.org_matrix) }}
    steps:
      - uses: actions/checkout@v4
      - uses: ./.github/actions/filter-files-by-org
        with:
          changed_files: ${{ needs.detect-changes.outputs.changed_files }}
          deleted_files: ${{ needs.detect-changes.outputs.deleted_files }}
          org: ${{ matrix.org }}
      - name: Validate proxies for ${{ matrix.org }}
        # ... validation logic per org
```

---

## Implementation Plan

### 1. validate-proxy.yml Migration

**Current State**: 953 lines, single-job workflow with extensive validation
- YAML syntax validation
- JSON schema validation
- Naming convention checks
- Template reference validation
- KVM configuration validation
- OAS specification validation
- Template download verification
- Bundle build validation (dry-run import to Apigee)

**Target State**: Matrix-based validation with detect-changes + validate jobs

**Approach**:
1. Add `detect-changes` job (similar to deploy workflows)
2. Restructure existing validation logic into matrix `validate` job
3. Add per-org file filtering with `filter-files-by-org` action
4. Handle GCP authentication per org using `get-service-account` action
5. Aggregate validation results across matrix jobs for PR summary

**Complexity**: High
- Dry-run import requires GCP authentication per org
- Complex validation logic needs careful preservation
- PR summary needs aggregation across matrix jobs

**Estimated Effort**: 6-8 hours
- 2 hours: Restructure job architecture (detect-changes + validate matrix)
- 2 hours: Update file filtering and per-org logic
- 1 hour: GCP authentication per org (reuse get-service-account action)
- 2 hours: PR summary aggregation across matrix jobs
- 1 hour: Testing and refinement

---

### 2. validate-product.yml Migration

**Current State**: 309 lines, single-job workflow
- Product YAML validation
- Schema validation
- Proxy reference validation
- Consumer validation
- Quota validation

**Target State**: Matrix-based validation with detect-changes + validate jobs

**Approach**:
1. Add `detect-changes` job
2. Restructure validation logic into matrix `validate` job
3. Add per-org file filtering
4. Aggregate results for PR summary

**Complexity**: Medium
- Simpler than proxy validation (no GCP auth, no bundle building)
- Mostly schema and reference validation
- PR summary aggregation needed

**Estimated Effort**: 3-4 hours
- 1 hour: Restructure job architecture
- 1 hour: Update file filtering per org
- 1 hour: PR summary aggregation
- 30 min: Testing

---

## Detailed Migration Steps

### Step 1: validate-proxy.yml Refactor

#### 1.1 Add detect-changes Job (30 min)
```yaml
jobs:
  detect-changes:
    name: Detect Changed Proxies
    runs-on: ubuntu-latest
    outputs:
      org_matrix: ${{ steps.get-orgs.outputs.org_matrix }}
      changed_files: ${{ steps.changed-files.outputs.changed_files }}
      deleted_files: ${{ steps.changed-files.outputs.deleted_files }}
      has-changes: ${{ steps.check-changes.outputs.has-changes }}
      mal-code: ${{ steps.metadata.outputs.mal-code }}
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Calculate Changed Files
        id: changed-files
        uses: ./.github/actions/changed-files

      - name: Get Apigee organizations
        id: get-orgs
        uses: ./.github/actions/apigee-org
        with:
          changed_files: ${{ steps.changed-files.outputs.changed_files }}
          deleted_files: ${{ steps.changed-files.outputs.deleted_files }}

      - name: Check for Changes
        id: check-changes
        shell: bash
        run: |
          CHANGED="${{ steps.changed-files.outputs.changed_files }}"
          DELETED="${{ steps.changed-files.outputs.deleted_files }}"
          if [ -n "$CHANGED" ] || [ -n "$DELETED" ]; then
            echo "has-changes=true" >> $GITHUB_OUTPUT
          else
            echo "has-changes=false" >> $GITHUB_OUTPUT
          fi

      - name: Extract MAL Metadata
        id: metadata
        shell: bash
        run: |
          CHANGED="${{ steps.changed-files.outputs.changed_files }}"
          if [ -n "$CHANGED" ]; then
            FIRST_FILE=$(echo "$CHANGED" | awk '{print $1}')
            MAL_CODE=$(echo "$FIRST_FILE" | grep -oP 'mal-SYSGEN\K[0-9]{9}' || echo "")
            echo "mal-code=$MAL_CODE" >> $GITHUB_OUTPUT
          fi
```

#### 1.2 Convert to Matrix validate Job (2 hours)
```yaml
  validate:
    name: Validate Proxies for ${{ matrix.org }}
    runs-on: ubuntu-latest
    needs: detect-changes
    if: needs.detect-changes.outputs.has-changes == 'true' && needs.detect-changes.outputs.org_matrix != '[]'
    strategy:
      fail-fast: false
      matrix:
        org: ${{ fromJson(needs.detect-changes.outputs.org_matrix) }}
    environment:
      name: ${{ matrix.org }}
    env:
      APIGEE_ORG: ${{ matrix.org }}
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Filter files for this org
        id: filter-files
        uses: ./.github/actions/filter-files-by-org
        with:
          changed_files: ${{ needs.detect-changes.outputs.changed_files }}
          deleted_files: ${{ needs.detect-changes.outputs.deleted_files }}
          org: ${{ matrix.org }}

      - name: Derive Environment from Org
        id: derive-env
        shell: bash
        run: |
          if [[ "$APIGEE_ORG" =~ gcp-prj-apigee-([^-]+)-np-01 ]]; then
            ENV_SUFFIX="${BASH_REMATCH[1]}"
            APIGEE_ENV="apicc-${ENV_SUFFIX}"
          elif [[ "$APIGEE_ORG" =~ gcp-prj-apigee-([^-]+)-01 ]]; then
            ENV_SUFFIX="${BASH_REMATCH[1]}"
            APIGEE_ENV="apicc-${ENV_SUFFIX}"
          else
            echo "❌ Could not derive environment from org: $APIGEE_ORG"
            exit 1
          fi
          echo "apigee-env=$APIGEE_ENV" >> $GITHUB_OUTPUT
          echo "APIGEE_ENV=$APIGEE_ENV" >> $GITHUB_ENV

      # ... existing validation steps but using filtered files
```

#### 1.3 Add GCP Authentication per Org (1 hour)
```yaml
      - name: Get Service Account
        id: get-sa
        uses: ./.github/actions/get-service-account
        with:
          mal-code: SYSGEN${{ needs.detect-changes.outputs.mal-code }}
          apigee-org: ${{ matrix.org }}
          apigee-env: ${{ steps.derive-env.outputs.apigee-env }}

      - name: Authenticate with GCP
        shell: bash
        env:
          GCP_SA_KEY: ${{ steps.get-sa.outputs.sa_key }}
        run: |
          set +x
          if [ -z "$GCP_SA_KEY" ]; then
            echo "❌ GCP_SA_KEY secret not found for $APIGEE_ORG"
            exit 1
          fi
          echo "🔐 Authenticating with GCP for $APIGEE_ORG"
          printf "%s" "$GCP_SA_KEY" > /tmp/gcp-key.json
          gcloud auth activate-service-account --key-file=/tmp/gcp-key.json
          gcloud config set project "$APIGEE_ORG"
          GCP_ACCESS_TOKEN=$(gcloud auth print-access-token)
          echo "GCP_ACCESS_TOKEN=$GCP_ACCESS_TOKEN" >> $GITHUB_ENV
```

#### 1.4 Update File Filtering Logic (1 hour)
Replace all instances of:
```bash
CHANGED_FILES="${{ steps.changed-files.outputs.changed_files }}"
```

With:
```bash
CHANGED_FILES="${{ steps.filter-files.outputs.changed_files }}"
DELETED_FILES="${{ steps.filter-files.outputs.deleted_files }}"
```

Remove hardcoded org filtering:
```bash
# OLD - Remove this
if [[ "$file" =~ ^mal-SYSGEN[0-9]{9}/orgs/gcp-prj-apigee-dev-np-01/envs/.*/proxies/.*/.*\.yaml$ ]]; then

# NEW - Use this (files already filtered by composite action)
if [[ "$file" =~ /proxies/.*\.yaml$ ]]; then
```

#### 1.5 PR Summary Aggregation (2 hours)
Add a final aggregation job:
```yaml
  aggregate-results:
    name: Aggregate Validation Results
    runs-on: ubuntu-latest
    needs: [detect-changes, validate]
    if: always() && needs.detect-changes.outputs.has-changes == 'true'
    steps:
      - name: Generate Summary
        run: |
          echo "## Multi-Org Proxy Validation Results" >> $GITHUB_STEP_SUMMARY
          echo "" >> $GITHUB_STEP_SUMMARY

          # Check validation job status for each org
          ORGS='${{ needs.detect-changes.outputs.org_matrix }}'

          echo "| Organization | Status |" >> $GITHUB_STEP_SUMMARY
          echo "|--------------|--------|" >> $GITHUB_STEP_SUMMARY

          # This is pseudo-code - actual implementation needs job status checking
          # GitHub Actions doesn't provide easy access to matrix job statuses
          # Alternative: Have each matrix job write results to artifact, aggregate here
```

**Note**: PR summary aggregation across matrix jobs is challenging in GitHub Actions. Two approaches:
1. **Artifacts approach**: Each matrix job uploads validation results as artifact, aggregation job downloads and combines
2. **GitHub API approach**: Query workflow run API to get status of each matrix job
3. **Simplest approach**: Let each matrix job post its own summary section (no aggregation)

---

### Step 2: validate-product.yml Refactor

Similar structure but simpler:
1. Add detect-changes job (reuse pattern from validate-proxy)
2. Convert single validate job to matrix
3. Add file filtering per org
4. No GCP auth needed (products don't require Apigee API access for validation)
5. Simpler aggregation (just schema + reference validation)

**Detailed steps**: Same pattern as validate-proxy but without:
- GCP authentication
- Bundle building
- Dry-run imports
- Template downloads

**Estimated effort**: 3-4 hours

---

## Testing Strategy

### Phase 1: Single-Org Validation (Baseline)
1. Create PR with changes to single org
2. Verify validation runs successfully
3. Confirm results match pre-migration behavior

### Phase 2: Multi-Org Validation (Target)
1. Create PR with changes to 2-3 orgs
2. Verify matrix creates correct number of jobs
3. Confirm each org validates independently
4. Test isolated failure (introduce error in one org, verify others succeed)
5. Verify PR summary shows all org results

### Phase 3: Edge Cases
1. Empty PR (no changes) - should skip
2. Changes to non-proxy/non-product files - should skip
3. Deleted files only - should handle gracefully
4. Mix of changed and deleted files

---

## Success Criteria

### Functional
- ✅ Single-org PRs validate successfully
- ✅ Multi-org PRs create matrix with correct org count
- ✅ Validation runs independently per org
- ✅ Failures isolated (one org fails, others continue)
- ✅ PR summary shows results for all orgs

### Performance
- ✅ Multi-org validation runs in parallel
- ✅ No significant slowdown vs single-org (except for matrix overhead)

### Code Quality
- ✅ Reuses existing composite actions
- ✅ Follows same pattern as deployment workflows
- ✅ Matches gitops validation implementation
- ✅ Clear error messages and summaries

---

## Risks & Mitigations

### Risk: PR Summary Aggregation Complexity
**Impact**: High - Users need clear view of all validation results
**Mitigation**: Start with simplest approach (each matrix job posts own summary), iterate if needed

### Risk: Dry-run Import Concurrency
**Impact**: Medium - Multiple matrix jobs may import to same Apigee org
**Mitigation**:
- Use unique revision numbers per job
- Clean up test revisions after validation
- Consider rate limiting or org-level locking if issues arise

### Risk: Service Account Permissions
**Impact**: High - Validation requires read access to Apigee
**Mitigation**:
- Reuse existing get-service-account action (already working for deployments)
- MAL-based service accounts should have necessary permissions

### Risk: Workflow File Size/Complexity
**Impact**: Medium - validate-proxy.yml already 953 lines
**Mitigation**:
- Consider extracting validation steps into composite actions
- Document thoroughly
- Follow existing patterns from deploy workflows

---

## Timeline Estimate

### validate-proxy.yml: 6-8 hours
- Job restructure: 2 hours
- File filtering updates: 2 hours
- GCP auth per org: 1 hour
- PR summary aggregation: 2 hours
- Testing: 1 hour

### validate-product.yml: 3-4 hours
- Job restructure: 1 hour
- File filtering updates: 1 hour
- PR summary aggregation: 1 hour
- Testing: 30 min

### Documentation: 1 hour
- Update PRODUCT-WORKFLOW-GUIDE.md
- Update validation testing guides
- Multi-org usage examples

**Total: 10-13 hours**

---

## Open Questions

1. **PR Summary Aggregation**: Which approach to use?
   - Option A: Each matrix job posts own summary (simplest)
   - Option B: Artifacts + aggregation job (most comprehensive)
   - Option C: GitHub API query (most complex)

2. **Validation Scope**: Should validation be as thorough as deployment?
   - Currently does dry-run imports which require Apigee access
   - Could simplify to just schema/template/OAS validation (no Apigee API)
   - Trade-off: Speed vs early error detection

3. **Backward Compatibility**: Support single-org workflow during transition?
   - Add feature flag to enable/disable matrix strategy?
   - Or cut over completely once tested?

---

## Next Steps (Tomorrow)

1. ✅ **Tonight**: Complete testing of deployment workflows
2. 🚀 **Tomorrow**: Implement validate-proxy.yml migration
3. 🚀 **Tomorrow**: Implement validate-product.yml migration
4. 🧪 **Tomorrow**: End-to-end testing with multi-org PRs
5. 📝 **Tomorrow**: Update documentation

---

## References

- **Working Examples**:
  - [gitops/validate-apigee-proxy.yml](../../../enterprise-apigeex-gitops/.github/workflows/validate-apigee-proxy.yml)
  - [gitops/validate-apigee-sharedflow.yml](../../../enterprise-apigeex-gitops/.github/workflows/validate-apigee-sharedflow.yml)
  - [applications/deploy-products.yml](.github/workflows/deploy-products.yml) - Tested with PR #50

- **Composite Actions**:
  - [apigee-org](.github/actions/apigee-org/action.yml)
  - [filter-files-by-org](.github/actions/filter-files-by-org/action.yml)
  - [get-service-account](.github/actions/get-service-account/action.yml)

- **Testing**:
  - PR #50: Multi-org products validation (3 orgs, 3 matrix jobs)
  - Workflow run 20322168697: Confirmed matrix strategy working
