# Jira CSV Formatting Guide

## Overview

This guide explains how to create properly formatted Jira CSV files that preserve formatting (bold, line breaks, lists, code formatting) when imported.

## The Problem

Plain text CSV files lose all formatting when imported to Jira:
- Line breaks disappear → everything becomes one paragraph
- No bold, italic, or other text formatting
- No headers or sections
- No code highlighting

## The Solution

Use **Jira Wiki Markup** in CSV fields to preserve formatting.

## Wiki Markup Reference

### Line Breaks
```
Use \\ (double backslash) for line breaks in CSV
```

**Example CSV field**:
```csv
"First line\\Second line\\Third line"
```

**Renders in Jira as**:
```
First line
Second line
Third line
```

### Headers
```
h4. Header Text
```

**Example**:
```csv
"h4. TECHNICAL DETAILS\\Some content here"
```

**Renders in Jira as**:
```
#### TECHNICAL DETAILS
Some content here
```

### Bold and Italic
```
*bold text*
_italic text_
_*bold italic*_
```

**Example**:
```csv
"*As a* developer *I want* tools"
```

**Renders in Jira as**:
> **As a** developer **I want** tools

### Bullet Lists
```
* Item 1
* Item 2
** Nested item
```

**Example**:
```csv
"h4. ACCEPTANCE CRITERIA\\* Create action file\\* Install tools\\** Install yq\\** Install jq"
```

**Renders in Jira as**:
```
#### ACCEPTANCE CRITERIA
• Create action file
• Install tools
  ◦ Install yq
  ◦ Install jq
```

### Code Formatting

**Inline code** (file names, variable names, commands):
```
{{filename.yml}}
{{VARIABLE_NAME}}
```

**Example**:
```csv
"Create {{.github/workflows/deploy.yml}} and export {{API_KEY}} variable"
```

**Renders in Jira as**:
> Create `.github/workflows/deploy.yml` and export `API_KEY` variable

**Code blocks**:
```
{code:yaml}
key: value
{code}
```

## Formatted Story Example

### Plain Text (No Formatting)
```csv
"Description"
"As a developer I want automated tools So that I save time

TECHNICAL DETAILS:
Location: .github/actions/setup/action.yml
Install: apigeecli, yq, jq

ACCEPTANCE CRITERIA:
- Create action file
- Install tools
- Test it works"
```

### Wiki Markup (With Formatting)
```csv
"Description"
"*As a* developer\\*I want* automated tools\\*So that* I save time\\\\h4. TECHNICAL DETAILS\\* *Location:* {{.github/actions/setup/action.yml}}\\* *Install:* {{apigeecli}}, {{yq}}, {{jq}}\\\\h4. ACCEPTANCE CRITERIA\\* Create action file\\* Install tools\\* Test it works"
```

### How It Renders in Jira

**As a** developer
**I want** automated tools
**So that** I save time

#### TECHNICAL DETAILS
• **Location:** `.github/actions/setup/action.yml`
• **Install:** `apigeecli`, `yq`, `jq`

#### ACCEPTANCE CRITERIA
• Create action file
• Install tools
• Test it works

## Automation Script

We provide a Python script to automatically format CSV files:

### Usage
```bash
python3 scripts/format-jira-csv.py
```

### What It Does
1. Reads `docs/planning/jira-import.csv`
2. Detects sections (user stories, headers, lists)
3. Applies Wiki Markup formatting
4. Writes formatted CSV back to the same file

### Formatting Rules Applied
- **User stories**: Bolds "As a", "I want", "So that"
- **Headers**: Converts all-caps lines to `h4.` headers
- **Lists**: Converts `-` or `*` prefixes to Wiki list format
- **Code elements**: Wraps file paths, env vars, commands in `{{}}`
- **Key-value pairs**: Bolds keys, formats values

### Example Output
The script automatically converts this:

```
As a developer I want tools So that I save time

TECHNICAL DETAILS:
Location: .github/actions/setup.yml
Install: yq, jq

ACCEPTANCE CRITERIA:
- Create file
- Install tools
```

Into this:

```
*As a* developer\\*I want* tools\\*So that* I save time\\\\h4. TECHNICAL DETAILS\\* *Location:* {{.github/actions/setup.yml}}\\* *Install:* {{yq}}, {{jq}}\\\\h4. ACCEPTANCE CRITERIA\\* Create file\\* Install tools
```

## CSV Escaping Rules

### Double Backslashes in Python
When creating formatted strings in Python, use double backslashes:

```python
description = "*As a* developer\\\\*I want* tools"
```

The Python string has `\\\\` which becomes `\\` in the actual CSV field, which Jira interprets as a line break.

### CSV Module Auto-Escaping
The Python `csv` module automatically escapes special characters:
- `{{` becomes `{{{{` in the CSV file
- `\\` becomes `\\\\` in the CSV file
- Jira correctly interprets these when importing

**You don't need to manually escape** - let the CSV module handle it.

### Using csv.QUOTE_ALL
Always quote fields with formatting to prevent issues:

```python
import csv

with open('output.csv', 'w', newline='') as f:
    writer = csv.writer(f, quoting=csv.QUOTE_ALL)
    writer.writerow(['Description'])
    writer.writerow(['*As a* developer\\*I want* tools'])
```

## Testing Your Formatting

### Step 1: Create Test CSV
Create a CSV with ONE formatted story:

```csv
"Summary","Description"
"Test Story","*As a* developer\\*I want* tools\\*So that* I save time\\\\h4. ACCEPTANCE CRITERIA\\* Test item 1\\* Test item 2"
```

### Step 2: Import to Test Project
1. Create a test Jira project or use a sandbox
2. Import the single-story CSV
3. Open the created story
4. Verify formatting renders correctly

### Step 3: Adjust if Needed
If formatting doesn't look right:
- Check for missing `\\` between lines
- Check for unescaped special characters
- Verify Wiki Markup syntax
- Try different header levels (`h3.` vs `h4.` vs `h5.`)

### Step 4: Apply to All Stories
Once one story formats correctly, apply the same pattern to all stories.

## Common Patterns for User Stories

### Standard User Story
```
*As a* <role>\\*I want* <feature>\\*So that* <benefit>
```

### With Technical Details
```
*As a* <role>\\*I want* <feature>\\*So that* <benefit>\\\\h4. TECHNICAL DETAILS\\* *Key1:* value1\\* *Key2:* value2
```

### With Acceptance Criteria
```
*As a* <role>\\*I want* <feature>\\*So that* <benefit>\\\\h4. ACCEPTANCE CRITERIA\\* Criterion 1\\* Criterion 2\\* Criterion 3
```

### Full Template
```
*As a* <role>\\*I want* <feature>\\*So that* <benefit>\\\\h4. TECHNICAL DETAILS\\* *Location:* {{file/path}}\\* *Dependencies:* {{tool1}}, {{tool2}}\\\\h4. ACCEPTANCE CRITERIA\\* Create {{file}}\\* Configure {{setting}}\\* Test functionality
```

## Jira Compatibility

### Wiki Markup (Recommended)
- Works in **Jira Server, Jira Data Center, Jira Cloud**
- Most reliable and widely supported
- Described in this guide

### Markdown (Alternative)
- Supported in **Jira Cloud only** (newer instances)
- Not guaranteed to work in all Jira versions
- Use `\n` instead of `\\` for line breaks
- Use `**bold**` instead of `*bold*`

**For maximum compatibility, use Wiki Markup.**

## Troubleshooting

### Issue: Formatting not appearing
- **Solution**: Ensure you're using `\\` (double backslash) not `\n` or single `\`
- **Check**: Open CSV in text editor and verify `\\` appears in the file

### Issue: Code blocks showing as plain text
- **Solution**: Use `{{code}}` not `` `code` `` (Wiki Markup not Markdown)
- **Check**: Verify Jira supports Wiki Markup (should work in all versions)

### Issue: Headers not rendering
- **Solution**: Ensure `h4.` has a space after it: `h4. Header` not `h4.Header`
- **Try**: Different header levels (`h3.`, `h4.`, `h5.`)

### Issue: Lists not formatting
- **Solution**: Ensure each list item starts with `* ` (asterisk space)
- **Check**: No extra characters before the asterisk

### Issue: Double escaping ({{{{ instead of {{)
- **Solution**: This is normal CSV escaping - Jira will interpret it correctly
- **Don't**: Try to manually fix the escaping - let the CSV module handle it

## Demo Workflow

### For Your Team Demo

1. **Show the Problem**:
   - Show plain text CSV in Excel/editor
   - Import to Jira → formatting is lost
   - Stories are hard to read

2. **Explain the Solution**:
   - Show Wiki Markup syntax
   - Explain `\\` for line breaks, `*bold*`, `{{code}}`
   - Show formatted CSV example

3. **Run the Script**:
   ```bash
   python3 scripts/format-jira-csv.py
   ```
   - Show before/after comparison
   - Explain automation benefits

4. **Import and Verify**:
   - Import formatted CSV to Jira
   - Open a story → formatting is preserved
   - Show clean, professional formatting

5. **Provide Documentation**:
   - Share this guide
   - Share the script
   - Include in project README

## Resources

### Official Jira Documentation
- [Jira Wiki Markup Reference](https://jira.atlassian.com/secure/WikiRendererHelpAction.jspa)
- [CSV Import Guide](https://support.atlassian.com/jira-cloud-administration/docs/import-data-from-a-csv-file/)

### Our Scripts
- `scripts/format-jira-csv.py` - Automated CSV formatting
- `docs/planning/JIRA-IMPORT-INSTRUCTIONS.md` - Import instructions
- `docs/planning/CSV-FORMATTING-GUIDE.md` - This guide

### Example Files
- `docs/planning/jira-import.csv` - Formatted CSV with 26 stories
- Each story demonstrates proper Wiki Markup formatting

---

**Questions?** Check the troubleshooting section or review the formatted CSV examples in `jira-import.csv`.
