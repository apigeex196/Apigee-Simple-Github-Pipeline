# 🎨 Demo Slide Deck Outline

## Optional Backup Slides (if live demo fails or for async sharing)

---

## Slide 1: Title

**Visual**: Bold, clean title

```
From Copilot Chat to Jira Stories
in 60 Seconds

A Story About AI-Powered Productivity
```

**Speaker Notes**:
- This is about practical AI, not magic
- Real work, real time savings
- You can do this too

---

## Slide 2: The Challenge

**Visual**: Split screen or before/after

```
The Old Way: Creating Jira Stories

❌ Read requirements         (30 min)
❌ Break into stories         (45 min)
❌ Write 26 stories           (52-78 min)
❌ Format in Jira             (26-52 min)
❌ Create tracking dashboard  (30 min)

⏰ Total: 3-4 hours
😫 Tedious, repetitive, easy to miss details
```

**Speaker Notes**:
- Everyone knows this pain
- We've all spent hours on story creation
- This is just for ONE sprint planning session

---

## Slide 3: The Breakthrough

**Visual**: Copilot logo or chat interface screenshot

```
What if AI could do the heavy lifting?

💬 Conversation with GitHub Copilot:
   "Help me break down this infrastructure work
    into user stories for Jira import"

🤖 Copilot generates:
   ✓ 26 professional user stories
   ✓ Acceptance criteria
   ✓ Technical details
   ✓ Story point estimates
   ✓ Labels and categorization
```

**Speaker Notes**:
- Just like talking to a knowledgeable teammate
- Copilot understood our domain (Apigee X, GitHub Actions)
- Generated complete, detailed stories

---

## Slide 4: The Problem with Plain Text

**Visual**: Screenshot of ugly, unformatted Jira story

```
But CSV imports lose formatting...

Plain Text CSV:
"As a developer I want tools So that I save time
ACCEPTANCE CRITERIA: Create file Install tools Test it"

↓ Import to Jira ↓

Renders as one ugly paragraph:
As a developer I want tools So that I save time ACCEPTANCE
CRITERIA: Create file Install tools Test it
```

**Speaker Notes**:
- Jira strips all formatting from plain text
- No line breaks, no headers, no structure
- Back to manual formatting... or is there another way?

---

## Slide 5: The Automation Magic

**Visual**: Terminal screenshot or code snippet

```
Solution: Automated Wiki Markup Formatting

$ python3 scripts/format-jira-csv.py

📝 Formatting Jira CSV with Wiki Markup...
✅ Complete! Formatted: 26/26 stories

⚡ Transforms in < 1 second:
   Plain text → Jira Wiki Markup

   "As a developer"
   →
   "*As a* developer\\*I want*\\*So that*\\h4. CRITERIA"
```

**Speaker Notes**:
- Copilot also wrote this automation script
- Handles bold, line breaks, headers, code formatting
- 26 stories formatted instantly

---

## Slide 6: The Beautiful Result

**Visual**: Screenshot of formatted Jira story

```
Same Story After Import:

**As a** developer
**I want** automated installation
**So that** I don't repeat work

#### TECHNICAL DETAILS
• **Location:** `.github/actions/setup.yml`
• **Dependencies:** `apigeecli`, `yq`, `jq`

#### ACCEPTANCE CRITERIA
• Create action file
• Install required tools
• Test installation works
```

**Speaker Notes**:
- Professional formatting
- Clear sections
- Code highlighting
- Easy to read and understand

---

## Slide 7: The Dashboard

**Visual**: Screenshot of Confluence dashboard

```
Bonus: Auto-Updating Team Dashboard

📊 Real-Time Visibility:
   • Epic progress tracking
   • Active work across team
   • Recently completed stories
   • Blocked or high-priority items

🔄 Zero Maintenance:
   • Jira macros with JQL queries
   • Auto-refreshes on page load
   • No manual updates needed
```

**Speaker Notes**:
- Team always knows current status
- No more "what's the progress?" meetings
- Set up once, updates forever

---

## Slide 8: The Impact

**Visual**: Large, bold numbers

```
The Results

🕐 Time Comparison:
   Old Way:  180 minutes (3 hours)
   New Way:  5 minutes
   Savings:  95%

📊 Quality Comparison:
   ✅ More complete acceptance criteria
   ✅ Better technical details
   ✅ Consistent formatting
   ✅ Fewer missed dependencies

🔄 Repeatability:
   ✅ Use for every sprint
   ✅ Share with other teams
   ✅ Continuously improve prompts
```

**Speaker Notes**:
- This isn't just faster - it's better quality
- AI helps think through details I might miss
- Repeatable process we can standardize

---

## Slide 9: How It Works

**Visual**: Simple workflow diagram

```
The 3-Step Process:

1️⃣ CHAT
   Talk to Copilot about your project
   → Generates user stories

2️⃣ FORMAT
   Run automation script
   → Adds Jira Wiki Markup

3️⃣ IMPORT
   Upload CSV to Jira
   → Professional stories instantly

⏱️ Total: 5 minutes
```

**Speaker Notes**:
- Simple enough for anyone to use
- No coding required (just run the script)
- Can customize for your needs

---

## Slide 10: What Makes This Work

**Visual**: Key insights as bullets

```
Success Factors:

💬 Good Prompting
   • Give Copilot context (project structure, examples)
   • Start broad, refine iteratively
   • Conversational, not command-based

🔧 Smart Automation
   • Wiki Markup for Jira compatibility
   • Patterns for code elements ({{file.yml}})
   • Consistent formatting rules

📚 Documentation
   • Scripts in version control
   • Guides for team adoption
   • Examples for future reference
```

**Speaker Notes**:
- This is a skill anyone can learn
- Better prompts = better outputs
- Document and share with team

---

## Slide 11: Try It Yourself

**Visual**: Call to action with resources

```
Resources Available Now:

📂 In Our Repo:
   docs/planning/CSV-FORMATTING-GUIDE.md
   docs/planning/DEMO-SCRIPT.md
   scripts/format-jira-csv.py

🤝 Getting Started:
   1. Clone the repo
   2. Read the CSV formatting guide
   3. Try the script on your next stories
   4. Reach out if you need help

💡 Office Hours:
   [Your availability here]
   Happy to pair program or answer questions
```

**Speaker Notes**:
- Everything is documented and ready to use
- Encourage experimentation
- Offer to help teammates get started

---

## Slide 12: The Bigger Picture

**Visual**: Thoughtful, forward-looking

```
What This Means for Us:

🚀 Immediate Impact:
   • 95% time savings on story creation
   • Higher quality, more consistent stories
   • Better team visibility

🎯 Future Opportunities:
   • Apply to other repetitive tasks
   • Build team Copilot expertise
   • Share across organization

🤔 Key Insight:
   AI is best as a productivity multiplier,
   not a replacement. You still guide the work.
```

**Speaker Notes**:
- This is one example of many possibilities
- AI augments our work, doesn't replace thinking
- What other tedious tasks could we automate?

---

## Slide 13: Q&A

**Visual**: Simple, clean

```
Questions?

📧 Email: [your email]
💬 Slack: [your handle]
📁 Repo: [link]

"The best way to learn is to try it.
 Pick a small task and experiment."
```

**Speaker Notes**:
- Open floor for questions
- Encourage trying it out
- Offer continued support

---

## 🎨 Design Tips for Slides

### Visual Style
- **Clean and minimal** - Don't overwhelm with text
- **High contrast** - Easy to read from back of room
- **Screenshots** - Show real examples, not stock images
- **Consistent** - Same fonts, colors throughout

### Color Palette Suggestions
- **Primary**: Dark blue or gray background
- **Accent**: Bright green for checkmarks/success
- **Warning**: Orange/red for problems
- **Code**: Monospace font, syntax highlighting

### Font Recommendations
- **Headings**: Bold sans-serif (SF Pro, Helvetica)
- **Body**: Sans-serif, minimum 24pt
- **Code**: Monospace (Menlo, Monaco, Courier)

### Animations
- **Minimal** - Just simple reveals
- **Fast** - Don't waste time on transitions
- **Purpose** - Only animate to show before/after

---

## 📊 Optional: Additional Backup Slides

### Backup Slide A: Wiki Markup Reference

```
Jira Wiki Markup Cheat Sheet

Line Break:  \\
Bold:        *text*
Header:      h4. Title
Code:        {{code}}
List:        * Item
```

### Backup Slide B: Before/After Comparison

**Side by side screenshots**:
- Left: Plain text in CSV
- Right: Formatted in Jira

### Backup Slide C: The Script Explained

```python
# Key Functions:

format_user_story()     # Bold labels
format_code_elements()  # Wrap in {{}}
format_description()    # Add headers, breaks
```

### Backup Slide D: Copilot Prompting Tips

```
Good Prompts:
✅ "Create Jira stories for Apigee X infrastructure"
✅ "Include acceptance criteria and story points"
✅ "Format for CSV import with Wiki Markup"

Bad Prompts:
❌ "Make stories"
❌ "Help with Jira"
❌ [No context provided]
```

---

## 🎬 Presentation Tips

### Before the Presentation
- [ ] Test all screenshots on projector
- [ ] Verify slide readability from back of room
- [ ] Have backup plan (these slides) if live demo fails
- [ ] Practice timing (should be 7-10 minutes)

### During the Presentation
- [ ] Start with energy and hook
- [ ] Pause after key reveals (automation, formatting)
- [ ] Use "we" language (inclusive, not showing off)
- [ ] End with clear call to action

### After the Presentation
- [ ] Share slides and recording
- [ ] Send links to resources
- [ ] Follow up on action items
- [ ] Schedule office hours

---

## 💡 When to Use Slides vs Live Demo

### Use Live Demo When:
- ✅ You're confident in your setup
- ✅ You have good internet/connection
- ✅ Audience is technical and will appreciate seeing real tools
- ✅ You have time for Q&A during demo

### Use Slides When:
- ✅ You want async sharing (record and send)
- ✅ You're presenting to less technical audience
- ✅ You have limited time
- ✅ You want to avoid technical issues

### Best Approach:
**Live demo with slides as backup**
- Start with live demo
- Have slides ready if something breaks
- Use slides for recap/sharing afterward

---

**Ready to create killer slides? Use this outline with your favorite tool (PowerPoint, Keynote, Google Slides)** 🎨
