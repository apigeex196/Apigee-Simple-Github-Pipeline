# Template Repository Setup Guide

## Issue: Repository Access Error

The workflow fails with:
```
Could not resolve to a Repository with the name 'CenturyLink/enterprise-apigeex-templates'
```

## Root Cause

The `CenturyLink/enterprise-apigeex-templates` repository either:
1. Doesn't exist yet
2. Is private and the workflow lacks access
3. Has a different name

## Solutions

### Solution 1: Use Existing GitOps Repository (Current Fix)

**Status**: ✅ Applied

Updated `template-mappings.json` to point to `CenturyLink/enterprise-apigeex-gitops` as a temporary fallback.

```json
{
  "release_repository": "CenturyLink/enterprise-apigeex-gitops"
}
```

### Solution 2: Create the Templates Repository

If you need a dedicated templates repository:

1. **Create Repository**:
   ```bash
   # Via GitHub CLI
   gh repo create CenturyLink/enterprise-apigeex-templates --private --description "Apigee proxy templates"
   ```

2. **Add Release with Template**:
   ```bash
   # Create a release with template zip file
   gh release create SYSGEN788836350-JWT_and_OAuth_Proxy_AHPT_Backend_Template-v1.0.0 \
     --repo CenturyLink/enterprise-apigeex-templates \
     --title "JWT OAuth Proxy Template v1.0.0" \
     --notes "Initial template release" \
     template.zip
   ```

3. **Update template-mappings.json**:
   ```json
   {
     "release_repository": "CenturyLink/enterprise-apigeex-templates"
   }
   ```

### Solution 3: Fix Repository Permissions (Private Repo)

If the repository exists but is private:

#### Option A: Use GITHUB_TOKEN (Default - Works for Same Org)

The workflow already uses `github.token` which has access to repositories **in the same organization**.

**No changes needed** if repository is in `CenturyLink` org.

#### Option B: Create Personal Access Token (Cross-Org Access)

If templates are in a different organization:

1. **Create PAT** (Settings → Developer settings → Personal access tokens → Fine-grained tokens)
   - Resource owner: Organization with templates
   - Repository access: Select template repository
   - Permissions: `Contents: Read-only`

2. **Add as Repository Secret**:
   - Go to repository Settings → Secrets and variables → Actions
   - New repository secret: `TEMPLATES_REPO_TOKEN`
   - Value: Your PAT

3. **Update workflow** (`.github/workflows/test-download-template.yml`):
   ```yaml
   - name: Test download template action
     uses: ./.github/actions/download-template
     with:
       template_name: jwt-oauth-proxy-ahpt-backend
       output_dir: .template-cache
       github_token: ${{ secrets.TEMPLATES_REPO_TOKEN }}  # Add this line
   ```

4. **Update all workflows** that use download-template:
   - `.github/workflows/validate-proxy.yml`
   - Any deployment workflows

## Template Release Naming Convention

Current pattern: `SYSGEN788836350-JWT_and_OAuth_Proxy_AHPT_Backend_Template-v1.0.0`

### Components:
- **SYSGEN code**: `SYSGEN788836350`
- **Template name**: `JWT_and_OAuth_Proxy_AHPT_Backend_Template`
- **Version**: `v1.0.0` (semantic versioning)

### Pattern in template-mappings.json:
```json
"jwt-oauth-proxy-ahpt-backend": "SYSGEN788836350-JWT_and_OAuth_Proxy_AHPT_Backend_Template-v"
```

The `-v` suffix allows matching `v1.0.0`, `v1.1.0`, `v2.0.0`, etc.

## Verification

Test the fix:

```bash
# Check if repository is accessible
gh repo view CenturyLink/enterprise-apigeex-gitops

# List releases
gh release list --repo CenturyLink/enterprise-apigeex-gitops --limit 10

# Test download action locally
gh workflow run test-download-template.yml

# Check run status
gh run list --workflow=test-download-template.yml
```

## Current Status

✅ **Applied**: Updated `template-mappings.json` to use `enterprise-apigeex-gitops` repository
⚠️ **Note**: This is a temporary fix - templates repository may need to be created
⏳ **Pending**: Verify if templates repository should be created
⏳ **Pending**: Confirm correct repository name with team
⏳ **Pending**: Add template releases to the gitops repository or create dedicated templates repo

## Next Steps

1. **Verify the fix**: Run the workflow and check if it passes
2. **Decide on repository**: 
   - Keep using gitops repo, OR
   - Create dedicated templates repository
3. **Update documentation** once final repository is confirmed
4. **Add actual template releases** to the chosen repository

## Related Files

- `template-mappings.json` - Template to repository mappings
- `.github/actions/download-template/action.yml` - Download logic
- `.github/workflows/test-download-template.yml` - Test workflow
- `.github/workflows/validate-proxy.yml` - Uses template downloads
