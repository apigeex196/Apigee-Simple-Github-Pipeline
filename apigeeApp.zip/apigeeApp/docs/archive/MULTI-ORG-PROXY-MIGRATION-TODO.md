# Multi-Org Proxy Workflow Migration - TODO

## ✅ Completed
1. **Composite Actions** - Working and validated
   - `.github/actions/apigee-org/action.yml` - Extracts unique orgs from file paths
   - `.github/actions/filter-files-by-org/action.yml` - Filters files per org

2. **deploy-products.yml** - Fully migrated and validated
   - Matrix strategy working
   - 3 parallel jobs confirmed (PR #50 test)
   - MAL-based service account integration complete
   - File filtering per org working correctly

## 🔄 In Progress - Proxy Workflows

### Pattern to Apply (from deploy-products.yml)

**Step 1: Add detect-changes job**
```yaml
detect-changes:
  outputs:
    org_matrix: ${{ steps.get-orgs.outputs.org_matrix }}
    changed_files: ${{ steps.changed-files.outputs.changed_files }}
    deleted_files: ${{ steps.changed-files.outputs.deleted_files }}
  steps:
    - uses: ./.github/actions/changed-files
    - uses: ./.github/actions/apigee-org  # Extract unique orgs
```

**Step 2: Convert deploy job to matrix**
```yaml
deploy:
  strategy:
    fail-fast: false
    matrix:
      org: ${{ fromJson(needs.detect-changes.outputs.org_matrix) }}
  steps:
    - uses: ./.github/actions/filter-files-by-org  # Filter to org-specific files
    - name: Derive environment from org
    - uses: ./.github/actions/get-service-account  # MAL-based SA
    - name: Deploy (existing logic)
```

**Step 3: Update file filtering in deployment steps**
- Change from `$CHANGED_FILES` to `${{ steps.filter-files.outputs.changed_files }}`
- Remove org-specific regex filters (already filtered by composite action)
- Use `APIGEE_ORG` and `APIGEE_ENV` from matrix/derived values

### Workflows to Migrate

#### 1. deploy-to-dev.yml (682 lines)
- **Current**: Single org `gcp-prj-apigee-dev-np-01`
- **Target**: Support all dev orgs
- **Path pattern**: `mal-SYSGEN*/orgs/*/envs/*dev*/proxies/**/*.yaml`
- **Env mapping**: `gcp-prj-apigee-dev-np-01` → `apicc-dev`

#### 2. deploy-to-test.yml (688 lines)  
- **Current**: Single org `gcp-prj-apigee-test-np-01`
- **Target**: Support all test orgs
- **Path pattern**: `mal-SYSGEN*/orgs/*/envs/*test*/proxies/**/*.yaml`
- **Env mapping**: `gcp-prj-apigee-test-np-01` → `apicc-test1`

#### 3. deploy-to-prod.yml (682 lines)
- **Current**: Single org `gcp-prj-apigee-prod-01`
- **Target**: Support all prod orgs
- **Path pattern**: `mal-SYSGEN*/orgs/*/envs/*prod*/proxies/**/*.yaml` (or `apicc` env)
- **Env mapping**: `gcp-prj-apigee-prod-01` → `apicc`

### Key Differences from Products

**Products** (global/org-level):
- Path: `mal-SYSGEN*/orgs/{ORG}/products/*.yaml`
- No environment in path
- Simpler deployment

**Proxies** (environment-specific):
- Path: `mal-SYSGEN*/orgs/{ORG}/envs/{ENV}/proxies/**/*.yaml`
- Environment in path
- Complex deployment: KVMs, OAS validation, deploy/undeploy logic

### Environment Derivation Strategy

Since proxy files have env in path, we can:
1. Extract env from file path: `/envs/([^/]+)/` 
2. OR use mapping based on org name (safer for consistency)

**Recommended**: Use org-to-env mapping for consistency with products workflow.

## 📋 Implementation Checklist

### For Each Workflow (dev, test, prod):

- [ ] Add `detect-changes` job with org_matrix output
- [ ] Convert `deploy` job to use matrix strategy
- [ ] Add `filter-files-by-org` step
- [ ] Add `derive-env` step with org-to-env mapping
- [ ] Update `get-service-account` to use MAL code
- [ ] Update all `$CHANGED_FILES` references to use filtered files
- [ ] Remove org-specific regex filters in deployment steps
- [ ] Test with multi-org proxy PR

### Validation Workflows (Optional but Recommended):

#### validate-proxy.yml (952 lines)
- Add matrix strategy to validate per-org
- Run validation jobs in parallel
- Independent failures per org

#### validate-product.yml (309 lines)
- Add matrix strategy to validate per-org
- Already simpler, quick migration

## 🧪 Testing Strategy

1. **Unit Test**: Manual workflow dispatch with explicit files
2. **Integration Test**: Create PR with proxies across multiple orgs
3. **Validation**: Check matrix creates correct number of jobs
4. **Deployment**: Verify each org deploys independently
5. **Failure Isolation**: Confirm fail-fast: false works

## 📚 Reference

- **Working Example**: `.github/workflows/deploy-products.yml`
- **Gitops Implementation**: See `enterprise-apigeex-gitops` multi-org docs
- **Test PR**: PR #50 (products test with 3 orgs)

## 🎯 Success Criteria

- [ ] Single PR can modify proxies in multiple orgs
- [ ] Matrix creates N jobs for N affected orgs
- [ ] Jobs run in parallel (not sequential)
- [ ] Failures isolated per org (fail-fast: false)
- [ ] MAL-based service account works for all orgs
- [ ] File filtering correct per org
- [ ] Environment derivation accurate

## ⚠️ Known Issues / Limitations

1. **Service Account Permissions**: May need CCOE approval for GCP Secret Manager access
2. **Org-Env Mapping**: Hardcoded in workflow, add new orgs as they're onboarded
3. **Test Coverage**: Need test proxies in multiple orgs for full validation

## 📅 Estimated Effort

- **Per Workflow**: ~2-3 hours (including testing)
- **All 3 Deploy Workflows**: ~6-9 hours
- **Both Validation Workflows**: ~2-3 hours
- **Total**: ~8-12 hours

## 🚀 Quick Start

To migrate a workflow:
1. Copy `detect-changes` job from deploy-products.yml
2. Add matrix strategy to deploy job
3. Add filter-files-by-org and derive-env steps
4. Replace hardcoded org/env with matrix values
5. Test with manual dispatch using explicit files
