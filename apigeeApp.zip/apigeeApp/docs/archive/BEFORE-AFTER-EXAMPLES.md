# Before & After Examples

This document shows real examples from our jira-import.csv demonstrating the formatting transformation.

---

## Example 1: Simple Story

### ❌ Before (Plain Text)
```
As a developer I want automated installation of required Apigee tooling in workflows So that I don't have to manually install dependencies in each workflow

TECHNICAL DETAILS:
Location: .github/actions/setup-apigee-tooling/action.yml
Source: gitops/.github/actions/setup-apigee-tooling/action.yml
Changes: Direct copy - no modifications needed

ACCEPTANCE CRITERIA:
- Create .github/actions/setup-apigee-tooling/action.yml
- Install apigeecli (v2.7.0)
- Install apigee-go-gen (v1.0.0)
- Install yq (v4.40.5)
- Install jq
- Install Google Cloud SDK
- Add version outputs for verification
- Test action runs successfully in isolation
```

### ✅ After (Wiki Markup)
```
*As a* developer\\*I want* automated installation of required Apigee tooling in workflows\\*So that* I don't have to manually install dependencies in each workflow\\\\h4. TECHNICAL DETAILS\\* *Location:* {{.github/actions/setup-apigee-tooling/action.yml}}\\* *Source:* {{gitops/.github/actions/setup-apigee-tooling/action.yml}}\\* *Changes:* Direct copy - no modifications needed\\\\h4. ACCEPTANCE CRITERIA\\* Create {{.github/actions/setup-apigee-tooling/action.yml}}\\* Install {{apigeecli}} (v2.7.0)\\* Install {{apigee-go-gen}} (v1.0.0)\\* Install {{yq}} (v4.40.5)\\* Install {{jq}}\\* Install Google Cloud SDK\\* Add version outputs for verification\\* Test action runs successfully in isolation
```

### 🎨 Renders in Jira As:

**As a** developer
**I want** automated installation of required Apigee tooling in workflows
**So that** I don't have to manually install dependencies in each workflow

#### TECHNICAL DETAILS
• **Location:** `.github/actions/setup-apigee-tooling/action.yml`
• **Source:** `gitops/.github/actions/setup-apigee-tooling/action.yml`
• **Changes:** Direct copy - no modifications needed

#### ACCEPTANCE CRITERIA
• Create `.github/actions/setup-apigee-tooling/action.yml`
• Install `apigeecli` (v2.7.0)
• Install `apigee-go-gen` (v1.0.0)
• Install `yq` (v4.40.5)
• Install `jq`
• Install Google Cloud SDK
• Add version outputs for verification
• Test action runs successfully in isolation

---

## Example 2: Story with Nested Content

### ❌ Before (Plain Text)
```
As a CI/CD workflow I want to detect which MAL folders changed in a PR or push So that I only process/deploy affected proxies and products

TECHNICAL DETAILS:
Location: .github/actions/changed-files/action.yml
Source: gitops/.github/actions/changed-files/action.yml
Adaptations:
- Change from orgs/*/envs/*/proxies/* pattern to mal-SYSGEN*/** pattern
- Add MAL folder extraction logic

ACCEPTANCE CRITERIA:
- Create .github/actions/changed-files/action.yml
- Detect changed files for PRs (vs base_ref)
- Detect changed files for pushes (vs before commit)
- Support manual override via input parameter
- Export CHANGED_FILES environment variable
- Export DELETED_FILES environment variable
- Filter to only mal-SYSGEN*/ paths
- Handle empty change sets gracefully
```

### ✅ After (Wiki Markup)
```
*As a* CI/CD workflow\\*I want* to detect which MAL folders changed in a PR or push\\*So that* I only process/deploy affected proxies and products\\\\h4. TECHNICAL DETAILS\\* *Location:* {{.github/actions/changed-files/action.yml}}\\* *Source:* {{gitops/.github/actions/changed-files/action.yml}}\\h4. ADAPTATIONS\\* Change from {{orgs/*/envs/*/proxies/*}} pattern to {{mal-SYSGEN*/**}} pattern\\* Add MAL folder extraction logic\\\\h4. ACCEPTANCE CRITERIA\\* Create {{.github/actions/changed-files/action.yml}}\\* Detect changed files for PRs (vs base_ref)\\* Detect changed files for pushes (vs before commit)\\* Support manual override via input parameter\\* Export {{CHANGED_FILES}} environment variable\\* Export {{DELETED_FILES}} environment variable\\* Filter to only {{mal-SYSGEN*/}} paths\\* Handle empty change sets gracefully
```

### 🎨 Renders in Jira As:

**As a** CI/CD workflow
**I want** to detect which MAL folders changed in a PR or push
**So that** I only process/deploy affected proxies and products

#### TECHNICAL DETAILS
• **Location:** `.github/actions/changed-files/action.yml`
• **Source:** `gitops/.github/actions/changed-files/action.yml`

#### ADAPTATIONS
• Change from `orgs/*/envs/*/proxies/*` pattern to `mal-SYSGEN*/**` pattern
• Add MAL folder extraction logic

#### ACCEPTANCE CRITERIA
• Create `.github/actions/changed-files/action.yml`
• Detect changed files for PRs (vs base_ref)
• Detect changed files for pushes (vs before commit)
• Support manual override via input parameter
• Export `CHANGED_FILES` environment variable
• Export `DELETED_FILES` environment variable
• Filter to only `mal-SYSGEN*/` paths
• Handle empty change sets gracefully

---

## Example 3: Story with Complex Technical Details

### ❌ Before (Plain Text)
```
As a deployment workflow I want to extract MAL code, org, and environment from changed file paths So that I know which Apigee org/env to target for deployment

TECHNICAL DETAILS:
Input: mal-SYSGEN123456789/proxies/SYSGEN123456789-my-api/dev/base.yaml
Outputs:
- MAL_CODE=123456789
- APIGEE_ORG=gcp-prj-apigee-dev-np-01 (from workflow input)
- APIGEE_ORG_UPPER=GCP_PRJ_APIGEE_DEV_NP_01 (for secret name)
- APIGEE_ENV=apicc-dev (from workflow input)

ACCEPTANCE CRITERIA:
- Create .github/actions/extract-mal-metadata/action.yml
- Parse MAL code from mal-SYSGEN<code>/ folder name
- Determine target org from workflow input or file path
- Determine target env from workflow input (dev/test/prod)
- Export MAL_CODE environment variable
- Export APIGEE_ORG environment variable (normalized, uppercase for secret lookup)
- Export APIGEE_ENV environment variable
- Handle multiple MALs changed (process each)
```

### ✅ After (Wiki Markup)
```
*As a* deployment workflow\\*I want* to extract MAL code, org, and environment from changed file paths\\*So that* I know which Apigee org/env to target for deployment\\\\h4. TECHNICAL DETAILS\\* *Input:* {{mal-SYSGEN123456789/proxies/SYSGEN123456789-my-api/dev/base.yaml}}\\h4. OUTPUTS\\* {{MAL_CODE}}=123456789\\* {{APIGEE_ORG}}={{gcp-prj-apigee-dev-np-01}} (from workflow input)\\* {{APIGEE_ORG_UPPER}}=GCP_PRJ_APIGEE_DEV_NP_01 (for secret name)\\* {{APIGEE_ENV}}={{apicc-dev}} (from workflow input)\\\\h4. ACCEPTANCE CRITERIA\\* Create {{.github/actions/extract-mal-metadata/action.yml}}\\* Parse MAL code from {{mal-SYSGEN<code>/}} folder name\\* Determine target org from workflow input or file path\\* Determine target env from workflow input (dev/test/prod)\\* Export {{MAL_CODE}} environment variable\\* Export {{APIGEE_ORG}} environment variable (normalized, uppercase for secret lookup)\\* Export {{APIGEE_ENV}} environment variable\\* Handle multiple MALs changed (process each)
```

### 🎨 Renders in Jira As:

**As a** deployment workflow
**I want** to extract MAL code, org, and environment from changed file paths
**So that** I know which Apigee org/env to target for deployment

#### TECHNICAL DETAILS
• **Input:** `mal-SYSGEN123456789/proxies/SYSGEN123456789-my-api/dev/base.yaml`

#### OUTPUTS
• `MAL_CODE`=123456789
• `APIGEE_ORG`=`gcp-prj-apigee-dev-np-01` (from workflow input)
• `APIGEE_ORG_UPPER`=GCP_PRJ_APIGEE_DEV_NP_01 (for secret name)
• `APIGEE_ENV`=`apicc-dev` (from workflow input)

#### ACCEPTANCE CRITERIA
• Create `.github/actions/extract-mal-metadata/action.yml`
• Parse MAL code from `mal-SYSGEN<code>/` folder name
• Determine target org from workflow input or file path
• Determine target env from workflow input (dev/test/prod)
• Export `MAL_CODE` environment variable
• Export `APIGEE_ORG` environment variable (normalized, uppercase for secret lookup)
• Export `APIGEE_ENV` environment variable
• Handle multiple MALs changed (process each)

---

## Key Improvements

### 1. **Readability**
- ❌ Before: Wall of text, no visual hierarchy
- ✅ After: Clear sections, easy to scan

### 2. **Professional Appearance**
- ❌ Before: Looks like plain notes
- ✅ After: Formatted like professional documentation

### 3. **Code Clarity**
- ❌ Before: File paths and variables blend with text
- ✅ After: Code elements clearly highlighted

### 4. **Structure**
- ❌ Before: Flat list, hard to distinguish sections
- ✅ After: Headers create clear sections

### 5. **Emphasis**
- ❌ Before: All text same weight
- ✅ After: Bold highlights key information

---

## Formatting Legend

| Element | Wiki Markup | What It Does |
|---------|-------------|--------------|
| `*text*` | Bold | Highlights user story labels |
| `\\` | Line break | Separates lines within paragraph |
| `h4. Title` | Header (size 4) | Creates section headers |
| `* Item` | Bullet list | Creates bulleted list items |
| `{{code}}` | Inline code | Formats code, files, variables |
| `** Item` | Nested bullet | Creates sub-items in lists |

---

## Impact Analysis

### Time Comparison

**Manual Formatting** (one story):
1. Write story in Jira editor
2. Add bold to "As a", "I want", "So that"
3. Create header sections
4. Format each list item
5. Add code formatting to files/variables
6. Preview and adjust

**Total**: ~3 minutes per story × 26 stories = **78 minutes**

**Automated Formatting**:
1. Write plain text story
2. Run script: `python3 scripts/format-jira-csv.py`
3. Import to Jira

**Total**: < 1 second for all 26 stories = **< 1 second**

**Time Saved**: ~78 minutes per import batch

### Quality Comparison

| Aspect | Manual | Automated |
|--------|--------|-----------|
| Consistency | Variable - depends on who formats | 100% consistent |
| Completeness | May miss some formatting | Always applies all patterns |
| Accuracy | Prone to typos in markup | Perfect markup syntax |
| Maintenance | Hard to update all stories | Rerun script to update all |

---

## Next Steps

1. **Review**: Open `docs/planning/jira-import.csv` and review formatted stories
2. **Test**: Import one story to verify formatting renders correctly
3. **Adjust**: Modify `scripts/format-jira-csv.py` if needed for your Jira
4. **Import**: Import all 26 stories with perfect formatting
5. **Share**: Show your team the before/after comparison
6. **Reuse**: Use the script for all future Jira imports

---

**Files Referenced**:
- `docs/planning/jira-import.csv` - Formatted CSV ready for import
- `scripts/format-jira-csv.py` - Automation script
- `docs/planning/CSV-FORMATTING-GUIDE.md` - Complete formatting guide
- `docs/planning/DEMO-SCRIPT.md` - Demo walkthrough
