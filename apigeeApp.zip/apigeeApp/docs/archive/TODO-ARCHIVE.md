# TODO - Improvements Needed

## High Priority

### 1. Proxy Rename/Undeploy Flow
**Issue**: When renaming a proxy (changing `metadata.name`), the workflow attempts to deploy a new proxy with the same basepath as the existing one, causing a `CONFLICTING_DEPLOYMENT` error.

**Current Behavior**:
- Old proxy remains deployed with original name
- New proxy deployment fails due to basepath conflict
- Requires manual undeploy of old proxy before redeployment

**Needed Solution**:
- Detect proxy renames (old folder name vs new metadata.name)
- Automatically undeploy old proxy before deploying new one
- Handle the transition gracefully in the workflow

**Workaround**: Manually undeploy old proxy using:
```bash
apigeecli apis undeploy --name "OLD-NAME" --env "$env" --org "$org" --token "$TOKEN"
```

### 2. OAS Validation Configuration
**Issue**: OAS validation behavior needs better documentation and possibly more flexible configuration options.

**Current Limitations**:
- Default OAS validation can be too strict for some use cases
- OAS-Validation-Disabled.yaml is used as a workaround
- Need clearer documentation on when/how to use custom OAS files

**Needed Solution**:
- Document OAS validation options in README
- Provide examples of custom OAS file configuration
- Consider making validation level configurable (strict/lenient/disabled)

## Medium Priority

### 3. Changed-Files Action Rename Handling
**Issue**: The changed-files action was using old paths for renamed files.

**Status**: ✅ **FIXED** - Now correctly handles git renames by using column 3 for R-status files.

**Related Commit**: a81ea09

### 4. Workflow File Validation Trigger
**Issue**: `validate-proxy.yml` workflow fails with 0s elapsed time when pushing directly to main (bypassing PRs).

**Current Behavior**:
- Workflow only configured for `pull_request` events
- Fails immediately when triggered on `push` events
- Non-blocking but creates failed workflow runs

**Possible Solutions**:
1. Keep as-is (expected behavior when bypassing PRs)
2. Add `push` trigger to run validation on main branch
3. Add conditional to skip validation when not a PR

### 5. Manual Workflow Dispatch File Detection
**Issue**: Manually triggered workflows don't detect file changes, may skip deployment.

**Current Behavior**:
- `workflow_dispatch` doesn't have file change context
- Workflows may exit early with "No changed files detected"
- Requires actual file changes (version bump) to trigger deployment

**Needed Solution**:
- Add workflow input parameter to force deployment
- Or always deploy when manually triggered
- Better logging to indicate manual vs automatic runs

## Low Priority

### 6. Security - KVM Export Files
**Issue**: KVM export files contain sensitive keys and were accidentally committed.

**Status**: ✅ **FIXED** - Files removed and added to .gitignore.

**Prevention**:
- .gitignore pattern: `env__*__kvmfile__*.json`
- Keys still exist in git history (commit 5c3e5a2)
- Consider key rotation for production environments

**Related Commits**: 61f180f, a81ea09

### 7. Demo Script OAuth Credentials
**Issue**: OAuth credentials in demo script can become stale after redeployments.

**Current Behavior**:
- Credentials hardcoded in demo-proxy-enhanced.sh
- Must be manually updated after proxy redeployment
- Can cause demo failures if credentials regenerated

**Possible Solutions**:
- Fetch credentials dynamically using apigeecli
- Store credentials in GitHub secrets
- Add credential validation check before demo runs

## Documentation Needs

### 8. Proxy Naming Conventions
- Document the `SYSGEN[0-9]{9}-` naming pattern requirement
- Explain MAL folder structure
- Provide examples of valid proxy names

### 9. Template Usage Guide
- Document available templates (oauth-proxy-jwt-backend, etc.)
- Explain template-mappings.json usage
- Provide examples of template configuration options

### 10. Deployment Workflow Guide
- Document the full deployment flow
- Explain environment-specific configurations
- Troubleshooting common deployment issues

## Future Enhancements

### 11. Automated Testing
- Add Bruno test execution to deployment workflows
- Validate deployments automatically after completion
- Report test results in workflow output

### 12. Rollback Capability
- Implement automated rollback on deployment failure
- Track previous revision numbers
- Quick revert to last known good state

---

## Notes

**Last Updated**: 2025-12-12

**Repository**: enterprise-apigeex-applications

**Related Repositories**:
- enterprise-apigeex-templates (template definitions)
- enterprise-apigeex-gitops (environment configurations)
- enterprise-apigeex-bundles (proxy bundle source)
