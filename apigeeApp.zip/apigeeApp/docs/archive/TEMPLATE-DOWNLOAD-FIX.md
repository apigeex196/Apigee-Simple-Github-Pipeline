# Template Download Fix - Using GH_PAT Secret

## Problem
Template downloads were failing with authentication errors because:
- The `download-template` action was using `github.token` (default)
- `github.token` has limited permissions and couldn't access `CenturyLink/enterprise-apigeex-templates` repository

## Solution
Use the `GH_PAT` secret that's already configured in the repository (seen in `test-deploy-proxy-transform.yml`).

## Changes Made

### 1. test-download-template.yml
```yaml
- name: Test download template action
  id: download
  uses: ./.github/actions/download-template
  with:
    template_name: ${{ github.event.inputs.template_name || 'jwt-oauth-proxy-ahpt-backend' }}
    output_dir: .template-cache
    github-token: ${{ secrets.GH_PAT }}  # ← Added this line
```

### 2. validate-proxy.yml
```yaml
- name: Download and verify templates
  if: steps.extract-templates.outputs.has_templates == 'true'
  id: download-templates
  env:
    GH_TOKEN: ${{ secrets.GH_PAT }}  # ← Added this line
  run: |
```

## Why This Works
- The `download-template` action accepts a `github-token` input (line 9 of action.yml)
- The action uses this token via `GH_TOKEN` environment variable (lines 49, 71)
- `GH_PAT` is a Personal Access Token with broader permissions than `github.token`
- Pattern follows existing usage in `test-deploy-proxy-transform.yml` (lines 18, 35)

## Testing
Run the `test-download-template` workflow to verify:
1. Go to Actions tab
2. Select "Test Download Template" workflow
3. Click "Run workflow"
4. Check that template downloads successfully

## Expected Warnings
The YAML linter shows warnings about `GH_PAT` context access - this is normal and expected. These warnings appear because the linter can't verify that the secret exists in repository settings. As long as `GH_PAT` is configured as a repository secret, the workflow will work correctly.

## Files Modified
- `.github/workflows/test-download-template.yml` - Added `github-token` input
- `.github/workflows/validate-proxy.yml` - Added `GH_TOKEN` environment variable
