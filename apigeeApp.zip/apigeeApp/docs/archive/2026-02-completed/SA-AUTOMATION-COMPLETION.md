# Service Account Automation - Completion Documentation

## 🎉 Major Milestone Achieved - February 6, 2026

The **MAL Service Account Automation** workflow is now **fully functional and production-ready** across all environments (DEV, QA, PROD).

## Executive Summary

Successfully implemented and validated an automated GitHub Actions workflow that creates service accounts, grants IAM roles, generates keys, and stores them securely in Google Secret Manager for API Producer teams onboarding to Apigee X.

### Final Validation Results

**Test Run**: Workflow #21761567765 (SYSGEN777777777)

✅ **DEV Environment** - Complete Success
- Service Account: `sa-apigeex-sysgen777777777@gcp-prj-apigee-dev-np-01.iam.gserviceaccount.com`
- Secret: `sa-apigeex-SYSGEN777777777` with regional replication (us-central1, us-east1)
- IAM Roles: apigee.apiAdminV2, secretmanager.secretAccessor
- Labels: `alert_channel=mal_sysgen777777777`, `environment=dev`

✅ **QA Environment** - Complete Success
- Service Account: `sa-apigeex-sysgen777777777@gcp-prj-apigee-qa-np-01.iam.gserviceaccount.com`
- Secret: `sa-apigeex-SYSGEN777777777` with regional replication (us-central1, us-east1)
- IAM Roles: apigee.apiAdminV2, secretmanager.secretAccessor
- Labels: `alert_channel=mal_sysgen777777777`, `environment=qa`

✅ **PROD Environment** - Complete Success
- Service Account: `sa-apigeex-sysgen777777777@gcp-prj-apigee-prod-01.iam.gserviceaccount.com`
- Secret: `sa-apigeex-SYSGEN777777777` with regional replication (us-central1, us-east1)
- IAM Roles: apigee.apiAdminV2, secretmanager.secretAccessor
- Labels: `alert_channel=mal_sysgen777777777`, `environment=prod`

## Technical Challenges Overcome

### 1. Git Detection for Push Events
**Problem**: Workflow couldn't detect new MAL folders on push events because `github.base_ref` is empty for push events, causing `origin/main..HEAD` to return nothing.

**Solution**: Implemented event-specific git diff logic:
- Pull Requests: `git diff origin/${BASE_REF}..HEAD`
- Push Events: `git diff HEAD~1 HEAD`

**Files Changed**: `.github/workflows/create-mal-service-accounts.yml`

### 2. GCP Service Account Naming Case Sensitivity
**Problem**: GCP automatically lowercases service account names, but we were using uppercase MAL codes (e.g., `SYSGEN777777777`). This caused IAM policy binding failures because the workflow tried to grant roles to `sa-apigeex-SYSGEN777777777@...` but GCP created `sa-apigeex-sysgen777777777@...`.

**Solution**: Convert MAL code to lowercase for SA name and email construction while keeping display name uppercase for readability.

**Files Changed**: `.github/actions/create-mal-sa/action.yml` (lines 68-76)

### 3. Secret Manager Label Validation
**Problem**: GCP Secret Manager labels only allow lowercase letters, numbers, hyphens, and underscores (`[a-z0-9_-]`). Using uppercase MAL codes in labels caused: `Bad value [MAL_SYSGEN777777777]: Only hyphens (-), underscores (_), lowercase characters, and numbers are allowed`.

**Solution**: Convert MAL code to lowercase for all Secret Manager labels (`alert_channel=mal_sysgen777777777`).

**Files Changed**: `.github/actions/create-mal-sa/action.yml` (lines 297, 345, 355)

### 4. QA Environment Org Policy Restrictions
**Problem**: QA environment has organizational policy `constraints/gcp.resourceLocations` that blocks global secret replication. Error: `FAILED_PRECONDITION: Constraint constraints/gcp.resourceLocations violated attempting to create a secret in [global]`.

**Solution**: Changed from automatic (global) replication to user-managed replication with specific US regions:
```bash
--replication-policy="user-managed" \
--locations="us-central1,us-east1"
```

**Files Changed**: `.github/actions/create-mal-sa/action.yml` (line 295-296)

### 5. QA CICD Service Account JWT Authentication
**Problem**: QA CICD SA authentication failed with `ERROR: invalid_grant: Invalid JWT Signature`.

**Solution**: Generated fresh service account key and updated GitHub Secret `GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01`.

**Key ID**: 43ac8d7315ce23e11931085cea139e2a057ee5cd

### 6. Secret Existence Check Before Label Updates
**Problem**: When SA already exists but secret doesn't (from failed previous runs), the workflow tried to update secret labels without checking if the secret exists, causing `INVALID_ARGUMENT` errors.

**Solution**: Added secret existence check before attempting label updates:
```bash
gcloud secrets describe "${SECRET_NAME}" --project="${PROJECT}" > /dev/null 2>&1
SECRET_EXISTS=$?
if [ ${SECRET_EXISTS} -eq 0 ]; then
  # Update labels
fi
```

**Files Changed**: `.github/actions/create-mal-sa/action.yml` (lines 337-357)

## Workflow Architecture

### Trigger Mechanisms
1. **Push Events**: Automatically detects new `mal-SYSGEN*` folders added to main branch
2. **Pull Requests**: Detects new MAL folders in PR for validation (dry-run mode)
3. **Manual Dispatch**: Allows manual trigger with MAL code and dry-run flag

### Job Flow
```
Detect New MAL Folders
    ↓
Create SAs (Matrix: DEV, QA, PROD)
    ├→ Validate Input
    ├→ Set Variables
    ├→ Check SA Existence
    ├→ Create SA (if needed)
    ├→ Grant IAM Roles
    ├→ Create SA Key
    ├→ Store in Secret Manager
    ├→ Update Secret Labels (if SA existed)
    └→ Verify SA
    ↓
Create CCOE Audit Trail PR (optional)
    ↓
Comment on PR with Results (PRs only)
```

### Security Features
- **CICD Service Accounts**: Each environment has dedicated CICD SA with minimal required permissions
- **IAM Roles Granted**:
  - `roles/apigee.apiAdminV2` - Deploy proxies and products
  - `roles/secretmanager.secretAccessor` - Read other secrets (KVM values, backend credentials)
- **Secret Storage**: Keys stored in Secret Manager with encryption at rest
- **Regional Replication**: Secrets replicated across us-central1 and us-east1 for redundancy
- **Monitoring Labels**: All secrets tagged for monitoring integration (`alert_channel=mal_*`)

## Key Files and Components

### Workflows
- **`.github/workflows/create-mal-service-accounts.yml`** (606 lines)
  - Main orchestration workflow
  - Matrix strategy for parallel environment deployment
  - Integration with GitOps workflows

### Composite Actions
- **`.github/actions/create-mal-sa/action.yml`** (385 lines)
  - Reusable action for SA creation logic
  - Handles SA lifecycle, IAM grants, key generation, secret storage
  - Includes validation, error handling, and dry-run mode

### Supporting Documentation
- **`IMPLEMENTATION-STATUS.md`** - Tracks overall automation progress
- **`SA-ACTION-PLAN.md`** - Original implementation planning
- **`QA-JWT-ISSUE.md`** - Documents QA authentication troubleshooting

## Testing History

### Test Iterations
1. **SYSGEN999999999** - Initial test, discovered label validation issue
2. **SYSGEN123456789** - Tested label fix, discovered QA JWT issue
3. **SYSGEN444444444** - Tested with SA already existed scenario
4. **SYSGEN555555555** - Clean test, discovered git diff issue
5. **SYSGEN666666666** - Tested push event detection, discovered QA org policy
6. **SYSGEN777777777** - ✅ **Final successful validation across all environments**

### Cleanup Status
All test resources cleaned up except:
- **SYSGEN777777777**: Kept for monitoring/alerting development
- **SYSGEN788836350**: Legitimate production SA (not a test)

## Production Readiness Checklist

- [x] Workflow detects new MAL folders on push events
- [x] Workflow detects new MAL folders in pull requests
- [x] Service accounts created successfully in all environments
- [x] IAM roles granted correctly
- [x] Service account keys generated
- [x] Keys stored in Secret Manager with proper encryption
- [x] Secrets replicated across multiple regions
- [x] Labels comply with GCP requirements (lowercase)
- [x] Org policy restrictions handled (regional replication)
- [x] Authentication working in all environments
- [x] Error handling for edge cases (SA exists, secret missing, etc.)
- [x] Dry-run mode for testing
- [x] Monitoring labels applied for alerting integration
- [x] Documentation complete
- [x] Test resources cleaned up

## Next Steps

### Immediate (Ready for Production)
1. **API Producer Onboarding**: Workflow is ready for actual API Producer teams to use
2. **GitOps Integration**: CCOE PR creation needs token configuration for full automation
3. **Monitoring Integration**: Use SYSGEN777777777 resources for monitoring/alerting development

### Future Enhancements
1. **Automated Secret Rotation**: Implement key rotation workflow
2. **SA Lifecycle Management**: Add decommissioning workflow
3. **Enhanced Notifications**: Integrate with team notification channels
4. **Metrics Dashboard**: Track SA creation metrics and usage
5. **Self-Service Portal**: UI for API Producers to request SAs without GitHub access

## Team Recognition

This accomplishment represents significant collaboration across:
- **DevOps Engineering**: Workflow design and implementation
- **Security Engineering**: IAM policy review and approval
- **API Platform Team**: Requirements and validation
- **Site Reliability Engineering**: Org policy coordination

## Metrics

- **Total Development Time**: ~3 days (Feb 4-6, 2026)
- **Test Iterations**: 6 major test runs
- **Issues Identified and Resolved**: 6 critical issues
- **Lines of Code**: ~1,000 lines (workflows + composite actions)
- **Environments Validated**: 3 (DEV, QA, PROD)
- **Success Rate**: 100% (after fixes applied)

---

**Status**: ✅ **PRODUCTION READY**
**Date Completed**: February 6, 2026
**Validation Run**: #21761567765
**Test MAL**: SYSGEN777777777
