# QA CICD SA JWT Investigation

## Issue
During workflow run 21759817845 (SYSGEN123456789), QA environment failed with:
```
ERROR: (gcloud.iam.service-accounts.create) There was a problem refreshing auth tokens
for account sa-apigeex-cicd@gcp-prj-apigee-qa-np-01.iam.gserviceaccount.com:
('invalid_grant: Invalid JWT Signature.', 'error': 'invalid_grant',
'error_description': 'Invalid JWT Signature.')
```

## Analysis
- ✅ QA CICD SA works locally (can generate access tokens)
- ❌ QA CICD SA fails in GitHub Actions workflow
- ✅ DEV and PROD CICD SAs work in GitHub Actions

## Root Cause
The GitHub Secret `GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01` likely contains:
1. An expired/revoked service account key
2. A corrupted JSON key file
3. A key for a different service account

## Solution
Update the GitHub Secret with a fresh QA CICD SA key:

### Option 1: Generate new key via Google Cloud Console
1. Navigate to: https://console.cloud.google.com/iam-admin/serviceaccounts?project=gcp-prj-apigee-qa-np-01
2. Find: `sa-apigeex-cicd@gcp-prj-apigee-qa-np-01.iam.gserviceaccount.com`
3. Click "Keys" tab
4. Create new JSON key
5. Update GitHub Secret: `GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01`

### Option 2: Generate via gcloud (if you have permissions)
```bash
gcloud iam service-accounts keys create ~/qa-cicd-new-key.json \
  --iam-account=sa-apigeex-cicd@gcp-prj-apigee-qa-np-01.iam.gserviceaccount.com \
  --project=gcp-prj-apigee-qa-np-01

# Then update GitHub Secret with contents of ~/qa-cicd-new-key.json
# After updating, delete the local copy:
rm ~/qa-cicd-new-key.json
```

### Updating GitHub Secret
```bash
# Using gh CLI
gh secret set GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01 < ~/qa-cicd-new-key.json

# Or via GitHub UI:
# Settings > Secrets and variables > Actions > GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01 > Update
```

## Verification
After updating the secret, trigger the workflow with a new test MAL to verify QA works:
```bash
gh workflow run create-mal-service-accounts.yml -f mal-code=SYSGEN555555555 -f dry-run=false
```

## Current Status
- ⏳ Awaiting QA CICD SA key update
- ✅ DEV and PROD environments confirmed working with label fix
- ✅ All test resources cleaned up
