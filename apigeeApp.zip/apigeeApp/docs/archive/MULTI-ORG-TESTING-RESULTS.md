# Multi-Org Deploy-Products Testing

## Test Branch Created
- **Branch**: `test/multi-org-products`
- **Commit**: b908011
- **PR URL**: https://github.com/CenturyLink/enterprise-apigeex-applications/pull/new/test/multi-org-products

## Test Scenario
Testing multi-org deployment with 3 product files across 3 different organizations:

### Test Files Created
1. **Dev Org**: `mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/products/test-product-dev.yaml`
2. **QA Org**: `mal-SYSGEN788836350/orgs/gcp-prj-apigee-qa-np-01/products/test-product-qa.yaml`
3. **Prod Org**: `mal-SYSGEN788836350/orgs/gcp-prj-apigee-prod-01/products/test-product-prod.yaml`

## Validation Results ✅

### 1. Org Extraction Logic
**Input**: 3 product files from different orgs
**Output**: `["gcp-prj-apigee-dev-np-01", "gcp-prj-apigee-prod-01", "gcp-prj-apigee-qa-np-01"]`

✅ Correctly extracted 3 unique organizations
✅ JSON array format valid for matrix strategy
✅ Regex pattern matches MAL-based paths

### 2. File Filtering Logic
**Per-Org Results**:

- **gcp-prj-apigee-dev-np-01**:
  - Filtered files: `test-product-dev.yaml` ✅
  - Correctly isolated dev org files

- **gcp-prj-apigee-prod-01**:
  - Filtered files: `test-product-prod.yaml` ✅
  - Correctly isolated prod org files

- **gcp-prj-apigee-qa-np-01**:
  - Filtered files: `test-product-qa.yaml` ✅
  - Correctly isolated qa org files

### 3. Expected Workflow Behavior

When PR is created, the workflow should:

1. **detect-changes job**:
   - Detects 3 changed product files
   - Runs `apigee-org` action
   - Outputs: `org_matrix: ["gcp-prj-apigee-dev-np-01", "gcp-prj-apigee-prod-01", "gcp-prj-apigee-qa-np-01"]`

2. **deploy job (matrix strategy)**:
   - Creates 3 parallel jobs:
     - `deploy (gcp-prj-apigee-dev-np-01)`
     - `deploy (gcp-prj-apigee-prod-01)`
     - `deploy (gcp-prj-apigee-qa-np-01)`

3. **Each matrix job**:
   - Filters files using `filter-files-by-org`
   - Gets org-specific service account via `get-service-account`
   - Authenticates with GCP for that org
   - Deploys only that org's product file
   - Reports success/failure independently (fail-fast: false)

## What to Watch For

### ✅ Success Indicators
- [ ] 3 parallel jobs appear in workflow run (not sequential)
- [ ] Each job shows different org name: `Deploy Products to {org}`
- [ ] Filter step shows correct file for each org
- [ ] Each job authenticates with different service account
- [ ] All 3 jobs complete (even if one fails - fail-fast: false)
- [ ] GitHub Step Summary shows per-org deployment metrics

### ⚠️ Potential Issues to Monitor
- [ ] Service account secrets exist for all 3 orgs
  - `GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01`
  - `GCP_SA_KEY_GCP_PRJ_APIGEE_PROD_01`
  - `GCP_SA_KEY_GCP_PRJ_APIGEE_QA_NP_01`
- [ ] Echo proxy exists in all 3 orgs (referenced by test products)
- [ ] Environments exist: `apicc-dev`, `apicc-qa`, `apicc` (prod)

### 🐛 Known Limitations
- This test uses dummy products that reference `SYSGEN788836350-Echo` proxy
- If Echo proxy doesn't exist in an org, product deployment may fail
- That's OK - we're testing the workflow mechanics, not the products themselves

## Manual Testing Steps

### 1. Create Pull Request
Visit: https://github.com/CenturyLink/enterprise-apigeex-applications/pull/new/test/multi-org-products

### 2. Observe Workflow Run
- Go to "Actions" tab
- Find "Deploy API Products" workflow run
- Watch for matrix strategy to create 3 jobs

### 3. Verify Each Job
For each of the 3 matrix jobs, check:
- Filter step output shows correct file
- Authentication step uses correct service account
- Deploy step attempts to deploy correct product
- Job completes independently (doesn't block others)

### 4. Check Summary
- GitHub Step Summary should show 3 separate deployment sections
- Each section should indicate the org name
- Metrics should show deployment counts per org

## Expected Outcomes

### Best Case (All Succeed) 🎉
```
✅ deploy (gcp-prj-apigee-dev-np-01)   - Deployed 1 product
✅ deploy (gcp-prj-apigee-prod-01)     - Deployed 1 product
✅ deploy (gcp-prj-apigee-qa-np-01)    - Deployed 1 product
```

### Partial Success (Some Fail) ⚠️
```
✅ deploy (gcp-prj-apigee-dev-np-01)   - Deployed 1 product
❌ deploy (gcp-prj-apigee-prod-01)     - Failed (Echo proxy missing)
✅ deploy (gcp-prj-apigee-qa-np-01)    - Deployed 1 product
```
**This is still SUCCESS** - demonstrates fail-fast: false working correctly!

### Expected Failure Reasons
If any job fails, likely causes:
1. **Missing Service Account Secret** - Check GitHub repo secrets
2. **Missing Echo Proxy** - Echo proxy not deployed to that org
3. **Missing Environment** - Environment name mismatch
4. **Permission Issues** - Service account lacks Apigee permissions

## Comparison vs Single-Org

### Old Behavior (Pre-Multi-Org)
- Would require 3 separate PRs (one per org)
- Or 3 separate workflow runs (manual dispatch per env)
- Sequential execution even if different orgs
- Changes to deployment logic needed in 3 places

### New Behavior (Multi-Org)
- ✅ Single PR with all 3 org changes
- ✅ Automatic detection of affected orgs
- ✅ Parallel execution (3× faster)
- ✅ Single source of truth for deployment logic
- ✅ Isolated failures don't block other orgs

## Next Steps After Testing

1. **If Test Succeeds**:
   - Delete test branch and products
   - Apply same pattern to proxy deployment workflows
   - Update documentation with multi-org examples

2. **If Test Fails**:
   - Analyze workflow logs to identify issue
   - Fix composite actions or workflow logic
   - Re-test with corrected implementation

3. **Production Readiness**:
   - Test with real product changes
   - Verify with team that multi-org PRs are allowed
   - Update PR review process to handle multi-org changes
   - Train team on new multi-org capabilities

## Testing Checklist

- [x] Test branch created: `test/multi-org-products`
- [x] Test files created: 3 product YAMLs across 3 orgs
- [x] Branch pushed to GitHub
- [x] Org extraction logic validated locally
- [x] File filtering logic validated locally
- [ ] PR created on GitHub
- [ ] Workflow triggered automatically
- [ ] Matrix strategy created 3 jobs
- [ ] Each job filtered files correctly
- [ ] Each job authenticated independently
- [ ] Jobs ran in parallel (check timestamps)
- [ ] fail-fast: false behavior confirmed
- [ ] GitHub Step Summary shows per-org metrics

## Documentation
- Main implementation: [DEPLOY-PRODUCTS-MULTI-ORG-IMPLEMENTATION.md](DEPLOY-PRODUCTS-MULTI-ORG-IMPLEMENTATION.md)
- Migration guide: [MULTI-ORG-MIGRATION-ANALYSIS.md](MULTI-ORG-MIGRATION-ANALYSIS.md)
