# Core Infrastructure Implementation - Parallel Work Breakdown

**Goal**: Implement working CI/CD infrastructure for the applications repository (API producer self-service)

**Scope**: Workflows and composite actions only - documentation deferred

**Team**: 2 Engineers working in parallel

---

## 🔧 TRACK A: Foundation & Validation (Engineer A)

### A1: Setup Composite Action - Setup Apigee Tooling
**Story ID**: IMPL-001
**Epic**: Core Infrastructure
**Story Points**: 2

**As a** developer
**I want** automated installation of required Apigee tooling in workflows
**So that** I don't have to manually install dependencies in each workflow

**Acceptance Criteria**:
- [ ] Create `.github/actions/setup-apigee-tooling/action.yml`
- [ ] Install apigeecli (v2.7.0)
- [ ] Install apigee-go-gen (v1.0.0)
- [ ] Install yq (v4.40.5)
- [ ] Install jq
- [ ] Install Google Cloud SDK
- [ ] Add version outputs for verification
- [ ] Test action runs successfully in isolation

**Technical Details**:
```yaml
Location: .github/actions/setup-apigee-tooling/action.yml
Source: gitops/.github/actions/setup-apigee-tooling/action.yml
Changes: Direct copy - no modifications needed
```

**Definition of Done**:
- Action can be called from workflow
- All tools installed and available in PATH
- Versions verified in action output

---

### A2: Composite Action - Changed Files Detection
**Story ID**: IMPL-002
**Epic**: Core Infrastructure
**Story Points**: 3

**As a** CI/CD workflow
**I want** to detect which MAL folders changed in a PR or push
**So that** I only process/deploy affected proxies and products

**Acceptance Criteria**:
- [ ] Create `.github/actions/changed-files/action.yml`
- [ ] Detect changed files for PRs (vs base_ref)
- [ ] Detect changed files for pushes (vs before commit)
- [ ] Support manual override via input parameter
- [ ] Export CHANGED_FILES environment variable
- [ ] Export DELETED_FILES environment variable
- [ ] Filter to only `mal-SYSGEN*/` paths
- [ ] Handle empty change sets gracefully

**Technical Details**:
```yaml
Location: .github/actions/changed-files/action.yml
Source: gitops/.github/actions/changed-files/action.yml
Adaptations:
  - Change from "orgs/*/envs/*/proxies/*" pattern to "mal-SYSGEN*/**" pattern
  - Add MAL folder extraction logic
```

**Definition of Done**:
- Returns correct changed files for PR
- Returns correct changed files for push
- Manual override works
- Empty change sets don't break workflow

---

### A3: Composite Action - Extract MAL Metadata
**Story ID**: IMPL-003
**Epic**: Core Infrastructure
**Story Points**: 2

**As a** deployment workflow
**I want** to extract MAL code, org, and environment from changed file paths
**So that** I know which Apigee org/env to target for deployment

**Acceptance Criteria**:
- [ ] Create `.github/actions/extract-mal-metadata/action.yml`
- [ ] Parse MAL code from `mal-SYSGEN<code>/` folder name
- [ ] Determine target org from workflow input or file path
- [ ] Determine target env from workflow input (dev/test/prod)
- [ ] Export MAL_CODE environment variable
- [ ] Export APIGEE_ORG environment variable (normalized, uppercase for secret lookup)
- [ ] Export APIGEE_ENV environment variable
- [ ] Handle multiple MALs changed (process each)

**Technical Details**:
```bash
Input: mal-SYSGEN123456789/proxies/SYSGEN123456789-my-api/dev/base.yaml
Outputs:
  - MAL_CODE=123456789
  - APIGEE_ORG=gcp-prj-apigee-dev-np-01 (from workflow input)
  - APIGEE_ORG_UPPER=GCP_PRJ_APIGEE_DEV_NP_01 (for secret name)
  - APIGEE_ENV=apicc-dev (from workflow input)
```

**Definition of Done**:
- Correctly extracts MAL code
- Correctly sets org/env from inputs
- Exports all required environment variables
- Works with multiple MAL folders

---

### A4: Composite Action - Download Template
**Story ID**: IMPL-004
**Epic**: Core Infrastructure
**Story Points**: 3

**As a** proxy deployment process
**I want** to download the latest template bundle from GitHub releases
**So that** I can transform it with the proxy configuration

**Acceptance Criteria**:
- [ ] Create `.github/actions/download-template/action.yml`
- [ ] Load template mappings from `template-mappings.json`
- [ ] Fetch latest release tag matching template name
- [ ] Download release zip file using gh CLI
- [ ] Extract to specified output directory
- [ ] Return path to extracted template
- [ ] Cache downloaded templates to speed up subsequent runs
- [ ] Handle template not found errors

**Technical Details**:
```yaml
Location: .github/actions/download-template/action.yml
Source: gitops/.github/actions/download-template/action.yml
Changes: Direct copy - minimal modifications needed
Dependencies:
  - template-mappings.json (copy from gitops)
  - GitHub token for API access
```

**Definition of Done**:
- Downloads template successfully
- Extracts to correct directory
- Returns correct template path
- Error handling for missing templates

---

### A5: Workflow - Validate Proxy on PR
**Story ID**: IMPL-005
**Epic**: Core Infrastructure
**Story Points**: 5

**As an** API producer
**I want** my proxy configuration validated automatically on PR
**So that** I get fast feedback on errors before merging

**Acceptance Criteria**:
- [ ] Create `.github/workflows/validate-proxy.yml`
- [ ] Trigger on PR to paths: `mal-SYSGEN*/proxies/**/*.yaml`
- [ ] Call setup-apigee-tooling action
- [ ] Call changed-files action
- [ ] For each changed proxy YAML:
  - [ ] Validate YAML syntax (yq)
  - [ ] Validate against apiproxy.schema.json (ajv-cli)
  - [ ] Validate proxy name follows SYSGEN convention
  - [ ] Validate template reference exists in mappings
  - [ ] Download template and verify it exists
  - [ ] Check OAS file exists if oasValidation configured
- [ ] Post PR comment with validation results
- [ ] Fail workflow if any validation fails

**Technical Details**:
```yaml
Location: .github/workflows/validate-proxy.yml
Source: gitops/.github/workflows/validate-proxy.yml
Key Changes:
  - Path trigger: "mal-SYSGEN*/proxies/**/*.yaml"
  - Remove sharedflow logic
  - Remove apigee org detection (use workflow-level config)
  - Simplify to schema + template validation only
  - No Apigee API calls needed (pure validation)
```

**Definition of Done**:
- Validates proxy YAML successfully
- Catches schema violations
- Catches naming convention errors
- Catches missing template references
- PR status check shows pass/fail

---

### A6: Workflow - Validate MAL Structure
**Story ID**: IMPL-006
**Epic**: Core Infrastructure
**Story Points**: 3

**As a** repository administrator
**I want** to validate MAL folder structure on PRs
**So that** teams follow the required conventions

**Acceptance Criteria**:
- [ ] Create `.github/workflows/validate-mal-structure.yml`
- [ ] Trigger on PR to paths: `mal-SYSGEN*/**`
- [ ] For each changed MAL folder:
  - [ ] Verify folder name matches `mal-SYSGEN[0-9]{9}` pattern
  - [ ] Verify CODEOWNERS file exists
  - [ ] Verify proxies/ folder structure (proxy/env/base.yaml)
  - [ ] Verify products/ folder exists if products defined
  - [ ] Check for required environment folders (dev at minimum)
- [ ] Report validation errors clearly
- [ ] Pass if all structure checks pass

**Technical Details**:
```bash
Script: scripts/validate-mal-structure.sh
Called by: .github/workflows/validate-mal-structure.yml
Checks:
  1. Folder naming convention
  2. Required files (CODEOWNERS)
  3. Proxy folder structure
  4. No orphaned files outside expected structure
```

**Definition of Done**:
- Catches malformed MAL folder names
- Catches missing CODEOWNERS
- Catches incorrect proxy folder structure
- Clear error messages

---

### A7: Schema Files - Copy and Adapt
**Story ID**: IMPL-007
**Epic**: Core Infrastructure
**Story Points**: 1

**As a** developer
**I want** JSON schemas for proxy validation
**So that** my YAML files are validated correctly

**Acceptance Criteria**:
- [ ] Copy `apiproxy.schema.json` from gitops to repository root
- [ ] Copy `template-mappings.json` from gitops to repository root
- [ ] Copy `.yamllint.yml` from gitops to repository root
- [ ] Update template-mappings.json if needed for applications repo
- [ ] Test schema validation works with ajv-cli

**Technical Details**:
```bash
Files to copy:
  - gitops/apiproxy.schema.json → applications/apiproxy.schema.json
  - gitops/template-mappings.json → applications/template-mappings.json
  - gitops/.yamllint.yml → applications/.yamllint.yml
```

**Definition of Done**:
- Schema files present in repo root
- ajv-cli validates example proxy against schema
- yamllint validates example proxy

---

## 🚀 TRACK B: Deployment & Integration (Engineer B)

### B1: Composite Action - Get Service Account
**Story ID**: IMPL-008
**Epic**: Core Infrastructure
**Story Points**: 5

**As a** deployment workflow
**I want** to retrieve service account credentials from GCP Secret Manager
**So that** I can authenticate to Apigee for deployments

**Acceptance Criteria**:
- [ ] Create `.github/actions/get-service-account/action.yml`
- [ ] Accept inputs: MAL code, org, environment
- [ ] Build secret name: `sa-apigees-<mal-code>-<org>-<env>`
- [ ] Retrieve secret from GCP Secret Manager
- [ ] Write service account key to temp file
- [ ] Authenticate gcloud with service account
- [ ] Get and export GCP access token
- [ ] Export service account email
- [ ] Export GCP project ID
- [ ] Clean up credentials on workflow completion

**Technical Details**:
```yaml
Location: .github/actions/get-service-account/action.yml
Secret Naming: sa-apigees-123456789-gcp-prj-apigee-dev-np-01-apicc-dev
Dependencies:
  - gcloud CLI (from setup-apigee-tooling)
  - GCP project with Secret Manager API enabled
  - Workload Identity or service account for GitHub Actions
```

**Definition of Done**:
- Retrieves service account from Secret Manager
- Authenticates successfully
- Returns valid access token
- Handles missing secrets with clear error

---

### B2: Composite Action - Manage KVMs
**Story ID**: IMPL-009
**Epic**: Core Infrastructure
**Story Points**: 5

**As a** proxy deployment
**I want** KVMs automatically created/updated from YAML config
**So that** my proxy has access to required configuration data

**Acceptance Criteria**:
- [ ] Create `.github/actions/manage-kvms/action.yml`
- [ ] Accept inputs: config file path, org, env, GCP token
- [ ] Parse KVM definitions from YAML spec.kvms
- [ ] For each KVM:
  - [ ] Check if KVM exists in Apigee
  - [ ] Create KVM if missing (with encrypted flag)
  - [ ] For each entry in KVM:
    - [ ] Substitute secrets from GitHub Actions secrets context
    - [ ] Create/update entry using apigeecli
- [ ] Support environment-scoped and org-scoped KVMs
- [ ] Handle secret substitution: `${SECRET_NAME}` → actual value
- [ ] Validate all required secrets are available
- [ ] Report KVM operations in workflow output

**Technical Details**:
```yaml
Location: .github/actions/manage-kvms/action.yml
Source: gitops/.github/actions/manage-kvms/action.yml
Changes:
  - Adapt for MAL-based structure
  - Accept secrets context as input (JSON)
  - Use apigeecli kvms commands
Secret Context Format:
  {
    "OAUTH_CLIENT_ID": "actual-value",
    "OAUTH_CLIENT_SECRET": "actual-secret"
  }
```

**Definition of Done**:
- Creates KVMs successfully
- Substitutes secrets correctly
- Updates existing KVM entries
- Fails gracefully if secrets missing

---

### B3: Composite Action - Validate Proxy (Full)
**Story ID**: IMPL-010
**Epic**: Core Infrastructure
**Story Points**: 3

**As a** validation workflow
**I want** reusable proxy validation logic
**So that** I can call it from different workflows

**Acceptance Criteria**:
- [ ] Create `.github/actions/validate-proxy/action.yml`
- [ ] Accept inputs: proxy file path, template name
- [ ] Validate YAML syntax
- [ ] Validate against schema
- [ ] Download template
- [ ] Verify template can be transformed
- [ ] Return validation result (pass/fail)
- [ ] Output validation errors clearly

**Technical Details**:
```yaml
Location: .github/actions/validate-proxy/action.yml
Calls:
  - download-template action
  - ajv-cli for schema validation
  - yq for YAML parsing
Returns: exit code 0 (pass) or 1 (fail)
```

**Definition of Done**:
- Validates proxy configuration
- Downloads template successfully
- Returns clear pass/fail result
- Can be called from multiple workflows

---

### B4: Composite Action - Deploy Proxy
**Story ID**: IMPL-011
**Epic**: Core Infrastructure
**Story Points**: 8

**As a** deployment workflow
**I want** to deploy a proxy to Apigee from YAML configuration
**So that** API producers can deploy their APIs via GitOps

**Acceptance Criteria**:
- [ ] Create `.github/actions/deploy-proxy/action.yml`
- [ ] Accept inputs: proxy file, MAL code, org, env, access token
- [ ] Download template bundle
- [ ] Transform template with apigee-go-gen
- [ ] Apply YAML configuration to template
- [ ] Handle OAS validation file if specified
- [ ] Import proxy bundle to Apigee using apigeecli
- [ ] Deploy proxy to target environment
- [ ] Report deployment status
- [ ] Handle deployment errors gracefully
- [ ] Support dry-run mode (validate without deploying)

**Technical Details**:
```yaml
Location: .github/actions/deploy-proxy/action.yml
Source: gitops/.github/workflows/deploy-proxy.yml (deployment logic)
Key Steps:
  1. Download template (call download-template action)
  2. Transform: apigee-go-gen transform <template> <output> <config.yaml>
  3. Import: apigeecli apis create bundle -f <bundle.zip> --org --token
  4. Deploy: apigeecli apis deploy --name --env --org --token
  5. Verify deployment succeeded
```

**Definition of Done**:
- Deploys proxy successfully to Apigee
- Proxy is accessible in target environment
- Handles template transformation correctly
- Error handling for failed deployments

---

### B5: Workflow - Deploy to Dev
**Story ID**: IMPL-012
**Epic**: Core Infrastructure
**Story Points**: 5

**As an** API producer
**I want** my proxies automatically deployed to dev when I merge to main
**So that** I can test my changes immediately

**Acceptance Criteria**:
- [ ] Create `.github/workflows/deploy-to-dev.yml`
- [ ] Trigger on push to main branch
- [ ] Filter to paths: `mal-SYSGEN*/proxies/**/*.yaml`
- [ ] Call setup-apigee-tooling action
- [ ] Call changed-files action to detect changed MALs
- [ ] For each changed MAL:
  - [ ] Extract MAL metadata
  - [ ] Get service account for dev environment
  - [ ] For each proxy in `*/proxies/*/dev/base.yaml`:
    - [ ] Manage KVMs if defined
    - [ ] Deploy proxy to dev environment
- [ ] Target: `gcp-prj-apigee-dev-np-01` / `apicc-dev`
- [ ] Report deployment success/failure
- [ ] Post deployment status to commit/PR

**Technical Details**:
```yaml
Location: .github/workflows/deploy-to-dev.yml
Target Org: gcp-prj-apigee-dev-np-01
Target Env: apicc-dev
Calls:
  - extract-mal-metadata
  - get-service-account
  - manage-kvms
  - deploy-proxy
```

**Definition of Done**:
- Deploys to dev on main branch push
- Only deploys changed proxies
- Reports deployment status
- Multiple MALs can deploy in same push

---

### B6: Workflow - Deploy to Test
**Story ID**: IMPL-013
**Epic**: Core Infrastructure
**Story Points**: 3

**As an** API producer
**I want** my proxies deployed to test environment
**So that** I can perform integration testing

**Acceptance Criteria**:
- [ ] Create `.github/workflows/deploy-to-test.yml`
- [ ] Same logic as deploy-to-dev but target test environment
- [ ] Read proxy config from `*/proxies/*/test/base.yaml`
- [ ] Target: `gcp-prj-apigee-qa-np-01` / `apicc-test1`
- [ ] Trigger on push to main OR manual workflow_dispatch

**Technical Details**:
```yaml
Location: .github/workflows/deploy-to-test.yml
Target Org: gcp-prj-apigee-qa-np-01
Target Env: apicc-test1
Same pattern as deploy-to-dev, different org/env
```

**Definition of Done**:
- Deploys to test environment
- Uses test-specific configuration
- Can be triggered manually or automatically

---

### B7: Workflow - Deploy to Prod
**Story ID**: IMPL-014
**Epic**: Core Infrastructure
**Story Points**: 3

**As an** API producer
**I want** my proxies deployed to production with approval
**So that** I maintain control over production changes

**Acceptance Criteria**:
- [ ] Create `.github/workflows/deploy-to-prod.yml`
- [ ] Same logic as deploy-to-dev/test but with approval gate
- [ ] Read proxy config from `*/proxies/*/prod/base.yaml`
- [ ] Target: `gcp-prj-apigee-prod-01` / `apicc-prod`
- [ ] Require GitHub environment protection (manual approval)
- [ ] Trigger only on manual workflow_dispatch

**Technical Details**:
```yaml
Location: .github/workflows/deploy-to-prod.yml
Target Org: gcp-prj-apigee-prod-01
Target Env: apicc-prod
Environment: production (with protection rules)
Same pattern as dev/test, with approval requirement
```

**Definition of Done**:
- Deploys to prod environment
- Requires manual approval
- Uses prod-specific configuration
- Only manual trigger (no automatic deployment)

---

### B8: Product Deployment Actions & Workflows
**Story ID**: IMPL-015
**Epic**: Core Infrastructure
**Story Points**: 5

**As an** API producer
**I want** to deploy API products alongside my proxies
**So that** consumers can access my APIs

**Acceptance Criteria**:
- [ ] Create `.github/actions/validate-product/action.yml`
  - [ ] Validate product YAML against schema
  - [ ] Check proxy references exist
  - [ ] Validate product naming convention
- [ ] Create `.github/actions/deploy-product/action.yml`
  - [ ] Create/update product using apigeecli
  - [ ] Handle product attributes, quota, scopes
  - [ ] Support multiple environments
- [ ] Update deploy-to-dev/test/prod workflows to include products
  - [ ] Deploy products from `mal-*/products/*.yaml`
  - [ ] Deploy products after proxies
- [ ] Copy `apiproduct.schema.json` from gitops

**Technical Details**:
```yaml
Product files: mal-SYSGEN123456789/products/SYSGEN123456789-my-product.yaml
Schema: apiproduct.schema.json (from gitops)
Deploy with: apigeecli products create/update
```

**Definition of Done**:
- Products deploy successfully
- Products reference correct proxies
- Products created in correct environments
- Validation catches product errors

---

## 🔗 SHARED TASKS (Either Engineer)

### S1: Repository Configuration
**Story ID**: IMPL-016
**Epic**: Core Infrastructure
**Story Points**: 3

**As a** repository administrator
**I want** proper GitHub repository configuration
**So that** workflows and access controls work correctly

**Acceptance Criteria**:
- [ ] Create GitHub environments: dev, test, production
- [ ] Configure protection rules for production environment
  - [ ] Require manual approval
  - [ ] Restrict to specific approvers
- [ ] Set up branch protection for main:
  - [ ] Require PR before merge
  - [ ] Require status checks to pass
  - [ ] Require reviews (1 approver minimum)
- [ ] Add GitHub secrets for testing:
  - [ ] Sample OAUTH_CLIENT_ID
  - [ ] Sample OAUTH_CLIENT_SECRET
- [ ] Configure CODEOWNERS merge workflow
- [ ] Test service account retrieval from Secret Manager

**Technical Details**:
```yaml
Environments: dev, test, production
Branch Protection: main branch
Required Checks: validate-proxy, validate-mal-structure
```

**Definition of Done**:
- Environments configured
- Branch protection active
- Manual approval required for prod
- Test secrets available

---

### S2: End-to-End Integration Testing
**Story ID**: IMPL-017
**Epic**: Core Infrastructure
**Story Points**: 5

**As a** platform engineer
**I want** to verify the entire workflow end-to-end
**So that** I'm confident the system works before API producer onboarding

**Acceptance Criteria**:
- [ ] Create test MAL folder: `mal-SYSGEN999999999`
- [ ] Create test proxy using JWT template
- [ ] Create test product
- [ ] Open PR with test proxy → verify validation passes
- [ ] Merge PR → verify deployment to dev succeeds
- [ ] Manually trigger deploy to test → verify deployment succeeds
- [ ] Manually trigger deploy to prod with approval → verify deployment succeeds
- [ ] Verify proxy is accessible in all environments
- [ ] Test KVM creation with sample secrets
- [ ] Test error scenarios:
  - [ ] Invalid YAML syntax
  - [ ] Schema validation failure
  - [ ] Missing template reference
  - [ ] Missing service account
  - [ ] Failed deployment (wrong config)

**Definition of Done**:
- Full happy path works end-to-end
- Error scenarios handled gracefully
- All environments deploy successfully
- KVMs created correctly

---

### S3: CODEOWNERS Aggregation Workflow
**Story ID**: IMPL-018
**Epic**: Core Infrastructure
**Story Points**: 2

**As a** repository administrator
**I want** MAL-level CODEOWNERS automatically aggregated to root
**So that** GitHub enforces per-team ownership

**Acceptance Criteria**:
- [ ] Create/update `.github/workflows/merge-codeowners.yml`
- [ ] Trigger on PR when any `mal-*/CODEOWNERS` file changes
- [ ] Aggregate all MAL CODEOWNERS into root `.github/CODEOWNERS`
- [ ] Commit aggregated CODEOWNERS to PR automatically
- [ ] Validate CODEOWNERS syntax before committing

**Technical Details**:
```bash
Script Logic:
  1. Find all mal-*/CODEOWNERS files
  2. Read each file
  3. Combine into .github/CODEOWNERS
  4. Commit back to PR branch
```

**Definition of Done**:
- CODEOWNERS aggregation works
- Changes committed automatically
- GitHub enforces per-MAL ownership

---

## 📊 EPIC SUMMARY

### Epic: Core Infrastructure
**Goal**: Build working CI/CD infrastructure for API producer self-service

**Stories**: 18 total
**Total Story Points**: 62

**Track A** (Validation & Foundation): 7 stories, 19 points
**Track B** (Deployment & Integration): 8 stories, 37 points
**Shared**: 3 stories, 10 points

---

## 📅 SPRINT PLANNING RECOMMENDATION

### Sprint 1 (Week 1): Foundation
**Track A**: IMPL-001, IMPL-002, IMPL-003, IMPL-004, IMPL-007
**Track B**: IMPL-008, IMPL-010
**Goal**: Core actions and schemas in place

### Sprint 2 (Week 2): Workflows
**Track A**: IMPL-005, IMPL-006
**Track B**: IMPL-009, IMPL-011, IMPL-012
**Goal**: Validation and dev deployment working

### Sprint 3 (Week 3): Complete Environments
**Track B**: IMPL-013, IMPL-014, IMPL-015
**Shared**: IMPL-016, IMPL-017, IMPL-018
**Goal**: All environments working, end-to-end tested

---

## 🎯 DEPENDENCIES

### External Dependencies
- GCP Secret Manager must have service accounts provisioned
- Template repository must have stable releases
- GitHub org must allow environment protection rules
- Apigee dev/test/prod environments must exist and be accessible

### Internal Dependencies
```mermaid
graph TD
    IMPL-001[Setup Tooling] --> IMPL-002[Changed Files]
    IMPL-001 --> IMPL-004[Download Template]
    IMPL-002 --> IMPL-005[Validate Workflow]
    IMPL-003[Extract MAL] --> IMPL-012[Deploy Dev]
    IMPL-004 --> IMPL-010[Validate Action]
    IMPL-004 --> IMPL-011[Deploy Action]
    IMPL-007[Schemas] --> IMPL-005
    IMPL-008[Get Service Account] --> IMPL-011
    IMPL-009[Manage KVMs] --> IMPL-011
    IMPL-010 --> IMPL-005
    IMPL-011 --> IMPL-012
    IMPL-012 --> IMPL-013[Deploy Test]
    IMPL-012 --> IMPL-014[Deploy Prod]
```

---

## ✅ DEFINITION OF DONE (ALL STORIES)

**Code**:
- [ ] Code complete and peer reviewed
- [ ] No hardcoded secrets or credentials
- [ ] Error handling implemented
- [ ] Logging added for debugging

**Testing**:
- [ ] Unit tested (where applicable)
- [ ] Integration tested
- [ ] Error scenarios tested
- [ ] Works with example data

**Documentation**:
- [ ] Code comments added for complex logic
- [ ] Action/workflow inputs/outputs documented
- [ ] README updated if needed

**Deployment**:
- [ ] Changes merged to main branch
- [ ] Works in actual GitHub Actions environment
- [ ] No breaking changes to existing functionality

---

## 🚀 JIRA IMPORT INSTRUCTIONS

### Method 1: Manual Creation
1. Create Epic: "Core Infrastructure" (EPIC-001)
2. For each story IMPL-001 through IMPL-018:
   - Copy story title as Jira summary
   - Copy "As a/I want/So that" as description
   - Copy acceptance criteria as checklist
   - Copy technical details to comments
   - Set story points from table
   - Link to Epic

### Method 2: CSV Import
Create CSV with columns:
```csv
Summary,Description,Story Points,Epic Link,Acceptance Criteria
"Setup Composite Action - Setup Apigee Tooling","As a developer...","2","EPIC-001","[checklist]"
```

### Method 3: Jira API (Automated)
Use the acceptance criteria and technical details sections to generate Jira JSON payload for bulk import via API.

---

## 📝 NOTES

### Work Distribution Strategy
- **Engineer A** focuses on validation, which blocks nothing
- **Engineer B** focuses on deployment, which depends on some A tasks
- After Sprint 1, both can work more independently
- Shared tasks can be done by whoever finishes first

### Risk Mitigation
- **Risk**: Service account retrieval fails
  - *Mitigation*: Complete IMPL-008 early, test thoroughly
- **Risk**: Template download issues
  - *Mitigation*: Complete IMPL-004 early, verify template repo access
- **Risk**: Scope creep on deployment action
  - *Mitigation*: IMPL-011 is largest story, may need breakdown

### Success Metrics
- All 18 stories completed
- End-to-end test passes (IMPL-017)
- Ready for pilot team onboarding
- Zero P0/P1 bugs in integration testing
