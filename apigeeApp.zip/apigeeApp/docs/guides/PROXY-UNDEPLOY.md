# Proxy Undeploy/Delete Guide

This guide explains how proxy undeploy and delete are handled automatically when a proxy YAML is removed from the MAL folder.

## Overview

- When a proxy YAML is deleted in a commit, CI workflows detect the deletion and undeploy/delete the proxy from Apigee X.
- Applies to Dev, Test, and Prod workflows.
- Uses `apigeecli apis delete` to remove all revisions and undeploy from all environments.

## How It Works

1. The workflows run the `changed-files` composite action to compute changed and deleted files.
2. Deleted files are exported to environment (`DELETED_FILES`) for subsequent steps.
3. Each deleted proxy YAML path is processed:
   - Extracts the `metadata.name` from the last commit (`git show HEAD~1:"<path>" | yq ...`).
   - Calls `apigeecli apis delete --name <proxy>` with org-level credentials.
   - Logs success or not-found; continues safely.

## Caution

- Deleting a proxy YAML removes the proxy from Apigee entirely (all revisions, all envs).
- If you intend to undeploy only from a specific environment, open a PR to adjust logic rather than deleting the file.

## Rollback

- Re-introduce the proxy YAML in the MAL folder and merge; the normal deploy workflow will recreate and deploy the proxy.
- You may need to reconfigure KVMs and Target Servers depending on the proxy spec. Workflows handle these automatically.

## Troubleshooting

- "Could not extract proxy name": Ensure the deleted file path was an `ApiProxy` YAML and contained `metadata.name`.
- "Proxy not found": It may have been manually deleted or never deployed; the workflow continues safely.
