# Multi-Org Deployment Testing Checklist

## Tonight's Testing Focus
Validate the 4 deployment workflows we just migrated work correctly with multi-org/multi-env.

---

## Test 1: Multi-Org Product Deployment ✅ (Already tested with PR #50)

**Status**: VERIFIED
- PR #50 created with 3 products across 3 orgs
- Matrix created 3 parallel jobs correctly
- File filtering worked per org
- Service account lookup pattern validated (blocked by permissions - expected)

**Workflow Run**: 20322168697

---

## Test 2: Multi-Org Proxy Deployment (Dev)

**Workflow**: deploy-to-dev.yml

**Test Scenario**: Create PR with proxy changes in 2 different dev orgs

**Steps**:
1. Create test branch: `test/multi-org-proxies-dev`
2. Add/modify proxy YAML in:
   - `mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/test-proxy-1/proxy.yaml`
   - `mal-SYSGEN788836350/orgs/gcp-prj-apigee-[another-dev-org]/envs/[env]/proxies/test-proxy-2/proxy.yaml`
3. Push and merge to main
4. Observe workflow run

**Expected**:
- ✅ detect-changes job outputs org_matrix with 2 orgs
- ✅ deploy job creates 2 parallel matrix instances
- ✅ Each job filters to its own org's files
- ✅ Each job derives correct environment from org name
- ✅ Each job attempts to get MAL service account (may fail on permissions)

**Validation**:
```bash
# After merge, check workflow
gh run list --workflow=deploy-to-dev.yml --limit 1
gh run view <run-id>
```

---

## Test 3: Multi-Org Proxy Deployment (Test/QA)

**Workflow**: deploy-to-test.yml

**Test Scenario**: Same as Test 2 but for test/qa environments

**Steps**: Similar to Test 2, use qa orgs

**Expected**: Same matrix behavior with qa orgs

---

## Test 4: Multi-Org Proxy Deployment (Prod)

**Workflow**: deploy-to-prod.yml

**Test Scenario**: Same as Test 2 but for prod environment

**Steps**: Similar to Test 2, use prod org

**Expected**: Same matrix behavior with prod org

⚠️ **CAUTION**: Use test proxies only, be careful with prod deployments

---

## Test 5: Single-Org Deployment (Regression)

**Purpose**: Verify single-org PRs still work correctly

**Steps**:
1. Create PR with changes to single org only
2. Verify matrix creates 1 job (not empty array)
3. Confirm deployment succeeds

---

## Test 6: Mixed Changes (Products + Proxies)

**Purpose**: Verify multiple deployment workflows can trigger from same PR

**Steps**:
1. Create PR with:
   - Product change in org A
   - Proxy change in org B
2. Verify both workflows trigger
3. Verify each uses correct org matrix

---

## Test 7: No Changes (Skip Logic)

**Purpose**: Verify workflows skip when no relevant files changed

**Steps**:
1. Create PR with changes to:
   - README.md
   - docs/*.md
   - .github/workflows/ (non-path-matched files)
2. Verify deploy workflows don't trigger or skip gracefully

---

## Test 8: Isolated Failures

**Purpose**: Verify fail-fast: false works (one org fails, others continue)

**Steps**:
1. Create PR with changes to 3 orgs
2. Introduce error in one org's files (invalid YAML, missing template, etc.)
3. Push and observe workflow
4. Verify 2 orgs succeed, 1 fails
5. Confirm workflow completes (not cancelled)

---

## Quick Test Commands

### Check recent workflow runs
```bash
cd /Users/rschilm/RyanDev/GitHub/enterprise-apigeex-applications

# List recent runs for each workflow
gh run list --workflow=deploy-products.yml --limit 5
gh run list --workflow=deploy-to-dev.yml --limit 5
gh run list --workflow=deploy-to-test.yml --limit 5
gh run list --workflow=deploy-to-prod.yml --limit 5
```

### View specific workflow run
```bash
gh run view <run-id> --log
```

### Check for errors in workflow runs
```bash
gh run list --workflow=deploy-products.yml --status=failure --limit 10
```

---

## Success Criteria

### Functional
- ✅ Multi-org matrix creates correct number of jobs
- ✅ File filtering per org works correctly
- ✅ Environment derivation works for all org naming patterns
- ✅ Service account lookup pattern correct (even if blocked by permissions)
- ✅ Isolated failures work (fail-fast: false)

### Edge Cases
- ✅ Single-org PRs work (regression test)
- ✅ Empty changes skip gracefully
- ✅ Mixed products + proxies trigger correct workflows

---

## Known Blockers (Expected)

1. **Service Account Permissions**: MAL service accounts may not have Secret Manager access yet
   - Expected error: "Permission denied on secret"
   - This is a CCOE approval issue, not a workflow issue
   - Validation: Check that workflow attempted to look up correct SA name

2. **Test Org Availability**: May not have access to all test orgs
   - Work with available orgs
   - Document which orgs were tested

---

## Test Results Template

```markdown
## Test Results: [Test Name]

**Date**: 2025-12-17
**Tester**: [Your name]
**Branch**: [test branch name]
**PR**: #[number]
**Workflow Run**: [run ID or URL]

### Matrix Strategy
- Orgs detected: [count]
- Matrix jobs created: [count]
- ✅/❌ Match expected: [yes/no]

### File Filtering
- ✅/❌ Each job received correct files: [yes/no]
- ✅/❌ No cross-org leakage: [yes/no]

### Execution
- ✅/❌ Jobs ran in parallel: [yes/no]
- ✅/❌ Isolated failures worked: [yes/no]

### Blockers
- [List any unexpected blockers]

### Notes
- [Any observations]
```

---

## Tonight's Goal

Get through Tests 1-5 (or as many as possible):
- ✅ Test 1: Already done (PR #50)
- 🎯 Test 2: Multi-org proxies (dev)
- 🎯 Test 5: Single-org regression

Document findings for tomorrow's validation work.
