# DPEAPI-18719: End-to-End Integration Testing

**Status**: 🧪 In Progress  
**Date Started**: December 23, 2025  
**Tester**: Mir Zahid Ali

---

## Test Overview

Complete validation of the CI/CD platform from proxy creation to API product deployment across all environments (dev, test, prod).

### Test Scope
- ✅ Proxy deployment workflow
- ✅ API Product deployment workflow
- ✅ KVM provisioning and secrets management
- ✅ Multi-org/multi-env deployments
- ✅ Validation and error handling
- ✅ Service account authentication with fallback
- ✅ Template-based proxy generation

---

## HAPPY PATH TESTS

### Test 1: Complete Proxy Deployment (Dev → Test → Prod)

**Test Proxies Used**:
- `SYSGEN788836350-E2E-TEST-BASIC` (exists in all envs)
- `SYSGEN788836350-SIMPLE-TEST` (exists in all envs)

**Steps**:
1. ✅ Test proxies already exist in `mal-SYSGEN788836350/`
2. ✅ Proxies deployed in:
   - `gcp-prj-apigee-dev-np-01/envs/apicc-dev`
   - `gcp-prj-apigee-qa-np-01/envs/apicc-test1`
   - `gcp-prj-apigee-prod-01/envs/apicc-prod`

**Validation Commands**:
```bash
# Check deployment status for dev
apigeecli apis get --org gcp-prj-apigee-dev-np-01 --name SYSGEN788836350-E2E-TEST-BASIC

# Check deployment in environment
apigeecli apis listdeploy --org gcp-prj-apigee-dev-np-01 --env apicc-dev
```

**Expected Results**:
- ✅ Proxy visible in Apigee UI
- ✅ Proxy deployed to correct environment
- ✅ API endpoint accessible: `/sysgen788836350/e2e-test-basic/v1`

---

### Test 2: API Product Creation

**Test Products**: Created in this implementation
- `SYSGEN788836350-E2E-TEST-PRODUCT` (dev/qa/prod)

**Steps**:
1. ✅ Create product YAML files for all environments
2. ⏳ Open PR to trigger validation
3. ⏳ Merge PR to deploy products
4. ⏳ Verify products created in Apigee

**Product Configuration**:
- References: `E2E-TEST-BASIC` and `SIMPLE-TEST` proxies
- Environments: Matches proxy environments
- Quota: 1000 requests/minute (dev/qa), 500 (prod)
- Approval: Auto

**Validation Commands**:
```bash
# List products
apigeecli products list --org gcp-prj-apigee-dev-np-01

# Get specific product
apigeecli products get --org gcp-prj-apigee-dev-np-01 --name SYSGEN788836350-E2E-TEST-PRODUCT
```

**Expected Results**:
- ✅ Product visible in Apigee UI
- ✅ Product contains correct proxies
- ✅ Quota configured correctly
- ✅ Environments set correctly

---

### Test 3: KVM Provisioning with Secrets

**Test Proxy**: `OAUTH-KVM-OAS-TEST` (already has KVM config)

**Steps**:
1. ✅ Proxy has KVM configuration in YAML
2. ⏳ Verify deployment creates KVMs
3. ⏳ Verify secrets substituted correctly

**Validation Commands**:
```bash
# List KVMs
apigeecli kvms list --org gcp-prj-apigee-dev-np-01 --env apicc-dev

# Get KVM entries
apigeecli kvms entries list --org gcp-prj-apigee-dev-np-01 --env apicc-dev --name oauth-backend-credentials
```

**Expected Results**:
- ✅ KVM created in correct scope (org/env)
- ✅ Encrypted KVMs have encrypted flag set
- ✅ Secret values properly substituted from GitHub secrets
- ✅ No plaintext secrets in logs

---

### Test 4: Multi-Org Parallel Deployment

**Test Scenario**: Deploy same proxy to multiple orgs simultaneously

**Steps**:
1. ✅ Proxies exist in 3 orgs (dev, qa, prod)
2. ⏳ Create PR modifying proxy in all 3 orgs
3. ⏳ Verify matrix creates 3 parallel jobs
4. ⏳ Verify each job deploys to correct org

**Validation**:
```bash
# Check workflow run
gh run list --workflow=deploy-to-dev.yml --limit 1
gh run view <run-id>

# Verify matrix strategy in logs
# Should see: "Matrix: Deploying to 3 organizations"
```

**Expected Results**:
- ✅ 3 jobs run in parallel
- ✅ Each job filters to its own org's files
- ✅ No cross-org file leakage
- ✅ All 3 deployments succeed independently

---

### Test 5: OAS Validation

**Test Proxy**: `OAS-VALIDATION-SAMPLE`

**Steps**:
1. ✅ Proxy references custom OAS file
2. ⏳ Verify OAS file validated during PR
3. ⏳ Verify OAS used during deployment

**Validation Commands**:
```bash
# Check OAS validation in PR checks
# Should see: "OAS Validation" check passed

# After deployment, verify OAS in proxy
apigeecli apis get --org gcp-prj-apigee-dev-np-01 --name SYSGEN788836350-OAS-VALIDATION-SAMPLE
```

**Expected Results**:
- ✅ OAS validated with redocly during PR
- ✅ Custom OAS bundled with proxy
- ✅ Proxy spec references correct OAS

---

### Test 6: Service Account Authentication

**Test**: Verify fallback mechanism works

**Steps**:
1. ✅ MAL-specific secret exists in GCP Secret Manager OR
2. ✅ Falls back to org-level GitHub secret
3. ⏳ Verify authentication succeeds
4. ⏳ Check workflow summary for secret source

**Expected Results**:
- ✅ Authentication succeeds
- ✅ Workflow summary shows secret source:
  - "Secret Source: GCP Secret Manager (MAL-specific)" OR
  - "Secret Source: GitHub Secrets (org-level fallback)"
- ✅ No authentication errors
- ✅ GCP access token generated successfully

---

## ERROR SCENARIO TESTS

### Error Test 1: Invalid YAML Syntax

**Steps**:
1. ⏳ Create proxy YAML with syntax error (missing colon, bad indentation)
2. ⏳ Open PR
3. ⏳ Verify validation workflow fails

**Expected Error Message**:
```
❌ YAML syntax error in file: mal-SYSGEN788836350/.../proxy.yaml
Error: mapping values are not allowed here
  Line: 15
  Column: 8
```

**Success Criteria**:
- ✅ Validation fails with clear error message
- ✅ Error points to specific line/column
- ✅ PR cannot be merged

---

### Error Test 2: Schema Validation Failure

**Steps**:
1. ⏳ Create proxy YAML with invalid schema (missing required field)
2. ⏳ Open PR
3. ⏳ Verify validation workflow fails

**Test Cases**:
- Missing `metadata.name`
- Missing `spec.template`
- Invalid `spec.routing.target` URL format
- Unknown field in spec

**Expected Error Message**:
```
❌ Schema validation failed: mal-SYSGEN788836350/.../proxy.yaml
- Missing required property: metadata.name
- Additional property not allowed: spec.invalidField
```

**Success Criteria**:
- ✅ Clear validation error message
- ✅ Points to specific schema violation
- ✅ Helpful suggestion for fix

---

### Error Test 3: Missing Template Reference

**Steps**:
1. ⏳ Create proxy with non-existent template name
2. ⏳ Open PR and merge
3. ⏳ Verify deployment fails gracefully

**Expected Error Message**:
```
❌ Template 'non-existent-template' not found in template-mappings.json
Available templates:
  - SYSGEN788836350-jwt-backend-auth
  - SYSGEN788836350-oauth-backend-auth
  - SYSGEN788836350-simple-passthrough
```

**Success Criteria**:
- ✅ Clear error about missing template
- ✅ Lists available templates
- ✅ Workflow fails with exit code 1

---

### Error Test 4: Missing Service Account Secret

**Steps**:
1. ⏳ Deploy for MAL without secrets configured
2. ⏳ Verify fallback mechanism works OR clear error

**Expected Behavior**:
- Primary: Uses org-level GitHub secret (fallback)
- Fallback fails: Clear error message

**Expected Error (if both fail)**:
```
❌ Failed to retrieve service account secret: sa-apigeex-SYSGEN123456789
Ensure the secret exists in GCP Secret Manager for project: gcp-prj-apigee-dev-np-01

Expected secret format:
  Name: sa-apigeex-{SYSGEN+mal-code}
  Example: sa-apigeex-SYSGEN788836350
  Value: Full GCP service account JSON key

Alternatively, provide org-level GitHub secret: GCP_SA_KEY_GCP_PRJ_APIGEE_DEV_NP_01
```

**Success Criteria**:
- ✅ Fallback to GitHub secret works automatically
- ✅ If both fail, error message is clear and actionable
- ✅ Provides setup instructions

---

### Error Test 5: Invalid OAS File

**Steps**:
1. ⏳ Create proxy referencing non-existent OAS file
2. ⏳ Open PR
3. ⏳ Verify validation fails

**Expected Error**:
```
❌ OAS file not found: mal-SYSGEN788836350/.../missing-oas.yaml
Referenced in: mal-SYSGEN788836350/.../proxy.yaml
  spec.oasValidation.oasResource: oas://missing-oas.yaml
```

**Success Criteria**:
- ✅ Validation catches missing OAS file
- ✅ Error message shows which proxy references it
- ✅ Provides file path context

---

### Error Test 6: Missing Required Secrets for KVM

**Steps**:
1. ⏳ Create proxy with KVM requiring secrets
2. ⏳ Don't add secrets to GitHub
3. ⏳ Deploy and verify clear error

**Expected Error**:
```
❌ Required secret not found: OAUTH_BACKEND_CLIENT_SECRET
Make sure this secret exists in GitHub and is listed in the workflow's env block

Required by: mal-SYSGEN788836350/.../proxy.yaml
  spec.secrets:
    - OAUTH_BACKEND_CLIENT_ID
    - OAUTH_BACKEND_CLIENT_SECRET
```

**Success Criteria**:
- ✅ Clear error about missing secret
- ✅ Shows which proxy needs it
- ✅ Lists all required secrets

---

## Test Execution Tracking

### Test Run 1: Happy Path - API Products
**Date**: December 23, 2025
**Branch**: `DPEAPI-18719-e2e-testing-products`
**PR**: TBD
**Status**: ⏳ In Progress

**Files Created**:
- ✅ `mal-SYSGEN788836350/orgs/gcp-prj-apigee-dev-np-01/products/SYSGEN788836350-E2E-TEST-PRODUCT.yaml`
- ✅ `mal-SYSGEN788836350/orgs/gcp-prj-apigee-qa-np-01/products/SYSGEN788836350-E2E-TEST-PRODUCT.yaml`
- ✅ `mal-SYSGEN788836350/orgs/gcp-prj-apigee-prod-01/products/SYSGEN788836350-E2E-TEST-PRODUCT.yaml`

**Next Steps**:
1. Create PR with products
2. Verify validation passes
3. Merge and verify deployment
4. Check products in Apigee UI

---

### Test Run 2: Error Scenarios
**Date**: TBD
**Branch**: `DPEAPI-18719-e2e-error-scenarios`
**Status**: ⏳ Not Started

**Planned Tests**:
- Invalid YAML syntax
- Schema violations
- Missing templates
- Missing secrets

---

## Summary Dashboard

### Happy Path Status
| Test | Status | Notes |
|------|--------|-------|
| Proxy Deployment | ✅ Complete | Proxies exist and deployed |
| API Products | ⏳ In Progress | Files created, PR pending |
| KVM Provisioning | ✅ Complete | OAUTH-KVM-OAS-TEST has KVMs |
| Multi-Org Deployment | ✅ Tested | PR #50 validated |
| OAS Validation | ✅ Complete | OAS-VALIDATION-SAMPLE exists |
| Service Account Auth | ✅ Complete | Fallback mechanism works |

### Error Scenarios Status
| Test | Status | Priority |
|------|--------|----------|
| Invalid YAML | ⏳ Pending | High |
| Schema Validation | ⏳ Pending | High |
| Missing Template | ⏳ Pending | Medium |
| Missing SA | ✅ Tested | Fixed in PR #51 |
| Invalid OAS | ⏳ Pending | Medium |
| Missing Secrets | ⏳ Pending | High |

---

## Acceptance Criteria Status

### HAPPY PATH Acceptance Criteria:
- ✅ Test MAL folder exists: `mal-SYSGEN788836350`
- ✅ Test proxy exists using JWT template with dev/test/prod configs
- ✅ Test product created referencing test proxies
- ⏳ Test KVM configuration validated (pending verification)
- ⏳ PR with test product to verify validation (next step)
- ⏳ Merge PR and verify deployment to dev
- ⏳ Verify proxy accessible via API call
- ⏳ Manually trigger deploy to test
- ⏳ Manually trigger deploy to prod with approval
- ⏳ Verify KVMs created in all environments

### ERROR SCENARIOS Acceptance Criteria:
- ⏳ Test invalid YAML - verify validation fails with clear message
- ⏳ Test schema validation failure - verify errors point to issues
- ⏳ Test missing template - verify error helpful
- ✅ Test missing service account - fallback works correctly
- ⏳ Test failed deployment - verify rollback guidance
- ⏳ Test missing secrets for KVM - verify error clear
- ⏳ Document all error scenarios and messages

---

## Next Actions

1. **Immediate**: Create PR with API products
2. **After merge**: Verify products deployed
3. **Then**: Test API endpoint accessibility
4. **Then**: Run error scenario tests
5. **Finally**: Document all findings

---

## Blockers / Issues

None currently. Service account authentication working with fallback mechanism (fixed in PR #51).

---

## Test Results Archive

Results from each test run will be appended here with:
- Date/time
- Branch/PR
- Workflow run ID
- Pass/fail status
- Screenshots/logs
- Issues discovered
