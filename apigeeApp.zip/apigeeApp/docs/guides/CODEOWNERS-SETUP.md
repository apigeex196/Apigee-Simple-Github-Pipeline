# CODEOWNERS Setup Guide

This guide explains how folder-level permissions work in the Applications repository using CODEOWNERS and GitHub branch protection rules.

---

## Overview

**Goal:** Each API Producer team can only modify files in their MAL folder, while the API Enablement team maintains oversight.

**How it works:**
1. **CODEOWNERS file** defines who can approve changes to which folders
2. **Branch protection rules** enforce those approvals before merge
3. **GitHub teams** manage membership automatically

---

## Current Configuration

### Global Access
- **Team:** `@lumen/api-enablement-team`
- **Access:** All files and folders (platform oversight)

### MAL Folder Access
- **Team:** Specific producer team (e.g., `@lumen/producer-team-a`)
- **Access:** Only their MAL folder (e.g., `/mal-SYSGEN123456789/`)

### Critical Files (Platform Only)
- `/.github/` - Workflows and automation
- `*.schema.json` - Validation schemas
- `/template-mappings.json` - Template configuration

---

## Branch Protection Setup

**Repository Settings → Branches → Branch protection rules → main**

### Required Settings

✅ **Require a pull request before merging**
- Require approvals: **1**
- Dismiss stale pull request approvals when new commits are pushed

✅ **Require status checks to pass before merging**
- Require branches to be up to date before merging
- Status checks: Add validation workflows

✅ **Require code owner reviews**
- **THIS IS CRITICAL** - Enforces CODEOWNERS file rules

✅ **Do not allow bypassing the above settings**
- Includes administrators: **Enabled**
- Allow specified actors to bypass: Add `@lumen/api-enablement-team` for emergency overrides

### Result
When a PR touches files in `/mal-SYSGEN123456789/`, GitHub automatically:
1. Requires approval from `@lumen/producer-team-a` (folder owner)
2. Prevents merge until approval is given
3. Notifies the correct team for review

---

## Onboarding New API Producer Team

### Step 1: Create GitHub Team
**GitHub Organization Settings → Teams → New team**

- **Team name:** `producer-team-a` (lowercase, hyphens)
- **Description:** API Producer Team A - Owner of mal-SYSGEN123456789
- **Parent team:** None (or `api-producers` if grouping)
- **Visibility:** Visible (team members can see)

### Step 2: Add Team Members
**Team → Members → Add a member**

- Add producer team's developers
- Grant "Member" role (not "Maintainer")

### Step 3: Update CODEOWNERS
Edit `.github/CODEOWNERS` and add:

```bash
# Producer Team A
/mal-SYSGEN123456789/ @lumen/producer-team-a
```

Commit and push the change.

### Step 4: Verify
Create test PR that modifies `/mal-SYSGEN123456789/orgs/.../proxy.yaml`:

1. PR should show required review from `@lumen/producer-team-a`
2. PR cannot be merged without approval
3. Team members should receive notification

---

## Testing Permissions

### Test Case 1: Producer modifies their own folder
**Expected:** ✅ Team member can approve and merge PR

```bash
# Create test change in producer's MAL folder
echo "test" >> mal-SYSGEN123456789/orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/TEST/proxy.yaml
git checkout -b test-producer-permissions
git add .
git commit -m "test: Producer team permission test"
git push origin test-producer-permissions
# Open PR → Should require @lumen/producer-team-a approval
```

### Test Case 2: Producer tries to modify another team's folder
**Expected:** ❌ Cannot approve PR (requires other team's approval)

```bash
# Try to modify different MAL folder
echo "test" >> mal-SYSGEN987654321/orgs/.../proxy.yaml
# PR will require @lumen/producer-team-b approval (not team-a)
```

### Test Case 3: API Enablement team override
**Expected:** ✅ Can approve any PR (global access)

---

## Common Scenarios

### Scenario: Producer needs help with deployment
**Answer:** API Enablement team can approve PR and assist

### Scenario: Producer accidentally creates PR in wrong MAL folder
**Answer:** PR will require approval from correct team (GitHub blocks merge)

### Scenario: Emergency fix needed across multiple MALs
**Answer:** API Enablement team can bypass with emergency override permissions

### Scenario: Producer team member leaves company
**Answer:** Remove from GitHub team → automatic permission revocation

---

## Troubleshooting

### Issue: PR merge blocked with "Review required"
**Solution:** Ensure correct team member approves PR (check CODEOWNERS for folder ownership)

### Issue: Team mentioned but approval not accepted
**Solution:** Verify team member is in correct GitHub team (not just repository collaborator)

### Issue: CODEOWNERS changes not taking effect
**Solution:** CODEOWNERS file must be in main branch to take effect (merge CODEOWNERS change first)

### Issue: Need to transfer MAL to different team
**Solution:**
1. Update CODEOWNERS: change `@lumen/old-team` to `@lumen/new-team`
2. Update service account ownership (coordinate with CCOE)
3. Notify both teams of transfer

---

## Reference

**CODEOWNERS File:** `.github/CODEOWNERS`
**Branch Protection:** Settings → Branches → main
**GitHub Teams:** Organization → Teams
**Documentation:** https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners

---

## Maintenance

### Monthly Review
- Audit GitHub teams for inactive members
- Verify CODEOWNERS matches current MAL folders
- Check for orphaned MAL folders (no team assigned)

### Quarterly Review
- Review emergency bypass usage
- Update documentation based on lessons learned
- Gather feedback from producer teams
