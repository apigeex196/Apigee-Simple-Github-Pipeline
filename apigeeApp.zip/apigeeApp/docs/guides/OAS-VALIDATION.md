# OAS Validation Guide

This guide explains how to enable and use OpenAPI (OAS) validation in the Applications repository workflows.

## Overview

- OAS linting runs during PR validation and deployment (Dev/Test/Prod).
- Uses Redocly `openapi-cli` to lint OpenAPI 3.x (and Swagger 2.0) specs.
- Proxies can provide a custom OAS file in their MAL folder and reference it from the proxy YAML.

## Proxy YAML Configuration

Add the `oasValidation` block under `spec` in your `ApiProxy` manifest:

```yaml
kind: ApiProxy
apiVersion: apigee.cloud.lumen.com/v1alpha1
metadata:
  name: SYSGEN123456789-YourProxy
spec:
  template: OAuth_Proxy_JWT_Backend_Template
  oasValidation:
    enabled: true
    oasResource: oas://your-openapi.yaml
```

### Fields

- `enabled`: When `true`, workflows lint the OAS and fail on errors.
- `oasResource`: Path to the OAS file relative to the proxy YAML folder. Use the `oas://` prefix.

## File Placement

Place your OAS file alongside the proxy YAML, for example:

```
mal-SYSGEN123456789/
  orgs/gcp-prj-apigee-dev-np-01/envs/apicc-dev/proxies/YourProxy/
    YourProxy.yaml            # ApiProxy manifest
    your-openapi.yaml         # OAS file referenced via oas://your-openapi.yaml
```

## Workflow Behavior

### PR Validation: `.github/workflows/validate-proxy.yml`

- Validates proxy YAML, naming, template mapping, and KVM configuration.
- If `oasValidation.enabled` and `oasResource` are set, lints the OAS file.
- Also scans changed files for standalone OAS documents (by `openapi`/`swagger` keys) and lints them.

### Deployment (Dev/Test/Prod)

- Installs `openapi-cli` on runners.
- Copies the custom OAS file into the temporary build directory.
- Lints the OAS before transforming YAML into Apigee bundle.
- **Injects the OAS file into `apiproxy/resources/oas/` within the bundle** so Apigee's OASValidation policy can resolve the `oas://` reference.
- Falls back to template OAS (e.g., `OAS-Validation-Disabled.yaml`) if no custom OAS is provided.

## Tips

- Keep OAS small and focused; avoid large examples that slow linting.
- Prefer OpenAPI 3.0+; Swagger 2.0 is supported but may have stricter warnings.
- Fix lint errors locally with `npx @redocly/openapi-cli@latest lint your-openapi.yaml`.

## Troubleshooting

- "OAS file not found": Verify the `oasResource` filename and location; ensure the `oas://` prefix.
- "Lint failed": Review errors in the workflow summary; address required fields (info, paths), schemas, and formats.
- Standalone OAS not linted: Ensure the file is part of the PR change set and contains `openapi` or `swagger` at the root.
