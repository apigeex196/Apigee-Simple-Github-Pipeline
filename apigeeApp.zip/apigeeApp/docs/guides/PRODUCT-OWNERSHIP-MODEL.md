# API Product Ownership Model

## Overview

API Products in Apigee X are **organization-level resources** that define which API proxies are packaged together for consumption. This document clarifies where products should be stored across our repository structure and how ownership works.

## Repository Structure

### Products Storage Location

Products should be stored at the **organization level**, outside of any individual MAL folder:

```
enterprise-apigeex-applications/
└── orgs/
    └── gcp-prj-apigee-{env}-{np|}-01/
        └── global/
            └── products/
                ├── SYSGEN123456789-team-a-product.yaml
                ├── SYSGEN987654321-team-b-product.yaml
                └── SYSGEN555555555-cross-team-product.yaml

mal-SYSGEN123456789/
└── orgs/
    └── gcp-prj-apigee-{env}-{np|}-01/
        └── envs/
            └── apicc-dev/
                └── proxies/          # ← MAL-specific proxies only
```

**Key Points:**
- Products live at `orgs/{org}/global/products/` (same as gitops repo)
- MAL folders contain only `envs/` with environment-specific proxy configurations
- This mirrors the GitOps repository structure exactly

### Why Products Are Global

1. **Cross-MAL Products**: A product can reference proxies from multiple application teams (MALs)
2. **Organization Scope**: Products are inherently org-level in Apigee, not environment-specific
3. **Flexible Ownership**: Products can be owned by different teams regardless of proxy ownership
4. **Consistency**: Matches the gitops repository pattern for platform resources

## Product Ownership Patterns

### Pattern 1: Single-Team Product

Most common case - one team owns all proxies in a product:

```yaml
# orgs/gcp-prj-apigee-dev-np-01/global/products/SYSGEN123456789-my-product.yaml
metadata:
  name: SYSGEN123456789-my-product
  owner: team-a@company.com
  sysgen: SYSGEN123456789
spec:
  proxies:
    - name: SYSGEN123456789-api-one      # Team A proxy
    - name: SYSGEN123456789-api-two      # Team A proxy
```

**CODEOWNERS**: Team A owns the product file

### Pattern 2: Cross-Team Product

Product references proxies from multiple MALs:

```yaml
# orgs/gcp-prj-apigee-dev-np-01/global/products/SYSGEN555555555-composite-product.yaml
metadata:
  name: SYSGEN555555555-composite-product
  owner: integration-team@company.com
  sysgen: SYSGEN555555555
spec:
  proxies:
    - name: SYSGEN123456789-customer-api  # Team A proxy
    - name: SYSGEN987654321-order-api     # Team B proxy
    - name: SYSGEN555555555-composite-api # Integration team proxy
```

**CODEOWNERS**: Integration team or shared ownership

### Pattern 3: Platform Product

Platform team manages products for utility/shared proxies:

```yaml
# orgs/gcp-prj-apigee-dev-np-01/global/products/SYSGEN788836350-oauth-product.yaml
metadata:
  name: SYSGEN788836350-oauth-product
  owner: platform-team@company.com
  sysgen: SYSGEN788836350
spec:
  proxies:
    - name: SYSGEN788836350-OAuth_Token_Service_V2
    - name: SYSGEN788836350-JWT_Validation_Service
```

**CODEOWNERS**: Platform/API Enablement team

## CODEOWNERS Configuration

Since products are outside MAL folders, ownership must be explicit:

```
# Global products - default to platform team
/orgs/*/global/products/ @CenturyLink/api-enablement-team

# Team-specific products - override with explicit paths
/orgs/*/global/products/SYSGEN123456789-* @CenturyLink/team-a
/orgs/*/global/products/SYSGEN987654321-* @CenturyLink/team-b
```

**Options:**
1. **Default platform ownership**: All products require platform review
2. **Pattern-based delegation**: Use SYSGEN prefix to route to teams
3. **Explicit per-product**: List each product file individually

## Migration from Current Structure

### Current State
```
mal-SYSGEN788836350/
└── orgs/
    └── gcp-prj-apigee-dev-np-01/
        └── products/              # ← Currently here
            └── SYSGEN788836350-E2E-TEST-PRODUCT.yaml
```

### Target State
```
orgs/
└── gcp-prj-apigee-dev-np-01/
    └── global/
        └── products/              # ← Should be here
            └── SYSGEN788836350-E2E-TEST-PRODUCT.yaml

mal-SYSGEN788836350/
└── orgs/
    └── gcp-prj-apigee-dev-np-01/
        └── envs/                  # ← Only envs remain
            └── apicc-dev/
                └── proxies/
```

### Migration Steps

1. **Create global products directory structure**:
   ```bash
   mkdir -p orgs/gcp-prj-apigee-dev-np-01/global/products
   mkdir -p orgs/gcp-prj-apigee-qa-np-01/global/products
   mkdir -p orgs/gcp-prj-apigee-prod-01/global/products
   ```

2. **Move product files**:
   ```bash
   # For each MAL folder with products
   mv mal-SYSGEN*/orgs/*/products/*.yaml \
      orgs/gcp-prj-apigee-{env}/global/products/
   ```

3. **Update workflows** to use new path pattern:
   ```yaml
   # FROM:
   - 'mal-SYSGEN*/products/*.yaml'

   # TO:
   - 'orgs/*/global/products/*.yaml'
   ```

4. **Update CODEOWNERS**:
   ```
   # Add global products ownership rules
   /orgs/*/global/products/ @CenturyLink/api-enablement-team
   ```

5. **Update documentation** (README.md) to reflect new structure

## Comparison with GitOps Repository

### GitOps Repo (Platform-Managed)
```
enterprise-apigeex-gitops/
└── orgs/
    └── gcp-prj-apigee-dev-np-01/
        ├── global/
        │   └── products/          # Platform/utility products
        └── envs/
            └── apicc-dev/
                ├── apigeeproxies/  # Platform utility proxies
                └── proxies/        # Application proxies (YAML only)
```

### Applications Repo (Team-Managed)
```
enterprise-apigeex-applications/
├── orgs/
│   └── gcp-prj-apigee-dev-np-01/
│       └── global/
│           └── products/          # Application products
└── mal-SYSGEN*/
    └── orgs/
        └── gcp-prj-apigee-dev-np-01/
            └── envs/
                └── apicc-dev/
                    └── proxies/    # Application proxy configs
```

**Key Difference**:
- **GitOps**: Manages actual proxy bundles and shared infrastructure
- **Applications**: Manages proxy deployment configs and team-owned products
- **Both**: Store products at `orgs/{org}/global/products/` for consistency

## Decision Matrix: Which Repo?

| Product Type | Repository | Rationale |
|-------------|-----------|-----------|
| Platform utility product (OAuth, JWT services) | **gitops** | Platform team owns infrastructure |
| Single-team application product | **applications** | Team owns their API surface |
| Cross-team composite product | **applications** | Product ownership separate from proxy ownership |
| Shared service product (spans multiple teams) | **gitops** or **applications** | Depends on governance model |

## Best Practices

1. **Use SYSGEN prefixes consistently**: Products should use the SYSGEN of the owning team/MAL
2. **Document cross-team dependencies**: When products reference multiple MALs, document in product description
3. **Centralize ownership rules**: Use CODEOWNERS to enforce approvals
4. **Align with GitOps structure**: Keep paths identical across repos for developer familiarity
5. **Version product changes**: Follow semantic versioning in product metadata

## Open Questions

- [ ] Should all products live in applications repo, or keep some in gitops?
- [ ] How to handle CODEOWNERS for cross-team products?
- [ ] Migration timeline for existing products?
- [ ] Approval workflow differences between repos?

## Related Documentation

- [GitOps Product Workflow Guide](../../enterprise-apigeex-gitops/docs/PRODUCT-WORKFLOW-GUIDE.md)
- [Applications Repository README](../README.md)
- [CODEOWNERS Setup Guide](CODEOWNERS-SETUP.md)
