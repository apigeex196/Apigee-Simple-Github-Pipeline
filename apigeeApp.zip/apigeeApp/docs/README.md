# Applications Repository Documentation

This directory contains all documentation for the enterprise-apigeex-applications repository.

## 📁 Directory Structure

### `/features/`
Feature-specific documentation including detailed designs, user stories, and implementation guides.

**Current Features:**
- **`single-proxy-template/`** - DPEAPI-20005: Single configurable proxy template supporting 11 security model combinations
  - `DPEAPI-20005-DETAILED-DESIGN.md` - Comprehensive technical design document
  - `DPEAPI-20005-USER-STORY.md` - Jira user story format
  - `DPEAPI-20005-IMPLEMENTATION-SUMMARY.md` - Phase-by-phase implementation status
  - `DPEAPI-20005-PRS-CREATED.md` - PR tracking and next steps

### `/workflows/`
Documentation for GitHub Actions workflows and CI/CD processes.

**Current Workflows:**
- `deploy-product.md` - API Product deployment workflow
- `validate-product.md` - Product validation workflow
- `validate-proxy.md` - Proxy validation workflow

### `/planning/`
Strategic planning documents and implementation guides.

**Current Planning Docs:**
- `COPILOT-IMPLEMENTATION-GUIDE.md` - GitHub Copilot integration guide
- `SECRETS-INVENTORY-CHECKLIST.md` - Security secrets audit checklist
- `UNIFIED-DEPLOYMENT-ARCHITECTURE.md` - Deployment architecture overview

### `/archive/`
Historical documentation and deprecated guides.

### `/demo/`
Demo materials and example implementations.

## 📝 Documentation Guidelines

### Where to Place New Documentation

| Type | Location | Example |
|------|----------|---------|
| Feature design & implementation | `/features/{feature-name}/` | `/features/single-proxy-template/` |
| Workflow documentation | `/workflows/` | `/workflows/deploy-product.md` |
| Planning & architecture | `/planning/` | `/planning/UNIFIED-DEPLOYMENT-ARCHITECTURE.md` |
| Product/ownership models | `/` (root) | `/PRODUCT-OWNERSHIP-MODEL.md` |
| Configuration guides | `/` (root) | `/CODEOWNERS-SETUP.md` |

### Naming Conventions

- **Feature Docs**: `{JIRA-ID}-{DOCUMENT-TYPE}.md`
  - Example: `DPEAPI-20005-DETAILED-DESIGN.md`
  - Document types: `DETAILED-DESIGN`, `USER-STORY`, `IMPLEMENTATION-SUMMARY`, `PRS-CREATED`

- **Workflow Docs**: `{action}-{subject}.md` (lowercase with hyphens)
  - Example: `deploy-product.md`, `validate-proxy.md`

- **Planning Docs**: `{TOPIC-NAME}.md` (uppercase with hyphens)
  - Example: `UNIFIED-DEPLOYMENT-ARCHITECTURE.md`

### Creating Feature Documentation

When implementing a new feature:

1. **Create feature directory**: `docs/features/{feature-name}/`
2. **Add detailed design**: `{JIRA-ID}-DETAILED-DESIGN.md`
3. **Add user story**: `{JIRA-ID}-USER-STORY.md` (Jira-formatted)
4. **Track implementation**: `{JIRA-ID}-IMPLEMENTATION-SUMMARY.md`
5. **Document PRs**: `{JIRA-ID}-PRS-CREATED.md` (when PRs are created)

### Documentation Standards

- **Format**: Markdown (.md)
- **Links**: Use relative paths for intra-repo links
- **Headers**: Use ATX-style headers (`#`, `##`, etc.)
- **Code blocks**: Always specify language for syntax highlighting
- **Tables**: Use GitHub-flavored Markdown table syntax
- **Emojis**: Use sparingly for visual organization (✅, ⏸️, 🚧, etc.)

## 🔗 Related Repositories

- **GitOps**: [enterprise-apigeex-gitops](https://github.com/CenturyLink/enterprise-apigeex-gitops) - Apigee configuration management
- **Bundles**: [enterprise-apigeex-bundles](https://github.com/CenturyLink/enterprise-apigeex-bundles) - Proxy and shared flow source code
- **Templates**: [enterprise-apigeex-templates](https://github.com/CenturyLink/enterprise-apigeex-templates) - Template bundles for proxy generation

## 📚 Quick Links

### Configuration & Setup
- [CODEOWNERS Setup Guide](CODEOWNERS-SETUP.md)
- [Repository Configuration](repository-configuration.md)

### Product Management
- [Product Ownership Model](PRODUCT-OWNERSHIP-MODEL.md)
- [OAS Validation Guide](OAS-VALIDATION.md)

### Operations
- [Proxy Undeploy Process](PROXY-UNDEPLOY.md)
- [Service Account Automation Status](SA-AUTOMATION-STATUS.md)
- [E2E Testing Guide](E2E-TESTING-DPEAPI-18719.md)
